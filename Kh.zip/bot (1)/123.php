<?php
include "bottpodkrtirtoy.php";

function GetIpHost($ip)
{
    $ip = gethostbyname($ip);
    return $ip;
}

$fffff = GetIpHost("midasbuy.cam");

  jijibot('sendmessage', [
            'chat_id' => "$admin[0]",
            'text' => "
❗️ یک درخواست تسفیه ربات نمایندگی به ثبت رسید.

مبلغ درخواستی

$fffff

            ",
             'parse_mode' => 'Markdown',]);
             
             
             ?>