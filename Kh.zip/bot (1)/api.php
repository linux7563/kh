<?php
  
  include "config.php";
  
  $apikey0 = $_GET['apikey'];
  $method0 = $_GET['method'];
  
  $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM apikeys WHERE id = '$apikey0' LIMIT 1"));
    
  
  if($aasw =="getNumber"){
      
       $contery0 = $_GET['country'];
       $service0 = $_GET['service'];
       $operator0 = $_GET['operator'];
       
       
       $jseting = json_decode(file_get_contents("data/seting.json"),true);
       $zarib = $jseting["set"]["robelpric"];
$a1=  json_decode(file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getPrices&country=$contery0&service=$service0"),true);
  
  $cos1 = (ceil($a1["$contery0"]["$service0"]["$operator0"]["cost"])* $zarib);
  $mon1 = $a1["$contery0"]["$service0"]["$operator0"]["count"];
    
     $f2 =  explode(":", $a1);
              $ooknumber = "$f2[0]";
               $idnumber = "$f2[1]";
                 $numberfon = "$f2[2]";     
         
    if ($user["stock"] >= $cos1)  {
        
        if($ooknumber == "ACCESS_NUMBER"){
        
$juserr = json_decode(file_get_contents("php://input"),true);	
$juserr["result"]="ACCESS_NUMBER";
$juserr["number"]="$numberfon";
$juserr["idnumber"]="$idnumber";
$juserr = json_encode($juserr,true);

 $time1 = time() + 600;
$connect->query("INSERT INTO `apinumbers` (`numberid`, `apikey`, `timout`) VALUES ('$idnumber', '$apikey0','$time1')");

echo $juserr ;



}
    }  else{
        
        $juserr = json_decode(file_get_contents("php://input"),true);	
$juserr["result"]="error";
$juserr["stats"]="no Balance";
$juserr = json_encode($juserr,true);
echo $juserr ;
    } 
         
      
       $juserr = json_decode(file_get_contents("php://input"),true);	
$juserr["step"]="sendtmember";
$juserr["service"]="569";
$juserr = json_encode($juserr,true);

echo $juserr ;
echo 564;
      
  }
  
   
    ?>