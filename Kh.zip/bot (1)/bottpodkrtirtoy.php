<?php

error_reporting(0);

ob_start();



include "jdf.php";

define('API_KEY', '000'); // توکن
//-----------------------------------------------------------------------------------------
//فانکشن jijibot :

function jijibot($method, $datas = []) {
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}

function getramz(){
        $length=6;
        $characters='0123456789abcdefghijklmnopqrstuvwxyz';
        $string='';
            for($p=0;$p<$length;$p++){
            $string.=$characters[mt_rand(0,strlen($characters))];
            }
            return $string;
        } 

//-----------------------------------------------------------------------------------------
//متغیر ها :
$admin = array("000", "000", "000"); // ایدی ادمین ها را ماننده این الگورتیم بگذارید ادمین اصلی ایدی اول است
$usernamebot = "000"; // یوزرنیم ربات

$channelby = "000"; // یوزرنیم کانال گزارش خرید کاربران
$usernamepanelgetsms = "000"; // یوزرنیم پنل get sms را وارد کنید
$api_key = "000"; // توکن پنل get sms را وارد کنید
$web = "000"; // ادرس ربات شماره مجازی
$channelbc = "000"; // کانال نقل و انتقالات
$usersharg = "000";// یوزرنیم سایت آینکس
$passsharg = "000"; // پسورد سایت
$channelff = "000"; // چنل ادمین
$apimember="000"; // Api key سناتور عضو
//-----------------------------------------------------------------------------------------------
// database 
// اطلاعات دیتا بیس را وارد کنید
$servername = "localhost";
$username = "000"; // یوزر دیتابیس
$password = "000"; // پسورد دیتابیس
$dbname = "000"; // نام دیتابیس
$connect = mysqli_connect($servername, $username, $password, $dbname);
//----------------------------------------------------------------------------

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$tc = $message->chat->type;
$textmassage = $message->text;
$messageid = $update->callback_query->message->message_id;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->from->id;
$firstname = $update->callback_query->from->first_name;
$data = $update->callback_query->data;

$membercall = $update->callback_query->id;
$re_id = $update->message->reply_to_message->forward_from->id;
//=====================================================================================
// get 
$user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$from_id' LIMIT 1"));
$usert = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$fromid' LIMIT 1"));
$blaklist = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM blaklist WHERE id = '$from_id' LIMIT 1"));
$adminsql = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE id = '$from_id' LIMIT 1"));
$usercd = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM coduser WHERE id = '$from_id' LIMIT 1"));
$userservict = $usert["service"];
//==============================================================================
$jseting = json_decode(file_get_contents("data/seting.json"),true);
$jbuy = json_decode(file_get_contents("data/listbuy.json"),true);
//============================================================================
$activesell = $jseting["set"]["active"];
$porsant = $jseting["set"]["porsant"];
$oneramzbot = $jseting["set"]["oneramzbot"];
$oneramzbottala = $jseting["set"]["oneramzbottala"];
$chh = $jseting["set"]["channel"];
$channel = "$chh"; // یوزرنیم کانال
//=======================================
$tr_num = jdate('en');;
$dat_mah = jdate('F'); // اسم ماه
$dat_day = jdate('d'); // روز برج
$dat_haf = jdate('l'); // روز هفته
$dat_mahn = jdate('m'); // شماره ماه
$dat_min = jdate('i'); // دقیقه
$dat_s = jdate('s'); // ثانیه 
$dat_yer = jdate('Y'); // سال
$dat_h = jdate('H'); // ساعت
$dat_now = "$dat_yer/$dat_mahn/$dat_day" ;
$time_now = "$dat_h:$dat_min";
$dat_fa = "$dat_haf $dat_day $dat_mah  $dat_yer" ;
//===================================
$stock = $user["stock"];

//==================================فانکشن های پنل

function getbalance() {
 $api_key = "000";
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getBalance");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
$curl_exec = curl_exec($ch);
curl_close($ch);
return $curl_exec;
}

function getnumber($service , $country , $operator) {
 $api_key = "000";
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getNumber&service=$service&operator=$operator&country=$country");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
$curl_exec = curl_exec($ch);
curl_close($ch);
return $curl_exec;
}
function setstats($orderid) {
 $api_key = "000";
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "http://sms-activate.api.5sim.net/stubs/handler_api.php?api_key=$api_key&action=setStatus&status=-1&id=$orderid");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
$curl_exec = curl_exec($ch);
curl_close($ch);
return $curl_exec;
}
function getstats($orderid) {
 $api_key = "000";
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "http://sms-activate.api.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getStatus&id=$orderid");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
$curl_exec = curl_exec($ch);
curl_close($ch);
return $curl_exec;
}

$api_key = "000";

//===================================
include "sharg.php";
include "member.php";
//====================================کیبرد
$keybord = json_encode([
            'keyboard' => [
                [
                    ['text' => "📲 خرید شماره مجازی"]
                ],
                 [
                   ['text' => "✔️ خدمات سیمکارت اعتباری"], ['text' => "✔️ خدمات تلگرام"]
                ],
                
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "💸 شارژ حساب"]
                ]
                ,
                [
                     ['text' => "🤖 ربات شماره مجازی شما [ربات نمایندگی]"] 
                    ],
                     [
                   ['text' => "👥 زیرمجموعه گیری"]
                    ],
                     [
                    ['text' => "🛍 خرید های من"], ['text' => "👤 اطلاعات حساب"]
                    ],
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
            'resize_keyboard' => true
        ]);
//=================================
if(strpos($textmassage,"'") !== false or strpos($textmassage,'"') !== false or strpos($textmassage,"}") !== false or strpos($textmassage,"{") !== false or strpos($textmassage,")'") !== false or strpos($textmassage,"(") !== false or  strpos($textmassage,'$') !== false){ 


$connect->query("UPDATE user SET step = 'blok' WHERE id = '$from_id' LIMIT 1");
  jijibot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد دادن به ربات ممنوعه شما را به تیم مدیریت ربات گزارش کردم 🔒 حساب کاربری شما نیز موقتا مسدود شد 🖊",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]); 
  jijibot('sendMessage',[
 'chat_id'=>"$admin[0]",
 'text'=>"
- - - - - - - - — - — - - - - - -  - - - - - - - —- ——- - - - — - - - - - — - - - - - -  -
🚨یک نفر به ربات کد داد و موقتا حساب کاربریش مسدود شد!

🔫[👤پروفایلش](tg://user?id=$from_id)👉🏿
👉🏿 @$username 👈🏿



👈 کدی  که فرستاد :
🔻🔻🔻🔻🔻
🔴{ $textmassage } 🔴
🔺🔺🔺🔺🔺

- - - - - - - - — - — - - - - - -  - - - - - - - —- ——- - - - — - - - - - — - - - - - -  -
",
 'parse_mode'=>"MarkDown",
  ]); 
 }
else {
if($activesell == '1' or $chat_id == "$admin[0]"){
    if ($user["step"] != "blok" or  $chat_id == "$admin[0]"){
        
         $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
         $tch2 = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$fromid"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator' or $tch2 == 'member' or $tch2 == 'creator' or $tch2 == 'administrator') {
          if (($user["step"] !="pinn" or $usert["step"] !="pinn") or $data == "join"){
           if ($user["step"] !="daryaftcod" or $textmassage == "❌ لغو شماره" or $textmassage == "⛔️ اعلام مسدودی شماره"){
        

if ($textmassage == "/start" or $textmassage =="خروج از پنل") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "😄 سلام $first_name
	
🌟 به ربات شماره مجازی (رایگان) خوش آمدید. 

این ربات بصورت اتوماتیک است و میتوانید فقط در ظرف چند ثانیه شماره مجازی و کد اختصاصی شمارهٔ مجازی خودتون رو دریافت کنید.🌹 

👥 با معرفی ربات به دوستان خود از بخش زیر مجموعه گیری 20 درصد از هر فروش شماره به موجودی شما اضافه می گردد .

🔻 از دکمه های زیر استفاده کنید",
        'reply_markup' => $keybord
    ]);
    if ($user["id"] != true) {
        $connect->query("INSERT INTO `user` (`id`, `step`, `stock`, `member`, `listby`, `inviter`, `service`, `country`, `getfile`, `price`, `namecontry`, `numberby`, `panel` , `numberid`) VALUES ('$from_id', 'none', '0', '0', '', '0', '', '', '', '', '', '0','', '0')");
    }
   
    
} elseif (strpos($textmassage, '/start ') !== false) {
    $start = str_replace("/start ", "", $textmassage);
    if ($user["id"] == true) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "😄 سلام $first_name
	
🌟 به ربات شماره مجازی (رایگان) خوش آمدید. 

این ربات بصورت اتوماتیک است و میتوانید فقط در ظرف چند ثانیه شماره مجازی و کد اختصاصی شمارهٔ مجازی خودتون رو دریافت کنید.🌹 

👥 با معرفی ربات به دوستان خود از بخش زیر مجموعه گیری 20 درصد از هر فروش شماره به موجودی شما اضافه می گردد .

🔻 از دکمه های زیر استفاده کنید",
            'reply_markup' => $keybord
        ]);
      
    } else {
        $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$start' LIMIT 1"));
        $plusmember = $user["member"] + 1;
        
        $stoockk = $user["stock"];

        
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "😄 سلام $first_name
	
🌟 به ربات شماره مجازی (رایگان) خوش آمدید. 

این ربات بصورت اتوماتیک است و میتوانید فقط در ظرف چند ثانیه شماره مجازی و کد اختصاصی شمارهٔ مجازی خودتون رو دریافت کنید.🌹 

👥 با معرفی ربات به دوستان خود از بخش زیر مجموعه گیری 20 درصد از هر فروش شماره به موجودی شما اضافه می گردد .

🔻 از دکمه های زیر استفاده کنید",
            'reply_markup' => $keybord
        ]);
        $name = str_replace(["`", "*", "_", "[", "]"], ["", "", "", "", ""], $first_name);
        jijibot('sendmessage', [
            'chat_id' => $start,
            'text' => "
🌟 کاربر [$name](tg://user?id=$from_id) با استفاده از لینک دعوت شما وارد ربات شده.

❄️ جهت جلوگیری از تقلب و اطمینان از واقعی بودن کاربر دعوت شده توسط شما ، پس از عوضیت کاربر در کانال ربات مبلغ $porsant تومان پورسانت زیرمجموعه گیری به شما داده میشود.

👥 تعداد زیر مجموعه ها : $plusmember

📋 در صورتی که زیر مجموعه شما از ربات خرید کند شما مطلع خواهید شد
💰یک دهم (10 درصد) از هر خرید زیر مجموعه به موجودی شما اضافه می گردد",
            'parse_mode' => 'Markdown',
        ]);
          jijibot('sendmessage', [
            'chat_id' => "@$channelbc" ,
            'text' => "
🌟 کاربر [$name](tg://user?id=$from_id) با استفاده از لینک دعوت کاربر  [$start](tg://user?id=$start) وارد ربات شده  است.

⚠️کاربر هنوز عضو کانال نشده است !!
	
👥 تعداد زیر مجموعه ها : $plusmember

 
            ",
            'parse_mode' => 'Markdown',
        ]);
        $connect->query("UPDATE user SET member = '$plusmember'WHERE id = '$start' LIMIT 1");
    }
    $connect->query("INSERT INTO `user` (`id`, `step`, `stock`, `member`, `listby`, `inviter`, `service`, `country`, `getfile`, `price`, `namecontry`,  `numberby`, `panel`, `numberid`) VALUES ('$from_id', 'pinn', '0', '0', '', '$start', '', '', '', '', '', '0', '', '0')");
   
    
} elseif ($textmassage == "🔙 برگشت" or $textmassage == "خیر منصرف شدم 👎") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "🌟 به منوی اصلی ربات برگشتیم 
	
🎈 از دکمه های زیر میتونی استفاده کنی",
        'reply_markup' => $keybord
    ]);
    $ddd = $user["getfile"];
      file_get_contents("https://api.numberland.ir/v2.php/?apikey=[API_CODE]&method=cancelnumber&id=$ddd");
    $connect->query("UPDATE user SET step = 'none' , service = '', panel = '', getfile = '' WHERE id = '$from_id' LIMIT 1");
} 



//==========================================================
elseif ($textmassage == "📲 خرید شماره مجازی") { 
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🔘 سرویس | اپلکیشن مورد نظر خود را انتخاب کنید !",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "💠 اینستاگرام"], ['text' => "💠 تلگرام"], ['text' => "💠 واتساپ"]
                    ],
                     [
                        ['text' => "💠 وی چت"], ['text' => "💠 وایبر"], ['text' => "💠 توییتر"]
                    ],
                     [
                        ['text' => "💠 لاین"], ['text' => "💠 ایمو"], ['text' => "💠 فیسبوک"]
                    ],
                     [
                        ['text' => "💠 همراه اول"], ['text' => "💠 دیوار"], ['text' => "💠 ایرانسل"]
                    ],
                     [
                        ['text' => "💠 گوگل"], ['text' => "💠 یاهو"], ['text' => "💠 دیسکورد"]
                    ],
                     [
                        ['text' => "💠 آمازون"], ['text' => "💠 علی بابا"], ['text' => "💠 علی پی"]
                    ],
                     [
                        ['text' => "💠 بیگو لایو"], ['text' => "💠 لینکدین"], ['text' => "💠 ماکروسافت"]
                    ],
                     [
                        ['text' => "💠 پی پال"], ['text' => "💠 اسنپ چت"], ['text' => "💠 تیک تاک"]
                    ],
                    [
                        ['text' => "💠 دیجی کالا"], ['text' => "💠  پابجی"], ['text' => "💠  بلاکچین"]
                    ],
                     [
                        ['text' => "💠  تانگو"], ['text' => ""], ['text' => ""]
                    ],
                     [
                        ['text' => ""], ['text' => ""], ['text' => ""]
                    ],
                     [
                        ['text' => "💠 1688"], ['text' => "💠 1xbet"], ['text' => "💠 23red"]
                    ],
                     [
                        ['text' => "💠 ace2three"], ['text' => "💠 adidas"], ['text' => "💠 airbnb"]
                    ],
                     [
                        ['text' => "💠 airtel"], ['text' => "💠 akelni"], ['text' => "💠 aliexpress"]
                    ],
                     [
                        ['text' => "💠 amasia"], ['text' => "💠 aol"], ['text' => "💠 avito"]
                    ],
                     [
                        ['text' => "💠 azino"], ['text' => "💠 b4ucabs"], ['text' => "💠 bigcash"]
                    ],
                     [
                        ['text' => "💠 bitclout"], ['text' => "💠 bittube"], ['text' => "💠 blablacar"]
                    ],
                     [
                        ['text' => "💠 blizzard"], ['text' => "💠 pyaterochka"], ['text' => "💠 burgerking"]
                    ],
                     [
                        ['text' => "💠 careem"], ['text' => "💠 cdkeys"], ['text' => "💠 cekkazan"]
                    ],
                     [
                        ['text' => "💠 citymobil"], ['text' => "💠 clickentregas"], ['text' => "💠 coinbase"]
                    ],
                    
                     [
                        ['text' => "💠 craigslist"], ['text' => "💠 deliveroo"], ['text' => "💠 delivery"]
                    ],
                     [
                        ['text' => "💠 dent"], ['text' => "💠 didi"], ['text' => "💠 dixy"]
                    ],
                     [
                        ['text' => "💠 dodopizza"], ['text' => "💠 domdara"], ['text' => "💠 dostavista"]
                    ],
                     [
                        ['text' => "💠 douyu"], ['text' => "💠 drom"], ['text' => "💠 drugvokrug"]
                    ],
                     [
                        ['text' => "💠 dukascopy"], ['text' => "💠 ebay"], ['text' => "💠 edgeless"]
                    ],
                     [
                        ['text' => "💠 electroneum"], ['text' => "💠 ezway"], ['text' => "💠 fiverr"]
                    ],
                     [
                        ['text' => "💠 flipkart"], ['text' => "💠 foodpanda"], ['text' => "💠 foody"]
                    ],
                     [
                        ['text' => "💠 forwarding"], ['text' => "💠 galaxy"], ['text' => "💠 gameflip"]
                    ],
                     [
                        ['text' => "💠 gcash"], ['text' => "💠 get"], ['text' => "💠 getir"]
                    ],
                    [
                        ['text' => "💠 gett"], ['text' => "💠 globus"], ['text' => "💠 glovo"]
                    ],
                     [
                        ['text' => "💠 grabtaxi"], ['text' => "💠 green"], ['text' => "💠 grindr"]
                    ],
                     [
                        ['text' => "💠 haraj"], ['text' => "💠 hezzl"], ['text' => "💠 hopi"]
                    ],
                     [
                        ['text' => "💠 hqtrivia"], ['text' => "💠 icard"], ['text' => "💠 icq"]
                    ],
                     [
                        ['text' => "💠 ininal"], ['text' => "💠 iost"], ['text' => "💠 jd"]
                    ],
                     [
                        ['text' => "💠 justdating"], ['text' => "💠 kakaotalk"], ['text' => "💠 keybase"]
                    ],
                     [
                        ['text' => "💠 komandacard"], ['text' => "💠 kotak811"], ['text' => "💠 kufarby"]
                    ],
                     [
                        ['text' => "💠 kwai"], ['text' => "💠 lazada"], ['text' => "💠 lbry"]
                    ],
                     [
                        ['text' => "💠 lenta"], ['text' => "💠 lianxin"], ['text' => "💠 livescore"]
                    ],
                    [
                        ['text' => "💠 magnit"], ['text' => "💠 magnolia"], ['text' => "💠 mailru"]
                    ],
                     [
                        ['text' => "💠 mamba"], ['text' => "💠 mcdonalds"], ['text' => "💠 meetme"]
                    ],
                     [
                        ['text' => "💠 mega"], ['text' => "💠 mercado"], ['text' => "💠 michat"]
                    ],
                     [
                        ['text' => "💠 miratorg"], ['text' => "💠 mtscashback"], ['text' => "💠 nana"]
                    ],
                     [
                        ['text' => "💠 naver"], ['text' => "💠 netflix"], ['text' => "💠 nhseven"]
                    ],
                     [
                        ['text' => "💠 nifty"], ['text' => "💠 nike"], ['text' => "💠 nimses"]
                    ],
                     [
                        ['text' => "💠 nttgame"], ['text' => "💠 odnoklassniki"], ['text' => "💠 offerup"]
                    ],
                     [
                        ['text' => "💠 okcupid"], ['text' => "💠 okey"], ['text' => "💠 olx"]
                    ],
                    [
                        ['text' => "💠 openpoint"], ['text' => "💠 oraclecloud"], ['text' => "💠 ozon"]
                    ],
                     [
                        ['text' => "💠 pairs"], ['text' => "💠 papara"], ['text' => "💠 paycell"]
                    ],
                     [
                        ['text' => "💠 paymaya"], ['text' => "💠 paysend"], ['text' => "💠 peoplecom"]
                    ],
                     [
                        ['text' => "💠 perekrestok"], ['text' => "💠 pof"], ['text' => "💠 pokec"]
                    ],
                     [
                        ['text' => "💠 pokermaster"], ['text' => "💠 potato"], ['text' => "💠 proton"]
                    ],
                     [
                        ['text' => "💠 protp"], ['text' => "💠 qiwiwallet"], ['text' => "💠 quioo"]
                    ],
                     [
                        ['text' => "💠 quipp"], ['text' => "💠 reuse"], ['text' => "💠 ripkord"]
                    ],
                     [
                        ['text' => "💠 samokat"], ['text' => "💠 seosprint"], ['text' => "💠 sheerid"]
                    ],
                    [
                        ['text' => "💠 shopee"], ['text' => "💠 signal"], ['text' => "💠 sikayetvar"]
                    ],
                     [
                        ['text' => "💠 skout"], ['text' => "💠 steam"], ['text' => "💠 swvl"]
                    ],
                     [
                        ['text' => "💠 taksheel"], ['text' => "💠 zomato"], ['text' => "💠 tantan"]
                    ],
                     [
                        ['text' => "💠 taobao"], ['text' => "💠 tencentqq"], ['text' => "💠 tinder"]
                    ],
                     [
                        ['text' => "💠 tosla"], ['text' => "💠 totalcoin"], ['text' => "💠 touchance"]
                    ],
                    [
                        ['text' => "💠 trendyol"], ['text' => "💠 truecaller"], ['text' => "💠 uber"]
                    ],
                     [
                        ['text' => "💠 uploaded"], ['text' => "💠 vernyi"], ['text' => "💠 vkontakte"]
                    ],
                     [
                        ['text' => "💠 voopee"], ['text' => "💠 weibo"], ['text' => "💠 weku"]
                    ],
                     [
                        ['text' => "💠 winston"], ['text' => "💠 wish"], ['text' => "💠 yalla"]
                    ],
                     [
                        ['text' => "💠 yandex"], ['text' => "💠 yemeksepeti"], ['text' => "💠 youdo"]
                    ],
                     [
                        ['text' => "💠 youla"], ['text' => "💠 zalo"], ['text' => "💠 zoho"]
                    ],
                     [
                        ['text' => ""]
                    ],
                   
                     [
                        ['text' => "🌐 دیگر سرویس ها"]
                    ],
                    [
                        ['text' => "🔙 برگشت"], ['text' => "🚦 راهنما"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]); 
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
}

elseif (in_array($textmassage, array("💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"))) {
    $str = str_replace(["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], ["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], $textmassage);
    
    
   $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
  
  $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
  
   foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("data/prics2/$vvv.json"),true);
        $sssw = $jsettting["$str"]["amount"] * 550;
         $ssswm = $jsettting["$str"]["count"];
         $qq = $countryss2[$key];
        if($sssw =="---" or $sssw ==""){ $fff= "100000";  }
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌"){   
        
       
$result[]=$vvv;
$result2[]=$sssw;
$result3[]=$sssw;
$result5[]=$qq;
}
       
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
  $dffdff =  count($result);
 for($z = 0;$z <= $dffdff;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];



$topname = $topname."$stat2"."\n";   
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);

 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
  $stat29 = $nname[28];
  $stat30 = $nname[29];
  $stat31 = $nname[30];
  $stat32 = $nname[31];
  $stat33 = $nname[32];
  $stat34 = $nname[33];
  $stat35 = $nname[34];
  $stat36 = $nname[35];
  $stat37 = $nname[36];
  $stat38 = $nname[37];
  $stat39 = $nname[38];
  $stat40 = $nname[39];
  $stat41 = $nname[40];
  $stat42 = $nname[41];
  $stat43 = $nname[42];
  $stat44 = $nname[43];
  $stat45 = $nname[44];
  $stat46 = $nname[45];
  $stat47 = $nname[46];
  $stat48 = $nname[47];
  $stat49 = $nname[48];
  $stat50 = $nname[49];
  $stat51 = $nname[50];
  $stat52 = $nname[51];
  $stat53 = $nname[52];
  $stat54 = $nname[53];
  $stat55 = $nname[54];
  $stat56 = $nname[55];
  $stat57 = $nname[56];
  $stat58 = $nname[57];
  $stat59 = $nname[58];
  $stat60 = $nname[59];
  $stat61 = $nname[60];
  $stat62 = $nname[61];
  $stat63 = $nname[62];
  $stat64 = $nname[63];
  $stat65 = $nname[64];
  $stat66 = $nname[65];
  $stat67 = $nname[66];
  $stat68 = $nname[67];
  $stat69 = $nname[68];
  $stat70 = $nname[69];
  $stat71 = $nname[70];
  $stat72 = $nname[71];
  $stat73 = $nname[72];
  $stat74 = $nname[73];
  $stat75 = $nname[74];
  $stat76 = $nname[75];
  $stat77 = $nname[76];
  $stat78 = $nname[77];
  $stat79 = $nname[78];
  $stat80 = $nname[79];
  $stat81 = $nname[80];
  $stat82 = $nname[81];
  $stat83 = $nname[82];
  $stat84 = $nname[83];
  $stat85 = $nname[84];
  $stat86 = $nname[85];
  $stat87 = $nname[86];
  $stat88 = $nname[87];
  $stat89 = $nname[88];
  $stat90 = $nname[89];
  $stat91 = $nname[90];
  $stat92 = $nname[91];
  $stat93 = $nname[92];
  $stat94 = $nname[93];
  $stat95 = $nname[94];
  $stat96 = $nname[95];
  $stat97 = $nname[96];
  $stat98 = $nname[97];
  $stat99 = $nname[98];
  $stat100 = $nname[99];
  $stat101 = $nname[100];
  $stat102 = $nname[101];
  $stat103 = $nname[102];
  $stat104 = $nname[103];
  $stat105 = $nname[104];
  $stat106 = $nname[105];
  $stat107 = $nname[106];
  $stat108 = $nname[107];
  $stat109 = $nname[108];
  $stat110 = $nname[109];
  $stat111 = $nname[110];
  $stat112 = $nname[111];
  $stat113 = $nname[112];
  $stat114 = $nname[113];
  $stat115 = $nname[114];
  $stat116 = $nname[115];
  $stat117 = $nname[116];
  $stat118 = $nname[117];
  $stat119 = $nname[118];
  $stat120 = $nname[119];
  $stat121 = $nname[120];
  $stat122 = $nname[121];
  $stat123 = $nname[122];
  $stat124 = $nname[123];
  $stat125 = $nname[124];
  $stat126 = $nname[125];
  $stat127 = $nname[126];
  $stat128 = $nname[127];
  $stat129 = $nname[128];
  $stat130 = $nname[129];
  $stat131 = $nname[130];
  $stat132 = $nname[131];
  $stat133 = $nname[132];
  $stat134 = $nname[133];
  $stat135 = $nname[134];
  $stat136 = $nname[135];
  $stat137 = $nname[136];
  $stat138 = $nname[137];
  $stat139 = $nname[138];
  $stat140 = $nname[139];
  $stat141 = $nname[140];
  $stat142 = $nname[141];
  $stat143 = $nname[142];
  $stat144 = $nname[143];
  $stat145 = $nname[144];
  $stat146 = $nname[145];
  $stat147 = $nname[146];
  $stat148 = $nname[147];
  $stat149 = $nname[148];
  $stat150 = $nname[149];
  $stat151 = $nname[150];
  $stat152 = $nname[151];
  $stat153 = $nname[152];
  $stat154 = $nname[153];
  $stat155 = $nname[154];
  $stat156 = $nname[155];
  $stat157 = $nname[156];
  $stat158 = $nname[157];
  $stat159 = $nname[158];
  $stat160 = $nname[159];
  $stat161 = $nname[160];
  $stat162 = $nname[161];
  $stat163 = $nname[162];
  $stat164 = $nname[163];
  $stat165 = $nname[164];
  $stat166 = $nname[165];
  $stat167 = $nname[166];
  $stat168 = $nname[167];
  $stat169 = $nname[168];
  $stat170 = $nname[169];
  $stat171 = $nname[170];
  $stat172 = $nname[171];
  $stat173 = $nname[172];
  $stat174 = $nname[173];
  $stat175 = $nname[174];
  $stat176 = $nname[175];
  $stat177 = $nname[176];
  $stat178 = $nname[177];
  $stat179 = $nname[178];
  $stat180 = $nname[179];
  $stat181 = $nname[180];
  $stat182 = $nname[181];
  $stat183 = $nname[182];
  $stat184 = $nname[183];
  $stat185 = $nname[184];
  $stat186 = $nname[185];
  
  
 
   $ttt = $jseting["set"]["up"]["time"];
  $ddd = $jseting["set"]["up"]["data"];
 
    
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "🌍 کشور مورد نظر را انتخاب کنید !

✅ مجموعا $dffdff کشور دارای شماره برای این سرویس یافت شد. (موجودی ها هر 10 دقیقه یکبار بروز میشوند)

♻️ آخرین بروزرسانی :
$ttt
$ddd

❗️ فقط کشورهای دارای موجودی شماره برای سرویس مورد نظر شما برای شما نمایش داده میشوند.
❗️ کشور ها زیر به ترتیب قیمت از ارزانترین به گرانترین برای شما مرتب شده اند.👇👇
",
        'reply_markup' => json_encode([
            'keyboard' => [
                 [
                    ['text' => "$stat1"], ['text' => "$stat2"], ['text' => "$stat3"]
                ],
                   [
                    ['text' => "$stat4"], ['text' => "$stat5"], ['text' => "$stat6"]
                ],
                 [
                    ['text' => "$stat7"], ['text' => "$stat8"], ['text' => "$stat9"]
                ],
                   [
                    ['text' => "$stat10"], ['text' => "$stat11"], ['text' => "$stat12"]
                ],
                 [
                    ['text' => "$stat13"], ['text' => "$stat14"], ['text' => "$stat15"]
                ],
                   [
                    ['text' => "$stat16"], ['text' => "$stat17"], ['text' => "$stat18"]
                ],
                 [
                    ['text' => "$stat19"], ['text' => "$stat20"], ['text' => "$stat21"]
                ],
                   [
                    ['text' => "$stat22"], ['text' => "$stat23"], ['text' => "$stat24"]
                ],
                 [
                    ['text' => "$stat25"], ['text' => "$stat26"], ['text' => "$stat27"]
                ],
                   [
                    ['text' => "$stat28"], ['text' => "$stat29"], ['text' => "$stat30"]
                ],
                 [
                    ['text' => "$stat31"], ['text' => "$stat32"], ['text' => "$stat33"]
                ],
                   [
                    ['text' => "$stat34"], ['text' => "$stat35"], ['text' => "$stat36"]
                ],
                 [
                    ['text' => "$stat37"], ['text' => "$stat38"], ['text' => "$stat39"]
                ],
                   [
                    ['text' => "$stat40"], ['text' => "$stat41"], ['text' => "$stat42"]
                ],
                 [
                    ['text' => "$stat43"], ['text' => "$stat44"], ['text' => "$stat45"]
                ],
                   [
                    ['text' => "$stat46"], ['text' => "$stat47"], ['text' => "$stat48"]
                ],
                 [
                    ['text' => "$stat49"], ['text' => "$stat50"], ['text' => "$stat51"]
                ],
                   [
                    ['text' => "$stat52"], ['text' => "$stat53"], ['text' => "$stat54"]
                ],
                 [
                    ['text' => "$stat55"], ['text' => "$stat56"], ['text' => "$stat57"]
                ],
                 [
                    ['text' => "$stat58"], ['text' => "$stat59"], ['text' => "$stat60"]
                ],
                [
                    ['text' => "$stat61"], ['text' => "$stat62"], ['text' => "$stat63"]
                ],
                [
                    ['text' => "$stat64"], ['text' => "$stat65"], ['text' => "$stat66"]
                ],
                [
                    ['text' => "$stat67"], ['text' => "$stat68"], ['text' => "$stat69"]
                ],
                [
                    ['text' => "$stat70"], ['text' => "$stat71"], ['text' => "$stat72"]
                ],
                [
                    ['text' => "$stat73"], ['text' => "$stat74"], ['text' => "$stat75"]
                ],
                 [
                    ['text' => "$stat76"], ['text' => "$stat77"], ['text' => "$stat78"]
                ],
                 [
                    ['text' => "$stat79"], ['text' => "$stat80"], ['text' => "$stat81"]
                ],
                [
                    ['text' => "$stat82"], ['text' => "$stat83"], ['text' => "$stat84"]
                ],
                [
                    ['text' => "$stat85"], ['text' => "$stat86"], ['text' => "$stat87"]
                ],
                [
                    ['text' => "$stat88"], ['text' => "$stat89"], ['text' => "$stat90"]
                ],
                [
                    ['text' => "$stat91"], ['text' => "$stat92"], ['text' => "$stat93"]
                ],
                [
                    ['text' => "$stat94"], ['text' => "$stat95"], ['text' => "$stat96"]
                ],
                 [
                    ['text' => "$stat97"], ['text' => "$stat98"], ['text' => "$stat99"]
                ],
                 [
                    ['text' => "$stat100"], ['text' => "$stat101"], ['text' => "$stat102"]
                ],
                [
                    ['text' => "$stat103"], ['text' => "$stat104"], ['text' => "$stat105"]
                ],
                [
                    ['text' => "$stat106"], ['text' => "$stat107"], ['text' => "$stat108"]
                ],
                [
                    ['text' => "$stat109"], ['text' => "$stat110"], ['text' => "$stat111"]
                ],
                [
                    ['text' => "$stat112"], ['text' => "$stat113"], ['text' => "$stat114"]
                ],
                [
                    ['text' => "$stat115"], ['text' => "$stat116"], ['text' => "$stat117"]
                ],
                 [
                    ['text' => "$stat118"], ['text' => "$stat119"], ['text' => "$stat120"]
                ],
                 [
                    ['text' => "$stat121"], ['text' => "$stat122"], ['text' => "$stat123"]
                ],
                [
                    ['text' => "$stat124"], ['text' => "$stat125"], ['text' => "$stat126"]
                ],
                [
                    ['text' => "$stat127"], ['text' => "$stat128"], ['text' => "$stat129"]
                ],
                [
                    ['text' => "$stat130"], ['text' => "$stat131"], ['text' => "$stat132"]
                ],
                [
                    ['text' => "$stat133"], ['text' => "$stat134"], ['text' => "$stat135"]
                ],
                [
                    ['text' => "$stat136"], ['text' => "$stat137"], ['text' => "$stat138"]
                ],
                 [
                    ['text' => "$stat139"], ['text' => "$stat140"], ['text' => "$stat141"]
                ],
                 [
                    ['text' => "$stat142"], ['text' => "$stat143"], ['text' => "$stat144"]
                ],
                [
                    ['text' => "$stat145"], ['text' => "$stat146"], ['text' => "$stat147"]
                ],
                [
                    ['text' => "$stat148"], ['text' => "$stat149"], ['text' => "$stat150"]
                ],
                [
                    ['text' => "$stat151"], ['text' => "$stat152"], ['text' => "$stat153"]
                ],
                [
                    ['text' => "$stat154"], ['text' => "$stat155"], ['text' => "$stat156"]
                ],
                [
                    ['text' => "$stat157"], ['text' => "$stat158"], ['text' => "$stat159"]
                ],
                 [
                    ['text' => "$stat160"], ['text' => "$stat161"], ['text' => "$stat162"]
                ],
                 [
                    ['text' => "$stat163"], ['text' => "$stat164"], ['text' => "$stat165"]
                ],
                [
                    ['text' => "$stat166"], ['text' => "$stat167"], ['text' => "$stat168"]
                ],
                [
                    ['text' => "$stat169"], ['text' => "$stat170"], ['text' => "$stat171"]
                ],
                [
                    ['text' => "$stat172"], ['text' => "$stat173"], ['text' => "$stat174"]
                ],
                [
                    ['text' => "$stat175"], ['text' => "$stat176"], ['text' => "$stat177"]
                ],
                [
                    ['text' => "$stat178"], ['text' => "$stat179"], ['text' => "$stat180"]
                ],
                 [
                    ['text' => "$stat181"], ['text' => "$stat182"], ['text' => "$stat183"]
                ],
                 [
                    ['text' => "$stat184"], ['text' => "$stat185"], ['text' => "$stat186"]
                ],
                [
                    ['text' => "$stat187"]
                ],
                
                [
                    ['text' => "🔙 برگشت"], ['text' => "💳 استعلام | قیمت ها"]
                ]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("UPDATE user SET service = '$str'  WHERE id = '$from_id' LIMIT 1");
} 
elseif ($textmassage == "♻️انتخاب کشور دیگه"){
    
   
    
    $str = $user["service"];
    
    
   $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   
  $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
  
   foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("data/prics2/$vvv.json"),true);
        $sssw = $jsettting["$str"]["amount"] * 550;
         $ssswm = $jsettting["$str"]["count"];
         $qq = $countryss2[$key];
        if($sssw =="---" or $sssw ==""){ $fff= "100000";  }
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌"){   
        
       
$result[]=$vvv;
$result2[]=$sssw;
$result3[]=$sssw;
$result5[]=$qq;
}
       
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
  $dffdff =  count($result);
 for($z = 0;$z <= $dffdff;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];



$topname = $topname."$stat2"."\n";   
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);

 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
  $stat29 = $nname[28];
  $stat30 = $nname[29];
  $stat31 = $nname[30];
  $stat32 = $nname[31];
  $stat33 = $nname[32];
  $stat34 = $nname[33];
  $stat35 = $nname[34];
  $stat36 = $nname[35];
  $stat37 = $nname[36];
  $stat38 = $nname[37];
  $stat39 = $nname[38];
  $stat40 = $nname[39];
  $stat41 = $nname[40];
  $stat42 = $nname[41];
  $stat43 = $nname[42];
  $stat44 = $nname[43];
  $stat45 = $nname[44];
  $stat46 = $nname[45];
  $stat47 = $nname[46];
  $stat48 = $nname[47];
  $stat49 = $nname[48];
  $stat50 = $nname[49];
  $stat51 = $nname[50];
  $stat52 = $nname[51];
  $stat53 = $nname[52];
  $stat54 = $nname[53];
  $stat55 = $nname[54];
  $stat56 = $nname[55];
  $stat57 = $nname[56];
  $stat58 = $nname[57];
  $stat59 = $nname[58];
  $stat60 = $nname[59];
  $stat61 = $nname[60];
  $stat62 = $nname[61];
  $stat63 = $nname[62];
  $stat64 = $nname[63];
  $stat65 = $nname[64];
  $stat66 = $nname[65];
  $stat67 = $nname[66];
  $stat68 = $nname[67];
  $stat69 = $nname[68];
  $stat70 = $nname[69];
  $stat71 = $nname[70];
  $stat72 = $nname[71];
  $stat73 = $nname[72];
  $stat74 = $nname[73];
  $stat75 = $nname[74];
  $stat76 = $nname[75];
  $stat77 = $nname[76];
  $stat78 = $nname[77];
  $stat79 = $nname[78];
  $stat80 = $nname[79];
  $stat81 = $nname[80];
  $stat82 = $nname[81];
  $stat83 = $nname[82];
  $stat84 = $nname[83];
  $stat85 = $nname[84];
  $stat86 = $nname[85];
  $stat87 = $nname[86];
  $stat88 = $nname[87];
  $stat89 = $nname[88];
  $stat90 = $nname[89];
  $stat91 = $nname[90];
  $stat92 = $nname[91];
  $stat93 = $nname[92];
  $stat94 = $nname[93];
  $stat95 = $nname[94];
  $stat96 = $nname[95];
  $stat97 = $nname[96];
  $stat98 = $nname[97];
  $stat99 = $nname[98];
  $stat100 = $nname[99];
  $stat101 = $nname[100];
  $stat102 = $nname[101];
  $stat103 = $nname[102];
  $stat104 = $nname[103];
  $stat105 = $nname[104];
  $stat106 = $nname[105];
  $stat107 = $nname[106];
  $stat108 = $nname[107];
  $stat109 = $nname[108];
  $stat110 = $nname[109];
  $stat111 = $nname[110];
  $stat112 = $nname[111];
  $stat113 = $nname[112];
  $stat114 = $nname[113];
  $stat115 = $nname[114];
  $stat116 = $nname[115];
  $stat117 = $nname[116];
  $stat118 = $nname[117];
  $stat119 = $nname[118];
  $stat120 = $nname[119];
  $stat121 = $nname[120];
  $stat122 = $nname[121];
  $stat123 = $nname[122];
  $stat124 = $nname[123];
  $stat125 = $nname[124];
  $stat126 = $nname[125];
  $stat127 = $nname[126];
  $stat128 = $nname[127];
  $stat129 = $nname[128];
  $stat130 = $nname[129];
  $stat131 = $nname[130];
  $stat132 = $nname[131];
  $stat133 = $nname[132];
  $stat134 = $nname[133];
  $stat135 = $nname[134];
  $stat136 = $nname[135];
  $stat137 = $nname[136];
  $stat138 = $nname[137];
  $stat139 = $nname[138];
  $stat140 = $nname[139];
  $stat141 = $nname[140];
  $stat142 = $nname[141];
  $stat143 = $nname[142];
  $stat144 = $nname[143];
  $stat145 = $nname[144];
  $stat146 = $nname[145];
  $stat147 = $nname[146];
  $stat148 = $nname[147];
  $stat149 = $nname[148];
  $stat150 = $nname[149];
  $stat151 = $nname[150];
  $stat152 = $nname[151];
  $stat153 = $nname[152];
  $stat154 = $nname[153];
  $stat155 = $nname[154];
  $stat156 = $nname[155];
  $stat157 = $nname[156];
  $stat158 = $nname[157];
  $stat159 = $nname[158];
  $stat160 = $nname[159];
  $stat161 = $nname[160];
  $stat162 = $nname[161];
  $stat163 = $nname[162];
  $stat164 = $nname[163];
  $stat165 = $nname[164];
  $stat166 = $nname[165];
  $stat167 = $nname[166];
  $stat168 = $nname[167];
  $stat169 = $nname[168];
  $stat170 = $nname[169];
  $stat171 = $nname[170];
  $stat172 = $nname[171];
  $stat173 = $nname[172];
  $stat174 = $nname[173];
  $stat175 = $nname[174];
  $stat176 = $nname[175];
  $stat177 = $nname[176];
  $stat178 = $nname[177];
  $stat179 = $nname[178];
  $stat180 = $nname[179];
  $stat181 = $nname[180];
  $stat182 = $nname[181];
  $stat183 = $nname[182];
  $stat184 = $nname[183];
  $stat185 = $nname[184];
  $stat186 = $nname[185];
  
  
  
   $ttt = $jseting["set"]["up"]["time"];
  $ddd = $jseting["set"]["up"]["data"];
  
    
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "🌍 کشور مورد نظر را انتخاب کنید !

✅ مجموعا $dffdff کشور دارای شماره برای این سرویس یافت شد. (موجودی ها هر 10 دقیقه یکبار بروز میشوند)

♻️ آخرین بروزرسانی :
$ttt
$ddd

❗️ فقط کشورهای دارای موجودی شماره برای سرویس مورد نظر شما برای شما نمایش داده میشوند.
❗️ کشور ها زیر به ترتیب قیمت از ارزانترین به گرانترین برای شما مرتب شده اند.👇👇
",
        'reply_markup' => json_encode([
            'keyboard' => [
                 [
                    ['text' => "$stat1"], ['text' => "$stat2"], ['text' => "$stat3"]
                ],
                   [
                    ['text' => "$stat4"], ['text' => "$stat5"], ['text' => "$stat6"]
                ],
                 [
                    ['text' => "$stat7"], ['text' => "$stat8"], ['text' => "$stat9"]
                ],
                   [
                    ['text' => "$stat10"], ['text' => "$stat11"], ['text' => "$stat12"]
                ],
                 [
                    ['text' => "$stat13"], ['text' => "$stat14"], ['text' => "$stat15"]
                ],
                   [
                    ['text' => "$stat16"], ['text' => "$stat17"], ['text' => "$stat18"]
                ],
                 [
                    ['text' => "$stat19"], ['text' => "$stat20"], ['text' => "$stat21"]
                ],
                   [
                    ['text' => "$stat22"], ['text' => "$stat23"], ['text' => "$stat24"]
                ],
                 [
                    ['text' => "$stat25"], ['text' => "$stat26"], ['text' => "$stat27"]
                ],
                   [
                    ['text' => "$stat28"], ['text' => "$stat29"], ['text' => "$stat30"]
                ],
                 [
                    ['text' => "$stat31"], ['text' => "$stat32"], ['text' => "$stat33"]
                ],
                   [
                    ['text' => "$stat34"], ['text' => "$stat35"], ['text' => "$stat36"]
                ],
                 [
                    ['text' => "$stat37"], ['text' => "$stat38"], ['text' => "$stat39"]
                ],
                   [
                    ['text' => "$stat40"], ['text' => "$stat41"], ['text' => "$stat42"]
                ],
                 [
                    ['text' => "$stat43"], ['text' => "$stat44"], ['text' => "$stat45"]
                ],
                   [
                    ['text' => "$stat46"], ['text' => "$stat47"], ['text' => "$stat48"]
                ],
                 [
                    ['text' => "$stat49"], ['text' => "$stat50"], ['text' => "$stat51"]
                ],
                   [
                    ['text' => "$stat52"], ['text' => "$stat53"], ['text' => "$stat54"]
                ],
                 [
                    ['text' => "$stat55"], ['text' => "$stat56"], ['text' => "$stat57"]
                ],
                 [
                    ['text' => "$stat58"], ['text' => "$stat59"], ['text' => "$stat60"]
                ],
                [
                    ['text' => "$stat61"], ['text' => "$stat62"], ['text' => "$stat63"]
                ],
                [
                    ['text' => "$stat64"], ['text' => "$stat65"], ['text' => "$stat66"]
                ],
                [
                    ['text' => "$stat67"], ['text' => "$stat68"], ['text' => "$stat69"]
                ],
                [
                    ['text' => "$stat70"], ['text' => "$stat71"], ['text' => "$stat72"]
                ],
                [
                    ['text' => "$stat73"], ['text' => "$stat74"], ['text' => "$stat75"]
                ],
                 [
                    ['text' => "$stat76"], ['text' => "$stat77"], ['text' => "$stat78"]
                ],
                 [
                    ['text' => "$stat79"], ['text' => "$stat80"], ['text' => "$stat81"]
                ],
                [
                    ['text' => "$stat82"], ['text' => "$stat83"], ['text' => "$stat84"]
                ],
                [
                    ['text' => "$stat85"], ['text' => "$stat86"], ['text' => "$stat87"]
                ],
                [
                    ['text' => "$stat88"], ['text' => "$stat89"], ['text' => "$stat90"]
                ],
                [
                    ['text' => "$stat91"], ['text' => "$stat92"], ['text' => "$stat93"]
                ],
                [
                    ['text' => "$stat94"], ['text' => "$stat95"], ['text' => "$stat96"]
                ],
                 [
                    ['text' => "$stat97"], ['text' => "$stat98"], ['text' => "$stat99"]
                ],
                 [
                    ['text' => "$stat100"], ['text' => "$stat101"], ['text' => "$stat102"]
                ],
                [
                    ['text' => "$stat103"], ['text' => "$stat104"], ['text' => "$stat105"]
                ],
                [
                    ['text' => "$stat106"], ['text' => "$stat107"], ['text' => "$stat108"]
                ],
                [
                    ['text' => "$stat109"], ['text' => "$stat110"], ['text' => "$stat111"]
                ],
                [
                    ['text' => "$stat112"], ['text' => "$stat113"], ['text' => "$stat114"]
                ],
                [
                    ['text' => "$stat115"], ['text' => "$stat116"], ['text' => "$stat117"]
                ],
                 [
                    ['text' => "$stat118"], ['text' => "$stat119"], ['text' => "$stat120"]
                ],
                 [
                    ['text' => "$stat121"], ['text' => "$stat122"], ['text' => "$stat123"]
                ],
                [
                    ['text' => "$stat124"], ['text' => "$stat125"], ['text' => "$stat126"]
                ],
                [
                    ['text' => "$stat127"], ['text' => "$stat128"], ['text' => "$stat129"]
                ],
                [
                    ['text' => "$stat130"], ['text' => "$stat131"], ['text' => "$stat132"]
                ],
                [
                    ['text' => "$stat133"], ['text' => "$stat134"], ['text' => "$stat135"]
                ],
                [
                    ['text' => "$stat136"], ['text' => "$stat137"], ['text' => "$stat138"]
                ],
                 [
                    ['text' => "$stat139"], ['text' => "$stat140"], ['text' => "$stat141"]
                ],
                 [
                    ['text' => "$stat142"], ['text' => "$stat143"], ['text' => "$stat144"]
                ],
                [
                    ['text' => "$stat145"], ['text' => "$stat146"], ['text' => "$stat147"]
                ],
                [
                    ['text' => "$stat148"], ['text' => "$stat149"], ['text' => "$stat150"]
                ],
                [
                    ['text' => "$stat151"], ['text' => "$stat152"], ['text' => "$stat153"]
                ],
                [
                    ['text' => "$stat154"], ['text' => "$stat155"], ['text' => "$stat156"]
                ],
                [
                    ['text' => "$stat157"], ['text' => "$stat158"], ['text' => "$stat159"]
                ],
                 [
                    ['text' => "$stat160"], ['text' => "$stat161"], ['text' => "$stat162"]
                ],
                 [
                    ['text' => "$stat163"], ['text' => "$stat164"], ['text' => "$stat165"]
                ],
                [
                    ['text' => "$stat166"], ['text' => "$stat167"], ['text' => "$stat168"]
                ],
                [
                    ['text' => "$stat169"], ['text' => "$stat170"], ['text' => "$stat171"]
                ],
                [
                    ['text' => "$stat172"], ['text' => "$stat173"], ['text' => "$stat174"]
                ],
                [
                    ['text' => "$stat175"], ['text' => "$stat176"], ['text' => "$stat177"]
                ],
                [
                    ['text' => "$stat178"], ['text' => "$stat179"], ['text' => "$stat180"]
                ],
                 [
                    ['text' => "$stat181"], ['text' => "$stat182"], ['text' => "$stat183"]
                ],
                 [
                    ['text' => "$stat184"], ['text' => "$stat185"], ['text' => "$stat186"]
                ],
                [
                    ['text' => "$stat187"]
                ],
                
                [
                    ['text' => "🔙 برگشت"], ['text' => "💳 استعلام | قیمت ها"]
                ]
            ],
            'resize_keyboard' => true
        ])
    ]);
   
}
elseif (in_array($textmassage, array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه"))) {
     
    $userservicc = $user["service"];
    
      jijibot('sendmessage', [
            'chat_id' => $chat_id,
        'text' => "
  
درحال یافتن ارزانترین پنل ...
صبور باشید.

        ",]); 
    
    $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservicc);
    
    $str3 = str_replace(["🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه"], ["afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe"], $textmassage);
    $userservicp = $user["service"];
    
    //=========================
    $operator = array("019","activ","altel","beeline","claro","ee","globe","itelecom","kcell","kyivstar","lycamobile","matrix","megafon","movistar","mts","orange","pildyk","play","range1","redbull","redbullmobile","rostelecom","smart","sun","tele2","three","tigo","tmobile","tnt","virginmobile","virtual11","virtual12","virtual15","virtual16","virtual17","virtual18","virtual19","virtual2","virtual20","virtual21","virtual22","virtual23","virtual24","virtual4","virtual5","virtual6","virtual7","virtual8","virtual9","vodafone","yota","zz");
     $get = json_decode(file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getPrices&country=$str3&service=$userservicc"),true);
     foreach ($operator as $key3 => $vvvop) {
        
        
       
       
            $sssw = $get["$str3"]["$userservicc"]["$vvvop"]["cost"];
         $ssswm = $get["$str3"]["$userservicc"]["$vvvop"]["count"];
       
        if( $sssw !="" and  $sssw != "0" and  $ssswm !="" and  $ssswm != "0"){
        
       
$result[]=$vvvop;
$result2[]=$sssw;
$result3[]=$sssw;
$result4[]=$ssswm;

        }
        
      
        
       if ($vvvop == 'zz') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
   $dffdff =  count($result);
 for($z = 0;$z <= $dffdff;$z++){
     
      $gets2 = array_search($result2[$z],$result3);
$stat2 = $result[$gets2];

$result60[]=$stat2;
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
}


    
    //============================
    
    
    
   
    $zarib = $jseting["set"]["robelpric"];

    $stock = $user["stock"];
    $npanel = $user["panel"];
    
    $jsetting21 = json_decode(file_get_contents("data/prics2/$str3.json"),true);
$r3 = $jsetting21["$userservicc"]["operator"];
 $alll10 = explode("|", $r3);
             $m1 = "$alll10[0]";
             $m2 = "$alll10[1]";
              $m3 = "$alll10[2]";
               $m4 = "$alll10[3]";
                 $m5 = "$alll10[4]";

  
   $a1=  json_decode(file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getPrices&country=$str3&service=$userservicc"),true);
   
     $cos1 = (ceil($a1["$str3"]["$userservicc"]["$m1"]["cost"])* $zarib);
         $mon1 = $a1["$str3"]["$userservicc"]["$m1"]["count"];
         
           $cos2 = (ceil($a1["$str3"]["$userservicc"]["$m2"]["cost"])* $zarib);
         $mon2 = $a1["$str3"]["$userservicc"]["$m2"]["count"];
         
           $cos3 = (ceil($a1["$str3"]["$userservicc"]["$m3"]["cost"])* $zarib);
         $mon3 = $a1["$str3"]["$userservicc"]["$m3"]["count"];
         
           $cos4 = (ceil($a1["$str3"]["$userservicc"]["$m4"]["cost"])* $zarib);
         $mon4 = $a1["$str3"]["$userservicc"]["$m4"]["count"];
         
         $cos5 = (ceil($a1["$str3"]["$userservicc"]["$m5"]["cost"])* $zarib);
         $mon5 = $a1["$str3"]["$userservicc"]["$m5"]["count"];

if($mon1 > 0){
$s1 = "قیمت پنل(1) : $cos1 تومان [$mon1 عدد]"."\n";
}
if($mon2 > 0){
$s2 = "قیمت پنل(2) : $cos2 تومان  [$mon2 عدد]"."\n";
}
if($mon3 > 0){
$s3 = "قیمت پنل(3) : $cos3 تومان  [$mon3 عدد]"."\n";
}
if($mon4 > 0){
$s4 = "قیمت پنل(4) : $cos4 تومان  [$mon4 عدد]"."\n";
}
if($mon5 > 0){
$s5 = "قیمت پنل(4) : $cos5 تومان  [$mon5 عدد]"."\n";
}
   
       
     jijibot('deletemessage', [
            'chat_id' => $chat_id,
                'message_id'=>$message_id + 1,
            ]);
     
    if ($mon1 > 0 or $mon2 > 0 or $mon3 > 0 or $mon4 > 0 or $mon5 > 0  ){
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
        'text' => "
  
💢 شما قصد خرید شماره مجازی با مشخصات زیر را دارید :
〰️〰️〰️〰️〰️〰️〰️
کشور : $textmassage
سرویس :  $str2
$s1 $s2 $s3 $s4 $s5

موجودی کیف پول شما : $stock تومان


❗️ ربات به صورت اتوماتیک ارزانترین پنل قابل دریافت شماره را برای شما انتخاب خواهد کرد.
〰️〰️〰️〰️〰️〰️〰️
آیا مایل به ادامه و خرید هستید ؟
.

        ",
                    'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "خیر منصرف شدم 👎"], ['text' => "بله میخوام 👍"]
                    ],
                    [
                        ['text' => "♻️انتخاب کشور دیگه"]
                    ]
                    
                ],
            'resize_keyboard' => true
        ])
        
    ]); 
     $connect->query("UPDATE user SET namecontry = '$textmassage'  WHERE id = '$from_id' LIMIT 1");
    }else {
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
        'text' => "
        💢 شما قصد خرید شماره مجازی با مشخصات زیر را دارید :
〰️〰️〰️〰️〰️〰️〰️
کشور : $textmassage
سرویس :  $str2
$s1 $s2 $s3 $s4 $s5

موجودی شما : $stock تومان
〰️〰️〰️〰️〰️〰️〰️
⚠️ کشور مورد نطر در حال حاظر موجود نمیباشد !
   
🌟 لطفا کشور دیگری را انتخاب کنید یا ساعاتی دیگر مجدد امتحان کنید
.
        ",
         'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "🔙 برگشت"], ['text' => "♻️انتخاب کشور دیگه"]
                    ]
                    
                ],
            'resize_keyboard' => true
        ])
         ]); 
    }
}
//=============================================================

 
elseif ($textmassage == "بله میخوام 👍") {
    $stock = $user["stock"];
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
لطفا نوع پرداخت رو انتخاب کنید :

💳 پرداخت آنلاین : متصل شدن به درگاه پرداخت ، پرداخت وجه به مقدار قیمت شماره.
💰 پرداخت از کیف پول : پرداخت وجه از کیف پول شما 

موجودی کیف پول شما : $stock تومان
",
             
                   'reply_markup' => json_encode([
                'keyboard' => [
                        [
                            ['text' => "💰 پرداخت از کیف پول"],
                            ['text' => "💳 پرداخت آنلاین "]
                        ],
                         [
                            ['text' => "🔙 برگشت"]
                        ]
                    ],
                    'resize_keyboard' => true
                ])
            ]);
    
}
elseif ($textmassage == "💳 پرداخت آنلاین") {
      jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
این بخش درحال تعمیر است
کیف پول خود را شارژ نموده و از دکمه پرداخت از کیف پول استفاده نمایید.
",
           ]);
    
}
elseif ($textmassage == "💳 پرداخت آنلاین") {
     if ($blaklist["id"] != true){
         if ($activesell == "1" or $from_id == "$admin[0]" ){
    $stock = $user["stock"];
     $pp = $user["price"];
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
✅ لینک درگاه پرداخت شما ساخته شد.

مبلغ : $pp تومان
 
از طریق دکمه زیر پرداخت کنید 👇👇
",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "💰 $pp تومان", 'url' => "$web/pay/pay.php?amount=$pp&callback=$web/pay/back-ss.php?user=$from_id"]
                        ],
                         [
                            ['text' => "❌ انصراف", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
                
            ]);
            
             $gefft = file_get_contents("https://sms-activate.ru/stubs/handler_api.php?api_key=$api_key&action=getBalance");	
         $alll = explode(":", $gefft);
             $getsmsys = "$alll[1]";
             $getsmssd = $getsmsys * 500 ;

         }else {
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️ فروش به صورت موقت توسط مدیر غیر فعال شده است.
لطفا بعدا دوباره امتحان کنید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
         }
    else { 
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📛 متاسفانه شما از استفاده از ربات محروم شده اید.

در صورتی که اشتباهی رخ داده با پشتیبانی در ارتباط باشید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
    
}
elseif ($data == "ex") {
   $connect->query("UPDATE user SET price = '' WHERE id = '$fromid' LIMIT 1");
     jijibot('deletemessage', [
            'chat_id' => $chatid,
                'message_id'=>$messageid,
            ]);
    
}


elseif ($textmassage == "💰 پرداخت از کیف پول"){    
     $namecontry = $user["namecontry"];
     $str = $user["price"];
    $userservicc = $user["service"];
 
    
    $stock = $user["stock"];
     
         if ($activesell == "1" or $from_id == "$admin[0]"){
   
       
       $countryy = str_replace(["🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه"], ["afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe"], $namecontry);
      
        $userservic = $user["service"];
         $userservicop = $user["panel"];
      
               $userservic = $user["service"];
               
             
            
     //=================================
$jsetting21 = json_decode(file_get_contents("data/prics2/$countryy.json"),true);	
               $r3 = $jsetting21["$userservic"]["operator"];
               
               $alll10 = explode("|", $r3);
            
$zarib = $jseting["set"]["robelpric"];
    
      $stokkj = $user["stock"];

$dffdff =  count($alll10);

 $a1=  json_decode(file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getPrices&country=$countryy&service=$userservic"),true);
foreach ($alll10 as $key3 => $vvvopt) {
   
    
   
  $cos1 = (ceil($a1["$countryy"]["$userservic"]["$vvvopt"]["cost"])* $zarib);
         $mon1 = $a1["$countryy"]["$userservic"]["$vvvopt"]["count"];
    if($stokkj >= $cos1 and $cos1 > 0){
     
      
         $f1 =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getNumber&service=$userservic&operator=$vvvopt&country=$countryy");
         
             $f2 =  explode(":", $f1);
              $ooknumber = "$f2[0]";
               $idnumber = "$f2[1]";
                 $numberfon = "$f2[2]";
              
              if($ooknumber == "ACCESS_NUMBER"){
                $s9 = $key3 + 1;
                $pp = $cos1;
                $op = $vvvopt;
                    $connect->query("UPDATE user SET price = '$cos1' WHERE id = '$from_id' LIMIT 1");
                 break; 
              }
    }
    if($stokkj < $cos1){
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "💳 موجودی کیف پول شما برای خرید کافی نمیباشد !
			
💎 قیمت شماره مورد نظر : $cos1 تومان
💰 موجودی کیف پول شما : $stokkj تومان

💳 برای افزایش موجودی کیف پول کافیست از دکمه شارژ حساب استفاده کنید سپس میتوانید نسبت به خرید اقدام کنید
ℹ


",
            'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                       ['text' => "🔙 برگشت"], ['text' => "💸 شارژ حساب"] 
                       
                    ],
                   
                ],
                'resize_keyboard' => true
            ])
        ]);
         break;
    }
     
  if ($key3 == "$dffdff") {
        jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "⚠️ کشور مورد نطر در حال حاظر موجود نمیباشد !
		
🌟 لطفا کشور دیگری را انتخاب کنید یا ساعاتی دیگر مجدد امتحان کنید

",
'reply_markup' => $keybord
            ]);
        break;
        
    }
    
      if ($key3 == "4") {
        break;
    }
   }
//================================     
             $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$from_id' LIMIT 1"));
             
        $userservice = $user["service"] ;
        
      
         
         $strservic = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservice);
        if ($ooknumber == "ACCESS_NUMBER")
        {
              $plusstock = $stock - $user["price"];
           jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
 ✅	شماره کشور مورد نظر با موفقیت ساخته شد 		

 ✅ شماره از پنل  شماره $s9 به قیمت $cos1 دریافت شد.

📞 شماره مجازی شما :
🅿️ +$numberfon


 شماره را همراه با پیش شماره در سرویس $strservic وارد کنید سپس منتظر دریافت کد در ربات بمانید .
شماره پس از 7 دقیقه لغو میشود.

.
",
             
                   'reply_markup' => json_encode([
                'keyboard' => [
                        [
                             ['text' => "❌ لغو شماره"]
                        ],
                         [
                             ['text' => "⛔️ اعلام مسدودی شماره"],
                        ]
                    ],
                    'resize_keyboard' => true
                ])
            ]);
            
            jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
در انتظار دریافت کد ....

صبور باشد😌
    ",]);
            $connect->query("UPDATE user SET stock = '$plusstock' ,country = '+$numberfon' , getfile = '$idnumber'  WHERE id = '$from_id' LIMIT 1");
            
             $connect->query("UPDATE user SET  step = 'daryaftcod'  WHERE id = '$from_id' LIMIT 1");
    $num = $user["country"];
    if ($usercd["id"] != true) {
        $connect->query("INSERT INTO `coduser` (`id`, `number`, `date`, `time`) VALUES ('$from_id', '$num', '$dat_now', '$time_now')");
    }else {
        $connect->query("UPDATE coduser SET  number = '$numberfon', date = '$dat_now', time = '$time_now'  WHERE id = '$from_id' LIMIT 1");
        $connect->query("UPDATE user SET numberid = '0'  WHERE id = '$from_id' LIMIT 1");
    }
    
        $timee = "$dat_h:$dat_min" ;
   
    
    
    
    $userscd = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM coduserbot WHERE numberid = '$idnumber' LIMIT 1"));
if ($userscd["numberid"] != true) {
     $time1 = time() + 600;
    
        $connect->query("INSERT INTO `numbers` (`numberid`, `id`, `idbot`, `timout`) VALUES ('$idnumber', '$from_id','$usernamebot','$time1')");
    }   
    
     }
          if($ooknumber == "NO_BALANCE"){
           
            
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
⚠️ شارژ پنل ربات به اتمام رسیده و در حال شارژ پنل هستیم. به دلیل فرآیند تبدیل ارز تا چند ساعت آینده پنل شارژ میشود و میتوانید اقدام به خرید شماره نمایید.
.
",
'reply_markup' => $keybord
            ]);
        }
        
        if($ooknumber == "NO_NUMBERS"){
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "⚠️ کشور مورد نطر در حال حاظر موجود نمیباشد !
		
🌟 لطفا کشور دیگری را انتخاب کنید یا ساعاتی دیگر مجدد امتحان کنید

",
'reply_markup' => $keybord
            ]);
        }
            
        
  
        
    
             }else {
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️ فروش به صورت موقت توسط مدیر غیر فعال شده است.
لطفا بعدا دوباره امتحان کنید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }

    
} 


elseif ($textmassage == "💳 استعلام | قیمت ها") {
  
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        
          jijibot('sendmessage', [
         'chat_id'=>$chat_id,
     
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💠 اینستاگرام", 'callback_data' => "instagram"], ['text' => "💠 تلگرام", 'callback_data' => "telegram"], ['text' => "💠 واتساپ", 'callback_data' => "whatsapp"]
                    ],
                       [
                        ['text' => "💠 وی چت", 'callback_data' => "wechat"], ['text' => "💠 وایبر", 'callback_data' => "viber"], ['text' => "💠 توییتر", 'callback_data' => "twitter"]
                    ],
                      [
                        ['text' => "💠 لاین", 'callback_data' => "line"], ['text' => "💠 ایمو", 'callback_data' => "imo"], ['text' => "💠 فیسبوک", 'callback_data' => "facebook"]
                    ],
                      [
                        ['text' => "💠 گوگل", 'callback_data' => "google"], ['text' => "💠 یاهو", 'callback_data' => "yahoo"], ['text' => "💠 دیسکورد", 'callback_data' => "discord"]
                    ],
                      [
                        ['text' => "💠 آمازون", 'callback_data' => "amazon"], ['text' => "💠 علی بابا", 'callback_data' => "alibaba"], ['text' => "💠 علی پی", 'callback_data' => "alipay"]
                    ],
                      [
                        ['text' => "💠 بیگو لایو", 'callback_data' => "bigolive"], ['text' => "💠 لینکدین", 'callback_data' => "linkedin"], ['text' => "💠 ماکروسافت", 'callback_data' => "microsoft"]
                    ],
                      [
                        ['text' => "💠 پی پال", 'callback_data' => "paypal"], ['text' => "💠 اسنپ چت", 'callback_data' => "snapchat"], ['text' => "💠 تیک تاک", 'callback_data' => "tiktok"]
                    ],
                      [
                        ['text' => "💠 دیجی کالا", 'callback_data' => "digikala"], ['text' => "💠 دیوار", 'callback_data' => "divar"], ['text' => "💠 همراه اول", 'callback_data' => "hamrahaval"]
                    ],
                      [
                        ['text' => "💠 ایرانسل", 'callback_data' => "irancell"], ['text' => "💠  پابجی", 'callback_data' => "pubg"], ['text' => "💠  بلاکچین", 'callback_data' => "blockchain"]
                    ],
                      [
                        ['text' => "💠  تانگو", 'callback_data' => "tango"], ['text' => "💠 1688", 'callback_data' => "1688"], ['text' => "💠 1xbet", 'callback_data' => "1xbet"]
                    ],
                      
                    [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 2", 'callback_data' => "paper2"],
                    ]
                ]
            ])
        ]);
        
     } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
}
elseif ($data == "paper1") {
    
      jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💠 اینستاگرام", 'callback_data' => "instagram"], ['text' => "💠 تلگرام", 'callback_data' => "telegram"], ['text' => "💠 واتساپ", 'callback_data' => "whatsapp"]
                    ],
                       [
                        ['text' => "💠 وی چت", 'callback_data' => "wechat"], ['text' => "💠 وایبر", 'callback_data' => "viber"], ['text' => "💠 توییتر", 'callback_data' => "twitter"]
                    ],
                      [
                        ['text' => "💠 لاین", 'callback_data' => "line"], ['text' => "💠 ایمو", 'callback_data' => "imo"], ['text' => "💠 فیسبوک", 'callback_data' => "facebook"]
                    ],
                      [
                        ['text' => "💠 گوگل", 'callback_data' => "google"], ['text' => "💠 یاهو", 'callback_data' => "yahoo"], ['text' => "💠 دیسکورد", 'callback_data' => "discord"]
                    ],
                      [
                        ['text' => "💠 آمازون", 'callback_data' => "amazon"], ['text' => "💠 علی بابا", 'callback_data' => "alibaba"], ['text' => "💠 علی پی", 'callback_data' => "alipay"]
                    ],
                      [
                        ['text' => "💠 بیگو لایو", 'callback_data' => "bigolive"], ['text' => "💠 لینکدین", 'callback_data' => "linkedin"], ['text' => "💠 ماکروسافت", 'callback_data' => "microsoft"]
                    ],
                      [
                        ['text' => "💠 پی پال", 'callback_data' => "paypal"], ['text' => "💠 اسنپ چت", 'callback_data' => "snapchat"], ['text' => "💠 تیک تاک", 'callback_data' => "tiktok"]
                    ],
                      [
                        ['text' => "💠 دیجی کالا", 'callback_data' => "digikala"], ['text' => "💠 دیوار", 'callback_data' => "divar"], ['text' => "💠 همراه اول", 'callback_data' => "hamrahaval"]
                    ],
                      [
                        ['text' => "💠 ایرانسل", 'callback_data' => "irancell"], ['text' => "💠  پابجی", 'callback_data' => "pubg"], ['text' => "💠  بلاکچین", 'callback_data' => "blockchain"]
                    ],
                      [
                        ['text' => "💠  تانگو", 'callback_data' => "tango"], ['text' => "💠 1688", 'callback_data' => "1688"], ['text' => "💠 1xbet", 'callback_data' => "1xbet"]
                    ],
                      
                    [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 2", 'callback_data' => "paper2"],
                    ]
                ]
            ])
        ]);
    
}
elseif ($data == "paper2") {
    
      jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                   
                      [
                        ['text' => "💠 23red", 'callback_data' => "23red"], ['text' => "💠 ace2three", 'callback_data' => "ace2three"], ['text' => "💠 adidas", 'callback_data' => "adidas"]
                    ],
                      [
                        ['text' => "💠 airbnb", 'callback_data' => "airbnb"], ['text' => "💠 airtel", 'callback_data' => "airtel"], ['text' => "💠 akelni", 'callback_data' => "akelni"]
                    ],
                      [
                        ['text' => "💠 aliexpress", 'callback_data' => "aliexpress"], ['text' => "💠 amasia", 'callback_data' => "amasia"], ['text' => "💠 aol", 'callback_data' => "aol"]
                    ],
                      [
                        ['text' => "💠 avito", 'callback_data' => "avito"], ['text' => "💠 azino", 'callback_data' => "azino"], ['text' => "💠 b4ucabs", 'callback_data' => "b4ucabs"]
                    ],
                      [
                        ['text' => "💠 bigcash", 'callback_data' => "bigcash"], ['text' => "💠 bitclout", 'callback_data' => "bitclout"], ['text' => "💠 bittube", 'callback_data' => "bittube"]
                    ],
                      [
                        ['text' => "💠 blablacar", 'callback_data' => "blablacar"], ['text' => "💠 blizzard", 'callback_data' => "blizzard"], ['text' => "💠 burgerking", 'callback_data' => "burgerking"]
                    ],
                      [
                        ['text' => "💠 careem", 'callback_data' => "careem"], ['text' => "💠 cdkeys", 'callback_data' => "cdkeys"], ['text' => "💠 cekkazan", 'callback_data' => "cekkazan"]
                    ],
                      [
                        ['text' => "💠 citymobil", 'callback_data' => "citymobil"], ['text' => "💠 clickentregas", 'callback_data' => "clickentregas"], ['text' => "💠 coinbase", 'callback_data' => "coinbase"]
                    ],
                      [
                        ['text' => "💠 craigslist", 'callback_data' => "craigslist"], ['text' => "💠 deliveroo", 'callback_data' => "deliveroo"], ['text' => "💠 delivery", 'callback_data' => "delivery"]
                    ], 
                    [
                        ['text' => "💠 dent", 'callback_data' => "dent"], ['text' => "💠 didi", 'callback_data' => "didi"], ['text' => "💠 dixy", 'callback_data' => "dixy"]
                    ],
                     
                    [
                        ['text' => "◀️ صفحه 1 ", 'callback_data' => "paper1"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 3", 'callback_data' => "paper3"],
                    ],
                     [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                         
                    ]
                ]
            ])
        ]);
    
}
elseif ($data == "paper3") {
   
   
          jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💠 dodopizza", 'callback_data' => "dodopizza"], ['text' => "💠 domdara", 'callback_data' => "domdara"], ['text' => "💠 dostavista", 'callback_data' => "dostavista"]
                    ],
                        [
                        ['text' => "💠 douyu", 'callback_data' => "douyu"], ['text' => "💠 drom", 'callback_data' => "drom"], ['text' => "💠 drugvokrug", 'callback_data' => "drugvokrug"]
                    ],
                        [
                        ['text' => "💠 dukascopy", 'callback_data' => "dukascopy"], ['text' => "💠 ebay", 'callback_data' => "ebay"], ['text' => "💠 edgeless", 'callback_data' => "edgeless"]
                    ],
                       [
                        ['text' => "💠 electroneum", 'callback_data' => "electroneum"], ['text' => "💠 ezway", 'callback_data' => "ezway"], ['text' => "💠 fiverr", 'callback_data' => "fiverr"]
                    ],
                        [
                        ['text' => "💠 flipkart", 'callback_data' => "flipkart"], ['text' => "💠 foodpanda", 'callback_data' => "foodpanda"], ['text' => "💠 foody", 'callback_data' => "foody"]
                    ],
                       [
                        ['text' => "💠 forwarding", 'callback_data' => "forwarding"], ['text' => "💠 galaxy", 'callback_data' => "galaxy"], ['text' => "💠 gameflip", 'callback_data' => "gameflip"]
                    ],
                       [
                        ['text' => "💠 gcash", 'callback_data' => "gcash"], ['text' => "💠 get", 'callback_data' => "get"], ['text' => "💠 getir", 'callback_data' => "getir"]
                    ],
                       [
                        ['text' => "💠 gett", 'callback_data' => "gett"], ['text' => "💠 globus", 'callback_data' => "globus"], ['text' => "💠 glovo", 'callback_data' => "glovo"]
                    ],
                        [
                        ['text' => "💠 grabtaxi", 'callback_data' => "grabtaxi"], ['text' => "💠 green", 'callback_data' => "green"], ['text' => "💠 grindr", 'callback_data' => "grindr"]
                    ],
                       [
                        ['text' => "💠 haraj", 'callback_data' => "haraj"], ['text' => "💠 hezzl", 'callback_data' => "hezzl"], ['text' => "💠 hopi", 'callback_data' => "hopi"]
                    ],
                       
                     
                   [
                        ['text' => "◀️ صفحه 2 ", 'callback_data' => "paper2"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 4", 'callback_data' => "paper4"],
                    ],
                     [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                         
                    ]
                ]
            ])
        ]);
       
    }
    elseif ($data == "paper4") {
   
   
          jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    
                       [
                        ['text' => "💠 hqtrivia", 'callback_data' => "hqtrivia"], ['text' => "💠 icard", 'callback_data' => "icard"], ['text' => "💠 icq", 'callback_data' => "icq"]
                    ],
                       [
                        ['text' => "💠 ininal", 'callback_data' => "ininal"], ['text' => "💠 iost", 'callback_data' => "iost"], ['text' => "💠 jd", 'callback_data' => "jd"]
                    ],
                       [
                        ['text' => "💠 justdating", 'callback_data' => "justdating"], ['text' => "💠 kakaotalk", 'callback_data' => "kakaotalk"], ['text' => "💠 keybase", 'callback_data' => "keybase"]
                    ],
                        [
                        ['text' => "💠 komandacard", 'callback_data' => "komandacard"], ['text' => "💠 kotak811", 'callback_data' => "kotak811"], ['text' => "💠 kufarby", 'callback_data' => "kufarby"]
                    ],
                       [
                        ['text' => "💠 kwai", 'callback_data' => "kwai"], ['text' => "💠 lazada", 'callback_data' => "lazada"], ['text' => "💠 lbry", 'callback_data' => "lbry"]
                    ],
                       [
                        ['text' => "💠 lenta", 'callback_data' => "lenta"], ['text' => "💠 lianxin", 'callback_data' => "lianxin"], ['text' => "💠 livescore", 'callback_data' => "livescore"]
                    ],
                       [
                        ['text' => "💠 magnit", 'callback_data' => "magnit"], ['text' => "💠 magnolia", 'callback_data' => "magnolia"], ['text' => "💠 mailru", 'callback_data' => "mailru"]
                    ],
                        [
                        ['text' => "💠 mamba", 'callback_data' => "mamba"], ['text' => "💠 mcdonalds", 'callback_data' => "mcdonalds"], ['text' => "💠 meetme", 'callback_data' => "meetme"]
                    ],
                       [
                        ['text' => "💠 mega", 'callback_data' => "mega"], ['text' => "💠 mercado", 'callback_data' => "mercado"], ['text' => "💠 miratorg", 'callback_data' => "miratorg"]
                    ],
                     [
                        ['text' => "💠 mtscashback", 'callback_data' => "mtscashback"], ['text' => "💠 nana", 'callback_data' => "nana"], ['text' => "💠 naver", 'callback_data' => "naver"]
                    ],
                     [
                        ['text' => "💠 netflix", 'callback_data' => "netflix"], ['text' => "💠 nhseven", 'callback_data' => "nhseven"], ['text' => "💠 nifty", 'callback_data' => "nifty"]
                    ],
                     
                    [
                        ['text' => "◀️ صفحه 3 ", 'callback_data' => "paper3"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 5", 'callback_data' => "paper5"],
                    ],
                     [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                         
                    ]
                ]
            ])
        ]);
       
    }
    elseif ($data == "paper5") {
   
   
          jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💠 nike", 'callback_data' => "nike"], ['text' => "💠 nimses", 'callback_data' => "nimses"], ['text' => "💠 nttgame", 'callback_data' => "nttgame"]
                    ],
                        [
                        ['text' => "💠 odnoklassniki", 'callback_data' => "odnoklassniki"], ['text' => "💠 offerup", 'callback_data' => "offerup"], ['text' => "💠 okcupid", 'callback_data' => "okcupid"]
                    ],
                        [
                        ['text' => "💠 okey", 'callback_data' => "okey"], ['text' => "💠 olx", 'callback_data' => "olx"], ['text' => "💠 openpoint", 'callback_data' => "openpoint"]
                    ],
                       [
                        ['text' => "💠 oraclecloud", 'callback_data' => "oraclecloud"], ['text' => "💠 ozon", 'callback_data' => "ozon"], ['text' => "💠 pairs", 'callback_data' => "pairs"]
                    ],
                        [
                        ['text' => "💠 papara", 'callback_data' => "papara"], ['text' => "💠 paycell", 'callback_data' => "paycell"], ['text' => "💠 paymaya", 'callback_data' => "paymaya"]
                    ],
                       [
                        ['text' => "💠 paysend", 'callback_data' => "paysend"], ['text' => "💠 peoplecom", 'callback_data' => "peoplecom"], ['text' => "💠 perekrestok", 'callback_data' => "perekrestok"]
                    ],
                       [
                        ['text' => "💠 pof", 'callback_data' => "pof"], ['text' => "💠 pokec", 'callback_data' => "pokec"], ['text' => "💠 pokermaster", 'callback_data' => "pokermaster"]
                    ],
                       [
                        ['text' => "💠 qiwiwallet", 'callback_data' => "qiwiwallet"], ['text' => "💠 quioo", 'callback_data' => "quioo"], ['text' => "💠 quipp", 'callback_data' => "quipp"]
                    ],
                        [
                        ['text' => "💠 reuse", 'callback_data' => "reuse"], ['text' => "💠 ripkord", 'callback_data' => "ripkord"], ['text' => "💠 samokat", 'callback_data' => "samokat"]
                    ],
                       [
                        ['text' => "💠 seosprint", 'callback_data' => "seosprint"], ['text' => "💠 sheerid", 'callback_data' => "sheerid"], ['text' => "💠 shopee", 'callback_data' => "shopee"]
                    ],
                       
                    [
                        ['text' => "◀️ صفحه 4 ", 'callback_data' => "paper4"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 6", 'callback_data' => "paper6"],
                    ],
                     [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                         
                    ]
                ]
            ])
        ]);
       
    }
    elseif ($data == "paper6") {
   
   
          jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    
                       [
                        ['text' => "💠 signal", 'callback_data' => "signal"], ['text' => "💠 sikayetvar", 'callback_data' => "sikayetvar"], ['text' => "💠 skout", 'callback_data' => "skout"]
                    ],
                       [
                        ['text' => "💠 steam", 'callback_data' => "steam"], ['text' => "💠 swvl", 'callback_data' => "swvl"], ['text' => "💠 taksheel", 'callback_data' => "taksheel"]
                    ],
                       [
                        ['text' => "💠 tantan", 'callback_data' => "tantan"], ['text' => "💠 taobao", 'callback_data' => "taobao"], ['text' => "💠 tencentqq", 'callback_data' => "tencentqq"]
                    ],
                        [
                        ['text' => "💠 tinder", 'callback_data' => "tinder"], ['text' => "💠 tosla", 'callback_data' => "tosla"], ['text' => "💠 totalcoin", 'callback_data' => "totalcoin"]
                    ],
                       [
                        ['text' => "💠 touchance", 'callback_data' => "touchance"], ['text' => "💠 trendyol", 'callback_data' => "trendyol"], ['text' => "💠 truecaller", 'callback_data' => "truecaller"]
                    ],
                       [
                        ['text' => "💠 uber", 'callback_data' => "uber"], ['text' => "💠 uploaded", 'callback_data' => "uploaded"], ['text' => "💠 vernyi", 'callback_data' => "vernyi"]
                    ],
                       [
                        ['text' => "💠 vkontakte", 'callback_data' => "vkontakte"], ['text' => "💠 voopee", 'callback_data' => "voopee"], ['text' => "💠 weibo", 'callback_data' => "weibo"]
                    ],
                        [
                        ['text' => "💠 weku", 'callback_data' => "weku"], ['text' => "💠 winston", 'callback_data' => "winston"], ['text' => "💠 wish", 'callback_data' => "wish"]
                    ],
                       [
                        ['text' => "💠 yalla", 'callback_data' => "yalla"], ['text' => "💠 yandex", 'callback_data' => "yandex"], ['text' => "💠 yemeksepeti", 'callback_data' => "yemeksepeti"]
                    ],
                     [
                        ['text' => "💠 youdo", 'callback_data' => "youdo"], ['text' => "💠 youla", 'callback_data' => "youla"], ['text' => "💠 zalo", 'callback_data' => "zalo"]
                    ],
                     [
                        ['text' => "💠 zoho", 'callback_data' => "zoho"], ['text' => "💠 zomato", 'callback_data' => "zomato"]
                        , ['text' => "💠 michat", 'callback_data' => "michat"]
                    ],
                     
                     [
                        ['text' => "🌐 دیگر سرویس ها", 'callback_data' => "other"]
                    ],
                    [
                        ['text' => "◀️ صفحه 5 ", 'callback_data' => "paper5"],
                        ['text' => "⏭ صفحه  نخست ", 'callback_data' => "paper1"],
                         ['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ]
                ]
            ])
        ]);
       
    }
elseif ($data == "backpricservis") {
 
      jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💠 اینستاگرام", 'callback_data' => "instagram"], ['text' => "💠 تلگرام", 'callback_data' => "telegram"], ['text' => "💠 واتساپ", 'callback_data' => "whatsapp"]
                    ],
                       [
                        ['text' => "💠 وی چت", 'callback_data' => "wechat"], ['text' => "💠 وایبر", 'callback_data' => "viber"], ['text' => "💠 توییتر", 'callback_data' => "twitter"]
                    ],
                      [
                        ['text' => "💠 لاین", 'callback_data' => "line"], ['text' => "💠 ایمو", 'callback_data' => "imo"], ['text' => "💠 فیسبوک", 'callback_data' => "facebook"]
                    ],
                      [
                        ['text' => "💠 گوگل", 'callback_data' => "google"], ['text' => "💠 یاهو", 'callback_data' => "yahoo"], ['text' => "💠 دیسکورد", 'callback_data' => "discord"]
                    ],
                      [
                        ['text' => "💠 آمازون", 'callback_data' => "amazon"], ['text' => "💠 علی بابا", 'callback_data' => "alibaba"], ['text' => "💠 علی پی", 'callback_data' => "alipay"]
                    ],
                      [
                        ['text' => "💠 بیگو لایو", 'callback_data' => "bigolive"], ['text' => "💠 لینکدین", 'callback_data' => "linkedin"], ['text' => "💠 ماکروسافت", 'callback_data' => "microsoft"]
                    ],
                      [
                        ['text' => "💠 پی پال", 'callback_data' => "paypal"], ['text' => "💠 اسنپ چت", 'callback_data' => "snapchat"], ['text' => "💠 تیک تاک", 'callback_data' => "tiktok"]
                    ],
                      [
                        ['text' => "💠 دیجی کالا", 'callback_data' => "digikala"], ['text' => "💠 دیوار", 'callback_data' => "divar"], ['text' => "💠 همراه اول", 'callback_data' => "hamrahaval"]
                    ],
                      [
                        ['text' => "💠 ایرانسل", 'callback_data' => "irancell"], ['text' => "💠  پابجی", 'callback_data' => "pubg"], ['text' => "💠  بلاکچین", 'callback_data' => "blockchain"]
                    ],
                      [
                        ['text' => "💠  تانگو", 'callback_data' => "tango"], ['text' => "💠 1688", 'callback_data' => "1688"], ['text' => "💠 1xbet", 'callback_data' => "1xbet"]
                    ],
                      
                    [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 2", 'callback_data' => "paper2"],
                    ]
                ]
            ])
        ]);
  
        $connect->query("UPDATE user SET service = '' WHERE id = '$fromid' LIMIT 1");
    }
    
elseif (in_array($data, array("instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"))) {
     
    
    
      $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $data);
    
    $connect->query("UPDATE user SET service = '$data' WHERE id = '$fromid' LIMIT 1");
     jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
درحال استعلام...
        ",         ]);
        
        

//=============================================================
 $ttt = $jseting["set"]["up"]["time"];
  $ddd = $jseting["set"]["up"]["data"];
$zarib = $jseting["set"]["robelpric"];
$servisss = $str ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
 
   foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("data/prics2/$vvv.json"),true);
        $sssw = ceil($jsettting["$data"]["amount"]) * $zarib;
         $ssswm = $jsettting["$data"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 0;$z <= 28;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11 = $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15 = $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24 = $nname[23];
  $stat25 = $nname[24];
  $stat26 = $nname[25];
  $stat27 = $nname[26];
  $stat28 = $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
    $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================


     jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat27 ", 'callback_data' => "text"], ['text' => "$cost27", 'callback_data' => "text"], ['text' => "$statt27", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat28 ", 'callback_data' => "text"], ['text' => "$cost28", 'callback_data' => "text"], ['text' => "$statt28", 'callback_data' => "text"]
                    ],
                                        [
                       
                    ],
                                          [
                        ['text' => "⤴️ صفحه آخر", 'callback_data' => "pag7"], ['text' => "▶️ صفحه 2", 'callback_data' => "pag2"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]);   

}
elseif ($data == "pag1") {
     
  
         $userservic = $usert["service"];
    $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservic);
  
     
    $userservicp = $usert["panel"];
    $dddddsdsds="";
//=============================================================
 $ttt = $jseting["set"]["up"]["time"];
  $ddd = $jseting["set"]["up"]["data"];
$zarib = $jseting["set"]["robelpric"];
$servisss = $usert["service"]; ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("data/prics2/$vvv.json"),true);
        $sssw = ceil($jsettting["$servisss"]["amount"]) * $zarib;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 0;$z <= 28;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
   $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

     jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat27 ", 'callback_data' => "text"], ['text' => "$cost27", 'callback_data' => "text"], ['text' => "$statt27", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat28 ", 'callback_data' => "text"], ['text' => "$cost28", 'callback_data' => "text"], ['text' => "$statt28", 'callback_data' => "text"]
                    ],
                                        [
                       
                    ],
                                         [
                        ['text' => "⤴️ صفحه آخر", 'callback_data' => "pag7"], ['text' => "▶️ صفحه 2", 'callback_data' => "pag2"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]);   

}
elseif ($data == "pag2") {
     
   
    
        $userservic = $usert["service"];
    $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservic);
  
    
  
  //=============================================================
 $ttt = $jseting["set"]["up"]["time"];
  $ddd = $jseting["set"]["up"]["data"];
$zarib = $jseting["set"]["robelpric"];
$servisss = $usert["service"]; ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("data/prics2/$vvv.json"),true);
        $sssw = ceil($jsettting["$servisss"]["amount"]) * $zarib;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm ==""  or $sssw !="---" or $sssw !=""){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 29;$z <= 56;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
   $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

    jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat27 ", 'callback_data' => "text"], ['text' => "$cost27", 'callback_data' => "text"], ['text' => "$statt27", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat28 ", 'callback_data' => "text"], ['text' => "$cost28", 'callback_data' => "text"], ['text' => "$statt28", 'callback_data' => "text"]
                    ],
                                        [
                       
                    ],
                                        [
                        ['text' => "صفحه 1 ◀️", 'callback_data' => "pag1"], ['text' => "▶️ صفحه 3", 'callback_data' => "pag3"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]);   

}
elseif ($data == "pag3") {
     
   
    
       $userservic = $usert["service"];
    $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservic);
  
     
    $userservicp = $usert["panel"];
   
//=============================================================
 $ttt = $jseting["set"]["up"]["time"];
  $ddd = $jseting["set"]["up"]["data"];
$zarib = $jseting["set"]["robelpric"];
$servisss = $usert["service"]; ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("data/prics2/$vvv.json"),true);
        $sssw = ceil($jsettting["$servisss"]["amount"]) * $zarib;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 57;$z <= 83;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
 $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

    jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                   
                                        [
                        ['text' => "صفحه 2 ◀️", 'callback_data' => "pag2"], ['text' => "▶️ صفحه 4", 'callback_data' => "pag4"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]);   

}
elseif ($data == "pag4") {
     
   
     
       $userservic = $usert["service"];
    $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservic);
  
     
    $userservicp = $usert["panel"];
   
//=============================================================
 $ttt = $jseting["set"]["up"]["time"];
  $ddd = $jseting["set"]["up"]["data"];
$zarib = $jseting["set"]["robelpric"];
$servisss = $usert["service"]; ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("data/prics2/$vvv.json"),true);
        $sssw = ceil($jsettting["$servisss"]["amount"]) * $zarib;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 84;$z <= 110;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
 $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

    jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                   
                                        [
                        ['text' => "صفحه 3 ◀️", 'callback_data' => "pag3"], ['text' => "▶️ صفحه 5", 'callback_data' => "pag5"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],
                ],
            
        ])
        
    ]);   

}
elseif ($data == "pag5") {
     
   
     
       $userservic = $usert["service"];
    $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservic);
  
     
    $userservicp = $usert["panel"];
   
//=============================================================
 $ttt = $jseting["set"]["up"]["time"];
  $ddd = $jseting["set"]["up"]["data"];
$zarib = $jseting["set"]["robelpric"];
$servisss = $usert["service"]; ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("data/prics2/$vvv.json"),true);
        $sssw = ceil($jsettting["$servisss"]["amount"]) * $zarib;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 111;$z <= 137;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
 $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

    jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                                      [
                        ['text' => "صفحه 4 ◀️", 'callback_data' => "pag4"], ['text' => "▶️ صفحه 6", 'callback_data' => "pag6"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]);   

}
elseif ($data == "pag6") {
     
   
     
       $userservic = $usert["service"];
    $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservic);
  
     
    $userservicp = $usert["panel"];
   
//=============================================================
 $ttt = $jseting["set"]["up"]["time"];
  $ddd = $jseting["set"]["up"]["data"];
$zarib = $jseting["set"]["robelpric"];
$servisss = $usert["service"]; ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("data/prics2/$vvv.json"),true);
        $sssw = ceil($jsettting["$servisss"]["amount"]) * $zarib;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 138;$z <= 165;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
 $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

    jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                   
                                        [
                        ['text' => "صفحه 5 ◀️", 'callback_data' => "pag5"], ['text' => "▶️ صفحه 7", 'callback_data' => "pag7"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]);   

}
elseif ($data == "pag7") {
     
   
    
       $userservic = $usert["service"];
    $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservic);
  
     
    $userservicp = $usert["panel"];
   
//=============================================================
 $ttt = $jseting["set"]["up"]["time"];
  $ddd = $jseting["set"]["up"]["data"];
$zarib = $jseting["set"]["robelpric"];
$servisss = $usert["service"]; ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("data/prics2/$vvv.json"),true);
        $sssw = ceil($jsettting["$servisss"]["amount"]) * $zarib;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 166;$z <= 186;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
 $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

    jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                   
                      
                     
                                      [
                        ['text' => "صفحه 6 ◀️", 'callback_data' => "pag6"], ['text' => "⤴️ صفحه اول", 'callback_data' => "pag1"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]);   

}
elseif(strpos($data,"estelam|") !== false){
    
      $alll = explode("|", $data);
             $cuntry0 = "$alll[1]";
             $service0 = "$alll[2]";
            $er = "$alll[3]";
              
               
                $strservic = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $service0);
               
     
      
      $str3 = str_replace(["afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe"], ["🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه"], $cuntry0);
      
     
    $zarib = $jseting["set"]["robelpric"];
    
    
    $jsetting21 = json_decode(file_get_contents("data/prics2/$cuntry0.json"),true);	
               $r3 = $jsetting21["$service0"]["operator"];
               
               $alll10 = explode("|", $r3);
            
$zarib = $jseting["set"]["robelpric"];
    
      $stokkj = $user["stock"];

$dffdff =  count($alll10);

 $a1=  json_decode(file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getPrices&country=$cuntry0&service=$service0"),true);
foreach ($alll10 as $key3 => $vvvopt) {
   
    
   
  $cos1 = (ceil($a1["$cuntry0"]["$service0"]["$vvvopt"]["cost"])* $zarib);
         $mon1 = $a1["$cuntry0"]["$service0"]["$vvvopt"]["count"];
    if($cos1 == $er){
        
         break;
    }
     
  if ($key3 == "$dffdff") {
       
        break;
        
    }
    
      if ($key3 == "4") {
        break;
    }
   }
//================================   
    
    

 $get = json_decode(file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getPrices"),true);
  $ros0 = ceil($get["$cuntry0"]["$service0"]["$vvvopt"]["cost"])* $zarib;
         $cros00 = $get["$cuntry0"]["$service0"]["$vvvopt"]["count"];
         if($cros00 == ""){ $cros00 =="0"  ;}
             
               jijibot('answercallbackquery', [
            'callback_query_id' => $membercall,
            'text' => "
〰️〰️〰️〰️〰️〰️〰️
کشور : $str3
سرویس :  $strservic
قیمت : $er تومان
تعداد موجود : $cros00 عدد
〰️〰️〰️〰️〰〰️〰️
",
            'show_alert' => true
        ]);
    
}
elseif ($textmassage == "👤 اطلاعات حساب") {
    
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        $stock = $user["stock"];
        $member = $user["member"];
        $numberby = $user["numberby"];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🎫 حساب کاربری شما در ربات خرید شماره مجازی :

🗣 نام : $first_name
👾 شناسه : $from_id
🥇 موجودی کیف پول شما : $stock تومان
🏵 تعداد خرید : $numberby
👥 تعداد زیر مجموعه ها : $member نفر

🎈 با دعوت هر نفر به ربات $porsant تومان اعتبار دریافت کنید و 10 درصد از هر خرید هر زیر مجموعه را پورسانت بگیرید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "👥 دعوت دیگران", 'callback_data' => "member"]
                    ],
                    [
                        ['text' => "💎 خرید های من", 'callback_data' => "myby"]
                    ],
                ]
            ])
        ]);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
} 

elseif ($textmassage == "💸 شارژ حساب" ) {
     
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 چقدر میخوای شارژ کنی؟

⚠️ مبلغ رو به تومان و اعداد انگلیسی وارد کن مثلا 5000

⚠️ مبلغ وردی باید بین 3000 الی 100000 تومان باشد
",
             'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       
 $connect->query("UPDATE user SET step = 'upsharggg' WHERE id = '$from_id' LIMIT 1");
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
} 
elseif ($user["step"] == "upsharggg" and $textmassage != "🔙 برگشت") {
     
    if ( filter_var($textmassage,FILTER_VALIDATE_INT)) {
    if ($textmassage >= 3000 && $textmassage <= 100000) {
        
       $time1 = getramz();  
            
           jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
✅ لینک درگاه پرداخت شما ساخته شد.

مبلغ : $textmassage تومان
 
از طریق دکمه زیر پرداخت کنید 👇👇
",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "💰 $textmassage تومان", 'url' => "$web/pay/pay.php?amount=$textmassage&user=$from_id&r=$time1&callback=$web/pay/back-st.php?user=$from_id"]
                        ],
                         [
                            ['text' => "❌ انصراف", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
                
            ]);
      
           
$connect->query("UPDATE user SET price = '$textmassage' , getfile = '$time1' WHERE id = '$from_id' LIMIT 1");
        
       
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "
⚠️ مبلغ وردی باید بین 3000 الی 100000 تومان باشد.
",
            
        ]);
    }
    }
    else { 
    
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا یک مقدار عددی وارد کنید :",
        ]);
}
} 

 elseif ($textmassage == "👥 زیرمجموعه گیری") {
   
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        $member = $user["member"];
        $stock = $user["stock"];
        jijibot('sendphoto', [
            'chat_id' => $chat_id,
            'photo' => "https://t.me/antispamtitan/103",
            'caption' => " چطوری اکانت ناشناس بسازیم؟ خب معلومه با شماره مجازی؟! 🤔

😳 با این ربات از بیش از 90 کشور دنیا سیم کارت و شماره اختصاصی بگیرید!👇
telegram.me/$usernamebot?start=$from_id ",
'parse_mode' => 'Markdown',
        ]);
         jijibot('sendphoto', [
            'chat_id' => $chat_id,
            'photo' => "https://t.me/antispamtitan/103",
            'caption' => " 
👈 با 《 شماره مجازی | سل ‌نامبر 》 شماره مجازی خود را دریافت کنید . . .

☑️ دریافت شماره دلخواه
☑️ اتوماتیک و بدون هزینه
☑️ با ضمانت برگشت هزینه
☑️ شماره مجازی کشور دلخواه

💬 لینک ورود به سل ‌نامبر :

[برا عضویت زود اینجا کلیک کن](telegram.me/$usernamebot?start=$from_id) ",
'parse_mode' => 'Markdown',
        ]);
    
         jijibot('sendphoto', [
            'chat_id' => $chat_id,
            'photo' => "https://t.me/antispamtitan/103",
            'caption' => " 
فروشگاه شماره مجازی | نامبرینو
🇱🇷🇲🇼🇲🇬🇱🇺🇱🇸🇳🇮🇳🇴🇲🇵🇳🇫🇲🇳🇷🇺
💠 تا حالا خواستی یه اکانت ناشناس داشته باشی ولی حوصله خریدن یه سیمکارت جدید نداشته باشی؟!😉
💠 با ربات نامبرینو به صورت کاملا اتوماتیک میتونی در عرض چند ثانیه شماره مجازی بیش از 84 کشور دنیارو بگیری!!😲💯
حتی شماره مجازی ایران 🇮🇷🤠
🇷🇪🇶🇦🇵🇷🇵🇹🇿🇦🇸🇧🇬🇸🇸🇰🇨🇽🇨🇷🇸🇽
همین الان میتونی وارد نامبرینو بشی و شمارتو بگیری👇
telegram.me/$usernamebot?start=$from_id ",
'parse_mode' => 'Markdown',
        ]);
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🎈 پیام بالا حاوی لینک دعوت شما به ربات است 	

🌟 با دعوت دوستان خود علاوه بر حمایت از ما با دعوت هر نفر $porsant تومان موجودی کیف پول دریافت میکنید
---------------------------
⚠️ افرادی که اقدام به زیرمجموعه گیری با اکانت های فیک میکنند مسدود میشن.📛

گزارش تمام زیرمجموعه گیری ها برای ما ارسال میشه و همیشه در حال رصد کردن هستیم.
گاهی به صورت رندم با چندین زیر مجموعه چت میشه تا از صحت واقعی بودن زیر مجموعه ها اطمینان حاصل بشه.

💰 موجودی کیف پول شما : $stock
👥 تعداد زیر مجموعه ها : $member",
        ]);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
}  
elseif ($textmassage == "👮🏻 پشتیبانی") {
     
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "👮🏻 همکاران ما در خدمت شما هستن !
	
🔘 در صورت وجود نظر , ایده , گزارش مشکل , پیشنهاد , ایراد سوال , یا انتقاد میتوانید با ما در ارتباط باشید 
💬 لطفا پیام خود را به صورت فارسی و روان ارسال کنید",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        $connect->query("UPDATE user SET step = 'sup' WHERE id = '$from_id' LIMIT 1");
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
} 
elseif ($textmassage == "❌ لغو شماره" or $textmassage == "⛔️ اعلام مسدودی شماره") {
     $stock = $user["stock"];
    $userservice = $user["service"];
    $country = $user["country"];
    $namecontry = $user["namecontry"];
    $idnumber = $user["getfile"];
   
    $get =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getStatus&id=$idnumber");
      $alll = explode(":", $get);
             $cros000 = "$alll[0]";
             $cod000 = "$alll[1]";
            
    
   
      $connect->query("UPDATE user SET  numberid = '0'  WHERE id = '$from_id' LIMIT 1");
      

    if ($cros000 == "STATUS_OK") {
       
        $price = $user["price"];
        $plusby = $user["numberby"] + 1;
        $member = $user["member"];
       
       jijibot('sendmessage', [
            'chat_id' => "$from_id",
            'text' => "کد با موفقیت دریافت شد ✅
💭 کد ورود شما به برنامه : $cod000

ℹ️ گزارش خریدبه کانال ما @$channelby ارسال شد 
🔆 درصورت وجود هرگونه مشکل کافیست با پشتیبانی در تماس باشید",
            'reply_markup' => $keybord
        ]);
        
        $strservic = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservice);
        $number = mb_substr("$country", "0", "10") . "***";
        $usidf = mb_substr("$from_id", "0", "6") . "***";
        jijibot('sendmessage', [
            'chat_id' => "@$channel",
            'text' => "
📱یک عدد شماره مجازی $namecontry خریداری شد!
⚜️اطلاعات شماره و خریدار 👇
➖➖➖➖➖➖➖➖
☎️ number : $number
➖➖➖➖➖➖➖➖
👤 user : $usidf
➖➖➖➖➖➖➖➖
📱 service : $strservic
➖➖➖➖➖➖➖➖
💸 نوع پرداخت :  #کیف_پول
➖➖➖➖➖➖➖➖
❗️روش خرید و دریافت شماره مجازی :
۱-وارد ربات @$usernamebot شوید.
۲-اعتبار خود را $price تومان افزایش دهید.
۳-سرویس $strservic را انخاب کنید.
۴-شماره مجازی  $namecontry دریافت کنید!
☝️شماره های مجازی ثبت نشده هستند و با متد های اتومات توسط کاربران ربات @$usernamebot نامبرینو به صورت کاملا خودکار دریافت و ثبت می شوند.
این پیام  خودکار با دریافت کد شماره مجازی توسط کاربر ربات نامبرینو  ارسال شده است.
***************
🤖 @$usernamebot
🔊@$channel
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "☎️ ربات خرید شماره مجازی", 'url' => "https://t.me/$usernamebot"],
                    ],
                ]
            ])
        ]);
        $connect->query("UPDATE user SET step ='none',  numberby = '$plusby' , listby = CONCAT (listby,'^$country ➡️ $price ➡️ $time_now ⌚️ $dat_now'), numberid = '0'  WHERE id = '$from_id' LIMIT 1");
        $connect->query("DELETE FROM coduser WHERE id ='$from_id'");}
        
   else { $ddd = $user["getfile"];
   
   
    
     $get =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=setStatus&status=-1&id=$idnumber");
      $alll = explode(":", $get);
             $cros000 = "$alll[0]";
             $cod000 = "$alll[1]";
     
     
      if ($cros000 == "ACCESS_CANCEL") {
          $stock = $user["stock"];
           $plusstock = $stock + $user["price"];
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
✅ شماره با موفقیت کنسل شد.

⚠️مبلغ به کیف پول شما برگشت داده شد.
	",
        'reply_markup' => $keybord
    ]);
    $connect->query("DELETE FROM coduser WHERE id ='$from_id'");
    $connect->query("UPDATE user SET stock = '$plusstock', step = 'none' , service = '', panel = '', getfile = '' WHERE id = '$from_id' LIMIT 1");
} else {
jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
❌ لغو شماره نا موفق.

دلیل : سیستم کد رو دریافت کرده و شما پس از دریافت کد دکمه لغو رو زدید.

⚠️مبلغ از کیف پول شما کسر شد.

از طریق دکمه زیر میتونید کد رو دریافت کنید:
	",
        'reply_markup' => json_encode([
            'keyboard' => [
                        [
                            ['text' => "🔙 برگشت"]
                        ]
                    ],
            'resize_keyboard' => true
        ])
    ]);
    $connect->query("DELETE FROM coduser WHERE id ='$from_id'");
    $connect->query("UPDATE user SET step = 'none'  WHERE id = '$from_id' LIMIT 1");
}
}
}

elseif ($textmassage == "🚦 راهنما") {
    
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🚸 به بخش راهنما خوش امدید

🤗 شما با استفاده از این ربات هوشمند شماره مجازی کشور ها مختلف را به صورت ارزان خریدار می کنید.
♋️ تمام روند خرید و دریافت شماره و ثبت نام در برنامه مورد نظر کاملا اتوماتیک انجام می شود.
📴 با کم ترین هزینه ممکن در سریع ترین زمان و امن ترین حالت ممکن شماره مجازی خود را خریداری نمایید.
⚠️ در صورت بروز هرگونه مشکل با کلید بر روی دکمه پشتیبانی در منو اصلی با ما ارتباط برقرار نمایید.

🔽 از منو زیر جهت راهنمایی استفاده کنید 🔽",
            'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                        ['text' => "📲 شماره مجازی چیست؟"], ['text' => "🔔 سوالات متداول"]
                    ],
                    
                    [
                        ['text' => "💎 کسب درآمد"], ['text' => "📽 اموزش خرید"]
                    ],
                    [
                        ['text' => "ℹ️ قوانین"], ['text' => "💡 درباره"]
                    ],
                    [
                        ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
} elseif ($textmassage == "📲 شماره مجازی چیست؟") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "📱شماره مجازی چیست؟

📍هنگام ثبت‌نام در اپلیکیشن‌های پیام ‌رسان و شبکه‌های اجتماعی موبایل، باید از شماره تلفن خود به عنوان شناسه استفاده کنید. اگر از کاربرانی هستید که علاقه‌ای به اشتراک‌گذاری شماره‌ی اصلی خود ندارید یا اینکه نیاز به ثبت‌نام بیش از یک بار در این برنامه‌ها دارید، می‌توانید از شماره‌های مجازی استفاده کنید. همچنین شماره مجازی این امکان را می‌دهد که بدون ثبت سیم کارت و اهراز هویت و بدون صرف وقت و هزینه صاحب شماره از کشور های مختلف شوید.

ℹ️مزایا و کاربرد شماره مجازی چیست؟

➊ تلگرام، واتس اپ، وایبر، اینستاگرام  و... برای ثبت‌نام به شماره تلفن شما نیاز دارند تا کدفعال‌سازی مربوطه را برای تشخیص هویت به تلفن‌تان ارسال کنند که به جای شماره اصلی خود میتوان از شماره مجازی برای فعال کردن حساب خود استفاده کرد.

➋ بسیاری از افراد به دلایل مختلف مانند مدیریت یک اکانت دیگر برای مباحث کاری یا... نیاز به اکانت دوم دارند تا بتوانند در عین ارتباط داشتن با مشتریان، از تلگرام شخصی و خصوصی خود نیز استفاده کنند.
 
➌ بدون ثبت نام در اپراتور و بدون صرف وقت و هزینه و اهراز هویت صاحب شماره مجازی می شوید .

➍ استفاده در تمامی اپلیکیشن های اجتماعی با شماره از کشورهای مختلف! همراه با هویتی ناشناس

🤖 @$usernamebot",
    ]);
} 


elseif ($textmassage == "🔔 سوالات متداول") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "❓سوالات متداول

❓شماره خریدم کد نمیده چیکار کنم؟
▫️جواب : ابتدا فیلم آموزش نحوه خرید را مشاهده کنید. جهت دریافت کد پس از اطمینان از ارسال کد توسط اپلیکیشن درخواستی به شماره مورد نظر 30 ثانیه صبر کنید و سپس بر روی دکمه دریافت کد کلیک کنید ، اگر پس از گذشت 5 دقیقه از دریافت شماره، کد را دریافت نکردید بر روی دکمه بازگشت کلیک کنید سپس مجددا نسبت به دریافت شماره جدید و کد اقدام نمایید.

❓شماره رو وارد آپ کردم میگه شماره اشتباهه(مسدوده) و پیام Banned Number میدهد چکار کنم؟
▫️جواب : این حالت بیشتر برای شماره چین ، روسیه و آمریکا پیش میاد. بر روی دکمه بازگشت کلیک کنید سپس مجددا نسبت به دریافت شماره جدید و کد اقدام نمایید.

❓کد تایید گرفتم اما وارد آپ نکردم، باید چیکار کنم؟
▫️جواب : متاسفانه امکان بازگشت وجه در چنین وضعیتی وجود ندارد. چون پول شماره در پنل خارجی همزمان با دریافت کد از حساب ما کم میشود‌.

❓شماره از ربات خریدم اما بعد از چند دقیقه شماره دلیت اکانت شد علت چیه؟
▫️جواب : علت دلیت اکانت شدن شماره‌ حساس شدن تلگرام نسبت به ip شماست.
از آنجایی که تلگرام مخالف با عضو فیک است نباید بیش از 3 شماره مجازی بر روی یک ip ثبت نام کنید.
اگر قصد دارید تعداد بالا شماره مجازی خریداری و ثبت نام کنید، باید آی پی خود را پس از ثبت هر شماره تغییر دهید.
برای تغییر ip دو راه وجود دارد :
1- استفاده از فیلترشکن
2- خاموش و روشن کردن مودم ، یا خاموش و روشن کردن دیتا در تلفن همراه برای چند دقیقه موجب تغییر آی پی شما خواهد شد.

❓شماره‌ای که برای تلگرام خریدم بعد از دریافت کد یه نفر دیگه داخل اکانت بود یا two-step verification روی اکانت فعال بود، و نتوستم وارد اکانت بشم ، الان چکار کنم؟
▫️جواب : با توجه به اینکه شماره ها مستقیما از پنل های خارجی دریافت می شوند و ربات استوری نامبر تنها واسط بین کاربر و پنل است امکان بررسی شماره ها توسط ما امکان پذیر نیست! به همین علت گاها ممکن است بعد از دریافت کد اکانتی از قبل توسط شماره مورد نظر در اپلیکیشن مورد نظرتان خصوصا تلگرام فعال باشد؛ تنها راه حل برای جلوگیری از بروز این مشکل، چک کردن شماره مجازی قبل از دریافت کد است، بررسی این که شماره مجازی در اپلیکیشن مورد نظرتان قبلا ثبت شده است یا خیر به راحتی امکان پذیر است، برای تلگرام اگر شماره ثبت شده باشد بلافاصله با وارد کردن شماره در تلگرام پیغام ارسال کد به تلگرام فعال دیگر نمایش داده می شود و مانند شماره های ریجستر نشده نیست و این مورد به راحتی برای تلگرام و دیگر اپلیکیشن ها قابل بررسی است؛ در هر صورت اگر شماره ای دریافت کردید که از قبل ثبت شده بود (به ندرت پیش می آید) هرگونه عواقب آن بر عهده خریدار خواهد بود و استوری نامبر هیچ گونه مسئولیتی در رابطه با بی دقتی کاربران را برعهده نمی گیرد.

💎 سوالاتان در این بخش نبود ؟ به منوی اصلی برگردید و با پشتیبانی در تماس باشید 

🤖 @$usernamebot",
    ]);
} elseif ($textmassage == "💎 کسب درآمد") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "🔰 راهنمای کسب درآمد

🐥 با دریافت لینک مخصوص زیر مجموعه گیری خود از منو تومان رایگان؛ به ازای هر خرید زیرمجموعه های شما از ربات، اعتبار شما به میزان 10 درصد از مبلغ خریداری شده شارژ می شود.
(برای مثال؛ اگر زیر مجموعه شما 10 هزارتومان خرید کند ، حساب شما 1 هزارتومان شارژ خواهد شد)

🍁 برای مثال اگر روزانه 10 نفر از لینک شما عضو ربات شوند، و میانگین هر زیر مجموعه بطور ماهانه 10000 تومان خرید کند.
بعد از یک ماه درآمد شما 300 هزارتومان خواهد رسید!!!

🤗 با کمی تبلیغات به راحتی میتوانید میلیونر شوید. 

🙊 جهت دریافت لینک مخصوص زیر مجموعه گیری خود به منو اصلی برگشته و دکمه زیر مجموعه گیری را انتخاب نمایید.

🤖 @$usernamebot",
    ]);
} elseif ($textmassage == "ℹ️ قوانین") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "⚠️ قوانین ربات خرید شماره مجازی

➊ - پس از تحویل شماره توسط ربات بلافاصله شماره را در نرم افزار اصلی وارد کنید و بعد از 2 دقیقه کلید دریافت کد را بزنید تا کد وریفای برایتان ارسال گردد. در صورتی که پس از 5 دقیقه بعد از دریافت شماره موفق به دریافت کد نشدید دکمه بازگشت را بزنید و شماره جدید دریافت کنید.
➋ - برای هر شماره فقط یکبار کد فعالسازی از سمت اپراتور کشور ارائه دهنده ارسال میشود و مجدد کد ارسال نمیشود لذا پس از دریافت کد سریعا در نرم افزار بزنید تا کد منقضی نشود.
➌ - بر روی شماره‌های دریافتی تایید دو مرحله‌ای فعال کنید تا امنیت شماره برای شما صد در صد شود.
➍ - اغلب شماره‌های مجازی (به جز شماره‌های ستاره‌دار) دارای ۴ تا ۷ روز محدودیت هستند، پس از ۴ تا ۷ روز شما قادر به ارسال پیام به اکانت‌های ایرانی در تلگرام هستید.
➎- ساخت ربات تبچی با هر شماره‌ای اشتباه است زیرا که سیاست تلگرام این است که از تبلیغات جلوگیری کند و اگر روی شماره ها تبچی نصب کنید شماره دلیت خواهد شد.
➏ - توصیه میشود در یک روز بیش از 1 شماره مجازی روی یک دستگاه ثبت نام نکنید چون موجب دلیت شدن اکانت میشود.
➐ - تمامی شماره‌های ربات خام هستند یعنی قبل از شما ثبت نام نکرده‌اند ، به جز برخی شماره‌های کشور چین و آمریکا که برای جلوگیری از این شماره را توی تلگرام چک کنید و سپس اقدام به گرفتن کد کنید.
➑ - هنگام ثبت شماره برای اپلیکیشن تلگرام ابتدا فیلترشکن را روشن کنید سپس اقدام به دریافت شماره کنید، موقع ثبت اسم به زبان آن کشور اسم وارد کنید(نمونه اسم روسیه: привет و چین: 你好) یا از اعداد انگلیسی (...123) استفاده کنید. پس از وارد شدن به اکانت، عکس پروفایل و یوزرنیم بزارید و کانال و گروه ایجاد کنید و پست ارسال کنید و اینکه حداقل 5 دقیقه داخل اکانت باشید و فعالیت کنید و خارج نشوید.
➒ - با توجه به اینکه تلگرام مخالف عضو فیک هست لذا استوری نامبر هیچ مسئولیتی در قبال دلیت شدن اکانت (Delete account) یا لاگ اوت (Log out) شدن اکانت ندارد. همچنین پس از تحویل کد، ربات دیگر هیچ مسئولیتی در مورد شماره ندارد.
➓ - در صورت عمل نکردن به بندهای بالا عواقب آن بر عهده شماست و وجهی بازگشت داده نمی‌شود.

🤖 @$usernamebot",
    ]);
} elseif ($textmassage == "💡 درباره") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "ℹ️ درباره ربات  :

🤖 ربات شماره مجازی برنامه نویسی شده توسط حسین ویکی
🔘 تمام حقوق و متون پیام ها و سورس کد ربات محفوظ است و هر نوع کپی بر داری پیگرد قانونی دارد

🎈 برنامه نویسی شده جهت خرید شماره مجازی به صورت خودکار و سهولت در خرید شماره مجازی مطمعن و اسان

🤖 @$usernamebot",
    ]);
}

elseif ($textmassage == "👥 خرید ممبر کانال و گپ") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
خرید ممبر کانال و گپ ارزانتر از همه جا 

✅ ممبر فیک و آفلاین کانال و گپ (بدون ریزش) :

1 کا  👈 کانال : 9 تومن / گروه : 11 تومن
2 کا 👈 کانال : 17 تومن / گروه : 21 تومن
3 کا 👈 کانال : 25 تومن / گروه : 31 تومن
4 کا 👈 کانال : 32 تومن / گروه : 40 تومن
5 کا 👈 کانال : 36 تومن / گروه : 48 تومن
6 کا 👈 کانال : 43 تومن / گروه : 57 تومن
7 کا 👈 کانال : 50 تومن / گروه : 66 تومن
8 کا 👈 کانال : 57 تومن / گروه : 74 تومن
9 کا 👈 کانال : 64 تومن / گروه : 83 تومن
10 کا 👈 کانال : 72 تومن / گروه : 90 تومن

〰️〰️〰️〰️〰️〰️〰️
✅ ممبر واقعی کانال و گپ (دارای ریزش) :

هر 1 کا  👈 کانال : 17 تومن / گروه : 22 تومن

〰️〰️〰️〰️〰️〰️〰️
 جهت سفارش به آیدی زیر مراجعه کنید :
🆔 @I_love_gad
        ",
    ]);
}
//===========================================================

elseif ($data == "join") {
    $name = str_replace(["`", "*", "_", "[", "]"], ["", "", "", "", ""], $firstname);
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$fromid"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chatid,
            'text' => "عضویت شما تایید شد ✅
	
📍 اکنون میتوانید از دکمه های زیر استفاده کنید",
            'reply_markup' => $keybord
        ]);
        

        if ($usert["step"] == "pinn" ){
       $start = $usert["inviter"];
            $useryy = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$start' LIMIT 1"));
        $stoockk = $useryy["stock"];
        $pluscoin = $stoockk + $porsant;
        
        
         jijibot('sendmessage', [
            'chat_id' => "$start",
            'text' => "🌟 کاربر [$name](tg://user?id=$fromid) با استفاده از لینک دعوت شما وارد ربات شده بود اکنون عضو کانال ربات شد.  
 $porsant تومان پورسانت دریافت نمودید.
  
💰 موجودی کیف پول  شما : $pluscoin

",
            'parse_mode' => 'Markdown',
        ]);
        
          jijibot('sendmessage', [
            'chat_id' => "@$channelbc" ,
            'text' => "
🌟 کاربر [$name](tg://user?id=$fromid) با استفاده از لینک دعوت کاربر  [$start](tg://user?id=$start) وارد ربات شده  بود اکنون عضو کانال شد.
  
❄️ مبلغ  $porsant به کیف پول سر مجموعه اضافه شد.
💰 موجودی جدید سر مجموعه : $pluscoin
 
            ",
            'parse_mode' => 'Markdown',
        ]);
             $connect->query("UPDATE user SET step = 'none' WHERE id = '$fromid' LIMIT 1");
             $connect->query("UPDATE user SET stock = '$pluscoin' WHERE id = '$start' LIMIT 1");
        
        }
    } else {
        jijibot('answercallbackquery', [
            'callback_query_id' => $membercall,
            'text' => "❌ هنوز داخل کانال @$channel عضو نیستید",
            'show_alert' => true
        ]);
    }
} 

elseif ($textmassage == "🛍 خرید های من") {
    $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$from_id' LIMIT 1"));
    $listby = $user["listby"];
    $getby = explode("^", $listby);
    if (count($getby) > 1) {
        for ($z = 1; $z <= count($getby) - 1; $z++) {
            $result = $result . "$z - $getby[$z]" . "\n";
        }
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🛍 لیست تمام خرید های شما :
	
$result",
        ]);
    } else {
        jijibot('sendmessage', [
             'chat_id' => $chat_id,
            'text' => "❌ شما تاکنون خرید نکرده اید",
            
        ]);
    }
}


//==================================================
elseif ($user["step"] == "sup" && $tc == "private") {
  
        
    if(strpos($textmassage,"کص") !== false or strpos($textmassage,'گاییدم') !== false or strpos($textmassage,"کیر") !== false or strpos($textmassage,"ننتو") !== false or strpos($textmassage,"جنده") !== false or strpos($textmassage,"پدرسگ") !== false or  strpos($textmassage,'حرومزاده') !== false){
        
         $connect->query("UPDATE user SET step = 'blok' WHERE id = '$from_id' LIMIT 1");
         
    }   else{ 
        
    jijibot('ForwardMessage', [
        'chat_id' => $admin[0] ,
        'from_chat_id' => $chat_id,
        'message_id' => $message_id
    ]);
    jijibot('sendmessage', [
        'chat_id' => $admin[0] ,
        'from_chat_id' => $chat_id,
       'text' => "
👆👆👆👆👆👆
پیام بالا توسط کاربر  [$from_id](tg://user?id=$from_id)  ارسال شده است
       ",
        'parse_mode'=>"MarkDown",
         'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "📛 مسدود کردن کاربر", 'callback_data' => "blok|$from_id"]
                            ,
                            ['text' => " 💬 ارسال پاسخ به کاربر", 'callback_data' => "answer|$from_id|$message_id"]
                            
                        ],
                       
                    ],
                    'resize_keyboard' => true
                ]),
    ]);
    
 
    
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "📍 پیام شما با موفقیت ارسال شد منتظر پاسخ پشتیبانی باشید",
    ]);
    }
    }
   
//===================================

elseif (strpos($data,"blok|") !== false) {
    
     $getby05555 = explode("|", $data);
      $idd = $getby05555[1];
      
    
     jijibot('sendmessage', [
        "chat_id" => $chatid,
        "text" => "
📛 کاربر [$idd](tg://user?id=$idd)  با موفقیت از ربات محروم شد.

جهت آزاد کردن کاربر از پنل مدیریت استفاده کنید.

        ️",
         'parse_mode'=>"MarkDown",
    ]);
    
    $connect->query("UPDATE user SET step = 'blok' WHERE id = '$idd' LIMIT 1");
    
}

elseif (strpos($data,"answer|") !== false) {
    
     $getby05555 = explode("|", $data);
      $idd = $getby05555[1];
       $midd = $getby05555[2];
    
     jijibot('sendmessage', [
        "chat_id" => $chatid,
        "text" => "
پاسخ خود را ارسال نمایید : 

⚠️فقط پیام متنی قابل ارسال میباشد.
        ️"
    ]);
    
    $connect->query("UPDATE user SET step = 'answer|$idd|$midd' WHERE id = '$fromid' LIMIT 1");
    
}

elseif (strpos($user["step"],"answer|") !== false) {
    
  
  $getby05555 = explode("|", $user["step"]);
      $idd = $getby05555[1];
       $midd = $getby05555[2];
     
    jijibot('sendmessage', [
        "chat_id" => "$idd",
        'reply_to_message_id' =>"$midd",
        "text" => "
👮🏻پاسخ پشتیبان برای شما :

$textmassage

",
        'parse_mode' => 'MarkDown'
    ]);
   
     jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "پاسخ شما برای فرد ارسال شد ☑️"
    ]);
    
    $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
   
}

//===========================================================

elseif ($update->message && $update->message->reply_to_message &&( $from_id == $admin[0] or $from_id == $admin[1]) && $tc == "private" and $textmassage != "بلاک") {
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "پاسخ شما برای فرد ارسال شد ☑️"
    ]);
    jijibot('sendmessage', [
        "chat_id" => $update->message->reply_to_message->forward_from->id,
        "text" => "👮🏻پاسخ پشتیبان برای شما :

`$textmassage`",
        'parse_mode' => 'MarkDown'
    ]);
}
//=============================================== ربات ساز
elseif ($textmassage == "🤖 ربات شماره مجازی شما [ربات نمایندگی]" or $textmassage == "🔙  برگشت") {
   
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 به بخش ساخت ربات خوش اومدی.

در این قسمت میتونی به راحتی ربات اختصاصی خودتو بسازی و کسب درآمد کنی از فروش شماره.
نامبر سل تمام امکانات رو براتون فراهم میکنه.

دو نوع ربات میتونی بسازی :
🥇 ربات شماره مجازی  با درگاه اختصاصی 
🥈 ربات شماره مجازی  با درگاه نامبرینو 

تو بخش راهنمای همین بخش میتونید اطلاعات بیشتر کسب کنید که فرقشون چیه.👇👇

نمونه ربات ساخته شده با نامبرینو 👈👈👈👈 @Kalmatibot
            ",
             'reply_markup' => json_encode([
            'keyboard' => [
                [
                     ['text' => "💻 پنل فروش"], ['text' => "🥇 ساخت ربات"]
                ],
                 
                [
                    ['text' => "🔙 برگشت"], ['text' => "🚦 راهنمای ساخت ربات"]
                ],
            ],
            'resize_keyboard' => true
        ])
        ]);$connect->query("UPDATE user SET step = '' , price = '' WHERE id = '$from_id' LIMIT 1");
    
}
elseif ($textmassage == '🚦 راهنمای ساخت ربات' ) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 به بخش راهنمای ساخت ربات خوش اومدی.

یکی از گزینه های زیر رو انتخاب کن 👇👇
            ",
             'reply_markup' => json_encode([
            'keyboard' => [
                 [
                    ['text' => "چطور با نامبرینو رباتمو بسازم؟"]
                ],
                [
                    ['text' => "🥇 ربات درگاه نمایندگی چیه ؟"]
                ],
                [
                    ['text' => "🔙  برگشت"], ['text' => "🤖 توکن ربات چیست؟"]
                ],
                
            ],
            'resize_keyboard' => true
        ])
        ]);
}
elseif ($textmassage == 'چطور با نامبرینو رباتمو بسازم؟' ) {
      
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
لینک فایل ویدیو ساخت ربات نمایندگی در نامبرینو

رو لینک بزن ویدیو آموزشی رو ببین 👇👇

https://t.me/sellnumbers20/280
            ",
        ]);
}

elseif ($textmassage == '🥇 ربات درگاه نمایندگی چیه ؟' ) {
       
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
🥇 ربات شماره مجازی با درگاه اختصاصی 


امکانات :
 
✅ فروش شماره مجازی : نامحدود
✅  بدون نیاز به درگاه زرین پال
✅ نیاز به شارژ پنل 
✅ امکان ارائه ربات نمایندگی
✅ دریافت پورسانت ربات نمایندگی تا 2 لول
✅ امکان فوروارد پیام به همه کاربران 
✅ امکان ارسال پیام به همه کاربران 
✅ امکان ارسال پیام به کاربر خاص 
✅ قابلیت تنظیم اتصال به کانال ربات 
✅ بخش پشتیبانی کاربران 
✅امکان زیر مجموعه گیری 
✅ امکان افزایش یا کاهش موجودی کاربران 
✅ امکان تنظیم قیمت های فروش 
✅ امکان ارسال و فوروارد پیام به نمایندگان 
✅ امکان مشاهده لیست نمایندگان 
✅ قابلیت پشتیبانی از مشتریان از داخل ربات
✅ امکان تنظیم متن و عکس بنر زیرمجموعه گیری
✅ ارسال گزارش فروش نمایندگان شما به کانال شما
✅ امکان تنظیم پورسانت زیر مجموعه گیری
✅ امکان ساخت و باطل کردن  کد یکبار مصرف ساخت ربات نمایندگی
✅ امکان فروش شارژ سیمکارت های همراه اول و ایرانسل و رایتل به صورت مستقیم و پین
✅ دارای کنترل مرکز برای روشن و خاموش کردن بخش های مختلف ربات
✅ امکان شارژ پنل ربات و درخواست تسفیه از داخل پنل مدیریت ربات خود
✅ و کلی امکانت دیگر ...
تسلط کامل بر همه بخش های ربات.


〰️〰️〰️〰️〰️〰️〰️〰️
توضیحات :  
در این نوع ربات شما باید پنل فروشتون رو داخل ربات خودتون  شارژ کنید تا بتونید شماره بفروشید.
تقریبا 95% ربات مستقل هستش و فقط نیاز به شارژ پنل در ربات نامبرینو دارید.
〰️〰️〰️〰️〰️〰️〰️〰️
❗️ برای شارژ پنل باید از طریق پنل مدیریت داخل ربات خودتون  اقدام کنید.
❗️برای دسترسی به پنل مدیریت ، داخل ربات خود کافیه کلمه پنل  رو ارسال کنید تا پنلتون ظاهر بشه.
            ",
            
        ]);
    
}
elseif ($textmassage == '🤖 توکن ربات چیست؟' ) {
       
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
🤖 توکن ربات چیست؟
توکن در واقع رمز اتصال شما به رباتتون هستش بر روی سرور های تلگرام.

💢 چچور یه ربات روی سرور تلگرام بسازید و توکن رو بگیرید؟

1️⃣ به ربات @BotFather مراجعه کنید.
2️⃣ ربات رو /start کنید.
3️⃣ دستور /newbot رو ارسال کنید برای ساخت ربات جدید.
4️⃣ سپس بوت فادر از شما میخواد یه نام برای رباتتون انتخاب کنید. هر اسمی که میخواید.
5️⃣ سپس بوت فادر از شما میخواد یه یوزنیم برای رباتتون انتخاب کنید. یوزر نیم هرچی که میدید حتما آخرش باید bot داشته باشه. برای مثال : sellnumberbot
6️⃣ تبریک شما با موفقیت رباتتون رو ساختید . حالا بوت فادر یه پیام مانند نمونه  زیر  براتون فرستاده که حاوی توکن ربات شما هستش 👇👇

Use this token to access the HTTP API:
900371469:AAFo1LEF5Yjy8T5ZARmgYM3RqZ74-Jz7Tu9
            ",
            
        ]);
   
}
elseif ($textmassage == "🥈 ساخت ربات نقره ای" ) {
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
💢 ساخت ربات نقره با طلایی ادغام شده . با ساخت ربات طلایی میتونید از امکانت بالا و بدون استفاده از درگاه شخصی استفاده کنید.
        ",]);
}
elseif ($textmassage == '🥈 .ساخت ربات نقره ای' ) {
       if ($adminsql["id"] != true){
           
           if($from_id == "$admin[0]" or $from_id == "$admin[1]"){
               
                 jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
💢 توکن ربات خود را که در بوت فادر ساخته اید ارسال نمایید .
درصورتی که اطلاعات کافی در مورد توکن ندارید میتونوانید از دکمه راهنمای ساخت ربات استفاده کنید.
مانند نمونه زیر:

900371469:AAFo1LEF5Yjy8T5ZARmgYM3RqZ74-Jz7Tu9
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙  برگشت"],['text' => "🚦 راهنمای ساخت ربات"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
    $connect->query("UPDATE user SET step = 'sendtoken' , price = '' WHERE id = '$from_id' LIMIT 1");
           }else {
       $sqqq = $jseting["set"]["pricbotn"];
         $connect->query("UPDATE user SET price = '$sqqq', step = 'bybotn' WHERE id = '$from_id' LIMIT 1");
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
⭕️ برای ساخت ربات نقره ای شماره مجازی بایذ مبلغ $sqqq تومان پرداخت کنید. یکبار برای همیشه.

❗️ این مبلغ برای جلوگیری از ساخت ربات های هرزنامه و بی جهت در نظر گرفته شده است.

❗️ جهت پرداخت و ساخت ربات روی دکمه پرداخت زیر بزنید. پس از پرداخت ربات از شما توکن خواهد خواست برای ساخت ربات.👇👇

⚠️⚠️⚠️ اگر پول رو کارت به کارت کردید و پشتیبانی بهتون کد یکبار مصرف ساخت ربات داده ، ارسال کنید کد رو :
            ",
             'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "💸 پرداخت", 'url' => "$web/pay/pay.php?amount=$sqqq&callback=$web/pay/back-botno.php?user=$from_id"]
                        ],
                         [
                            ['text' => "❌ انصراف", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
      } }else{
    $uu = $adminsql["userbot"];
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
⚠️ شما به محدودیت ساخت ربات در نامبرینو رسیده اید .

❗️هر کاربر حداکثر میتواند 1 ربات در نامبرینو بسازد.
〰️〰️〰️〰️〰️〰️〰️
لیست ربات های شما :
1 - @$uu
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"],['text' => "❌ حذف ربات من"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]); $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}   
}
elseif ($textmassage == '🥇 ساخت ربات') {
       if ($adminsql["id"] != true){
           
           if($from_id == "$admin[0]" or $from_id == "$admin[1]"){
               
                 jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
💢 توکن ربات خود را که در بوت فادر ساخته اید ارسال نمایید .
درصورتی که اطلاعات کافی در مورد توکن ندارید میتونوانید از دکمه راهنمای ساخت ربات استفاده کنید.
مانند نمونه زیر:

900371469:AAFo1LEF5Yjy8T5ZARmgYM3RqZ74-Jz7Tu9
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙  برگشت"],['text' => "🚦 راهنمای ساخت ربات"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
    $connect->query("UPDATE user SET step = 'sendtokent' , price = '' WHERE id = '$from_id' LIMIT 1");
           }else {
               
       $sqqq = $jseting["set"]["pricbottala"];
        
           $time1 = getramz();  
            $connect->query("UPDATE user SET getfile = '$time1',price = '$sqqq', step = 'bybottala' WHERE id = '$from_id' LIMIT 1");
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
⭕️ برای ساخت ربات طلایی شماره مجازی بایذ مبلغ $sqqq تومان پرداخت کنید. یکبار برای همیشه.

❗️ این مبلغ برای جلوگیری از ساخت ربات های هرزنامه و بی جهت در نظر گرفته شده است.
(در واقعیت افراد کمی حاضرن این مبلغو پرداخت کنند برای ساخت ربات طلایی ، این یعنی رقیب کمتر و فروش بیشتر که به نفع همه سازنده ها هستش😉)

❗️ جهت پرداخت و ساخت ربات روی دکمه پرداخت زیر بزنید. پس از پرداخت ربات از شما توکن خواهد خواست برای ساخت ربات.👇👇

⚠️⚠️⚠️ اگر پول رو کارت به کارت کردید و پشتیبانی بهتون کد یکبار مصرف ساخت ربات داده ، ارسال کنید کد رو :
            ",
             'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "💸 پرداخت", 'url' => "$web/pay/pay.php?amount=$sqqq&user=$from_id&r=$time1&callback=$web/pay/back-bottala.php?user=$from_id"]
                        ],
                         [
                            ['text' => "❌ انصراف", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
      } }else{
    $uu = $adminsql["userbot"];
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
⚠️ شما به محدودیت ساخت ربات در نامبرینو رسیده اید .

❗️هر کاربر حداکثر میتواند 1 ربات در نامبرینو بسازد.
〰️〰️〰️〰️〰️〰️〰️
لیست ربات های شما :
1 - @$uu
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"],['text' => "❌ حذف ربات من"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]); $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}   
}
elseif ($textmassage == '💻 پنل فروش' or $textmassage == 'پنل فروش') {
  if ( $adminsql["id"] == true) {
       $usertypbot = $adminsql["typ"];
          if($usertypbot == "1"){
       
       
      $usernbot = $adminsql["userbot"];
      $usernnbot = $adminsql["allsellprice"];
      $usernnnbot = $adminsql["allnum"];
      $usernnnnbot = $adminsql["stock"];
      
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 به پنل فروش خوش اومدی .

مشخصات و آمار ربات های شما :

💠 تعداد ربات های ثبت شده شما 1 عدد
💠 یوزرنیم ربات شما : @$usernbot
💠 مبلغ کل فروش شما : $usernnbot تومان
💠 تعداد شماره های فروخته شده : $usernnnbot عدد
🥈 نوع ربات #نقره‌ای
✳️ موجودی حاصل از فروش شما : $usernnnnbot تومان
            ",
             'reply_markup' => json_encode([
            'keyboard' => [
                [
                    ['text' => "💸 درخواست تسفیه"], ['text' => "❌ حذف ربات من"]
                ],
                
                [
                    ['text' => "🔙 برگشت"], ['text' => "👮🏻 پشتیبانی"]
                ],
                
            ],
            'resize_keyboard' => true
        ])
        ]);} else {
            
             $usernbot = $adminsql["userbot"];
      $usernnbot = $adminsql["allsellprice"];
      $usernnnbot = $adminsql["allnum"];
      $usernnnnbot = $adminsql["sharg"];
       $usernnnnssbot = $adminsql["stock"];
      
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 به پنل فروش خوش اومدی .

مشخصات و آمار ربات های شما :

💠 تعداد ربات های ثبت شده شما 1 عدد
💠 یوزرنیم ربات شما : @$usernbot
💠 مبلغ کل فروش شما : $usernnbot تومان
💠 تعداد شماره های فروخته شده : $usernnnbot عدد
🥇 نوع ربات #طلایی

✳️ موجودی فروش شما جهت انجام تسفیه : $usernnnnssbot تومان
✳️ باقی مانده شارژ پنل شما : $usernnnnbot تومان
.
            ",
             'reply_markup' => json_encode([
            'keyboard' => [
               
                 [
                    ['text' => "❌ حذف ربات من"]
                ],
                [
                    ['text' => "🔙 برگشت"], ['text' => "👮🏻 پشتیبانی"]
                ],
                
            ],
            'resize_keyboard' => true
        ])
        ]);
        }
  }else {
      jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
⚠️ شما هیچ ربات ثبت شده ای در نامبرینو ندارید.
            ", ]);
  }
  
}


elseif ( $textmassage == "$oneramzbot" && $user["step"] == 'bybotn') {
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
💢 توکن ربات خود را که در بوت فادر ساخته اید ارسال نمایید .
درصورتی که اطلاعات کافی در مورد توکن ندارید میتونوانید از دکمه راهنمای ساخت ربات استفاده کنید.
مانند نمونه زیر:

900371469:AAFo1LEF5Yjy8T5ZARmgYM3RqZ74-Jz7Tu9
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙  برگشت"],['text' => "🚦 راهنمای ساخت ربات"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
    $connect->query("UPDATE user SET step = 'sendtoken' , price = '' WHERE id = '$from_id' LIMIT 1");
     $jseting = json_decode(file_get_contents("data/seting.json"),true);	
 $jseting["set"]["oneramzbot"] = "";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
}
elseif ( $textmassage == "$oneramzbottala" and $user["step"] == 'bybottala' and $update->message->text) {
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
💢 توکن ربات خود را که در بوت فادر ساخته اید جهت ساخت ربات طلایی ارسال نمایید .
درصورتی که اطلاعات کافی در مورد توکن ندارید میتونوانید از دکمه راهنمای ساخت ربات استفاده کنید.
مانند نمونه زیر:

900371469:AAFo1LEF5Yjy8T5ZARmgYM3RqZ74-Jz7Tu9
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙  برگشت"],['text' => "🚦 راهنمای ساخت ربات"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
    $connect->query("UPDATE user SET step = 'sendtokent' , price = '' WHERE id = '$from_id' LIMIT 1");
     $jseting = json_decode(file_get_contents("data/seting.json"),true);	
 $jseting["set"]["oneramzbottala"] = "";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
}
elseif ( $user["step"] == "sendtoken" ) {
    
    $token = "$textmassage";
    
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
function objectToArrays( $object )
{if( !is_object( $object ) && !is_array( $object ) )
{return $object;}
if( is_object( $object ) )
{$object = get_object_vars( $object );}
return array_map( "objectToArrays", $object );
}

$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 'true'){
    
     jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
❗️توکن نامعتبر❗
$ee
        "]);
}else{
    if ($adminsql["id"] != true){
       jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
🚩در حال ساخت ربات 🚩
        "]);
$sq = "https://midasbuy.cam/bots/numberino/bots/$un";
$connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
     if (!file_exists("bots/$un/bottpodkrtirtoy.php")){
         mkdir("bots/$un");
         mkdir("bots/$un/data");
         mkdir("bots/$un/pay");
         $source = file_get_contents("sorcsbot.php");
     $source = str_replace("[*BOTTOKEN*]",$token,$source);
     $source = str_replace("[*ADMIN*]",$from_id,$source);
     $source = str_replace("[*ADRESSBOT*]",$sq,$source);
     $source = str_replace("[*usernamebot*]",$un,$source);
     file_put_contents("bots/$un/bottpodkrtirtoy.php",$source); 
     $source20 = file_get_contents("jdf.php");
     file_put_contents("bots/$un/jdf.php",$source20);
     $source1 = file_get_contents("paybots/back-1000.php");
      file_put_contents("bots/$un/pay/back-1000.php",$source1); 
     $source2 = file_get_contents("paybots/back-10000.php");
      file_put_contents("bots/$un/pay/back-10000.php",$source2);
     $source3 = file_get_contents("paybots/back-2000.php");
      file_put_contents("bots/$un/pay/back-2000.php",$source3);
     $source4 = file_get_contents("paybots/back-20000.php");
      file_put_contents("bots/$un/pay/back-20000.php",$source4);
     $source5 = file_get_contents("paybots/back-3000.php.php");
      file_put_contents("bots/$un/pay/back-3000.php",$source5);
     $source6 = file_get_contents("paybots/back-5000.php");
      file_put_contents("bots/$un/pay/back-5000.php",$source6);
     $source7 = file_get_contents("paybots/back-ss.php");
      file_put_contents("bots/$un/pay/back-ss.php",$source7);
     $source8 = file_get_contents("paybots/pay.php");
      file_put_contents("bots/$un/pay/pay.php",$source8);
     $source9 = file_get_contents("paybots/index.html");
      file_put_contents("bots/$un/pay/index.html",$source9);
     
file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=$web/bots/$un/bottpodkrtirtoy.php");
if ($adminsql["id"] != true) {
        $connect->query("INSERT INTO `admin` (`id`, `userbot`, `allsellprice`, `allnum`, `dsod`, `stock`,`token`, `typ`,`sharg`) VALUES ('$from_id', '$un', '0', '0', '600', '0', '$token', '1', '0')");
    }
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "

✅ ربات شما با موفقیت ساخته شد .
 
 آیدی ربات شما :
 🆔 @$un
 
 ❗️ وارد ربات خود شده و /start کنید
❗️ جهت مشاهده پنل مدیریت کلمه پنل را به ربات ارسال کنید.

⚠️ قبل از هر کاری ابتدا کانال ربات خود را از قسمت پنل مدیریت تنظیم کنید.
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
    
}else{
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
⚠️ ربات به آیدی @un از قبل در نامبرینو ثبت شده است.

لطفا آیدی ربات را تغییر دهید و دوباره ارسال نمایید توکن را: 

        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
}
    }else{
    $uu = $adminsql["userbot"];
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
⚠️ شما به محدودیت ساخت ربات در نامبرینو رسیده اید .

❗️هر کاربر حداکثر میتواند 1 ربات در نامبرینو بسازد.
〰️〰️〰️〰️〰️〰️〰️
لیست ربات های شما :
1 - @$uu
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"],['text' => "❌ حذف ربات من"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]); $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}   
}
    
}


elseif ( $user["step"] == "sendtokent" ) {
    
    $token = "$textmassage";
    
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
function objectToArrays( $object )
{if( !is_object( $object ) && !is_array( $object ) )
{return $object;}
if( is_object( $object ) )
{$object = get_object_vars( $object );}
return array_map( "objectToArrays", $object );
}

$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 'true'){
    
     jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
❗️توکن نامعتبر❗
$ee
        "]);
}else{
    if ($adminsql["id"] != true){
       jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
🚩در حال پردازش توکن ربات 🚩
        "]);
$sq = "https://midasbuy.cam/bots/numberino/bots/$un";
$connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
     if (!file_exists("bots/$un/bot.php")){
         mkdir("bots/$un");
         mkdir("bots/$un/data");
         mkdir("bots/$un/pay");
         $source = file_get_contents("sorcsbot2.php");
     $source = str_replace("[*BOTTOKEN*]",$token,$source);
     $source = str_replace("[*ADMIN*]",$from_id,$source);
     $source = str_replace("[*ADRESSBOT*]",$sq,$source);
     $source = str_replace("[*usernamebot*]",$un,$source);
     file_put_contents("bots/$un/bottpodkrtirtoy.php",$source);
     
      $source00 = file_get_contents("listnama.txt");
     file_put_contents("bots/$un/data/listnama.txt",$source00);
     
       $source2 = file_get_contents("jdf.php");
     file_put_contents("bots/$un/jdf.php",$source2); 
    
     $source22 = file_get_contents("codbots.php");
     file_put_contents("bots/$un/codbots.php",$source22); 
     
      $source23 = file_get_contents("index.html");
     file_put_contents("bots/$un/index.html",$source23); 
     
      $source22s = file_get_contents("smpbots.php");
     file_put_contents("bots/$un/smpbots.php",$source22s);
     
      $source22ss = file_get_contents("listsharg.txt");
     file_put_contents("bots/$un/data/listsharg.txt",$source22ss);
     
file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=$web/bots/$un/bottpodkrtirtoy.php");
if ($adminsql["id"] != true) {
        $connect->query("INSERT INTO `admin` (`id`, `userbot`, `allsellprice`, `allnum`, `dsod`, `stock`,`token`, `typ`,`sharg`) VALUES ('$from_id', '$un', '0', '0', 'new', '0', '$token', '2', '0')");
    }
    
    $marchandid = "724f776b-500b-4559-9b2c-9d659c892288" ;
    
 $source7dd = file_get_contents("paybots2/back-ss.php");
      $source7dd = str_replace("[*MAR*]",$marchandid,$source7dd);
      file_put_contents("bots/$un/pay/back-ss.php",$source7dd);
      
 $source8dd = file_get_contents("paybots2/pay.php");
      $source8dd = str_replace("[*MAR*]",$marchandid,$source8dd);
      file_put_contents("bots/$un/pay/pay.php",$source8dd);
      
$source9dd = file_get_contents("paybots2/index.html");
      $source9dd = str_replace("[*MAR*]",$marchandid,$source9dd);
      file_put_contents("bots/$un/pay/index.html",$source9dd);
    
    
     $source9ddss = file_get_contents("paybots2/back-bottala.php");
      $source9ddss = str_replace("[*MAR*]",$marchandid,$source9ddss);
      file_put_contents("bots/$un/pay/back-bottala.php",$source9ddss);
      
       $source9ddssff = file_get_contents("paybots2/back-up.php");
      $source9ddssff = str_replace("[*MAR*]",$marchandid,$source9ddssff);
      file_put_contents("bots/$un/pay/back-up.php",$source9ddssff);
      
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
✅  ربات شما با موفقیت ساخته شد.

آیدی ربات شما :
🆔 @$un
 
❗️ وارد ربات خود شده و /start کنید
❗️ جهت مشاهده پنل مدیریت کلمه پنل را به ربات ارسال کنید.

⚠️ قبل از هر کاری ابتدا کانال ربات خود را از قسمت پنل مدیریت تنظیم کنید.
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
    
  jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
نماینده گرامی نامبرینو

جهت تعامل بین نمایندگانمون ما یک گروهی ایجاد کردیم برای افزایش فروشتون.
داخل این گروه میتونید از راه و روش های دیگران و همچنین آموزش های مدیر نامبرینو جهت افزایش فروش خود استفاده کنید.

لینک گروه 👇👇
https://t.me/joinchat/ZUXd7aVOkTxhYjg0

⚠️ عضویت در این گروه برای نمایندگان #اجباریست .
        ",
       
    ]);
    
     jijibot('sendmessage', [
        "chat_id" => "$admin[0]",
        "text" => "
✅  یک ربات طلایی با موفقیت ساخته شد

مشخصات :
آیدی سازنده : $from_id
آیدی ربات : @$un
        ",
    ]);
    
}else{
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
⚠️ ربات به آیدی @un از قبل در نامبرینو ثبت شده است.

لطفا آیدی ربات را تغییر دهید و دوباره ارسال نمایید توکن را: 
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
}
    }else{
    $uu = $adminsql["userbot"];
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
⚠️ شما به محدودیت ساخت ربات در نامبرینو رسیده اید .

❗️هر کاربر حداکثر میتواند 1 ربات در نامبرینو بسازد.
〰️〰️〰️〰️〰️〰️〰️
لیست ربات های شما :
1 - @$uu
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"],['text' => "❌ حذف ربات من"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]); $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}   
}
    
}
elseif ( $user["step"] == "sendmaechandt" ) {
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
🚩در حال ساخت ربات 🚩
        "]);
        
        if($textmassage == "درگاه ندارم"){
            $un = $adminsql["userbot"];
    $marchandid = "724f776b-500b-4559-9b2c-9d659c892288" ;
     $source1 = file_get_contents("paybots2/back-1000.php");
      $source1 = str_replace("[*MAR*]",$marchandid,$source1);
      file_put_contents("bots/$un/pay/back-1000.php",$source1);
      
     $source2 = file_get_contents("paybots2/back-10000.php");
      $source2 = str_replace("[*MAR*]",$marchandid,$source2);
      file_put_contents("bots/$un/pay/back-10000.php",$source2);
      
     $source3 = file_get_contents("paybots2/back-2000.php");
      $source3 = str_replace("[*MAR*]",$marchandid,$source3);
      file_put_contents("bots/$un/pay/back-2000.php",$source3);
      
     $source4 = file_get_contents("paybots2/back-20000.php");
      $source4 = str_replace("[*MAR*]",$marchandid,$source4);
      file_put_contents("bots/$un/pay/back-20000.php",$source4);
      
     $source5 = file_get_contents("paybots2/back-3000.php.php");
      $source5 = str_replace("[*MAR*]",$marchandid,$source5);
      file_put_contents("bots/$un/pay/back-3000.php",$source5);
      
     $source6 = file_get_contents("paybots2/back-5000.php");
      $source6 = str_replace("[*MAR*]",$marchandid,$source6);
      file_put_contents("bots/$un/pay/back-5000.php",$source6);
      
     $source7 = file_get_contents("paybots2/back-ss.php");
      $source7 = str_replace("[*MAR*]",$marchandid,$source7);
      file_put_contents("bots/$un/pay/back-ss.php",$source7);
      
     $source8 = file_get_contents("paybots2/pay.php");
      $source8 = str_replace("[*MAR*]",$marchandid,$source8);
      file_put_contents("bots/$un/pay/pay.php",$source8);
      
     $source9 = file_get_contents("paybots2/index.html");
      $source9 = str_replace("[*MAR*]",$marchandid,$source9);
      file_put_contents("bots/$un/pay/index.html",$source9);
      
       
      
      jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
✅  ربات شما با موفقیت ساخته شد.

آیدی ربات شما :
🆔 @$un
 
❗️ وارد ربات خود شده و /start کنید
❗️ جهت مشاهده پنل مدیریت کلمه پنل را به ربات ارسال کنید.

⚠️ قبل از هر کاری ابتدا کانال ربات خود را از قسمت پنل مدیریت تنظیم کنید.
        ",
        ]);
            
        } else {
    $un = $adminsql["userbot"];
    $marchandid = "724f776b-500b-4559-9b2c-9d659c892288" ;
     $source1 = file_get_contents("paybots2/back-1000.php");
      $source1 = str_replace("[*MAR*]",$marchandid,$source1);
      file_put_contents("bots/$un/pay/back-1000.php",$source1);
      
     $source2 = file_get_contents("paybots2/back-10000.php");
      $source2 = str_replace("[*MAR*]",$marchandid,$source2);
      file_put_contents("bots/$un/pay/back-10000.php",$source2);
      
     $source3 = file_get_contents("paybots2/back-2000.php");
      $source3 = str_replace("[*MAR*]",$marchandid,$source3);
      file_put_contents("bots/$un/pay/back-2000.php",$source3);
      
     $source4 = file_get_contents("paybots2/back-20000.php");
      $source4 = str_replace("[*MAR*]",$marchandid,$source4);
      file_put_contents("bots/$un/pay/back-20000.php",$source4);
      
     $source5 = file_get_contents("paybots2/back-3000.php.php");
      $source5 = str_replace("[*MAR*]",$marchandid,$source5);
      file_put_contents("bots/$un/pay/back-3000.php",$source5);
      
     $source6 = file_get_contents("paybots2/back-5000.php");
      $source6 = str_replace("[*MAR*]",$marchandid,$source6);
      file_put_contents("bots/$un/pay/back-5000.php",$source6);
      
     $source7 = file_get_contents("paybots2/back-ss.php");
      $source7 = str_replace("[*MAR*]",$marchandid,$source7);
      file_put_contents("bots/$un/pay/back-ss.php",$source7);
      
     $source8 = file_get_contents("paybots2/pay.php");
      $source8 = str_replace("[*MAR*]",$marchandid,$source8);
      file_put_contents("bots/$un/pay/pay.php",$source8);
      
     $source9 = file_get_contents("paybots2/index.html");
      $source9 = str_replace("[*MAR*]",$marchandid,$source9);
      file_put_contents("bots/$un/pay/index.html",$source9);
      
      jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
✅ مرچند آیدی زرین پال با موفقیت تنظیم شد .

ربات شما با موفقیت ساخته شد.

آیدی ربات شما :
🆔 @$un
 
❗️ وارد ربات خود شده و /start کنید
❗️ جهت مشاهده پنل مدیریت کلمه پنل را به ربات ارسال کنید.

⚠️ قبل از هر کاری ابتدا کانال ربات خود را از قسمت پنل مدیریت تنظیم کنید.
        ",
        ]);}
        $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}
elseif ( $textmassage == "❌ حذف ربات من" ) {
     $un = $adminsql["userbot"];
     
     jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
⚠️ شما قصد پاک کردن ربات خود به آیدی @$un را دارید. 
❗️ ربات شما دیگر قابل بازگردانی نخواهد بود.

آیا از حذف ربات خود مطمئن میباشید؟      
        ",
         'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                    ['text' => "🔙 برگشت"], ['text' => "✅  بله"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
}
elseif ( $textmassage == "✅  بله" ) {
    $un = $adminsql["userbot"];
    $token = $adminsql["token"];
    if ($adminsql["id"] == "$from_id"){
        file_get_contents("http://api.telegram.org/bot".$token."/deletewebhook?url=$web/bots/$un/bot.php");
       $path ="bots/$un";
         $pathdata ="bots/$un/data";
         $pathpay ="bots/$un/pay";
     
$directory_handle2 = opendir("$pathdata");
while($directory_item = readdir($directory_handle2)) {
@unlink("$pathdata/".$directory_item);
}
$directory_handle3 = opendir("$pathpay");
while($directory_item = readdir($directory_handle3)) {
@unlink("$pathpay/".$directory_item);
}
closedir($directory_handle3);
rmdir("$pathpay");

closedir($directory_handle2);
rmdir("$pathdata");

$directory_handle1 = opendir("$path");
while($directory_item = readdir($directory_handle1)) {
@unlink("$path/"."$directory_item");
}

closedir($directory_handle1);
rmdir("$path");

    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
ربات شما به آیدی @$un با موفقیت پاک شد
        ",
         'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
     $connect->query("DELETE FROM admin WHERE id ='$from_id'");
    $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
    }else {
     
        jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
شما هیچ ربات ثبت شده ای ندارید.
        "
    ]);
    }
    }

//=========================================================================================== 

//panel admin
elseif ( in_array($from_id, $admin) or in_array($fromid, $admin)){
if ($textmassage == "/panel" or $textmassage == "پنل") {
    
  
   
    
    if ($tc == "private") {
        if (in_array($from_id, $admin)) {
            
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'disable_notification' => true ,
                'text' => "🚦 ادمین عزیز به پنل مدریت ربات خوش امدید
               
                $time1
                
                ",
                'reply_markup' => json_encode([
                    'keyboard' => [
                        [
                            ['text' => "📍 امار ربات"], ['text' => "📍 شارژ پنل"]
                        ],
                        [
                            ['text' => "📍 ارسال پیام"],  ['text' => "👥 مدیریت کاربران"]
                        ],
                        
                        [
                            ['text' => "⛔️ توقف فروش"],  ['text' => "❎ شروع فروش"]
                        ],
                         [
                            ['text' => "⛔️ توقف فروش نمایندگی ها"],  ['text' => "❎ شروع فروش نمایندگی ها"]
                        ],
                       
                        [
                            ['text' => "💸 تعیین قیمت روبل"],['text' =>"💸 تعیین قیمت ممبر"]
                        ],
                        [
                            ['text' => "💸 پورسانت زیر مجموعه گیری 👥"] ,  ['text' => "📍 لیست نمایندگی ها"]
                        ],
                        [
                            ['text' => "🛒 شارژهای فروخته شده"],['text' => "💵 پرداختی های ربات"]
                        ],
                         [
                             ['text' => "☑️ پیگیری سفارش ممبر"],   ['text' => "📍تعیین مبلغ خرید ربات طلایی"]
                        ],
                        [
                            ['text' => "📍 افزایش | کاهش موجودی پنل طلایی"]
                        ],
                         [
                            ['text' => "💳 پیگیری پرداخت"]
                        ],
                         [
                            ['text' => "📟 کد یکبار مصرف رباتساز طلایی"]
                        ],
                        
                         [
                            ['text' => "📢 تنظیم کانال ربات"]
                        ],
                        [
                            ['text' => "خروج از پنل"]
                        ],
                    ],
                    'resize_keyboard' => true
                ])
            ]);
        }
        
    }
}
elseif ( $textmassage == "📍 ارسال پیام") {
    if ($tc == "private") {
        if (in_array($from_id, $admin)) {
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "🚦 رِئیس به کیا میخوای بفرستی؟",
                'reply_markup' => json_encode([
                    'keyboard' => [
                        [
                            ['text' => "📍 ارسال به نمایندگان"], ['text' => "📍 فروارد به نمایندگان"]
                        ],
                        [
                            ['text' => "📍 ارسال به همه"], ['text' => "📍 فروارد همگانی"]
                        ],
                       [
                             ['text' => "📨 ارسال پیام به کاربر"]
                        ],
                        [
                             ['text' => "برگشت 🔙"],['text' => "خروج از پنل"]
                        ],
                    ],
                    'resize_keyboard' => true
                ])
            ]);
        }
        
    }
}
elseif ( $textmassage == "👥 مدیریت کاربران") {
    if ($tc == "private") {
        if (in_array($from_id, $admin)) {
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "🚦 رِئیس به کیا میخوای بفرستی؟",
                'reply_markup' => json_encode([
                    'keyboard' => [
                        [
                            ['text' => "⁉️ اطلاعات کاربر"], ['text' => "📍 افزایش | کاهش موجودی"]
                        ],
                        [
                            ['text' => "☠️افزودن کاربر به لیست سیاه"]   ,
                            ['text' => "حذف از لیست سیاه"]
                        ],
                      
                        [
                             ['text' => "برگشت 🔙"],['text' => "خروج از پنل"]
                        ],
                    ],
                    'resize_keyboard' => true
                ])
            ]);
        }
        
    }
}
elseif ($textmassage == "برگشت 🔙") {
    if ($tc == "private") {
        if (in_array($from_id, $admin)) {
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "🚦 به منوی مدیریت بازگشتید",
                'reply_markup' => json_encode([
                    'keyboard' => [
                        [
                            ['text' => "📍 امار ربات"], ['text' => "📍 شارژ پنل"]
                        ],
                        [
                            ['text' => "📍 ارسال پیام"],  ['text' => "👥 مدیریت کاربران"]
                        ],
                        
                        [
                            ['text' => "⛔️ توقف فروش"],  ['text' => "❎ شروع فروش"]
                        ],
                         [
                            ['text' => "⛔️ توقف فروش نمایندگی ها"],  ['text' => "❎ شروع فروش نمایندگی ها"]
                        ],
                       
                        [
                            ['text' => "💸 تعیین قیمت روبل"],['text' =>"💸 تعیین قیمت ممبر"]
                        ],
                        [
                            ['text' => "💸 پورسانت زیر مجموعه گیری 👥"] ,  ['text' => "📍 لیست نمایندگی ها"]
                        ],
                        [
                            ['text' => "🛒 شارژهای فروخته شده"],['text' => "💵 پرداختی های ربات"]
                        ],
                         [
                             ['text' => "☑️ پیگیری سفارش ممبر"],   ['text' => "📍تعیین مبلغ خرید ربات طلایی"]
                        ],
                        [
                            ['text' => "📍 افزایش | کاهش موجودی پنل طلایی"]
                        ],
                         [
                            ['text' => "💳 پیگیری پرداخت"]
                        ],
                         [
                            ['text' => "📟 کد یکبار مصرف رباتساز طلایی"]
                        ],
                        
                         [
                            ['text' => "📢 تنظیم کانال ربات"]
                        ],
                        [
                            ['text' => "خروج از پنل"]
                        ],
                    ],
                    'resize_keyboard' => true
                ])
            ]);
            $connect->query("UPDATE user SET step = 'none' , getfile = '0' WHERE id = '$from_id' LIMIT 1");
        }
    }
} 
 if($textmassage =="g1"){
    
        if (in_array($from_id, $admin)) {
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
به بخش وبسرویس ربات نامبرینو خوش اومدید. 

❗️ این قسمت مخصوص توسعه دهندگان میباشد.(افرادی که دانش کافی براس ساخت ربات ، سایت ، اپلکیشن دارند)

❗️ به وسیله وبسرویس ما میتونید ربات و سایت و اپلکیشن خودتون رو به نامبرینو متصل نمایید و از خدمات ما بهرمند شوید.
.
                ",
                'reply_markup' => json_encode([
                    'keyboard' => [
                        [
                             ['text' => "🗝 کلید وبسرویس"]
                        ],
                        [
                            ['text' => "➕ افزایش موجودی"]   ,
                            ['text' => "🔐 حساب کاربری"]
                        ],
                       [
                           ['text' => "📚 مستندات وبسرویس"],   ['text' => "🗝 تغییر کلید وبسرویس"]
                        ],
                        [
                             ['text' => "برگشت 🔙"]
                        ],
                    ],
                    'resize_keyboard' => true
                ])
            ]);
        }
        
    
}

if($textmassage =="🗝 کلید وبسرویس"){
    
        if (in_array($from_id, $admin)) {
            
         function getramz2(){
        $length=16;
        $characters='0123456789abcdefghijklmnopqrstuvwxyzQWERTYUIOPASDFGHJKLZXCVBNM';
        $string='';
            for($p=0;$p<$length;$p++){
            $string.=$characters[mt_rand(0,strlen($characters))];
            }
            return $string;
        } 
            
            $time1 = getramz2(); 
            
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
✅ کلید وبسرویس شما با موفقیت یاخته شد.

☑️ کلید وبسرویس :  $time1
.
                ",
               
            ]);
        }
        
    
}

elseif ($textmassage == "📍 امار ربات") {
    if (in_array($from_id, $admin)) {
        
        number_format(number,decimals,decimalpoint,separator);
        
        $users = mysqli_query($connect, "select id from user");
        $alltotal = mysqli_num_rows($users);
        $userss = mysqli_query($connect, "select id from user WHERE inviter = ''");
        $usersss = mysqli_query($connect, "select id from user WHERE inviter = '0'");
        $alltotall = mysqli_num_rows($userss);
        $alltotalll = mysqli_num_rows($usersss);
        $allzir = $alltotal - ($alltotall + $alltotalll) ;
        $allmos = $alltotall + $alltotalll ;
        
         $usersallbot = mysqli_query($connect, "select id from admin");
        $alltotalallbot = mysqli_num_rows($usersallbot);
      
      //====================  member
        
          $ordersm = mysqli_query($connect, "select id from ordersm");
        $allordersm = mysqli_num_rows($ordersm);
        
         $ordersmt = mysqli_query($connect, "select id from ordersm WHERE statos = '✅ تکمیل شد'");
        $allordersmt = mysqli_num_rows($ordersmt);
        
        $ordersmt2 = mysqli_query($connect, "select id from ordersm WHERE statos = 'مبلغ برگشت داده شد'");
        $allordersmt2 = mysqli_num_rows($ordersmt2);
       
        $a1 = mysqli_query($connect,"select * from ordersm"); 
        $r1 = mysqli_fetch_assoc($a1);
        while ($r1 = mysqli_fetch_assoc($a1)) {
            if($r1['statos'] != "مبلغ برگشت داده شد"){
  $suma1 += $r1['price'];
            }
        }
        $asdgffdg = $suma1 ;
        $suma1 = number_format($suma1);
        
        
    $a2 = mysqli_query($connect,"select * from ordersm"); 
        $r2 = mysqli_fetch_assoc($a2);
        while ($r2 = mysqli_fetch_assoc($a2)) {
             if($r2['statos'] != "مبلغ برگشت داده شد"){
  $suma2 += $r2['member'];
             }
}
$dfa1 = $suma2 / 1000 ;
$sod = $jseting["set"]["memberpric"];
$dfa2 = number_format($suma2 * $sod) ;

//=======24 member

$m10 = $allordersmt - $jsetting["set"]["smrmber"]["oksell"];
$m11 = $allordersmt2 - $jsetting["set"]["smrmber"]["nosell"];
$m12 = number_format($asdgffdg -  $jsetting["set"]["smrmber"]["price"]);
$m13 = $dfa1 - $jsetting["set"]["smrmber"]["allmember"];
$m14 = number_format($dfa2 - $jsetting["set"]["smrmber"]["sodsell"]);
$m15 = $allordersm - $jsetting["set"]["smrmber"]["allsell"];


//=======

       //====================
        
       $ffff = mysqli_query($connect,"select * from admin"); 
        $res = mysqli_fetch_assoc($ffff);
        while ($res = mysqli_fetch_assoc($ffff)) {
  $sum += $res['allnum'];
}

 $ffnn = mysqli_query($connect,"select * from admin"); 
        $ress = mysqli_fetch_assoc($ffnn);
        while ($ress = mysqli_fetch_assoc($ffnn)) {
  $summ += $ress['allsellprice'];
}
$summ = number_format($summ);

$ffnnbb = mysqli_query($connect,"select * from user"); 
        $ressd = mysqli_fetch_assoc($ffnnbb);
        while ($ressd = mysqli_fetch_assoc($ffnnbb)) {
  $summm += $ressd['numberby'];
}
$vvvvd = $jseting["set"]["number"]["allnumbersellbots"] +$summm ;

$ffnnbbd = mysqli_query($connect,"select * from user"); 
        $ressdd = mysqli_fetch_assoc($ffnnbbd);
        while ($ressdd = mysqli_fetch_assoc($ffnnbbd)) {
  $summmn += $ressdd['stock'];
}
$summmn = number_format($summmn);

$ffnnbbd22 = mysqli_query($connect,"select * from admin"); 
        $ressdd22 = mysqli_fetch_assoc($ffnnbbd22);
        while ($ressdd22 = mysqli_fetch_assoc($ffnnbbd22)) {
  $summmn22 += ceil($ressdd22['sharg']);
}
$summmn22 = number_format($summmn22);

$pa = $jseting["set"]["mrmber"]["all"];
$pzir = $jseting["set"]["mrmber"]["zir"];
$pn = $jseting["set"]["mrmber"]["st"];
$pnb = $jseting["set"]["mrmber"]["num"];
$pnbss = $jseting["set"]["mrmber"]["sodnum"];

$dddg = $alltotal - $pa ;
$dgdg = $allzir - $pzir ;
$dgssd = $allmos - $pn ;
$efer = $vvvvd - $pnb ;

$sodall = number_format($jseting["set"]["number"]["allsod"]);
$sodallday = number_format($jseting["set"]["number"]["allsod"] - $pnbss)  ;

 $tttdss20 = mysqli_query($connect, "select id from admin");
         $yyfdd = mysqli_query($connect, "select * from admin");
         $alltotalllffdd44 = mysqli_num_rows($tttdss20);
         foreach ($yyfdd as $keyu20 => $aauserr58) {
              $un = $aauserr58["userbot"];
  
   $files = scandir("bots/$un/data/");
             $alluser = count($files) - 5;
    $ffvd = $ffvd + $alluser ;
    if ($keyu20 == $alltotalllffdd44) {
        break;
    }
}
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🤖 امار ربات شما : 
		
•   کل عضو ها : $alltotal
•   اعضای زیر مجموعه گیری  :  $allzir
•   اعضای مستقل : $allmos
•   شماره های فروخته شده : $vvvvd عدد
•   کل موجودی کاربران : $summmn تومان
•   کل فروش : $sodall تومان

•   تعداد ربات های ساخته شده : $alltotalallbot عدد

•   شماره های فروخته شده ربات ها : $sum عدد
•   کل مبلغ فروش ربات ها : $summ تومان
•   شارژ پنل کل نمایندگان : $summmn22 تومان
•  تعداد اعضای کل نمایندگان : $ffvd

•  تعداد کل سفارشات ممبر : $allordersm
•  سفارشات تکمیل شده : $allordersmt
•  سفارشات رد شده : $allordersmt2
•  مبلغ کل سفارشات ممبر : $suma1 تومان
•  تعداد کل ممبر های فروش رفته : K $dfa1
•  سود بدست آمده از فروش ممبر : $dfa2 تومان

〰️〰️〰️ در 24 ساعت گذشته  〰️〰️〰️

•  کل عضو های جدید : $dddg
•   اعضای جدید زیر مجموعه گیری  :  $dgdg
•  اعضای جدید مستقل : $dgssd
•  شماره های فروخته شده امروز : $efer عدد
•  فروش امروز : $sodallday تومان

• سفارشات ممبر :$m15
• سفارشات تکمیل شده : $m10
• سفارشات رد شده : $m11
• مبلغ سفارشات : $m12 تومان
• ممبر فروش رفته : $m13 k
• سود فروش ممبر : $m14 تومان
〰️〰️〰️〰️〰️〰️〰️〰️〰️

",
        ]);  $connect->query("UPDATE user SET inviter = '0'  WHERE id = '$from_id' LIMIT 1");
    }
} 

elseif ($textmassage == "📍 شارژ پنل") {
    if (in_array($from_id, $admin)) {
       
             
              $ddd = getbalance();
      $alll = explode(":", $ddd);
             $getsmsys = "$alll[1]";
             
        $zarib = $jseting["set"]["robelpric"];
        $eeee = $getsmsys * $zarib ;
        
        
         $getu =  json_decode(file_get_contents("https://inax.ir/webservice.php?method=credit&username=$usersharg&password=$passsharg"),true);
          $me = $getu['credit'];
          
          
           $getu20 =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=amount"),true);
          $me20 = $getu20['amount'];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
پنل شماره مجازی👇➖➖➖➖➖

📍 مقدار شارژ پنل : $getsmsys روبل

📍 معادل $eeee تومان

📍 قیمت تعیین شده برای هر روبل $zarib تومان


پنل شارژ سیمکارت👇➖➖➖➖➖

📍 مقدار شارژ پنل : $me تومان


پنل ممبر سناتور عضو👇➖➖➖➖➖

📍 مقدار شارژ پنل : $me20 تومان
.
",
'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"],['text' => "⬆️ شارژ پنل آینکس"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
    }
}
elseif ($textmassage == '⬆️ شارژ پنل آینکس') {
    if (in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
مقدار شارژ را به تومان ارسال کنید :
            ",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        $connect->query("UPDATE user SET step = 'upsharg' WHERE id = '$from_id' LIMIT 1");
        
       
    }}
elseif ($user["step"] == "upsharg" ) {
      
       $getu =  json_decode(file_get_contents("https://inax.ir/webservice.php?method=addfund&username=$usersharg&password=$passsharg&amount=$textmassage"),true);
          $me = $getu['trans_id'];
       
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 لینک پرداخت افزایش شارژ پنل ساخته شد 👇👇

$fff
            ",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "💸 پرداخت $textmassage تومان", 'url' => "https://inax.ir/pay.php?tid=$me"]
                        ],
                         [
                            ['text' => "❌ انصراف", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);$connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
       }  
elseif ($textmassage == '📍 ارسال به همه') {
    if (in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا متن یا رسانه خود را ارسال کنید [میتواند شامل عکس , گیف یا فایل باشد]  همچنین میتوانید رسانه را همراه با کشپن [متن چسپیده به رسانه ارسال کنید] 🚀",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        $connect->query("UPDATE user SET step = 'sendtoall' WHERE id = '$from_id' LIMIT 1");
        
       
    }
} elseif ($textmassage == '📍 فروارد همگانی') {
    if (in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا متن خود را فوروارد کنید  🚀",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        $connect->query("UPDATE user SET step = 'fortoall' WHERE id = '$from_id' LIMIT 1");
      
}}
elseif ($textmassage == '📍 ارسال به نمایندگان') {
    if (in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا متن یا رسانه خود را ارسال کنید [میتواند شامل عکس , گیف یا فایل باشد]  همچنین میتوانید رسانه را همراه با کشپن [متن چسپیده به رسانه ارسال کنید] 🚀",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        $connect->query("UPDATE user SET step = 'sendtoallpanel' WHERE id = '$from_id' LIMIT 1");
        
       
    }
} elseif ($textmassage == '📍 فروارد به نمایندگان') {
    if (in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا متن خود را فوروارد کنید  🚀",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        $connect->query("UPDATE user SET step = 'fortoallpanel' WHERE id = '$from_id' LIMIT 1");
      
}}

 elseif ($textmassage == '📍 فروارد به ربات ها') {}
elseif ($textmassage == '📍 افزایش | کاهش موجودی') {
    if(in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
📍 در خط اول ایدی عددی فرد و در خط دوم مقدار موجودی را اسال کنید
📍 اگر میخواهید موجودی فر را کم کنید از علامت - منفی استفاده کنید",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        $connect->query("UPDATE user SET step = 'senddowncoin' WHERE id = '$from_id' LIMIT 1");
    }else{
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
شما دسترسی به این قسمت را ندارید.
",]);
    }
    }

//=============================

elseif ($textmassage == "🛒 شارژهای فروخته شده"or ( $textmassage == "$fw51" and $update->message->text )) {
    
  
 
      $dfdf25555 = 0;
     
     $nexs = $dfdf25555 + 5 ;
     $egonexs = $dfdf25555 - 5 ;
    
    $listby =file_get_contents("data/listsharg.txt");
     $getby011 = explode("\n", $listby);
      
      
        
        $mogodish= $adminsql["sharg"];

    $allpayyyy1 = count($getby011) - 1;
   
   
  
  
   
    if ($allpayyyy1 >= 1) {
     if ($egonexs >= -5 and $nexs <= $allpayyyy1 + 5) {   
         $ends = floor($allpayyyy1 / 5 ) * 5  ;
          $sss= $dfdf25555 + 5 ;
    if($allpayyyy1 >= 5){ 
                if($sss <= $allpayyyy1){$adse = $sss;}
                if($sss > $allpayyyy1){$adse = $allpayyyy1;}
        
    }
    if($allpayyyy1 < 5){$adse = $allpayyyy1;}
    
        for ($z = $dfdf25555 ; $z < $adse; $z++) {
           
           $bbz = $z + 1 ;
            $xx = $getby011[$z];
    $getby0 = explode("|", $xx);
      $dfdf1 = $getby0[0];
      $dfdf2 = $getby0[1];
      $dfdf3 = $getby0[2];
      $dfdf4 = $getby0[3];
      $dfdf5 = $getby0[4];
      $dfdf6 = $getby0[5];
      $dfdf7 = $getby0[6];
      $dfdf8 = $getby0[7];
      $dfdf9 = $getby0[8];
      
     
           
            
            $result = $result . "
️〰️〰️🔻 شماره  $bbz 🔻〰〰
➖ $dfdf2
➖ $dfdf1
➖ $dfdf3
➖ $dfdf4 => $dfdf5
➖ $dfdf7
➖ $dfdf8
➖ $dfdf6

";
        }
         jijibot('sendmessage', [
        "chat_id" => $chat_id,
            'text' => "
- تعداد کل شارژ های فروخته شده: $allpayyyy1 عدد

$result",
 'reply_markup' => json_encode([
                'inline_keyboard' => [
                       
                         [
                          ['text' => "↗️صفحه آخر", 'callback_data' => "listsharg|$ends"],['text' => "▶️صفحه بعد", 'callback_data' => "listsharg|5"]
                        ],
                         [
                            ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    }} else {
        
          jijibot('sendmessage', [
        "chat_id" => $chat_id,
            'text' => "❌  هیچ شارژ فروخته شده ای وجود ندارد
            
            ",
               'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
    }
    

    
}

elseif (strpos($data,"listsharg|") !== false) {
    
  
  $getby05555 = explode("|", $data);
      $dfdf25555 = $getby05555[1];
     
     $nexs = $dfdf25555 + 5 ;
     $egonexs = $dfdf25555 - 5 ;
    
    $listby =file_get_contents("data/listsharg.txt");
     $getby011 = explode("\n", $listby);
  
        
        $mogodish= $adminsql["sharg"];

    $allpayyyy1 = count($getby011) - 1;
   
   
  
  
   
    if ($allpayyyy1 >= 1) {
     if ($egonexs >= -5 and $nexs <= $allpayyyy1 + 5) {   
         $ends = floor($allpayyyy1 / 5 ) * 5  ;
          $sss= $dfdf25555 + 5 ;
    if($allpayyyy1 >= 5){ 
                if($sss <= $allpayyyy1){$adse = $sss;}
                if($sss > $allpayyyy1){$adse = $allpayyyy1;}
        
    }
    if($allpayyyy1 < 5){$adse = $allpayyyy1;}
    
        for ($z = $dfdf25555 ; $z < $adse; $z++) {
           
            $bbz = $z + 1 ;
            $xx = $getby011[$z];
    $getby0 = explode("|", $xx);
      $dfdf1 = $getby0[0];
      $dfdf2 = $getby0[1];
      $dfdf3 = $getby0[2];
      $dfdf4 = $getby0[3];
      $dfdf5 = $getby0[4];
      $dfdf6 = $getby0[5];
      $dfdf7 = $getby0[6];
      $dfdf8 = $getby0[7];
      $dfdf9 = $getby0[8];
      
       
           
            
          $result = $result . "
️〰️〰️🔻 شماره  $bbz 🔻〰〰
➖ $dfdf2
➖ $dfdf1
➖ $dfdf3
➖ $dfdf4 => $dfdf5
➖ $dfdf7
➖ $dfdf8
➖ $dfdf6
";
        }
         jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
- تعداد کل شارژ های فروخته شده: $allpayyyy1 عدد

$result",
 'reply_markup' => json_encode([
                'inline_keyboard' => [
                       
                         [
                            ['text' => "◀️صفحه قبل", 'callback_data' => "listsharg|$egonexs"],['text' => "↗️صفحه آخر", 'callback_data' => "listsharg|$ends"],['text' => "▶️صفحه بعد", 'callback_data' => "listsharg|$nexs"]
                        ],
                         [
                            ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    }} else {
        
          jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "❌  هیچ نماینده لول یکی وجود ندارد",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                       
                         [
                            ['text' => "برگشت 🔙", 'callback_data' => "listnback"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    }
    

    
}

//==========================
elseif ($textmassage == "☠️افزودن کاربر به لیست سیاه") {
    if ($tc == "private") {
        if (in_array($from_id, $admin)) {
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "😈 آیدی عددی کاربر مورد نظر رو ارسال کن مدیر :",
                
            ]);
            $connect->query("UPDATE user SET step = 'adduserblak' WHERE id = '$from_id' LIMIT 1");
        }
    }
    
}
elseif ($user["step"] == "adduserblak") {
    if ($tc == "private") {
        if (in_array($from_id, $admin)) {
             $connect->query("UPDATE user SET step = 'blok' WHERE id = '$textmassage' LIMIT 1");
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "✅ کاربر $textmassage با موفقیت به بلک لیست افزوده شد.📛",
                
            ]);
            $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
        }
    }
    
}
elseif ($textmassage == "حذف از لیست سیاه") {
    if ($tc == "private") {
        if (in_array($from_id, $admin)) {
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "😈 آیدی عددی کاربر مورد نظر رو ارسال کن مدیر :",
                
            ]);
            $connect->query("UPDATE user SET step = 'adduserblakrr' WHERE id = '$from_id' LIMIT 1");
        }
    }
    
}
elseif ($user["step"] == "adduserblakrr") {
    if ($tc == "private") {
        if (in_array($from_id, $admin)) {
             $connect->query("UPDATE user SET step = 'none' WHERE id = '$textmassage' LIMIT 1");
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "✅ کاربر $textmassage با موفقیت از بلک لیست حذف  شد.📛",
                
            ]);
            $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
        }
    }
    
}

elseif ($textmassage == '⛔️ توقف فروش') {
    if (in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️ فروش شماره متوقف شد .",
            
        ]);
        
$jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["active"]="0";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

    }
}

elseif ($textmassage == '❎ شروع فروش') {
    if (in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "✅ فروش شماره فعال شد .",
            
        ]);
       
$jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["active"]="1";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

    }
}

elseif ($textmassage == '⛔️ توقف فروش نمایندگی ها') {
    if (in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️ فروش شماره نمایندگی ها متوقف شد .",
            
        ]);
        
$jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["activebots"]="0";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

    }
}

elseif ($textmassage == '❎ شروع فروش نمایندگی ها') {
    if (in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "✅ فروش شماره نمایندگی ها فعال شد .",
            
        ]);
       
$jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["activebots"]="1";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

    }
}

elseif ($textmassage == '💸 پورسانت زیر مجموعه گیری 👥') {
    if (in_array($from_id, $admin)) {
        $pp = $jseting["set"]["porsant"];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "مبلغ مورد نظر رو به تومان ارسال کنید :
⚖️ قیمت فعلی : $pp تومان
            .
            ",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       
$connect->query("UPDATE user SET step = 'okporsant' WHERE id = '$from_id' LIMIT 1");

    }
}
elseif ($user["step"] == "okporsant" && $tc == "private" and in_array($from_id, $admin)) {
    if ( filter_var($textmassage,FILTER_VALIDATE_INT)) {
    $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["porsant"]="$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "✅ مبلغ پورسانت $textmassage تومان تنظیم شد.",
        ]);
        $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
}
    else { 
    
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا یک مقدار عددی وارد کنید :",
        ]);
}
}

elseif ($textmassage == '💸 تعیین قیمت روبل') {
    if ($from_id == "$admin[0]") {
        $pp = $jseting["set"]["robelpric"];
         $pp2 = $jseting["set"]["robelpric0"];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
قیمت هر روبل را به تومان ارسال کنید :

⚖️ قیمت فروش فعلی : $pp تومان
⚖️ قیمت مبنا فعلی : $pp2 تومان

قیمت مبنا => قیمت خرید شما از صرافی
.
            ",
             'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       
$connect->query("UPDATE user SET step = 'okzsell' WHERE id = '$from_id' LIMIT 1");

    }elseif($from_id == $admin[1] or $from_id == $admin[2]){
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
شما دسترسی به این قسمت را ندارید.
",]);
    }
}
elseif ($user["step"] == "okzsell" && $tc == "private" and in_array($from_id, $admin)) {
    if ($textmassage != "برگشت 🔙") {
        if ($textmassage >= 400 and $textmassage <= 700){
            
              $all = explode("\n", $textmassage);
                 $userget = "$all[0]";
                 $userget2 = "$all[1]";
            
    $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["robelpric"]="$userget";
$jseting["set"]["robelpric0"]="$userget2";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
✅ مقدار سود تنظیم شد.

قیمت فروش : $userget تومان
قیمت مبنا : $userget2 تومان

",
        ]);
        $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
            
        }else{
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "مبلغ غیر مجاز
            ",
        ]);
        }
}
}
//===========
elseif ($textmassage == '💸 تعیین قیمت ممبر') {
    if ($from_id == "$admin[0]") {
        $pp = $jseting["set"]["memberpric"];
        
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
مقدار سود به ازای هر یک ممبر را به تومان ارسال کنید :

⚖️ مقدار سود فعلی : $pp تومان

.
            ",
             'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       
$connect->query("UPDATE user SET step = 'okzsellmember' WHERE id = '$from_id' LIMIT 1");

    }elseif($from_id == $admin[1] or $from_id == $admin[2]){
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
شما دسترسی به این قسمت را ندارید.
",]);
    }
}
elseif ($user["step"] == "okzsellmember" && $tc == "private" and in_array($from_id, $admin)) {
    if ($textmassage != "برگشت 🔙") {
        if ($textmassage >= 0.1 and $textmassage <= 1.5){
            
            
    $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["memberpric"]="$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
✅ مقدار سود تنظیم شد.

سود فروش به ازای هر یک ممبر : $textmassage تومان


",
        ]);
        $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
            
        }else{
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "مبلغ غیر مجاز
            ",
        ]);
        }
}
}

//=========
elseif ($textmassage == '📨 ارسال پیام به کاربر') {
    if (in_array($from_id, $admin)) {
       
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا پیام رو با فرمت زیر ارسال کنید :

آیدی عددی کاربر : پیام
            
            ",
             
        ]);
       
$connect->query("UPDATE user SET step = 'sendidp' WHERE id = '$from_id' LIMIT 1");

    }
}
elseif ($user["step"] == "sendidp" && $tc == "private" and in_array($from_id, $admin)) {
    
   $alll = explode(":", $textmassage);
             $idd = "$alll[0]";
             $payam = "$alll[1]";
jijibot('sendmessage', [
            'chat_id' => $idd,
            'text' => "📩 یک پیام از سوی پشتیبانی برای شما دریافت شد : 
$payam",
        ]);
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
            ✅ پیام شما با موفقیت به کاربر  ارسال شد.
            [$idd](tg://user?id=$idd) 
            ",
            'parse_mode' => 'Markdown',
        ]);
        $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");

}

elseif ($textmassage == "📢 تنظیم کانال ربات" && in_array($from_id, $admin)) {

     $connect->query("UPDATE user SET step = 'setch' WHERE id = '$from_id' LIMIT 1");
        
      

       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 لطفا آیدی کانال ربات را بدون @ ارسال کنید :

برای مثال :
sellnumberss
〰️〰️〰️〰️〰️〰️〰️〰️
❗️ عضویت کاربران ربات در این کانال اجباری خواهد بود.
❗️ گزارش های فروش به این کانال ارسال خواهد شد.
⚠️ دقیت کنید که #حتما این ربات در کانال مد نظر، #مدیر باشد.

.     
            ",
        ]);
    
}
elseif ($user["step"] == "setch" ) {

    if ($textmassage != "برگشت 🔙") {
        
        $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["channel"]="$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
✅ کانال ربات با موفقیت تنظیم شد.

آیدی کانال ربات :
🆔 @$textmassage

.
            " ,
        ]);
      $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
    }
}
elseif ($user["step"] == "senddowncoin" && $tc == "private" and $from_id == "$admin[0]") {
    
    $all = explode("\n", $textmassage);
    $userget = "$all[0]";
    $usergetss = "$all[1]";
    $usergets = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$userget' LIMIT 1"));
    $stoockk = $usergets["stock"];
    if($usergetss <= 50000){
    if ($usergets["id"] == true) {
        $coinusergets = $stoockk;
        $pluscoinusergets = $stoockk + $all[1];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "انتقال پول با موفقیت انجام شد ✅",
        ]);
        jijibot('sendmessage', [
            'chat_id' => $userget,
            'text' => "ℹ️ $all[1] تومان به شما هدیه داده شد !

💰 میزان جدید کیف پول شما : $pluscoinusergets
☂️ میزان قبلی   : $coinusergets
🎈 از طرف مدیر ربات !",
            'parse_mode' => 'Markdown',
        ]);
        $connect->query("UPDATE user SET stock = '$pluscoinusergets' WHERE id = '$userget' LIMIT 1");
        jijibot('sendmessage', [
            'chat_id' => "@$channelbc",
            'text' => "
            💰 اهدای پول از طرف #مدیر
$from_id
[$from_id](tg://user?id=$from_id)
مشخصات 👇👇

مبلغ :  $all[1] تومان
 آیدی کاربر : [$userget](tg://user?id=$userget)
میزان موجودی فعلی کاربر : $pluscoinusergets تومان
میزان موجودی قبلی کاربر : $coinusergets تومان

            ",
            'parse_mode' => 'Markdown',
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "55", 'callback_data' => "text"]
                    ],
                   
                    [
                        ['text' => "☎️ ربات خرید شماره مجازی", 'url' => "https://t.me/$usernamebot"],
                    ],
                ]
            ])
        ]);
    } else {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📍 کاربر مورد نظر یافت نشد ! شاید هنوز ربات را استارت نکرده باشد !			
🎈 شناسه کاربری هر فرد در قسمت اطلاعات حساب وی مشخص هست 
🌟 مثال :
267785153",
        ]);
    }
} else {
    $connect->query("INSERT INTO `blaklist` (`id`, `bicuse`) VALUES ('$from_id', 'by admin')");
}
}

elseif ($user["step"] == "sendtoall" && $tc == "private") {
    
    if ($textmassage != "برگشت 🔙") {
        set_time_limit(600);
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "در حال ارسال پیام...",
        ]);
         $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
        $cc = mysqli_query($connect, "select id from user");
         $y = mysqli_query($connect, "select * from user");
         $alltotal = mysqli_num_rows($cc);
        foreach ($y as $key => $aauser) {
              $abb = $aauser["id"];
     jijibot('sendmessage', [
            'chat_id' => "$abb",
            'text' => "$textmassage",
        ]);
        
         if ($key == $alltotal) {
        break;
    }
};
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "پیام با موفقیت به همه ارسال شد",
        ]);
        
       
       
    }
} elseif ($user["step"] == "fortoall" && $tc == "private") {
     set_time_limit(600);
    if ($textmassage != "برگشت 🔙") {
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "در حال ارسال پیام...",
        ]);
         $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
        $cc = mysqli_query($connect, "select id from user");
         $y = mysqli_query($connect, "select * from user");
         $alltotal = mysqli_num_rows($cc);
        foreach ($y as $key => $aauser) {
              $abb = $aauser["id"];
      jijibot('ForwardMessage', [
        'chat_id' => $abb ,
        'from_chat_id' => $chat_id,
        'message_id' => $message_id,
        ]);
        
         if ($key == "$alltotal") {
        break;
    }
};
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "پیام با موفقیت به همه فوروارد شد",
        ]);
        
       
       
    }
}

elseif ($user["step"] == "sendtoallpanel" && $tc == "private") {
    
    if ($textmassage != "برگشت 🔙") {
        set_time_limit(600);
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "در حال ارسال پیام...",
        ]);
         $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
        $cc = mysqli_query($connect, "select id from admin");
         $y = mysqli_query($connect, "select * from admin");
         $alltotal = mysqli_num_rows($cc);
        foreach ($y as $key => $aauser) {
              $abb = $aauser["id"];
     jijibot('sendmessage', [
            'chat_id' => "$abb",
            'text' => "$textmassage",
        ]);
        
         if ($key == $alltotal) {
        break;
    }
};
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "پیام با موفقیت به همه ارسال شد",
        ]);
        
       
       
    }
} elseif ($user["step"] == "fortoallpanel" && $tc == "private") {
     set_time_limit(600);
    if ($textmassage != "برگشت 🔙") {
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "در حال ارسال پیام...",
        ]);
         $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
        $cc = mysqli_query($connect, "select id from admin");
         $y = mysqli_query($connect, "select * from admin");
         $alltotal = mysqli_num_rows($cc);
        foreach ($y as $key => $aauser) {
              $abb = $aauser["id"];
      jijibot('ForwardMessage', [
        'chat_id' => $abb ,
        'from_chat_id' => $chat_id,
        'message_id' => $message_id
        ]);
        
         if ($key == "$alltotal") {
        break;
    }
};
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "پیام با موفقیت به همه فوروارد شد",
        ]);
        
       
       
    }
}
elseif ($textmassage == '📍تعیین مبلغ خرید ربات نقره ای' && in_array($from_id, $admin)) {
      
       $sqqq = $jseting["set"]["pricbotn"];
         
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 مبلغ خرید ساخت شماره مجازی نقره ای را به واحد تومان و با کیبرد لاتین ارسال کنید:

مبلغ فعلی : $sqqq تومان           
            ",
             
        ]);$connect->query("UPDATE user SET step = 'pricbotn' WHERE id = '$from_id' LIMIT 1");
       }
elseif ($user["step"] == "pricbotn" ) {
      
      
         $jseting = json_decode(file_get_contents("data/seting.json"),true);	
 $jseting["set"]["pricbotn"] = "$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 مبلغ با موفقیت $textmassage تومان تنظیم شد.
            ",
             
        ]);$connect->query("UPDATE user SET step = '' WHERE id = '$from_id' LIMIT 1");
       }  

elseif ($textmassage == '📟 کد یکبار مصرف رباتساز نقره ای' && in_array($from_id, $admin)) {
      
      
         
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 یه کد جدید یکبار مصرف برای خرید ربات شماره مجازی نقره اید ارسال کنید

برای مثال : Ab124          
            ",
             
        ]);$connect->query("UPDATE user SET step = 'setramzbotn' WHERE id = '$from_id' LIMIT 1");
       }
elseif ($user["step"] == "setramzbotn" ) {
      
      
         $jseting = json_decode(file_get_contents("data/seting.json"),true);	
 $jseting["set"]["oneramzbot"] = "$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 رمز $textmassage برای خرید ربات فعال شد
            ",
             
        ]);$connect->query("UPDATE user SET step = '' WHERE id = '$from_id' LIMIT 1");
       }  
elseif ($textmassage == '📟 کد یکبار مصرف رباتساز طلایی' && in_array($from_id, $admin)) {
      
      
         
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 یه کد جدید یکبار مصرف برای خرید ربات شماره مجازی نقره اید ارسال کنید

برای مثال : Ab124          
            ",
             
        ]);$connect->query("UPDATE user SET step = 'setramzbottala' WHERE id = '$from_id' LIMIT 1");
       }
elseif ($user["step"] == "setramzbottala" ) {
      
      
         $jseting = json_decode(file_get_contents("data/seting.json"),true);	
 $jseting["set"]["oneramzbottala"] = "$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 رمز $textmassage برای خرید ربات فعال شد
            ",
             
        ]);$connect->query("UPDATE user SET step = '' WHERE id = '$from_id' LIMIT 1");
       }  
       
       elseif ($textmassage == '📍تعیین مبلغ خرید ربات طلایی' && in_array($from_id, $admin)) {
      
       $sqqq = $jseting["set"]["pricbottala"];
         
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 مبلغ خرید ساخت شماره مجازی نقره ای را به واحد تومان و با کیبرد لاتین ارسال کنید:

مبلغ فعلی : $sqqq تومان           
            ",
             
        ]);$connect->query("UPDATE user SET step = 'pricbottala' WHERE id = '$from_id' LIMIT 1");
       }
elseif ($user["step"] == "pricbottala" ) {
      
      
         $jseting = json_decode(file_get_contents("data/seting.json"),true);	
 $jseting["set"]["pricbottala"] = "$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 مبلغ با موفقیت $textmassage تومان تنظیم شد.
            ",
             
        ]);$connect->query("UPDATE user SET step = '' WHERE id = '$from_id' LIMIT 1");
       }  
elseif ( $textmassage == "💳 پیگیری پرداخت" && in_array($from_id, $admin)) {
   
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
💢 آیدی کاربر مورد نظر را ارسال نمایید.
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
    ]);
    $connect->query("UPDATE user SET step = 'infoidpay' WHERE id = '$from_id' LIMIT 1");
}
elseif ($user["step"] == 'infoidpay' and $textmassage != "برگشت 🔙" ) {
     $listby =file_get_contents("$web/data/listpayy.txt");
    $getby = explode("\n", $listby);
    $allpayyyy = count($getby) - 1;
    if (count($getby) > 1) {
        for ($z = 0; $z <= count($getby) - 2; $z++) {
            
            if(strpos($getby[$z],"$textmassage") == true ){
            $result = $result . "$z - $getby[$z]" . "\n➖➖➖➖\n";
            }
                
            }
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
- تعداد کل پرداختی های کاربر مورد نظر : $allpayyyy عدد

🛍 لیست 15 پرداختی آخر کاربر :


$result",
        ]);
    
    
}
}

elseif ( $textmassage == "☑️ پیگیری سفارش ممبر" && in_array($from_id, $admin)) {
   
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
💢 شناسه سفارش مورد نظر را ارسال نمایید.
        ",
    ]);
    $connect->query("UPDATE user SET step = 'infoidorder' WHERE id = '$from_id' LIMIT 1");
}
elseif ($user["step"] == 'infoidorder' ) {
    
     $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
    
      $user1 = $textmassage;    
    
    $aauserr = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM ordersm  WHERE id = '$user1' LIMIT 1"));
    
                $ablink = $aauserr["link"];
                 $abtype = $aauserr["service"];
                  $abprice = $aauserr["price"];
                   $abdate = $aauserr["date"];
                    $abmember = $aauserr["member"];
                     $abmember0 = $aauserr["member0"];
                     $abuser = $aauserr["iduser"];
                     $ablink2 = $aauserr["statos"];
                    
                    	$result2 =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
     
                         $pin100= $result2['products']["$abtype"]['name'];
     
     	$result =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=20dba85e1e68268501c7&type=status&id=56158"),true);
     
       $pin10= $result['stats'];
   
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
شناسه : $textmassage
🔗 لینک : $ablink
🌐 نوع سفارش : $pin100
💰 هزینه سفارش : $abprice تومان
⏱ زمان : $abdate
👤 تعداد ممبر درخواستی : $abmember
👤 ممبرهای اولیه : $abmember0
✔️ وضعیت سفارش نامبرینو : $ablink2
✔️ وضعیت سفارش در وبسرویس : $pin10
.
            " ,
           
        ]);
      
    
}
elseif ( $textmassage == "⁉️ اطلاعات کاربر" && in_array($from_id, $admin)) {
   
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
💢 آیدی کاربر مورد نظر را ارسال نمایید.
        ",
    ]);
    $connect->query("UPDATE user SET step = 'infoid' WHERE id = '$from_id' LIMIT 1");
}
elseif ($user["step"] == 'infoid' ) {
 
        $usergetssss = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE id = '$textmassage' LIMIT 1"));
         $usergets = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$textmassage' LIMIT 1"));
         $st = $usergets["stock"];
         $invit = $usergets["member"];
         $buynum = $usergets["numberby"];
         $buylist = $usergets["listby"];
         $sttt = explode("^", $buylist);
         if (count($sttt) > 1) {
        for ($z = 1; $z <= count($sttt) - 1; $z++) {
            $result = $result . "$z - $sttt[$z]" . "\n〰️〰️〰️\n";
        }
       $nn = $result ;
    } else {
       
           $nn = "کاربر تاکنون خرید نکرده ❌ ";
            
       
    }
     if($usergetssss == true){
        $drdrd=  $usergetssss["stock"];
       $dffff=  $usergetssss["userbot"];
       $drdrdsss=  $usergetssss["sharg"];
         if($usergetssss["typ"]=="1"){
             
             $ssr ="❇️ کاربر 1 ربات ساخته شده در نامبرینو دارد.

📌 نوع ربات : نقره ای
📌 مقدار سود حاصله از فروش کاربر : $drdrd تومان
📌 آیدی ربات کاربر : @$dffff   ";

         }else{
         $ssr ="❇️ کاربر 1 ربات ساخته شده در نامبرینو دارد.

📌 نوع ربات : طلایی
📌 مقدار شارژ پنل کاربر : $drdrdsss تومان
📌 آیدی ربات کاربر : @$dffff";
         }
     }
     
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
📜 اطلاعات کاربر [$textmassage](tg://user?id=$textmassage)  :

💠 موجودی کاربر : $st تومان
💠 زیر مجموعه های کاربر : $invit  نفر
💠 تعداد شماره های خریداری شده : $buynum عدد

〰️〰️〰️〰️〰️〰️〰️
لیست شماره های خریداری شده 👇👇

$nn

〰️〰️〰️〰️〰

$ssr

〰️〰️〰️〰️〰
            ",
             'parse_mode' => 'Markdown',]);
 
   $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
  
}
elseif ($textmassage == '📍 افزایش | کاهش موجودی پنل طلایی' && in_array($from_id, $admin)) {
    
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📍 در خط اول ایدی عددی فرد و در خط دوم مقدار موجودی را اسال کنید
📍 اگر میخواهید موجودی فر را کم کنید از علامت - منفی استفاده کنید",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        $connect->query("UPDATE user SET step = 'senddowncoinpanel' WHERE id = '$from_id' LIMIT 1");
    
    }
elseif ($user["step"] == "senddowncoinpanel" && $tc == "private" and in_array($from_id, $admin)) {
    
    $all = explode("\n", $textmassage);
    $userget = "$all[0]";
    $usergets = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE id = '$userget' LIMIT 1"));
    $stoockk = $usergets["sharg"];

    if ($usergets["id"] == true) {
        $coinusergets = $stoockk;
        $pluscoinusergets = $stoockk + $all[1];
        $ddfssdf = $all[1];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "✅ پنل ربات کاربر با موفقیت شارژ شد.

📌 میزان شارژ شده : $ddfssdf تومان
📌 مقدار شارژ فعلی پنل ربات کاربر : $pluscoinusergets تومان
📌 موجودی قبلی پنل ربات کاربر : $coinusergets تومان",
        ]);
        jijibot('sendmessage', [
            'chat_id' => $userget,
            'text' => "
✅ پنل ربات شما با موفقیت شارژ شد.

📌 میزان شارژ شده : $ddfssdf تومان
📌 مقدار شارژ فعلی پنل ربات  : $pluscoinusergets تومان
📌 موجودی قبلی پنل ربات  : $coinusergets تومان
            ",
            'parse_mode' => 'Markdown',
        ]);
        $connect->query("UPDATE admin SET sharg = '$pluscoinusergets' WHERE id = '$userget' LIMIT 1");
        $connect->query("UPDATE user SET step = 'none' WHERE id = '$from_id' LIMIT 1");
        jijibot('sendmessage', [
            'chat_id' => "@$channelbc",
            'text' => "
            💰  شارژ پنل ربات طلایی از طرف #مدیر

مشخصات 👇

📌 آیدی کاربر : [$userget](tg://user?id=$userget)
📌 میزان شارژ شده : $ddfssdf تومان
📌 مقدار شارژ فعلی پنل ربات کاربر : $pluscoinusergets تومان
📌 موجودی قبلی پنل ربات کاربر : $coinusergets تومان

            ",'parse_mode' => 'Markdown',
          
        ]);
    } else {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📍 کاربر مورد نظر یافت نشد ! شاید هنوز ربات را استارت نکرده باشد !			
🎈 شناسه کاربری هر فرد در قسمت اطلاعات حساب وی مشخص هست 
🌟 مثال :
267785153",
        ]);
    }
} 
elseif ($update->message && $update->message->reply_to_message &&( $from_id == $admin[0] ) && $tc == "private" and $textmassage == "بلاک") {
    
    $userr = $update->message->reply_to_message->forward_from->id ;
    $connect->query("UPDATE user SET step = 'blok' WHERE id = '$userr' LIMIT 1");
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "📛 کاربر مورد نظر بلاک شد ."
    ]);
   
}
elseif ($update->message && $update->message->reply_to_message &&( $from_id == $admin[0] ) && $tc == "private" and $textmassage == "آنبلاک") {
    
    $userr = $update->message->reply_to_message->forward_from->id ;
    $connect->query("UPDATE user SET step = 'none' WHERE id = '$userr' LIMIT 1");
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => " کاربر مورد نظر آنبلاک شد ."
    ]);
   
}
elseif ($textmassage == "💵 پرداختی های ربات") {
   
    $listby =file_get_contents("$web/data/listpayy.txt");
    $getby = explode("\n", $listby);
    $allpayyyy = count($getby) - 1;
    if (count($getby) > 1) {
        for ($z = count($getby) - 16; $z <= count($getby) - 2; $z++) {
            $result = $result . "$z - $getby[$z]" . "\n➖➖➖➖\n";
        }
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
- تعداد کل پرداختی ها : $allpayyyy عدد

🛍 لیست 15 پرداختی آخر ربات :


$result",
        ]);
    } else {
        jijibot('sendmessage', [
             'chat_id' => $chat_id,
            'text' => "❌  پرداختی وجود ندارد",
            
        ]);
    }
}
elseif ($textmassage == "📍 لیست نمایندگی ها") {
   
 $cc = mysqli_query($connect, "select id from admin");
         $y = mysqli_query($connect, "select * from admin");
         $alltotal = mysqli_num_rows($cc);
    
       
         foreach ($y as $key => $aauser) {
              $abb = $aauser["userbot"];
               $abbs = $aauser["stock"];
                $abbsh = $aauser["sharg"];

              $result = $result . "🆔 آیدی ربات : @$abb
💎 شارژ پنل : $abbsh تومان
💰صندوق پرداختی : $abbs تومان" . "\n➖➖➖➖\n";
              
              if ($key == $alltotal) {
        break;
    }
}
    
    if ($alltotal > 1) {
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
- تعداد کل ربات ها : $alltotal عدد

$result",
        ]);
    } else {
        jijibot('sendmessage', [
             'chat_id' => $chat_id,
            'text' => "❌  پرداختی وجود ندارد",
            
        ]);
    }
}
if(strpos($data,"okdar|") !== false ){ 
     $alll = explode("|", $data);
             $cod = "$alll[1]";
             $idbot = "$alll[2]";
             $iduser = "$alll[3]";
             $price = "$alll[4]";
             
             
    file_get_contents("https://midasbuy.cam/bots/numberino/bots/$idbot/smpbots.php?code=$cod&user=$iduser&price=$price");
     jijibot('deletemessage', [
            'chat_id' => $chatid,
                'message_id'=>$messageid,
            ]);
}

elseif ($textmassage == "55000") {
    
     $tttdss = mysqli_query($connect, "select id from admin");
         $yyfdd = mysqli_query($connect, "select * from admin");
         $alltotalllffdd = mysqli_num_rows($tttdss);


         foreach ($yyfdd as $keyu => $aauserr) {
              $undd = $aauserr["userbot"];
             
              
              	
             unlink("bots/$undd/data/error_log");
              unlink("bots/$undd/pay/error_log");
              unlink("bots/$undd/error_log");
  
 

    if ($keyu == $alltotalllffdd) {
        break;
    }
}
 jijibot('sendmessage', [
            'chat_id' => $chat_id,
         'text' => "
         00

            ",
        ]);
}
elseif ($textmassage == "5500d") {
     set_time_limit(1200);
    $tttdss = mysqli_query($connect, "select id from admin");
         $yyfdd = mysqli_query($connect, "select * from admin");
         $alltotalllffdd = mysqli_num_rows($tttdss);

jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
            
در حال پردازش...
            ",
        ]);
        
         foreach ($yyfdd as $keyu => $aauserr) {
              $un = $aauserr["userbot"];
  
   
   
     $directory_handle2 = opendir("bots/$un/data");
while($directory_item = readdir($directory_handle2)) {
 $uss = str_replace(".json","",$directory_item);
 $juser = json_decode(file_get_contents("bots/$un/data/$uss.json"),true);
 $stock = $juser["stock"];
 if($stock < 0  or $stock > 50000){
 $aaaa = "$aaaa"."$un =>> $uss =>>  $stock"."\n";

  $juser = json_decode(file_get_contents("bots/$un/data/$uss.json"),true);	
$juser["stock"]="0";
$juser = json_encode($juser,true);
file_put_contents("bots/$un/data/$uss.json",$juser);
}
}
        
        

    if ($keyu == $alltotalllffdd) {
        break;
    }
}

 jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "gtyty
$aaaa
            ",
        ]);
}
elseif ($textmassage == "550") {
   
  $tttdss = mysqli_query($connect, "select id from admin");
         $yyfdd = mysqli_query($connect, "select * from admin");
         $alltotalllffdd = mysqli_num_rows($tttdss);


         foreach ($yyfdd as $keyu => $aauserr) {
              $un = $aauserr["userbot"];
  
    

  
  $source22 = file_get_contents("listsharg.txt");
     file_put_contents("bots/$un/data/listsharg.txt",$source22); 
     
     

    if ($keyu == $alltotalllffdd) {
        break;
    }
}
    
}
elseif ($textmassage == "55300" and $chat_id == "$admin[0]" ) {}
elseif ($textmassage == "123" and $chat_id == "$admin[0]" ) {
    $keyy = "000";
     $get = json_decode(file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=0000000000&action=getPrices&service=tg&operator=any"),true);
     
     $aa = $get["telegram"]["aruba"]["virtual4"]["cost"];
     
     $ddd = getbalance();
      $alll = explode(":", $ddd);
             $getsmsys = "$alll[1]";
             
             $f1 = getnumber("bigolive" ,"russia", "beeline");
             $f2 =  explode(":", $f1);
              $getf0 = "$f2[0]";
             $getf1 = "$f2[1]";
              $getf2 = "$f2[2]";
      jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "fgfg
       
    $aa        
        uu
    $getsmsys  
    
    $getf0
    آیدی : $getf1
    شماره : $getf2
        !
            ",
        ]);
}
}
}else {
     jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
🔴 شما در وضعیت دریافت کد میباشید.

جهت خروج از این وضعیت دکمه لغو شماره رو بزنید.
",
    ]);}

      } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "
            
❗️جهت نمایش دکمه های ربات روی دکمه زیر ضربه بزنید 👇👇

",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "✅ نمایش دکمه ها", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
        
         jijibot('sendmessage', [
            "chat_id" => $chatid,
            "text" => "
            
❗️جهت نمایش دکمه های ربات روی دکمه زیر ضربه بزنید 👇👇

",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "✅ نمایش دکمه ها", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }  
    
        
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

 بعد از عضویت بر روی دکمه 'عضو شدم' ضربه بزنید تا کیبرد ربات ظاهر شود 👇👇

",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    
    
    
    
    if (strpos($textmassage, '/start ') !== false) {
    $start = str_replace("/start ", "", $textmassage);
    if ($user["id"] != true) {
        $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$start' LIMIT 1"));
        $plusmember = $user["member"] + 1;
        
        $stoockk = $user["stock"];

        
       
        $name = str_replace(["`", "*", "_", "[", "]"], ["", "", "", "", ""], $first_name);
        jijibot('sendmessage', [
            'chat_id' => $start,
            'text' => "
🌟 کاربر [$name](tg://user?id=$from_id) با استفاده از لینک دعوت شما وارد ربات شده.

❄️ جهت جلوگیری از تقلب و اطمینان از واقعی بودن کاربر دعوت شده توسط شما ، پس از عوضیت کاربر در کانال ربات مبلغ $porsant تومان پورسانت زیرمجموعه گیری به شما داده میشود.

👥 تعداد زیر مجموعه ها : $plusmember

📋 در صورتی که زیر مجموعه شما از ربات خرید کند شما مطلع خواهید شد
💰یک دهم (10 درصد) از هر خرید زیر مجموعه به موجودی شما اضافه می گردد",
            'parse_mode' => 'Markdown',
        ]);
          jijibot('sendmessage', [
            'chat_id' => "@$channelbc" ,
            'text' => "
🌟 کاربر [$name](tg://user?id=$from_id) با استفاده از لینک دعوت کاربر  [$start](tg://user?id=$start) وارد ربات شده  است.

⚠️کاربر هنوز عضو کانال نشده است !!
	
👥 تعداد زیر مجموعه ها : $plusmember

 
            ",
            'parse_mode' => 'Markdown',
        ]);
        $connect->query("UPDATE user SET member = '$plusmember'WHERE id = '$start' LIMIT 1");
        
         $connect->query("INSERT INTO `user` (`id`, `step`, `stock`, `member`, `listby`, `inviter`, `service`, `country`, `getfile`, `price`, `namecontry`,  `numberby`, `panel`, `numberid`) VALUES ('$from_id', 'pinn', '0', '0', '', '$start', '', '', '', '', '', '0', '', '0')");
    }
    }
     if ($user["id"] != true and $textmassage == "/start") {
        $connect->query("INSERT INTO `user` (`id`, `step`, `stock`, `member`, `listby`, `inviter`, `service`, `country`, `getfile`, `price`, `namecontry`, `numberby`, `panel` , `numberid`) VALUES ('$from_id', 'none', '0', '0', '', '0', '', '', '', '', '', '0','', '0')");
    }
     if ($user["id"] != true and strpos($textmassage, '/start') == false) {
        $connect->query("INSERT INTO `user` (`id`, `step`, `stock`, `member`, `listby`, `inviter`, `service`, `country`, `getfile`, `price`, `namecontry`, `numberby`, `panel` , `numberid`) VALUES ('$from_id', 'none', '0', '0', '', '0', '', '', '', '', '', '0','', '0')");
    }
   
  
    
}
        
    }else {
   jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
شما از ربات محروم شده اید!
            ",
        ]);
        
        
    }
        
//=====================================================================

//=============================
}else {
   jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
ربات جهت آپدیت های جدید موقتا توسط مدیر غیر فعال شده.
            ",
        ]);
}
}



?>