<?php

include "bottpodkrtirtoy.php";
$usery = $_GET['user'];
$fnumber = $_GET['number'];
$tinow = "1";
$dtnow = "0";
$tedadd = $_GET['tedad'];
$idnumber = $_GET['idnumber'];


$juserr = json_decode(file_get_contents("data/$usery.json"),true);
$sdss=$juserr["step"];
 

include "../../soorcodbots.php";

?>