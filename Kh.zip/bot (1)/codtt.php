<?php
include "bottpodkrtirtoy.php";
set_time_limit(600);

 $time22 = time() ;

 
  $cc = mysqli_query($connect, "select id from coduser");
         $y = mysqli_query($connect, "select * from coduser");
         $alltotal = mysqli_num_rows($cc);
    
       
         foreach ($y as $key => $aauser) {
              $abb = $aauser["id"];
         $user = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$abb' LIMIT 1"));     
     $idnumber = $user["getfile"];
$country = $user["country"];
$pooos = $user["step"];      
if($pooos =="daryaftcod"){
     $stock = $user["stock"];
    $userservice = $user["service"];
    $country = $user["country"];
    $namecontry = $user["namecontry"];
    $idnumber = $user["getfile"];
   
   
            
    
    $get =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getStatus&id=$idnumber");
      $alll = explode(":", $get);
             $cros000 = "$alll[0]";
             $cod000 = "$alll[1]";
            
     
      

    if ($cros000 == "STATUS_OK") {
        
        
       
        $price = $user["price"];
        $plusby = $user["numberby"] + 1;
        $member = $user["member"];
        
        $bb12 = $jseting["set"]["number"]["allsod"] + $price ;
        $jseting = json_decode(file_get_contents("data/seting.json"),true);	
 $jseting["set"]["number"]["allsod"] = "$bb12";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
       
       jijibot('sendmessage', [
            'chat_id' => "$abb",
            'text' => "کد با موفقیت دریافت شد ✅
💭 کد ورود شما به برنامه : $cod000

ℹ️ گزارش خریدبه کانال ما @$channelby ارسال شد 
🔆 درصورت وجود هرگونه مشکل کافیست با پشتیبانی در تماس باشید",
            'reply_markup' => json_encode([
                'keyboard' => [
                [
                    ['text' => "📲 خرید شماره مجازی"]
                ],
                 [
                     ['text' => "📲 خرید شارژ سیمکارت اعتباری"]
                    
                    ],
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "💸 شارژ حساب"]
                ]
                ,
                [
                     ['text' => "🤖 ربات شماره مجازی شما [ربات نمایندگی]"] 
                    ],
                     [
                   ['text' => "👥 زیرمجموعه گیری"]
                    ],
                     [
                    ['text' => "🛍 خرید های من"], ['text' => "👤 اطلاعات حساب"]
                    ],
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
                'resize_keyboard' => true
            ])
        ]);
        
          $str3 = str_replace(["🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه"], ["afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe"], $namecontry);
         
        $strservic = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservice);
        
        ;
        $number = mb_substr("$country", "0", "10") . "***";
        $usidf = mb_substr("$abb", "0", "6") . "***";
        jijibot('sendmessage', [
            'chat_id' => "@$channel",
            'disable_notification' => true ,
            'text' => "
📱یک عدد شماره مجازی $namecontry خریداری شد!
⚜️اطلاعات شماره و خریدار 👇
➖➖➖➖➖➖➖➖
☎️ number : $number
➖➖➖➖➖➖➖➖
👤 user : $usidf
➖➖➖➖➖➖➖➖
📱 service : $strservic
➖➖➖➖➖➖➖➖
💸 نوع پرداخت :  #کیف_پول
➖➖➖➖➖➖➖➖
❗️روش خرید و دریافت شماره مجازی :
۱-وارد ربات @$usernamebot شوید.
۲-اعتبار خود را $price تومان افزایش دهید.
۳-سرویس $strservic را انخاب کنید.
۴-شماره مجازی  $namecontry دریافت کنید!
☝️شماره های مجازی ثبت نشده هستند و با متد های اتومات توسط کاربران ربات @$usernamebot نامبرینو به صورت کاملا خودکار دریافت و ثبت می شوند.
این پیام  خودکار با دریافت کد شماره مجازی توسط کاربر ربات نامبرینو  ارسال شده است.
***************
🤖 @$usernamebot
🔊@$channel
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "⏳استعلام شماره", 'callback_data' => "estelam|$str3|$userservice|$price"], ['text' => "📱خرید از ربات نامبرینو", 'url' => "https://t.me/$usernamebot"]
                    ]
                    
                ]
            ])
        ]);
        
        $get =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=setStatus&status=6&id=$idnumber");
      
        
        $connect->query("UPDATE user SET step ='none',  numberby = '$plusby' , listby = CONCAT (listby,'^$country ➡️ $price ➡️ $time_now ⌚️ $dat_now'), numberid = '0'  WHERE id = '$abb' LIMIT 1");
        $connect->query("DELETE FROM coduser WHERE id ='$abb'");
         $connect->query("DELETE FROM numbers WHERE numberid ='$idnumber'");
    
    
      $userservicc = $user["service"];


    }
    if($cros000  == "STATUS_WAIT_CODE")  {
        
        $tedadtim = $user['numberid'];
        $tedadtimnext = $tedadtim + 1 ;
        if($tedadtim == "0"){ $tim11 = "7"; }
        if($tedadtim == "1"){ $tim11 = "6"; }
        if($tedadtim == "2"){ $tim11 = "5"; }
       if($tedadtim == "3"){ $tim11 = "4"; }
        if($tedadtim == "4"){ $tim11 = "3"; }
        if($tedadtim == "5"){ $tim11 = "2"; }
         if($tedadtim == "6"){ $tim11 = "1"; }
         jijibot('sendmessage', [
            'chat_id' => "$abb",
            'text' => "
در انتظار دریافت کد ...
=======
💠 لطفا صبور باشد به محض دریافت کد برای شما ارسال خواهد شد.
در صورت عدم دریافت کد . پس از
          👉👉👉  $tim11 دقیقه 👈👈👈
شماره اتوماتیک لغو شده و پول شما برگردانده میشود.

", ]);
         $connect->query("UPDATE user SET  numberid = '$tedadtimnext' , listby =''  WHERE id = '$abb' LIMIT 1");
    
        if($tedadtimnext == "8"){ 
            
             $ddd = $user["getfile"];
     
      $get =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=setStatus&status=-1&id=$ddd");
      $alll = explode(":", $get);
             $cros000 = "$alll[0]";
             $cod000 = "$alll[1]";
     
      if ($cros000 == "ACCESS_CANCEL") {
          $stock = $user["stock"];
           $plusstock = $stock + $user["price"];
    jijibot('sendmessage', [
        'chat_id' => "$abb",
        'text' => "
✅ شماره با موفقیت کنسل شد.

⚠️مبلغ به کیف پول شما برگشت داده شد.

شماره دیگری را خرید کنید.
	",
        'reply_markup' => json_encode([
            'keyboard' => [
                [
                    ['text' => "📲 خرید شماره مجازی"]
                ],
                 [
                     ['text' => "📲 خرید شارژ سیمکارت اعتباری"]
                    
                    ],
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "💸 شارژ حساب"]
                ]
                ,
                [
                     ['text' => "🤖 ربات شماره مجازی شما [ربات نمایندگی]"] 
                    ],
                     [
                   ['text' => "👥 زیرمجموعه گیری"]
                    ],
                     [
                    ['text' => "🛍 خرید های من"], ['text' => "👤 اطلاعات حساب"]
                    ],
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
            'resize_keyboard' => true
        ])
    ]);
    
    $connect->query("UPDATE user SET stock = '$plusstock', step = 'none' , service = '', panel = '', getfile = '' , numberid = '0' WHERE id = '$abb' LIMIT 1");
     $connect->query("DELETE FROM coduser WHERE id ='$abb'");
} 
        }
        
    }
         
    
    
}
  if ($key == $alltotal) {
        break;
    }
}


//===================================نمایندگی ها


$ttt = mysqli_query($connect, "select id from coduserbot");
         $yy = mysqli_query($connect, "select * from coduserbot");
         $alltotalll = mysqli_num_rows($ttt);
    
       
         foreach ($yy as $key => $aauserr) {
              $abb = $aauserr["id"];
         $coduserbot = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM coduserbot WHERE id = '$abb' LIMIT 1"));     
     $idnumber = $coduserbot["idnumber"];
$idbot = $coduserbot["idbot"];
$nnnn = $coduserbot["number"];
$tedadg = $coduserbot["date"];
$soood = $coduserbot["sod"];
      
             
              $get =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getStatus&id=$idnumber");
      $alll = explode(":", $get);
             $cros000 = "$alll[0]";
             $cod000 = "$alll[1]";
            

    if ($cros000 == "STATUS_OK") {
       
       file_get_contents("$web/bots/$idbot/codbots.php?user=$abb&tedad=$tedadg&number=$nnnn&idnumber=$idnumber&sod=$soood");
       
       
    }
    else{
        
        
        $tedadtimnext = $tedadg + 1 ;
        
         $connect->query("UPDATE coduserbot SET  date = '$tedadtimnext'  WHERE id = '$abb' LIMIT 1");
 file_get_contents("$web/bots/$idbot/codbots.php?user=$abb&tedad=$tedadg&number=$nnnn&idnumber=$idnumber");
}
  if ($key == $alltotalll) {
        break;
    }
}

//==================================== کنسل شماره ها

$tttd = mysqli_query($connect, "select id from numbers");
         $yyf = mysqli_query($connect, "select * from numbers");
         $alltotalllff = mysqli_num_rows($tttd);
    
       
         foreach ($yyf as $key => $aauserr) {
              $abb = $aauserr["numberid"];
         $coduserbot = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM numbers WHERE numberid = '$abb' LIMIT 1"));     
     
$idbot = $coduserbot["idbot"];
$nnnn = $coduserbot["id"];
$tedadg = $coduserbot["timout"];
      
   
      $timee = "$dat_h:$dat_min" ;
   $Dfdfdf = $time22 + 59;
    if ($time22 <= $tedadg and $tedadg <= $Dfdfdf ) {
        
        
               $get =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=setStatus&status=-1&id=$abb");
                $connect->query("DELETE FROM numbers WHERE numberid ='$abb'");
      
    }

  if ($key == $alltotalllff) {
        break;
    }
}
//==============================================
$timee = "$dat_h:$dat_min" ;
if ($timee == "23:59"){
$users = mysqli_query($connect, "select id from user");
        $alltotal = mysqli_num_rows($users);
        
$userss = mysqli_query($connect, "select id from user WHERE inviter = ''");
        $usersss = mysqli_query($connect, "select id from user WHERE inviter = '0'");
        $alltotall = mysqli_num_rows($userss);
        $alltotalll = mysqli_num_rows($usersss);
        $allzir = $alltotal - ($alltotall + $alltotalll) ;
        
$tm = $alltotall + $alltotalll ;

$ffnnbb = mysqli_query($connect,"select * from user"); 
        $ressd = mysqli_fetch_assoc($ffnnbb);
        while ($ressd = mysqli_fetch_assoc($ffnnbb)) {
  $summm += $ressd['numberby'];
}
$vvvvd = $jseting["set"]["number"]["allnumbersellbots"] +$summm ;

$sodplus =  $jseting["set"]["number"]["allsod"];


  //====================  member
        
          $ordersm = mysqli_query($connect, "select id from ordersm");
        $allordersm = mysqli_num_rows($ordersm);
        
         $ordersmt = mysqli_query($connect, "select id from ordersm WHERE statos = '✅ تکمیل شد'");
        $allordersmt = mysqli_num_rows($ordersmt);
        
        $ordersmt2 = mysqli_query($connect, "select id from ordersm WHERE statos = 'مبلغ برگشت داده شد'");
        $allordersmt2 = mysqli_num_rows($ordersmt2);
       
        $a1 = mysqli_query($connect,"select * from ordersm"); 
        $r1 = mysqli_fetch_assoc($a1);
        while ($r1 = mysqli_fetch_assoc($a1)) {
            if($r1['statos'] != "مبلغ برگشت داده شد"){
  $suma1 += $r1['price'];
            }
        }
        
        
    $a2 = mysqli_query($connect,"select * from ordersm"); 
        $r2 = mysqli_fetch_assoc($a2);
        while ($r2 = mysqli_fetch_assoc($a2)) {
             if($r2['statos'] != "مبلغ برگشت داده شد"){
  $suma2 += $r2['member'];
             }
}
$dfa1 = $suma2 / 1000 ;
$sod = $jseting["set"]["memberpric"];
$dfa2 = $suma2 * $sod ;

       //====================



$jsetting = json_decode(file_get_contents("data/seting.json"),true);
$jsetting["set"]["mrmber"]["all"]="$alltotal";
$jsetting["set"]["mrmber"]["zir"]="$allzir";
$jsetting["set"]["mrmber"]["st"]="$tm";
$jsetting["set"]["mrmber"]["num"]="$vvvvd";
$jsetting["set"]["mrmber"]["sodnum"]="$sodplus";

$jsetting["set"]["smrmber"]["oksell"]="$allordersmt";
$jsetting["set"]["smrmber"]["nosell"]="$allordersmt2";
$jsetting["set"]["smrmber"]["price"]="$suma1";
$jsetting["set"]["smrmber"]["allmember"]="$dfa1";
$jsetting["set"]["smrmber"]["sodsell"]="$dfa2";
$jsetting["set"]["smrmber"]["allsell"]="$allordersm";
$jsetting = json_encode($jsetting,true);
file_put_contents("data/seting.json",$jsetting);
//=========
 $tttdss = mysqli_query($connect, "select id from admin");
         $yyfdd = mysqli_query($connect, "select * from admin");
         $alltotalllffdd = mysqli_num_rows($tttdss);
unlink("error_log");

         foreach ($yyfdd as $keyu => $aauserr) {
              $un = $aauserr["userbot"];
  
         unlink("bots/$un/data/error_log");
              unlink("bots/$un/pay/error_log");
              unlink("bots/$un/error_log");
               unlink("pay/error_log");
    if ($keyu == $alltotalllffdd) {
        break;
    }
}
}


//===============================================
 
?>