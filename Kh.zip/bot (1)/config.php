<?php
// database 
// اطلاعات دیتا بیس را وارد کنید
$servername = "localhost";
$username = "000"; // یوزر دیتابیس
$password = "000"; // پسورد دیتابیس
$dbname = "000"; // نام دیتابیس
$connect = mysqli_connect($servername, $username, $password, $dbname);
//----------------------------------------------------------------------------
$api_key = "000"; // توکن پنل get sms را وارد کنید
$usersharg = "000";// یوزرنیم سایت آینکس
$passsharg = "000"; // پسورد سایت
$apimember="000"; // Api key سناتور عضو

$web22 = "000"; // آدرس سورس ربات
?>