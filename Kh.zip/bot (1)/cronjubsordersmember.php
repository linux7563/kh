<?php
include "bottpodkrtirtoy.php";
set_time_limit(600);


$tttd = mysqli_query($connect, "select id from ordersm WHERE statos != '✅ تکمیل شد'");
         $yyf = mysqli_query($connect, "select * from ordersm WHERE statos != '✅ تکمیل شد'");
         $alltotalllff = mysqli_num_rows($tttd);
    
       
         foreach ($yyf as $key => $aauserr) {
              $abb = $aauserr["id"];
               $abuser = $aauserr["iduser"];
               $abuserss = $aauserr["statos"];
                $abidbot = $aauserr["idbot"];
       
       $result =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=status&id=$abb"),true);
   
    $pin10= $result['stats'];
    if ($pin10 == "تکمیل شد") {
      
              $connect->query("UPDATE ordersm SET statos = '✅ تکمیل شد' WHERE id = '$abb' LIMIT 1");
              
        if($abidbot =="numberinobot"){
         $abb2 = $aauserr["statos"];
                $ablink = $aauserr["link"];
                 $abtype = $aauserr["service"];
                  $abprice = $aauserr["price"];
                   $abdate = $aauserr["date"];
                    $abmember = $aauserr["member"];
                    
                    	$result =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
     
                         $pin100= $result['products']["$abtype"]['name'];
        
        
         jijibot('sendmessage', [
            'chat_id' => "$abuser",
            'text' =>"
✅ سفارش شما با شناسه $abb با موفقیت تکمیل شد

🔗 لینک : $ablink
🌐 نوع سفارش : $pin100
💰 هزینه سفارش : $abprice تومان
⏱ زمان : $abdate
👤 تعداد ممبر درخواستی : $abmember
.           " ,
        ]);
              

    
        }if($abidbot !="numberinobot"){
        
        $get256 = file_get_contents("$web/bots/$abidbot/smpbots.php?code=3&order=$abb");
        
    }

            
        }
     if ($pin10 != "تکمیل شد" and $pin10 != $abuserss  ) {
          $connect->query("UPDATE ordersm SET statos = '$pin10' WHERE id = '$abb' LIMIT 1");
         
          if($abidbot =="numberinobot"){
              
                    if($pin10 == "مبلغ برگشت داده شد"){
                        
                         $abb2 = $aauserr["statos"];
                $ablink = $aauserr["link"];
                 $abtype = $aauserr["service"];
                  $abprice = $aauserr["price"];
                   $abdate = $aauserr["date"];
                    $abmember = $aauserr["member"];
                    
                       $userss = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '$abuser' LIMIT 1"));
                        $plusstock = $userss["stock"] + $aauserr["price"];
                        
$connect->query("UPDATE user SET stock = '$plusstock' WHERE id = '$abuser' LIMIT 1");
                        
                        $bb12 = $jseting["set"]["number"]["allsod"] - $pin10m ;
                        $jsetingo = json_decode(file_get_contents("data/seting.json"),true);	
                        $jsetingo["set"]["number"]["allsod"] = "$bb12";
                        $jsetingo = json_encode($jsetingo,true);
                        file_put_contents("data/seting.json",$jsetingo);

$result =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
     $pin100= $result['products']["$abtype"]['name'];


jijibot('sendmessage', [
            'chat_id' => "$abuser",
            'text' =>"
❌ سفارش شما با شناسه $abb انجام نشد و مبلغ کسر شده به شما برگشت داده شد

🔗 لینک : $ablink
🌐 نوع سفارش : $pin100
💰 هزینه سفارش : $abprice تومان
⏱ زمان : $abdate
👤 تعداد ممبر درخواستی : $abmember
.           " ,
        ]);
                        
                    }else{
         jijibot('sendmessage', [
            'chat_id' => "$abuser",
            'text' =>"
❗️ سفارش شما با شناسه $abb تغییر وضعیت پیدا کرد.

وضعیت فعلی سفارش : $pin10
.           " ,
        ]);
        
                    }
     }if($abidbot !="numberinobot"){
         
         if($pin10 == "مبلغ برگشت داده شد"){
        
        $get256 = file_get_contents("$web/bots/$abidbot/smpbots.php?code=5&order=$abb");
         }else{
              $get256 = file_get_contents("$web/bots/$abidbot/smpbots.php?code=4&order=$abb");
         }
    }
     }
   
  if ($key == $alltotalllff) {
        break;
    }
    
   
}



?>