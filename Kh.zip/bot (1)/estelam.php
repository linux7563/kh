<?php


if ($textmassage == "💳 استعلام | قیمت ها") {
  
   
        
          jijibot('sendmessage', [
         'chat_id'=>$chat_id,
     
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💎 تلگرام", 'callback_data' => "tgg"], ['text' => "📸 اینستاگرام", 'callback_data' => "inn"], ['text' => "📞 واتساپ", 'callback_data' => "waa"]
                    ],
                     [
                        ['text' => "🔍 گوگل", 'callback_data' => "goo"], ['text' => "💡 وایبر", 'callback_data' => "vaii"], ['text' => "💬 ویچت", 'callback_data' => "weee"]
                    ],
                     [
                        ['text' => "📪 فیسبوک", 'callback_data' => "fas"], ['text' => "🐦 توییتر", 'callback_data' => "tow"], ['text' => "📨 یاهو", 'callback_data' => "yaho"]
                    ],
                     [
                        ['text' => "💭 ایمو", 'callback_data' => "imoo"], ['text' => "♨️ لینک دین", 'callback_data' => "paypal"], ['text' => "📗 لاین", 'callback_data' => "linn"]
                    ],
                     [
                        ['text' => "📬 ویکی", 'callback_data' => "vikiii"], ['text' => "💻 ماکروسافت", 'callback_data' => "mrs"], ['text' => "🛒 آمازون", 'callback_data' => "amaz"]
                    ],
                     
                     [
                        ['text' => "🌐 دیگر سرویس ها", 'callback_data' => "other"]
                    ],
                    [
                        ['text' => "🔙 برگشت", 'callback_data' => "backpan"], ['text' => "🚦 راهنما", 'callback_data' => "help"]
                    ]
                ]
            ])
        ]);
        
     } 
elseif ($data == "backpan") {
   
   
         jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💎 تلگرام", 'callback_data' => "tgg"], ['text' => "📸 اینستاگرام", 'callback_data' => "inn"], ['text' => "📞 واتساپ", 'callback_data' => "waa"]
                    ],
                     [
                        ['text' => "🔍 گوگل", 'callback_data' => "goo"], ['text' => "💡 وایبر", 'callback_data' => "vaii"], ['text' => "💬 ویچت", 'callback_data' => "weee"]
                    ],
                     [
                        ['text' => "📪 فیسبوک", 'callback_data' => "fas"], ['text' => "🐦 توییتر", 'callback_data' => "tow"], ['text' => "📨 یاهو", 'callback_data' => "yaho"]
                    ],
                     [
                        ['text' => "💭 ایمو", 'callback_data' => "imoo"], ['text' => "♨️ لینک دین", 'callback_data' => "paypal"], ['text' => "📗 لاین", 'callback_data' => "linn"]
                    ],
                     [
                        ['text' => "📬 ویکی", 'callback_data' => "vikiii"], ['text' => "💻 ماکروسافت", 'callback_data' => "mrs"], ['text' => "🛒 آمازون", 'callback_data' => "amaz"]
                    ],
                     
                     [
                        ['text' => "🌐 دیگر سرویس ها", 'callback_data' => "other"]
                    ],
                    [
                        ['text' => "🔙 برگشت", 'callback_data' => "backpan"], ['text' => "🚦 راهنما", 'callback_data' => "help"]
                    ]
                ]
            ])
        ]);
          $juser = json_decode(file_get_contents("data/$fromid.json"),true);  
$juser["service"]="";

$juser = json_encode($juser,true);
file_put_contents("data/$fromid.json",$juser);
    }

elseif (in_array($data, array("tgg", "inn", "waa", "goo", "vaii", "weee", "fas", "tow", "yaho", "imoo", "paypal", "linn", "vikiii", "mrs", "amaz", "other"))) {
     
   $str = str_replace(["tgg", "inn", "waa", "goo", "vaii", "weee", "fas", "tow", "yaho", "imoo", "paypal", "linn", "vikiii", "mrs", "amaz", "other"], ["tg", "ig", "wa", "go", "vi", "wb", "fb" , "tw" , "mb", "im", "tn", "me", "vk", "mm", "am" , "ot" ], $data);
    
    $juser = json_decode(file_get_contents("data/$fromid.json"),true);  
$juser["service"]="$str";

$juser = json_encode($juser,true);
file_put_contents("data/$fromid.json",$juser);

     jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
درحال استعلام...
        ",         ]);
        
        
    $str2 = str_replace(["tgg", "inn", "waa", "goo", "vaii", "weee", "fas", "tow", "yaho", "imoo", "paypal", "linn", "vikiii", "mrs", "amaz", "other"], ["💎 تلگرام", "📸 اینستاگرام", "📞 واتساپ", "🔍 گوگل", "💡 وایبر", "💬 ویچت", "📪 فیسبوک", "🐦 توییتر", "📨 یاهو","💭 ایمو", "♨️ لینک دین", "📬 ویکی", "📗 لاین", "💻 ماکروسافت", "🛒 آمازون", "🌐 دیگر سرویس ها"], $data);
    
    $str5 = str_replace(["tgg", "inn", "waa", "goo", "vaii", "weee", "fas", "tow", "yaho", "imoo", "paypal", "linn", "vikiii", "mrs", "amaz", "other"], [["tg", "ig", "wa", "go", "vi", "wb", "fb" , "tw" , "mb", "im", "tn", "me", "vk", "mm", "am" , "ot" ]], $data);
    $userservicp = $jusert["panel"];
    $userservicn = $jusert["service"];
    $countryss = array("1","2","3","78","4","5","6","7","8","9","10","11","12","13","14","15","16","18","19","20","21","22","23","24","25","26","27","28");
    $jjseting = json_decode(file_get_contents("../../data/seting.json"),true);
  $ttt = $jjseting["set"]["up"]["time"];
  $ddd = $jjseting["set"]["up"]["data"];
   $zarib = $jjseting["set"]["robelpric"];
      
$jsetting1 = json_decode(file_get_contents("../../data/prics/0.json"),true);
$jsetting2 = json_decode(file_get_contents("../../data/prics/1.json"),true);
$jsetting3 = json_decode(file_get_contents("../../data/prics/2.json"),true);
$jsetting78 = json_decode(file_get_contents("../../data/prics/57.json"),true);
$jsetting4 = json_decode(file_get_contents("../../data/prics/3.json"),true);
$jsetting5 = json_decode(file_get_contents("../../data/prics/4.json"),true);
$jsetting6 = json_decode(file_get_contents("../../data/prics/5.json"),true);
$jsetting7 = json_decode(file_get_contents("../../data/prics/6.json"),true);
$jsetting8 = json_decode(file_get_contents("../../data/prics/7.json"),true);
$jsetting9 = json_decode(file_get_contents("../../data/prics/8.json"),true);
$jsetting10 = json_decode(file_get_contents("../../data/prics/13.json"),true);
$jsetting11 = json_decode(file_get_contents("../../data/prics/10.json"),true);
$jsetting12 = json_decode(file_get_contents("../../data/prics/16.json"),true);
$jsetting13 = json_decode(file_get_contents("../../data/prics/44.json"),true);
$jsetting14 = json_decode(file_get_contents("../../data/prics/32.json"),true);
$jsetting15 = json_decode(file_get_contents("../../data/prics/34.json"),true);
$jsetting16 = json_decode(file_get_contents("../../data/prics/12.json"),true);
$jsetting18 = json_decode(file_get_contents("../../data/prics/11.json"),true);
$jsetting19 = json_decode(file_get_contents("../../data/prics/78.json"),true);
$jsetting20 = json_decode(file_get_contents("../../data/prics/76.json"),true);
$jsetting21 = json_decode(file_get_contents("../../data/prics/24.json"),true);
$jsetting22 = json_decode(file_get_contents("../../data/prics/20.json"),true);
$jsetting23 = json_decode(file_get_contents("../../data/prics/14.json"),true);
$jsetting24 = json_decode(file_get_contents("../../data/prics/73.json"),true);
$jsetting25 = json_decode(file_get_contents("../../data/prics/48.json"),true);
$jsetting26 = json_decode(file_get_contents("../../data/prics/87.json"),true);
$jsetting27 = json_decode(file_get_contents("../../data/prics/15.json"),true);
$jsetting28 = json_decode(file_get_contents("../../data/prics/44.json"),true);

    
$ros0 = $jsetting1["$str"]["amount"] * $zarib;
$cros00 = $jsetting1["$str"]["count"];


$ros1 = $jsetting2["$str"]["amount"] * $zarib;
$cros11 =$jsetting2["$str"]["count"];


$ros15 = $jsetting3["$str"]["amount"] * $zarib;
$cros1515 = $jsetting3["$str"]["count"];


$ros16 = $jsetting78["$str"]["amount"] * $zarib;
$cros1616 = $jsetting78["$str"]["count"];


$ros23 = $jsetting4["$str"]["amount"] * $zarib;
$cros2323 = $jsetting4["$str"]["count"];


$ros43 = $jsetting5["$str"]["amount"] * $zarib;
$cros4343 = $jsetting5["$str"]["count"];


$ros49 = $jsetting6["$str"]["amount"] * $zarib;
$cros4949 = $jsetting6["$str"]["count"];


$ros56 = $jsetting7["$str"]["amount"] * $zarib;
$cros5656 = $jsetting7["$str"]["count"];

$ros3 = $jsetting8["$str"]["amount"] * $zarib;
$cros33 = $jsetting8["$str"]["count"];


$ros4 = $jsetting9["$str"]["amount"] * $zarib;
$cros44 = $jsetting9["$str"]["count"];


$ros6 = $jsetting10["$str"]["amount"] * $zarib;
$cros66 = $jsetting10["$str"]["count"];


$ros7 = $jsetting11["$str"]["amount"] * $zarib;
$cros77 = $jsetting11["$str"]["count"];


$ros13 = $jsetting12["$str"]["amount"] * $zarib;
$cros1313 = $jsetting12["$str"]["count"];


$ros22 = $jsetting13["$str"]["amount"] * $zarib;
$cros2222 = $jsetting13["$str"]["count"];


$ros35 = $jsetting14["$str"]["amount"] * $zarib;
$cros3535 = $jsetting14["$str"]["count"];


$ros47 = $jsetting15["$str"]["amount"] * $zarib;
$cros4747 = $jsetting15["$str"]["count"];


$ros52 = $jsetting16["$str"]["amount"] * $zarib;
$cros5252 = $jsetting16["$str"]["count"];


$ros53 = $jsetting18["$str"]["amount"] * $zarib;
$cros5353 = $jsetting18["$str"]["count"];

$ros55 = $jsetting19["$str"]["amount"] * $zarib;
$cros5555 = $jsetting19["$str"]["count"];


$ros57 = $jsetting20["$str"]["amount"] * $zarib;
$cros5757 = $jsetting20["$str"]["count"];


$ros66 = $jsetting21["$str"]["amount"] * $zarib;
$cros6666 = $jsetting21["$str"]["count"];


$ros67 = $jsetting22["$str"]["amount"] * $zarib;
$cros6767 = $jsetting22["$str"]["count"];


$ros21 = $jsetting23["$str"]["amount"] * $zarib;
$cros2121 = $jsetting23["$str"]["count"];


$ros27 = $jsetting24["$str"]["amount"] * $zarib;
$cros2727 = $jsetting24["$str"]["count"];


$ros30 = $jsetting25["$str"]["amount"] * $zarib;
$cros3030 = $jsetting25["$str"]["count"];


$ros37 = $jsetting26["$str"]["amount"] * $zarib;
$cros3737 = $jsetting26["$str"]["count"];


$ros58 = $jsetting27["$str"]["amount"] * $zarib;
$cros5858 = $jsetting27["$str"]["count"];


$ros12 = $jsetting28["$str"]["amount"] * $zarib;
$cros1212 = $jsetting28["$str"]["count"];


     jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 15 دقيقه يک بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .

🌟 = شماره هایی که کنار آنها ستاره وجود دارد ریپورت نیستند.

 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇷🇺 روسیه ", 'callback_data' => "text"], ['text' => "$ros0", 'callback_data' => "text"], ['text' => "$cros00", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇺🇦 اکراین ", 'callback_data' => "text"], ['text' => "$ros1", 'callback_data' => "text"], ['text' => "$cros11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇰🇿 قزاقستان ", 'callback_data' => "text"], ['text' => "$ros15", 'callback_data' => "text"], ['text' => "$cros1515", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇮🇷 ایران ", 'callback_data' => "text"], ['text' => "$ros16", 'callback_data' => "text"], ['text' => "$cros1616", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇨🇳 چین ", 'callback_data' => "text"], ['text' => "$ros23", 'callback_data' => "text"], ['text' => "$cros2323", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇵🇭 فیلیپین ", 'callback_data' => "text"], ['text' => "$ros43", 'callback_data' => "text"], ['text' => "$cros4343", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇲🇲 میانمار ", 'callback_data' => "text"], ['text' => "$ros49", 'callback_data' => "text"], ['text' => "$cros4949", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇮🇩 اندونزی ", 'callback_data' => "text"], ['text' => "$ros56", 'callback_data' => "text"], ['text' => "$cros5656", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇲🇾 مالزی ", 'callback_data' => "text"], ['text' => "$ros3", 'callback_data' => "text"], ['text' => "$cros33", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇰🇪 کنیا ", 'callback_data' => "text"], ['text' => "$ros4", 'callback_data' => "text"], ['text' => "$cros44", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇹🇿 اسرائیل ", 'callback_data' => "text"], ['text' => "$ros6", 'callback_data' => "text"], ['text' => "$cros66", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇻🇳 ویتنام ", 'callback_data' => "text"], ['text' => "$ros7", 'callback_data' => "text"], ['text' => "$cros77", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇬🇧 انگلستان ", 'callback_data' => "text"], ['text' => "$ros13", 'callback_data' => "text"], ['text' => "$cros1313", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇱🇻 لتونی ", 'callback_data' => "text"], ['text' => "$ros22", 'callback_data' => "text"], ['text' => "$cros2222", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇷🇴 رومانی ", 'callback_data' => "text"], ['text' => "$ros35", 'callback_data' => "text"], ['text' => "$cros3535", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇪🇪 استونی ", 'callback_data' => "text"], ['text' => "$ros47", 'callback_data' => "text"], ['text' => "$cros4747", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇺🇸 آمریکا ", 'callback_data' => "text"], ['text' => "$ros52", 'callback_data' => "text"], ['text' => "$cros5252", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇰🇬 قرقیزستان ", 'callback_data' => "text"], ['text' => "$ros53", 'callback_data' => "text"], ['text' => "$cros5353", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇫🇷 فرانسه ", 'callback_data' => "text"], ['text' => "$ros55", 'callback_data' => "text"], ['text' => "$cros5555", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇵🇸 آنگولا ", 'callback_data' => "text"], ['text' => "$ros57", 'callback_data' => "text"], ['text' => "$cros5757", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇰🇭 کامبوج ", 'callback_data' => "text"], ['text' => "$ros66", 'callback_data' => "text"], ['text' => "$cros6666", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇲🇴 ماکائو ", 'callback_data' => "text"], ['text' => "$ros67", 'callback_data' => "text"], ['text' => "$cros6767", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇭🇰 هنگ کنگ ", 'callback_data' => "text"], ['text' => "$ros21", 'callback_data' => "text"], ['text' => "$cros2121", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇧🇷 برزیل ", 'callback_data' => "text"], ['text' => "$ros27", 'callback_data' => "text"], ['text' => "$cros2727", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇵🇱 لهستان ", 'callback_data' => "text"], ['text' => "$ros30", 'callback_data' => "text"], ['text' => "$cros3030", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇵🇾 پاراگوئه ", 'callback_data' => "text"], ['text' => "$ros37", 'callback_data' => "text"], ['text' => "$cros3737", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇳🇱 هلند ", 'callback_data' => "text"], ['text' => "$ros58", 'callback_data' => "text"], ['text' => "$cros5858", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇱🇻 لیتوانی ", 'callback_data' => "text"], ['text' => "$ros12", 'callback_data' => "text"], ['text' => "$cros1212", 'callback_data' => "text"]
                    ],
                                        [
                       
                    ],
                                          [
                        ['text' => "صفحه 2", 'callback_data' => "pag2"], ['text' => "صفحه 3", 'callback_data' => "pag3"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"]
                    ],

                ],
            
        ])
        
    ]);     

}
elseif ($data == "pag1") {
     
  $str = $jusert["service"];
        $str55 = str_replace(["tg", "ig", "wa", "go", "vi", "wb", "fb" , "tw" , "mb", "im", "tn", "me", "vk", "mm", "am" , "ot" ], ["💎 تلگرام", "📸 اینستاگرام", "📞 واتساپ", "🔍 گوگل", "💡 وایبر", "💬 ویچت", "📪 فیسبوک", "🐦 توییتر", "📨 یاهو","💭 ایمو", "♨️ لینک دین", "📬 ویکی", "📗 لاین", "💻 ماکروسافت", "🛒 آمازون", "🌐 دیگر سرویس ها"], $str);
     
    $userservicp = $jusert["panel"];
    
    
   $jjseting = json_decode(file_get_contents("../../data/seting.json"),true);
  $ttt = $jjseting["set"]["up"]["time"];
  $ddd = $jjseting["set"]["up"]["data"];
   $zarib = $jjseting["set"]["robelpric"];
      
$jsetting1 = json_decode(file_get_contents("../../data/prics/0.json"),true);
$jsetting2 = json_decode(file_get_contents("../../data/prics/1.json"),true);
$jsetting3 = json_decode(file_get_contents("../../data/prics/2.json"),true);
$jsetting78 = json_decode(file_get_contents("../../data/prics/57.json"),true);
$jsetting4 = json_decode(file_get_contents("../../data/prics/3.json"),true);
$jsetting5 = json_decode(file_get_contents("../../data/prics/4.json"),true);
$jsetting6 = json_decode(file_get_contents("../../data/prics/5.json"),true);
$jsetting7 = json_decode(file_get_contents("../../data/prics/6.json"),true);
$jsetting8 = json_decode(file_get_contents("../../data/prics/7.json"),true);
$jsetting9 = json_decode(file_get_contents("../../data/prics/8.json"),true);
$jsetting10 = json_decode(file_get_contents("../../data/prics/13.json"),true);
$jsetting11 = json_decode(file_get_contents("../../data/prics/10.json"),true);
$jsetting12 = json_decode(file_get_contents("../../data/prics/16.json"),true);
$jsetting13 = json_decode(file_get_contents("../../data/prics/44.json"),true);
$jsetting14 = json_decode(file_get_contents("../../data/prics/32.json"),true);
$jsetting15 = json_decode(file_get_contents("../../data/prics/34.json"),true);
$jsetting16 = json_decode(file_get_contents("../../data/prics/12.json"),true);
$jsetting18 = json_decode(file_get_contents("../../data/prics/11.json"),true);
$jsetting19 = json_decode(file_get_contents("../../data/prics/78.json"),true);
$jsetting20 = json_decode(file_get_contents("../../data/prics/76.json"),true);
$jsetting21 = json_decode(file_get_contents("../../data/prics/24.json"),true);
$jsetting22 = json_decode(file_get_contents("../../data/prics/20.json"),true);
$jsetting23 = json_decode(file_get_contents("../../data/prics/14.json"),true);
$jsetting24 = json_decode(file_get_contents("../../data/prics/73.json"),true);
$jsetting25 = json_decode(file_get_contents("../../data/prics/48.json"),true);
$jsetting26 = json_decode(file_get_contents("../../data/prics/87.json"),true);
$jsetting27 = json_decode(file_get_contents("../../data/prics/15.json"),true);
$jsetting28 = json_decode(file_get_contents("../../data/prics/44.json"),true);

    
$ros0 = $jsetting1["$str"]["amount"] * $zarib;
$cros00 = $jsetting1["$str"]["count"];


$ros1 = $jsetting2["$str"]["amount"] * $zarib;
$cros11 =$jsetting2["$str"]["count"];


$ros15 = $jsetting3["$str"]["amount"] * $zarib;
$cros1515 = $jsetting3["$str"]["count"];


$ros16 = $jsetting78["$str"]["amount"] * $zarib;
$cros1616 = $jsetting78["$str"]["count"];


$ros23 = $jsetting4["$str"]["amount"] * $zarib;
$cros2323 = $jsetting4["$str"]["count"];


$ros43 = $jsetting5["$str"]["amount"] * $zarib;
$cros4343 = $jsetting5["$str"]["count"];


$ros49 = $jsetting6["$str"]["amount"] * $zarib;
$cros4949 = $jsetting6["$str"]["count"];


$ros56 = $jsetting7["$str"]["amount"] * $zarib;
$cros5656 = $jsetting7["$str"]["count"];

$ros3 = $jsetting8["$str"]["amount"] * $zarib;
$cros33 = $jsetting8["$str"]["count"];


$ros4 = $jsetting9["$str"]["amount"] * $zarib;
$cros44 = $jsetting9["$str"]["count"];


$ros6 = $jsetting10["$str"]["amount"] * $zarib;
$cros66 = $jsetting10["$str"]["count"];


$ros7 = $jsetting11["$str"]["amount"] * $zarib;
$cros77 = $jsetting11["$str"]["count"];


$ros13 = $jsetting12["$str"]["amount"] * $zarib;
$cros1313 = $jsetting12["$str"]["count"];


$ros22 = $jsetting13["$str"]["amount"] * $zarib;
$cros2222 = $jsetting13["$str"]["count"];


$ros35 = $jsetting14["$str"]["amount"] * $zarib;
$cros3535 = $jsetting14["$str"]["count"];


$ros47 = $jsetting15["$str"]["amount"] * $zarib;
$cros4747 = $jsetting15["$str"]["count"];


$ros52 = $jsetting16["$str"]["amount"] * $zarib;
$cros5252 = $jsetting16["$str"]["count"];


$ros53 = $jsetting18["$str"]["amount"] * $zarib;
$cros5353 = $jsetting18["$str"]["count"];

$ros55 = $jsetting19["$str"]["amount"] * $zarib;
$cros5555 = $jsetting19["$str"]["count"];


$ros57 = $jsetting20["$str"]["amount"] * $zarib;
$cros5757 = $jsetting20["$str"]["count"];


$ros66 = $jsetting21["$str"]["amount"] * $zarib;
$cros6666 = $jsetting21["$str"]["count"];


$ros67 = $jsetting22["$str"]["amount"] * $zarib;
$cros6767 = $jsetting22["$str"]["count"];


$ros21 = $jsetting23["$str"]["amount"] * $zarib;
$cros2121 = $jsetting23["$str"]["count"];


$ros27 = $jsetting24["$str"]["amount"] * $zarib;
$cros2727 = $jsetting24["$str"]["count"];


$ros30 = $jsetting25["$str"]["amount"] * $zarib;
$cros3030 = $jsetting25["$str"]["count"];


$ros37 = $jsetting26["$str"]["amount"] * $zarib;
$cros3737 = $jsetting26["$str"]["count"];


$ros58 = $jsetting27["$str"]["amount"] * $zarib;
$cros5858 = $jsetting27["$str"]["count"];


$ros12 = $jsetting28["$str"]["amount"] * $zarib;
$cros1212 = $jsetting28["$str"]["count"];


     jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 15 دقيقه يک بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .

🌟 = شماره هایی که کنار آنها ستاره وجود دارد ریپورت نیستند.

 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇷🇺 روسیه ", 'callback_data' => "text"], ['text' => "$ros0", 'callback_data' => "text"], ['text' => "$cros00", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇺🇦 اکراین ", 'callback_data' => "text"], ['text' => "$ros1", 'callback_data' => "text"], ['text' => "$cros11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇰🇿 قزاقستان ", 'callback_data' => "text"], ['text' => "$ros15", 'callback_data' => "text"], ['text' => "$cros1515", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇮🇷 ایران ", 'callback_data' => "text"], ['text' => "$ros16", 'callback_data' => "text"], ['text' => "$cros1616", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇨🇳 چین ", 'callback_data' => "text"], ['text' => "$ros23", 'callback_data' => "text"], ['text' => "$cros2323", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇵🇭 فیلیپین ", 'callback_data' => "text"], ['text' => "$ros43", 'callback_data' => "text"], ['text' => "$cros4343", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇲🇲 میانمار ", 'callback_data' => "text"], ['text' => "$ros49", 'callback_data' => "text"], ['text' => "$cros4949", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇮🇩 اندونزی ", 'callback_data' => "text"], ['text' => "$ros56", 'callback_data' => "text"], ['text' => "$cros5656", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇲🇾 مالزی ", 'callback_data' => "text"], ['text' => "$ros3", 'callback_data' => "text"], ['text' => "$cros33", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇰🇪 کنیا ", 'callback_data' => "text"], ['text' => "$ros4", 'callback_data' => "text"], ['text' => "$cros44", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇹🇿 اسرائیل ", 'callback_data' => "text"], ['text' => "$ros6", 'callback_data' => "text"], ['text' => "$cros66", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇻🇳 ویتنام ", 'callback_data' => "text"], ['text' => "$ros7", 'callback_data' => "text"], ['text' => "$cros77", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇬🇧 انگلستان ", 'callback_data' => "text"], ['text' => "$ros13", 'callback_data' => "text"], ['text' => "$cros1313", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇱🇻 لتونی ", 'callback_data' => "text"], ['text' => "$ros22", 'callback_data' => "text"], ['text' => "$cros2222", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇷🇴 رومانی ", 'callback_data' => "text"], ['text' => "$ros35", 'callback_data' => "text"], ['text' => "$cros3535", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇪🇪 استونی ", 'callback_data' => "text"], ['text' => "$ros47", 'callback_data' => "text"], ['text' => "$cros4747", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇺🇸 آمریکا ", 'callback_data' => "text"], ['text' => "$ros52", 'callback_data' => "text"], ['text' => "$cros5252", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇰🇬 قرقیزستان ", 'callback_data' => "text"], ['text' => "$ros53", 'callback_data' => "text"], ['text' => "$cros5353", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇫🇷 فرانسه ", 'callback_data' => "text"], ['text' => "$ros55", 'callback_data' => "text"], ['text' => "$cros5555", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇵🇸 آنگولا ", 'callback_data' => "text"], ['text' => "$ros57", 'callback_data' => "text"], ['text' => "$cros5757", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇰🇭 کامبوج ", 'callback_data' => "text"], ['text' => "$ros66", 'callback_data' => "text"], ['text' => "$cros6666", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇲🇴 ماکائو ", 'callback_data' => "text"], ['text' => "$ros67", 'callback_data' => "text"], ['text' => "$cros6767", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇭🇰 هنگ کنگ ", 'callback_data' => "text"], ['text' => "$ros21", 'callback_data' => "text"], ['text' => "$cros2121", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇧🇷 برزیل ", 'callback_data' => "text"], ['text' => "$ros27", 'callback_data' => "text"], ['text' => "$cros2727", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇵🇱 لهستان ", 'callback_data' => "text"], ['text' => "$ros30", 'callback_data' => "text"], ['text' => "$cros3030", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇵🇾 پاراگوئه ", 'callback_data' => "text"], ['text' => "$ros37", 'callback_data' => "text"], ['text' => "$cros3737", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇳🇱 هلند ", 'callback_data' => "text"], ['text' => "$ros58", 'callback_data' => "text"], ['text' => "$cros5858", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇱🇻 لیتوانی ", 'callback_data' => "text"], ['text' => "$ros12", 'callback_data' => "text"], ['text' => "$cros1212", 'callback_data' => "text"]
                    ],
                                        [
                       
                    ],
                                          [
                        ['text' => "صفحه 2", 'callback_data' => "pag2"], ['text' => "صفحه 3", 'callback_data' => "pag3"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"]
                    ],

                ],
            
        ])
        
    ]);     

}
elseif ($data == "pag2") {
     
   
     jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
درحال استعلام...
        ",         ]);
        $str = $jusert["service"];
    $str2 = str_replace(["tg", "ig", "wa", "go", "vi", "wb", "fb" , "tw" , "mb", "im", "tn", "me", "vk", "mm", "am" , "ot" ], ["💎 تلگرام", "📸 اینستاگرام", "📞 واتساپ", "🔍 گوگل", "💡 وایبر", "💬 ویچت", "📪 فیسبوک", "🐦 توییتر", "📨 یاهو","💭 ایمو", "♨️ لینک دین", "📬 ویکی", "📗 لاین", "💻 ماکروسافت", "🛒 آمازون", "🌐 دیگر سرویس ها"], $str);
     $userservicp = $jusert["panel"];
    $str5 = $jusert["service"];
    
    $jjseting = json_decode(file_get_contents("../../data/seting.json"),true);
  $ttt = $jjseting["set"]["up"]["time"];
  $ddd = $jjseting["set"]["up"]["data"];
   $zarib = $jjseting["set"]["robelpric"];
 $jsetting1 = json_decode(file_get_contents("../../data/prics/17.json"),true);
$jsetting2 = json_decode(file_get_contents("../../data/prics/18.json"),true);
$jsetting3 = json_decode(file_get_contents("../../data/prics/19.json"),true);
$jsetting78 = json_decode(file_get_contents("../../data/prics/31.json"),true);
$jsetting4 = json_decode(file_get_contents("../../data/prics/77.json"),true);
$jsetting5 = json_decode(file_get_contents("../../data/prics/21.json"),true);
$jsetting6 = json_decode(file_get_contents("../../data/prics/22.json"),true);
$jsetting7 = json_decode(file_get_contents("../../data/prics/23.json"),true);
$jsetting8 = json_decode(file_get_contents("../../data/prics/27.json"),true);
$jsetting9 = json_decode(file_get_contents("../../data/prics/29.json"),true);
$jsetting10 = json_decode(file_get_contents("../../data/prics/25.json"),true);
$jsetting11 = json_decode(file_get_contents("../../data/prics/37.json"),true);
$jsetting12 = json_decode(file_get_contents("../../data/prics/30.json"),true);
$jsetting13 = json_decode(file_get_contents("../../data/prics/38.json"),true);
$jsetting14 = json_decode(file_get_contents("../../data/prics/36.json"),true);
$jsetting15 = json_decode(file_get_contents("../../data/prics/39.json"),true);
$jsetting16 = json_decode(file_get_contents("../../data/prics/47.json"),true);
$jsetting18 = json_decode(file_get_contents("../../data/prics/43.json"),true);
$jsetting19 = json_decode(file_get_contents("../../data/prics/41.json"),true);
$jsetting20 = json_decode(file_get_contents("../../data/prics/62.json"),true);
$jsetting21 = json_decode(file_get_contents("../../data/prics/67.json"),true);
$jsetting22 = json_decode(file_get_contents("../../data/prics/50.json"),true);
$jsetting23 = json_decode(file_get_contents("../../data/prics/33.json"),true);
$jsetting24 = json_decode(file_get_contents("../../data/prics/70.json"),true);
$jsetting25 = json_decode(file_get_contents("../../data/prics/26.json"),true);
$jsetting26 = json_decode(file_get_contents("../../data/prics/79.json"),true);
$jsetting27 = json_decode(file_get_contents("../../data/prics/85.json"),true);
$jsetting28 = json_decode(file_get_contents("../../data/prics/80.json"),true);

    
$ros0 = $jsetting1["$str"]["amount"] * $zarib;
$cros00 = $jsetting1["$str"]["count"];


$ros1 = $jsetting2["$str"]["amount"] * $zarib;
$cros11 =$jsetting2["$str"]["count"];


$ros15 = $jsetting3["$str"]["amount"] * $zarib;
$cros1515 = $jsetting3["$str"]["count"];


$ros16 = $jsetting78["$str"]["amount"] * $zarib;
$cros1616 = $jsetting78["$str"]["count"];


$ros23 = $jsetting4["$str"]["amount"] * $zarib;
$cros2323 = $jsetting4["$str"]["count"];


$ros43 = $jsetting5["$str"]["amount"] * $zarib;
$cros4343 = $jsetting5["$str"]["count"];


$ros49 = $jsetting6["$str"]["amount"] * $zarib;
$cros4949 = $jsetting6["$str"]["count"];


$ros56 = $jsetting7["$str"]["amount"] * $zarib;
$cros5656 = $jsetting7["$str"]["count"];

$ros3 = $jsetting8["$str"]["amount"] * $zarib;
$cros33 = $jsetting8["$str"]["count"];


$ros4 = $jsetting9["$str"]["amount"] * $zarib;
$cros44 = $jsetting9["$str"]["count"];


$ros6 = $jsetting10["$str"]["amount"] * $zarib;
$cros66 = $jsetting10["$str"]["count"];


$ros7 = $jsetting11["$str"]["amount"] * $zarib;
$cros77 = $jsetting11["$str"]["count"];


$ros13 = $jsetting12["$str"]["amount"] * $zarib;
$cros1313 = $jsetting12["$str"]["count"];


$ros22 = $jsetting13["$str"]["amount"] * $zarib;
$cros2222 = $jsetting13["$str"]["count"];


$ros35 = $jsetting14["$str"]["amount"] * $zarib;
$cros3535 = $jsetting14["$str"]["count"];


$ros47 = $jsetting15["$str"]["amount"] * $zarib;
$cros4747 = $jsetting15["$str"]["count"];


$ros52 = $jsetting16["$str"]["amount"] * $zarib;
$cros5252 = $jsetting16["$str"]["count"];


$ros53 = $jsetting18["$str"]["amount"] * $zarib;
$cros5353 = $jsetting18["$str"]["count"];

$ros55 = $jsetting19["$str"]["amount"] * $zarib;
$cros5555 = $jsetting19["$str"]["count"];


$ros57 = $jsetting20["$str"]["amount"] * $zarib;
$cros5757 = $jsetting20["$str"]["count"];


$ros66 = $jsetting21["$str"]["amount"] * $zarib;
$cros6666 = $jsetting21["$str"]["count"];


$ros67 = $jsetting22["$str"]["amount"] * $zarib;
$cros6767 = $jsetting22["$str"]["count"];


$ros21 = $jsetting23["$str"]["amount"] * $zarib;
$cros2121 = $jsetting23["$str"]["count"];


$ros27 = $jsetting24["$str"]["amount"] * $zarib;
$cros2727 = $jsetting24["$str"]["count"];


$ros30 = $jsetting25["$str"]["amount"] * $zarib;
$cros3030 = $jsetting25["$str"]["count"];


$ros37 = $jsetting26["$str"]["amount"] * $zarib;
$cros3737 = $jsetting26["$str"]["count"];


$ros58 = $jsetting27["$str"]["amount"] * $zarib;
$cros5858 = $jsetting27["$str"]["count"];


$ros12 = $jsetting28["$str"]["amount"] * $zarib;
$cros1212 = $jsetting28["$str"]["count"];

     jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "

☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 15 دقيقه يک بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .

🌟 = شماره هایی که کنار آنها ستاره وجود دارد ریپورت نیستند.

 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇲🇬 ماداگاسکار ", 'callback_data' => "text"], ['text' => "$ros0", 'callback_data' => "text"], ['text' => "$cros00", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇨🇩 کنگو ", 'callback_data' => "text"], ['text' => "$ros1", 'callback_data' => "text"], ['text' => "$cros11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇳🇬 نیجریه ", 'callback_data' => "text"], ['text' => "$ros15", 'callback_data' => "text"], ['text' => "$cros1515", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇿🇦 آفریقا ", 'callback_data' => "text"], ['text' => "$ros16", 'callback_data' => "text"], ['text' => "$cros1616", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇵🇦 قبرس ", 'callback_data' => "text"], ['text' => "$ros23", 'callback_data' => "text"], ['text' => "$cros2323", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇪🇬 مصر ", 'callback_data' => "text"], ['text' => "$ros43", 'callback_data' => "text"], ['text' => "$cros4343", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇮🇳 هند ", 'callback_data' => "text"], ['text' => "$ros49", 'callback_data' => "text"], ['text' => "$cros4949", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇮🇪 ایرلند ", 'callback_data' => "text"], ['text' => "$ros56", 'callback_data' => "text"], ['text' => "$cros5656", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇨🇮 ساحل عاج ", 'callback_data' => "text"], ['text' => "$ros3", 'callback_data' => "text"], ['text' => "$cros33", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇷🇸 صربستان ", 'callback_data' => "text"], ['text' => "$ros4", 'callback_data' => "text"], ['text' => "$cros44", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇱🇦 لائوس ", 'callback_data' => "text"], ['text' => "$ros6", 'callback_data' => "text"], ['text' => "$cros66", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇲🇦 مراکش ", 'callback_data' => "text"], ['text' => "$ros7", 'callback_data' => "text"], ['text' => "$cros77", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇾🇪 یمن ", 'callback_data' => "text"], ['text' => "$ros13", 'callback_data' => "text"], ['text' => "$cros1313", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇬🇭 غنا ", 'callback_data' => "text"], ['text' => "$ros22", 'callback_data' => "text"], ['text' => "$cros2222", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇨🇦 کانادا ", 'callback_data' => "text"], ['text' => "$ros35", 'callback_data' => "text"], ['text' => "$cros3535", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇦🇷 آرژانتین ", 'callback_data' => "text"], ['text' => "$ros47", 'callback_data' => "text"], ['text' => "$cros4747", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇮🇶 عراق ", 'callback_data' => "text"], ['text' => "$ros52", 'callback_data' => "text"], ['text' => "$cros5252", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇩🇪 آلمان ", 'callback_data' => "text"], ['text' => "$ros53", 'callback_data' => "text"], ['text' => "$cros5353", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇨🇲 کامرون ", 'callback_data' => "text"], ['text' => "$ros55", 'callback_data' => "text"], ['text' => "$cros5555", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇹🇷 ترکیه ", 'callback_data' => "text"], ['text' => "$ros57", 'callback_data' => "text"], ['text' => "$cros5757", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇳🇿 نیوزیلند ", 'callback_data' => "text"], ['text' => "$ros66", 'callback_data' => "text"], ['text' => "$cros6666", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇦🇹 اتریش ", 'callback_data' => "text"], ['text' => "$ros67", 'callback_data' => "text"], ['text' => "$cros6767", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇨🇴 کلمبیا ", 'callback_data' => "text"], ['text' => "$ros21", 'callback_data' => "text"], ['text' => "$cros2121", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇻🇪 ونزوئلا ", 'callback_data' => "text"], ['text' => "$ros27", 'callback_data' => "text"], ['text' => "$cros2727", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇭🇹 هائیتی ", 'callback_data' => "text"], ['text' => "$ros30", 'callback_data' => "text"], ['text' => "$cros3030", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇺🇸 پاپوا ", 'callback_data' => "text"], ['text' => "$ros37", 'callback_data' => "text"], ['text' => "$cros3737", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇲🇩 مولداوی ", 'callback_data' => "text"], ['text' => "$ros58", 'callback_data' => "text"], ['text' => "$cros5858", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇲🇿 موزامبیک ", 'callback_data' => "text"], ['text' => "$ros12", 'callback_data' => "text"], ['text' => "$cros1212", 'callback_data' => "text"]
                    ],
                                        [
                       
                    ],
                                          [
                        ['text' => "صفحه 1", 'callback_data' => "pag1"], ['text' => "صفحه 3", 'callback_data' => "pag3"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"]
                    ],

                ],
            
        ])
        
    ]);   

}
elseif ($data == "pag3") {
     
   
     jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
درحال استعلام...
        ",         ]);
       $str = $jusert["service"];
    $str2 = str_replace(["tg", "ig", "wa", "go", "vi", "wb", "fb" , "tw" , "mb", "im", "tn", "me", "vk", "mm", "am" , "ot" ], ["💎 تلگرام", "📸 اینستاگرام", "📞 واتساپ", "🔍 گوگل", "💡 وایبر", "💬 ویچت", "📪 فیسبوک", "🐦 توییتر", "📨 یاهو","💭 ایمو", "♨️ لینک دین", "📬 ویکی", "📗 لاین", "💻 ماکروسافت", "🛒 آمازون", "🌐 دیگر سرویس ها"], $str);
    $userservicp = $jusert["panel"];
    $str5 = $jusert["service"];
    $countryss = array("81","82","83","84","51","52","53","54","55","56","57","58","59","60","61","62","63","64","65","66","67","68","69","70","71","72","73","74");
     $jjseting = json_decode(file_get_contents("../../data/seting.json"),true);
  $ttt = $jjseting["set"]["up"]["time"];
  $ddd = $jjseting["set"]["up"]["data"];
   $zarib = $jjseting["set"]["robelpric"];
 $jsetting1 = json_decode(file_get_contents("../../data/prics/28.json"),true);
$jsetting2 = json_decode(file_get_contents("../../data/prics/74.json"),true);
$jsetting3 = json_decode(file_get_contents("../../data/prics/75.json"),true);
$jsetting78 = json_decode(file_get_contents("../../data/prics/81.json"),true);
$jsetting4 = json_decode(file_get_contents("../../data/prics/53.json"),true);
$jsetting5 = json_decode(file_get_contents("../../data/prics/54.json"),true);
$jsetting6 = json_decode(file_get_contents("../../data/prics/56.json"),true);
$jsetting7 = json_decode(file_get_contents("../../data/prics/58.json"),true);
$jsetting8 = json_decode(file_get_contents("../../data/prics/59.json"),true);
$jsetting9 = json_decode(file_get_contents("../../data/prics/45.json"),true);
$jsetting10 = json_decode(file_get_contents("../../data/prics/51.json"),true);
$jsetting11 = json_decode(file_get_contents("../../data/prics/82.json"),true);
$jsetting12 = json_decode(file_get_contents("../../data/prics/46.json"),true);
$jsetting13 = json_decode(file_get_contents("../../data/prics/83.json"),true);
$jsetting14 = json_decode(file_get_contents("../../data/prics/71.json"),true);
$jsetting15 = json_decode(file_get_contents("../../data/prics/84.json"),true);
$jsetting16 = json_decode(file_get_contents("../../data/prics/66.json"),true);
$jsetting18 = json_decode(file_get_contents("../../data/prics/52.json"),true);
$jsetting19 = json_decode(file_get_contents("../../data/prics/55.json"),true);
$jsetting20 = json_decode(file_get_contents("../../data/prics/65.json"),true);
$jsetting21 = json_decode(file_get_contents("../../data/prics/89.json"),true);
$jsetting22 = json_decode(file_get_contents("../../data/prics/42.json"),true);
$jsetting23 = json_decode(file_get_contents("../../data/prics/69.json"),true);
$jsetting24 = json_decode(file_get_contents("../../data/prics/60.json"),true);
$jsetting25 = json_decode(file_get_contents("../../data/prics/68.json"),true);
$jsetting26 = json_decode(file_get_contents("../../data/prics/64.json"),true);
$jsetting27 = json_decode(file_get_contents("../../data/prics/40.json"),true);
$jsetting28 = json_decode(file_get_contents("../../data/prics/61.json"),true);

    
$ros0 = $jsetting1["$str"]["amount"] * $zarib;
$cros00 = $jsetting1["$str"]["count"];


$ros1 = $jsetting2["$str"]["amount"] * $zarib;
$cros11 =$jsetting2["$str"]["count"];


$ros15 = $jsetting3["$str"]["amount"] * $zarib;
$cros1515 = $jsetting3["$str"]["count"];


$ros16 = $jsetting78["$str"]["amount"] * $zarib;
$cros1616 = $jsetting78["$str"]["count"];


$ros23 = $jsetting4["$str"]["amount"] * $zarib;
$cros2323 = $jsetting4["$str"]["count"];


$ros43 = $jsetting5["$str"]["amount"] * $zarib;
$cros4343 = $jsetting5["$str"]["count"];


$ros49 = $jsetting6["$str"]["amount"] * $zarib;
$cros4949 = $jsetting6["$str"]["count"];


$ros56 = $jsetting7["$str"]["amount"] * $zarib;
$cros5656 = $jsetting7["$str"]["count"];

$ros3 = $jsetting8["$str"]["amount"] * $zarib;
$cros33 = $jsetting8["$str"]["count"];


$ros4 = $jsetting9["$str"]["amount"] * $zarib;
$cros44 = $jsetting9["$str"]["count"];


$ros6 = $jsetting10["$str"]["amount"] * $zarib;
$cros66 = $jsetting10["$str"]["count"];


$ros7 = $jsetting11["$str"]["amount"] * $zarib;
$cros77 = $jsetting11["$str"]["count"];


$ros13 = $jsetting12["$str"]["amount"] * $zarib;
$cros1313 = $jsetting12["$str"]["count"];


$ros22 = $jsetting13["$str"]["amount"] * $zarib;
$cros2222 = $jsetting13["$str"]["count"];


$ros35 = $jsetting14["$str"]["amount"] * $zarib;
$cros3535 = $jsetting14["$str"]["count"];


$ros47 = $jsetting15["$str"]["amount"] * $zarib;
$cros4747 = $jsetting15["$str"]["count"];


$ros52 = $jsetting16["$str"]["amount"] * $zarib;
$cros5252 = $jsetting16["$str"]["count"];


$ros53 = $jsetting18["$str"]["amount"] * $zarib;
$cros5353 = $jsetting18["$str"]["count"];

$ros55 = $jsetting19["$str"]["amount"] * $zarib;
$cros5555 = $jsetting19["$str"]["count"];


$ros57 = $jsetting20["$str"]["amount"] * $zarib;
$cros5757 = $jsetting20["$str"]["count"];


$ros66 = $jsetting21["$str"]["amount"] * $zarib;
$cros6666 = $jsetting21["$str"]["count"];


$ros67 = $jsetting22["$str"]["amount"] * $zarib;
$cros6767 = $jsetting22["$str"]["count"];


$ros21 = $jsetting23["$str"]["amount"] * $zarib;
$cros2121 = $jsetting23["$str"]["count"];


$ros27 = $jsetting24["$str"]["amount"] * $zarib;
$cros2727 = $jsetting24["$str"]["count"];


$ros30 = $jsetting25["$str"]["amount"] * $zarib;
$cros3030 = $jsetting25["$str"]["count"];


$ros37 = $jsetting26["$str"]["amount"] * $zarib;
$cros3737 = $jsetting26["$str"]["count"];


$ros58 = $jsetting27["$str"]["amount"] * $zarib;
$cros5858 = $jsetting27["$str"]["count"];


$ros12 = $jsetting28["$str"]["amount"] * $zarib;
$cros1212 = $jsetting28["$str"]["count"];

     jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "

☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 15 دقيقه يک بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .

🌟 = شماره هایی که کنار آنها ستاره وجود دارد ریپورت نیستند.

 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇬🇲 گامبیا ", 'callback_data' => "text"], ['text' => "$ros0", 'callback_data' => "text"], ['text' => "$cros00", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇦🇫 اففانستان ", 'callback_data' => "text"], ['text' => "$ros1", 'callback_data' => "text"], ['text' => "$cros11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇺🇬 اوگاندا ", 'callback_data' => "text"], ['text' => "$ros15", 'callback_data' => "text"], ['text' => "$cros1515", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇦🇺 نپال ", 'callback_data' => "text"], ['text' => "$ros16", 'callback_data' => "text"], ['text' => "$cros1616", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇸🇦 عربستان ", 'callback_data' => "text"], ['text' => "$ros23", 'callback_data' => "text"], ['text' => "$cros2323", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇲🇽 مکزیک ", 'callback_data' => "text"], ['text' => "$ros43", 'callback_data' => "text"], ['text' => "$cros4343", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇪🇸 اسپانیا ", 'callback_data' => "text"], ['text' => "$ros49", 'callback_data' => "text"], ['text' => "$cros4949", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇩🇿 الجزائر ", 'callback_data' => "text"], ['text' => "$ros56", 'callback_data' => "text"], ['text' => "$cros5656", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇸🇮 اسلوونی ", 'callback_data' => "text"], ['text' => "$ros3", 'callback_data' => "text"], ['text' => "$cros33", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇭🇷 کرواسی ", 'callback_data' => "text"], ['text' => "$ros4", 'callback_data' => "text"], ['text' => "$cros44", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇧🇾 بلاروس ", 'callback_data' => "text"], ['text' => "$ros6", 'callback_data' => "text"], ['text' => "$cros66", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇫🇮 بلژیک ", 'callback_data' => "text"], ['text' => "$ros7", 'callback_data' => "text"], ['text' => "$cros77", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇸🇪 سوئد ", 'callback_data' => "text"], ['text' => "$ros13", 'callback_data' => "text"], ['text' => "$cros1313", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇬🇪 بلغارستان ", 'callback_data' => "text"], ['text' => "$ros22", 'callback_data' => "text"], ['text' => "$cros2222", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇪🇹 اتیوپی ", 'callback_data' => "text"], ['text' => "$ros35", 'callback_data' => "text"], ['text' => "$cros3535", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇿🇲 مجارستان ", 'callback_data' => "text"], ['text' => "$ros47", 'callback_data' => "text"], ['text' => "$cros4747", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇵🇰 پاکستان ", 'callback_data' => "text"], ['text' => "$ros52", 'callback_data' => "text"], ['text' => "$cros5252", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇹🇭 تایلند ", 'callback_data' => "text"], ['text' => "$ros53", 'callback_data' => "text"], ['text' => "$cros5353", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇹🇼 تایوان ", 'callback_data' => "text"], ['text' => "$ros55", 'callback_data' => "text"], ['text' => "$cros5555", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇵🇪 پرو ", 'callback_data' => "text"], ['text' => "$ros57", 'callback_data' => "text"], ['text' => "$cros5757", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "🇵🇬 تونس ", 'callback_data' => "text"], ['text' => "$ros66", 'callback_data' => "text"], ['text' => "$cros6666", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇹🇩 چاد ", 'callback_data' => "text"], ['text' => "$ros67", 'callback_data' => "text"], ['text' => "$cros6767", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇲🇱 مالی ", 'callback_data' => "text"], ['text' => "$ros21", 'callback_data' => "text"], ['text' => "$cros2121", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇧🇩 بنگلادش ", 'callback_data' => "text"], ['text' => "$ros27", 'callback_data' => "text"], ['text' => "$cros2727", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇬🇳 گینه ", 'callback_data' => "text"], ['text' => "$ros30", 'callback_data' => "text"], ['text' => "$cros3030", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇱🇰 سری‌لانکا ", 'callback_data' => "text"], ['text' => "$ros37", 'callback_data' => "text"], ['text' => "$cros3737", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇺🇿 ازبکستان ", 'callback_data' => "text"], ['text' => "$ros58", 'callback_data' => "text"], ['text' => "$cros5858", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "🇸🇳 سنگال ", 'callback_data' => "text"], ['text' => "$ros12", 'callback_data' => "text"], ['text' => "$cros1212", 'callback_data' => "text"]
                    ],
                                        [
                       
                    ],
                                          [
                        ['text' => "صفحه 1", 'callback_data' => "pag1"], ['text' => "صفحه 2", 'callback_data' => "pag2"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"]
                    ],

                ],
            
        ])
        
    ]);   

}

?>