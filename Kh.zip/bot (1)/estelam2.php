<?php

$juseryy = json_decode(file_get_contents("data/setbotten.json"),true);
$sw13 = $juseryy["sw13"];
if($sw13==""){$sw13="💳 استعلام | قیمت ها";}



if (($textmassage == "💳 استعلام | قیمت ها" or ( $textmassage == "$sw13" and $update->message->text ))) {
 
          
          jijibot('sendmessage', [
         'chat_id'=>$chat_id,
     
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💠 اینستاگرام", 'callback_data' => "instagram"], ['text' => "💠 تلگرام", 'callback_data' => "telegram"], ['text' => "💠 واتساپ", 'callback_data' => "whatsapp"]
                    ],
                       [
                        ['text' => "💠 وی چت", 'callback_data' => "wechat"], ['text' => "💠 وایبر", 'callback_data' => "viber"], ['text' => "💠 توییتر", 'callback_data' => "twitter"]
                    ],
                      [
                        ['text' => "💠 لاین", 'callback_data' => "line"], ['text' => "💠 ایمو", 'callback_data' => "imo"], ['text' => "💠 فیسبوک", 'callback_data' => "facebook"]
                    ],
                      [
                        ['text' => "💠 گوگل", 'callback_data' => "google"], ['text' => "💠 یاهو", 'callback_data' => "yahoo"], ['text' => "💠 دیسکورد", 'callback_data' => "discord"]
                    ],
                      [
                        ['text' => "💠 آمازون", 'callback_data' => "amazon"], ['text' => "💠 علی بابا", 'callback_data' => "alibaba"], ['text' => "💠 علی پی", 'callback_data' => "alipay"]
                    ],
                      [
                        ['text' => "💠 بیگو لایو", 'callback_data' => "bigolive"], ['text' => "💠 لینکدین", 'callback_data' => "linkedin"], ['text' => "💠 ماکروسافت", 'callback_data' => "microsoft"]
                    ],
                      [
                        ['text' => "💠 پی پال", 'callback_data' => "paypal"], ['text' => "💠 اسنپ چت", 'callback_data' => "snapchat"], ['text' => "💠 تیک تاک", 'callback_data' => "tiktok"]
                    ],
                      [
                        ['text' => "💠 دیجی کالا", 'callback_data' => "digikala"], ['text' => "💠 دیوار", 'callback_data' => "divar"], ['text' => "💠 همراه اول", 'callback_data' => "hamrahaval"]
                    ],
                      [
                        ['text' => "💠 ایرانسل", 'callback_data' => "irancell"], ['text' => "💠  پابجی", 'callback_data' => "pubg"], ['text' => "💠  بلاکچین", 'callback_data' => "blockchain"]
                    ],
                      [
                        ['text' => "💠  تانگو", 'callback_data' => "tango"], ['text' => "💠 1688", 'callback_data' => "1688"], ['text' => "💠 1xbet", 'callback_data' => "1xbet"]
                    ],
                      
                    [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 2", 'callback_data' => "paper2"],
                    ]
                ]
            ])
        ]);
         $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["service"]="";

$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }
    elseif ($data == "paper1") {
    
      jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💠 اینستاگرام", 'callback_data' => "instagram"], ['text' => "💠 تلگرام", 'callback_data' => "telegram"], ['text' => "💠 واتساپ", 'callback_data' => "whatsapp"]
                    ],
                       [
                        ['text' => "💠 وی چت", 'callback_data' => "wechat"], ['text' => "💠 وایبر", 'callback_data' => "viber"], ['text' => "💠 توییتر", 'callback_data' => "twitter"]
                    ],
                      [
                        ['text' => "💠 لاین", 'callback_data' => "line"], ['text' => "💠 ایمو", 'callback_data' => "imo"], ['text' => "💠 فیسبوک", 'callback_data' => "facebook"]
                    ],
                      [
                        ['text' => "💠 گوگل", 'callback_data' => "google"], ['text' => "💠 یاهو", 'callback_data' => "yahoo"], ['text' => "💠 دیسکورد", 'callback_data' => "discord"]
                    ],
                      [
                        ['text' => "💠 آمازون", 'callback_data' => "amazon"], ['text' => "💠 علی بابا", 'callback_data' => "alibaba"], ['text' => "💠 علی پی", 'callback_data' => "alipay"]
                    ],
                      [
                        ['text' => "💠 بیگو لایو", 'callback_data' => "bigolive"], ['text' => "💠 لینکدین", 'callback_data' => "linkedin"], ['text' => "💠 ماکروسافت", 'callback_data' => "microsoft"]
                    ],
                      [
                        ['text' => "💠 پی پال", 'callback_data' => "paypal"], ['text' => "💠 اسنپ چت", 'callback_data' => "snapchat"], ['text' => "💠 تیک تاک", 'callback_data' => "tiktok"]
                    ],
                      [
                        ['text' => "💠 دیجی کالا", 'callback_data' => "digikala"], ['text' => "💠 دیوار", 'callback_data' => "divar"], ['text' => "💠 همراه اول", 'callback_data' => "hamrahaval"]
                    ],
                      [
                        ['text' => "💠 ایرانسل", 'callback_data' => "irancell"], ['text' => "💠  پابجی", 'callback_data' => "pubg"], ['text' => "💠  بلاکچین", 'callback_data' => "blockchain"]
                    ],
                      [
                        ['text' => "💠  تانگو", 'callback_data' => "tango"], ['text' => "💠 1688", 'callback_data' => "1688"], ['text' => "💠 1xbet", 'callback_data' => "1xbet"]
                    ],
                      
                    [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 2", 'callback_data' => "paper2"],
                    ]
                ]
            ])
        ]);
    
}
elseif ($data == "paper2") {
    
      jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                   
                      [
                        ['text' => "💠 23red", 'callback_data' => "23red"], ['text' => "💠 ace2three", 'callback_data' => "ace2three"], ['text' => "💠 adidas", 'callback_data' => "adidas"]
                    ],
                      [
                        ['text' => "💠 airbnb", 'callback_data' => "airbnb"], ['text' => "💠 airtel", 'callback_data' => "airtel"], ['text' => "💠 akelni", 'callback_data' => "akelni"]
                    ],
                      [
                        ['text' => "💠 aliexpress", 'callback_data' => "aliexpress"], ['text' => "💠 amasia", 'callback_data' => "amasia"], ['text' => "💠 aol", 'callback_data' => "aol"]
                    ],
                      [
                        ['text' => "💠 avito", 'callback_data' => "avito"], ['text' => "💠 azino", 'callback_data' => "azino"], ['text' => "💠 b4ucabs", 'callback_data' => "b4ucabs"]
                    ],
                      [
                        ['text' => "💠 bigcash", 'callback_data' => "bigcash"], ['text' => "💠 bitclout", 'callback_data' => "bitclout"], ['text' => "💠 bittube", 'callback_data' => "bittube"]
                    ],
                      [
                        ['text' => "💠 blablacar", 'callback_data' => "blablacar"], ['text' => "💠 blizzard", 'callback_data' => "blizzard"], ['text' => "💠 burgerking", 'callback_data' => "burgerking"]
                    ],
                      [
                        ['text' => "💠 careem", 'callback_data' => "careem"], ['text' => "💠 cdkeys", 'callback_data' => "cdkeys"], ['text' => "💠 cekkazan", 'callback_data' => "cekkazan"]
                    ],
                      [
                        ['text' => "💠 citymobil", 'callback_data' => "citymobil"], ['text' => "💠 clickentregas", 'callback_data' => "clickentregas"], ['text' => "💠 coinbase", 'callback_data' => "coinbase"]
                    ],
                      [
                        ['text' => "💠 craigslist", 'callback_data' => "craigslist"], ['text' => "💠 deliveroo", 'callback_data' => "deliveroo"], ['text' => "💠 delivery", 'callback_data' => "delivery"]
                    ], 
                    [
                        ['text' => "💠 dent", 'callback_data' => "dent"], ['text' => "💠 didi", 'callback_data' => "didi"], ['text' => "💠 dixy", 'callback_data' => "dixy"]
                    ],
                     
                    [
                        ['text' => "◀️ صفحه 1 ", 'callback_data' => "paper1"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 3", 'callback_data' => "paper3"],
                    ],
                     [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                         
                    ]
                ]
            ])
        ]);
    
}
elseif ($data == "paper3") {
   
   
          jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💠 dodopizza", 'callback_data' => "dodopizza"], ['text' => "💠 domdara", 'callback_data' => "domdara"], ['text' => "💠 dostavista", 'callback_data' => "dostavista"]
                    ],
                        [
                        ['text' => "💠 douyu", 'callback_data' => "douyu"], ['text' => "💠 drom", 'callback_data' => "drom"], ['text' => "💠 drugvokrug", 'callback_data' => "drugvokrug"]
                    ],
                        [
                        ['text' => "💠 dukascopy", 'callback_data' => "dukascopy"], ['text' => "💠 ebay", 'callback_data' => "ebay"], ['text' => "💠 edgeless", 'callback_data' => "edgeless"]
                    ],
                       [
                        ['text' => "💠 electroneum", 'callback_data' => "electroneum"], ['text' => "💠 ezway", 'callback_data' => "ezway"], ['text' => "💠 fiverr", 'callback_data' => "fiverr"]
                    ],
                        [
                        ['text' => "💠 flipkart", 'callback_data' => "flipkart"], ['text' => "💠 foodpanda", 'callback_data' => "foodpanda"], ['text' => "💠 foody", 'callback_data' => "foody"]
                    ],
                       [
                        ['text' => "💠 forwarding", 'callback_data' => "forwarding"], ['text' => "💠 galaxy", 'callback_data' => "galaxy"], ['text' => "💠 gameflip", 'callback_data' => "gameflip"]
                    ],
                       [
                        ['text' => "💠 gcash", 'callback_data' => "gcash"], ['text' => "💠 get", 'callback_data' => "get"], ['text' => "💠 getir", 'callback_data' => "getir"]
                    ],
                       [
                        ['text' => "💠 gett", 'callback_data' => "gett"], ['text' => "💠 globus", 'callback_data' => "globus"], ['text' => "💠 glovo", 'callback_data' => "glovo"]
                    ],
                        [
                        ['text' => "💠 grabtaxi", 'callback_data' => "grabtaxi"], ['text' => "💠 green", 'callback_data' => "green"], ['text' => "💠 grindr", 'callback_data' => "grindr"]
                    ],
                       [
                        ['text' => "💠 haraj", 'callback_data' => "haraj"], ['text' => "💠 hezzl", 'callback_data' => "hezzl"], ['text' => "💠 hopi", 'callback_data' => "hopi"]
                    ],
                       
                     
                   [
                        ['text' => "◀️ صفحه 2 ", 'callback_data' => "paper2"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 4", 'callback_data' => "paper4"],
                    ],
                     [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                         
                    ]
                ]
            ])
        ]);
       
    }
    elseif ($data == "paper4") {
   
   
          jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    
                       [
                        ['text' => "💠 hqtrivia", 'callback_data' => "hqtrivia"], ['text' => "💠 icard", 'callback_data' => "icard"], ['text' => "💠 icq", 'callback_data' => "icq"]
                    ],
                       [
                        ['text' => "💠 ininal", 'callback_data' => "ininal"], ['text' => "💠 iost", 'callback_data' => "iost"], ['text' => "💠 jd", 'callback_data' => "jd"]
                    ],
                       [
                        ['text' => "💠 justdating", 'callback_data' => "justdating"], ['text' => "💠 kakaotalk", 'callback_data' => "kakaotalk"], ['text' => "💠 keybase", 'callback_data' => "keybase"]
                    ],
                        [
                        ['text' => "💠 komandacard", 'callback_data' => "komandacard"], ['text' => "💠 kotak811", 'callback_data' => "kotak811"], ['text' => "💠 kufarby", 'callback_data' => "kufarby"]
                    ],
                       [
                        ['text' => "💠 kwai", 'callback_data' => "kwai"], ['text' => "💠 lazada", 'callback_data' => "lazada"], ['text' => "💠 lbry", 'callback_data' => "lbry"]
                    ],
                       [
                        ['text' => "💠 lenta", 'callback_data' => "lenta"], ['text' => "💠 lianxin", 'callback_data' => "lianxin"], ['text' => "💠 livescore", 'callback_data' => "livescore"]
                    ],
                       [
                        ['text' => "💠 magnit", 'callback_data' => "magnit"], ['text' => "💠 magnolia", 'callback_data' => "magnolia"], ['text' => "💠 mailru", 'callback_data' => "mailru"]
                    ],
                        [
                        ['text' => "💠 mamba", 'callback_data' => "mamba"], ['text' => "💠 mcdonalds", 'callback_data' => "mcdonalds"], ['text' => "💠 meetme", 'callback_data' => "meetme"]
                    ],
                       [
                        ['text' => "💠 mega", 'callback_data' => "mega"], ['text' => "💠 mercado", 'callback_data' => "mercado"], ['text' => "💠 miratorg", 'callback_data' => "miratorg"]
                    ],
                     [
                        ['text' => "💠 mtscashback", 'callback_data' => "mtscashback"], ['text' => "💠 nana", 'callback_data' => "nana"], ['text' => "💠 naver", 'callback_data' => "naver"]
                    ],
                     [
                        ['text' => "💠 netflix", 'callback_data' => "netflix"], ['text' => "💠 nhseven", 'callback_data' => "nhseven"], ['text' => "💠 nifty", 'callback_data' => "nifty"]
                    ],
                     
                    [
                        ['text' => "◀️ صفحه 3 ", 'callback_data' => "paper3"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 5", 'callback_data' => "paper5"],
                    ],
                     [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                         
                    ]
                ]
            ])
        ]);
       
    }
    elseif ($data == "paper5") {
   
   
          jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💠 nike", 'callback_data' => "nike"], ['text' => "💠 nimses", 'callback_data' => "nimses"], ['text' => "💠 nttgame", 'callback_data' => "nttgame"]
                    ],
                        [
                        ['text' => "💠 odnoklassniki", 'callback_data' => "odnoklassniki"], ['text' => "💠 offerup", 'callback_data' => "offerup"], ['text' => "💠 okcupid", 'callback_data' => "okcupid"]
                    ],
                        [
                        ['text' => "💠 okey", 'callback_data' => "okey"], ['text' => "💠 olx", 'callback_data' => "olx"], ['text' => "💠 openpoint", 'callback_data' => "openpoint"]
                    ],
                       [
                        ['text' => "💠 oraclecloud", 'callback_data' => "oraclecloud"], ['text' => "💠 ozon", 'callback_data' => "ozon"], ['text' => "💠 pairs", 'callback_data' => "pairs"]
                    ],
                        [
                        ['text' => "💠 papara", 'callback_data' => "papara"], ['text' => "💠 paycell", 'callback_data' => "paycell"], ['text' => "💠 paymaya", 'callback_data' => "paymaya"]
                    ],
                       [
                        ['text' => "💠 paysend", 'callback_data' => "paysend"], ['text' => "💠 peoplecom", 'callback_data' => "peoplecom"], ['text' => "💠 perekrestok", 'callback_data' => "perekrestok"]
                    ],
                       [
                        ['text' => "💠 pof", 'callback_data' => "pof"], ['text' => "💠 pokec", 'callback_data' => "pokec"], ['text' => "💠 pokermaster", 'callback_data' => "pokermaster"]
                    ],
                       [
                        ['text' => "💠 qiwiwallet", 'callback_data' => "qiwiwallet"], ['text' => "💠 quioo", 'callback_data' => "quioo"], ['text' => "💠 quipp", 'callback_data' => "quipp"]
                    ],
                        [
                        ['text' => "💠 reuse", 'callback_data' => "reuse"], ['text' => "💠 ripkord", 'callback_data' => "ripkord"], ['text' => "💠 samokat", 'callback_data' => "samokat"]
                    ],
                       [
                        ['text' => "💠 seosprint", 'callback_data' => "seosprint"], ['text' => "💠 sheerid", 'callback_data' => "sheerid"], ['text' => "💠 shopee", 'callback_data' => "shopee"]
                    ],
                       
                    [
                        ['text' => "◀️ صفحه 4 ", 'callback_data' => "paper4"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 6", 'callback_data' => "paper6"],
                    ],
                     [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                         
                    ]
                ]
            ])
        ]);
       
    }
    elseif ($data == "paper6") {
   
   
          jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    
                       [
                        ['text' => "💠 signal", 'callback_data' => "signal"], ['text' => "💠 sikayetvar", 'callback_data' => "sikayetvar"], ['text' => "💠 skout", 'callback_data' => "skout"]
                    ],
                       [
                        ['text' => "💠 steam", 'callback_data' => "steam"], ['text' => "💠 swvl", 'callback_data' => "swvl"], ['text' => "💠 taksheel", 'callback_data' => "taksheel"]
                    ],
                       [
                        ['text' => "💠 tantan", 'callback_data' => "tantan"], ['text' => "💠 taobao", 'callback_data' => "taobao"], ['text' => "💠 tencentqq", 'callback_data' => "tencentqq"]
                    ],
                        [
                        ['text' => "💠 tinder", 'callback_data' => "tinder"], ['text' => "💠 tosla", 'callback_data' => "tosla"], ['text' => "💠 totalcoin", 'callback_data' => "totalcoin"]
                    ],
                       [
                        ['text' => "💠 touchance", 'callback_data' => "touchance"], ['text' => "💠 trendyol", 'callback_data' => "trendyol"], ['text' => "💠 truecaller", 'callback_data' => "truecaller"]
                    ],
                       [
                        ['text' => "💠 uber", 'callback_data' => "uber"], ['text' => "💠 uploaded", 'callback_data' => "uploaded"], ['text' => "💠 vernyi", 'callback_data' => "vernyi"]
                    ],
                       [
                        ['text' => "💠 vkontakte", 'callback_data' => "vkontakte"], ['text' => "💠 voopee", 'callback_data' => "voopee"], ['text' => "💠 weibo", 'callback_data' => "weibo"]
                    ],
                        [
                        ['text' => "💠 weku", 'callback_data' => "weku"], ['text' => "💠 winston", 'callback_data' => "winston"], ['text' => "💠 wish", 'callback_data' => "wish"]
                    ],
                       [
                        ['text' => "💠 yalla", 'callback_data' => "yalla"], ['text' => "💠 yandex", 'callback_data' => "yandex"], ['text' => "💠 yemeksepeti", 'callback_data' => "yemeksepeti"]
                    ],
                     [
                        ['text' => "💠 youdo", 'callback_data' => "youdo"], ['text' => "💠 youla", 'callback_data' => "youla"], ['text' => "💠 zalo", 'callback_data' => "zalo"]
                    ],
                     [
                        ['text' => "💠 zoho", 'callback_data' => "zoho"], ['text' => "💠 zomato", 'callback_data' => "zomato"]
                        , ['text' => "💠 michat", 'callback_data' => "michat"]
                    ],
                     
                     [
                        ['text' => "🌐 دیگر سرویس ها", 'callback_data' => "other"]
                    ],
                    [
                        ['text' => "◀️ صفحه 5 ", 'callback_data' => "paper5"],
                        ['text' => "⏭ صفحه  نخست ", 'callback_data' => "paper1"],
                         ['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ]
                ]
            ])
        ]);
       
    }
elseif ($data == "backpricservis") {
   
   
         jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "💢 لطفا سرویس مورد نظر رو انتخاب کنید.",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💠 اینستاگرام", 'callback_data' => "instagram"], ['text' => "💠 تلگرام", 'callback_data' => "telegram"], ['text' => "💠 واتساپ", 'callback_data' => "whatsapp"]
                    ],
                       [
                        ['text' => "💠 وی چت", 'callback_data' => "wechat"], ['text' => "💠 وایبر", 'callback_data' => "viber"], ['text' => "💠 توییتر", 'callback_data' => "twitter"]
                    ],
                      [
                        ['text' => "💠 لاین", 'callback_data' => "line"], ['text' => "💠 ایمو", 'callback_data' => "imo"], ['text' => "💠 فیسبوک", 'callback_data' => "facebook"]
                    ],
                      [
                        ['text' => "💠 گوگل", 'callback_data' => "google"], ['text' => "💠 یاهو", 'callback_data' => "yahoo"], ['text' => "💠 دیسکورد", 'callback_data' => "discord"]
                    ],
                      [
                        ['text' => "💠 آمازون", 'callback_data' => "amazon"], ['text' => "💠 علی بابا", 'callback_data' => "alibaba"], ['text' => "💠 علی پی", 'callback_data' => "alipay"]
                    ],
                      [
                        ['text' => "💠 بیگو لایو", 'callback_data' => "bigolive"], ['text' => "💠 لینکدین", 'callback_data' => "linkedin"], ['text' => "💠 ماکروسافت", 'callback_data' => "microsoft"]
                    ],
                      [
                        ['text' => "💠 پی پال", 'callback_data' => "paypal"], ['text' => "💠 اسنپ چت", 'callback_data' => "snapchat"], ['text' => "💠 تیک تاک", 'callback_data' => "tiktok"]
                    ],
                      [
                        ['text' => "💠 دیجی کالا", 'callback_data' => "digikala"], ['text' => "💠 دیوار", 'callback_data' => "divar"], ['text' => "💠 همراه اول", 'callback_data' => "hamrahaval"]
                    ],
                      [
                        ['text' => "💠 ایرانسل", 'callback_data' => "irancell"], ['text' => "💠  پابجی", 'callback_data' => "pubg"], ['text' => "💠  بلاکچین", 'callback_data' => "blockchain"]
                    ],
                      [
                        ['text' => "💠  تانگو", 'callback_data' => "tango"], ['text' => "💠 1688", 'callback_data' => "1688"], ['text' => "💠 1xbet", 'callback_data' => "1xbet"]
                    ],
                      
                    [
                        
                        ['text' => "✖️ خروج", 'callback_data' => "ex"],
                        ['text' => "⏭ صفحه آخر ", 'callback_data' => "paper6"],
                         ['text' => "▶️ صفحه 2", 'callback_data' => "paper2"],
                    ]
                ]
            ])
        ]);
        $juser = json_decode(file_get_contents("data/$fromid.json"),true);  
$juser["service"]="";
$juser = json_encode($juser,true);
file_put_contents("data/$fromid.json",$juser);
    }
    
elseif (in_array($data, array("instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"))) {
     
   $str = $data;
    
    $juser = json_decode(file_get_contents("data/$fromid.json"),true);  
$juser["service"]="$data";
$juser = json_encode($juser,true);
file_put_contents("data/$fromid.json",$juser);

     jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
درحال استعلام...
        ",         ]);
        
    $str2 = $str;
    
   
 //=============================================================
 
 
   $zaribbb = $jseting["set"]["robelpric"];
 $ttt = $jsetingo["set"]["up"]["time"];
  $ddd = $jsetingo["set"]["up"]["data"];
$zarib = $jsetingo["set"]["robelpric"];
$servisss = $str ;
 $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("../../data/prics2/$vvv.json"),true);
        $sssw = (ceil($jsettting["$data"]["amount"]) * $zarib)+$zaribbb;
         $ssswm = $jsettting["$data"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 0;$z <= 28;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11 = $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15 = $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24 = $nname[23];
  $stat25 = $nname[24];
  $stat26 = $nname[25];
  $stat27 = $nname[26];
  $stat28 = $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
    $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================


     jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat27 ", 'callback_data' => "text"], ['text' => "$cost27", 'callback_data' => "text"], ['text' => "$statt27", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat28 ", 'callback_data' => "text"], ['text' => "$cost28", 'callback_data' => "text"], ['text' => "$statt28", 'callback_data' => "text"]
                    ],
                                        [
                       
                    ],
                                          [
                        ['text' => "⤴️ صفحه آخر", 'callback_data' => "pag7"], ['text' => "▶️ صفحه 2", 'callback_data' => "pag2"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]);     

}
elseif ($data == "pag1") {
     
  $str = $jusert["service"];
        
         $str55 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $str);
  
     
    $userservicp = $jusert["panel"];
    
    
   
   
  //=============================================================
 
 
   $zaribbb = $jseting["set"]["robelpric"];
 $ttt = $jsetingo["set"]["up"]["time"];
  $ddd = $jsetingo["set"]["up"]["data"];
$zarib = $jsetingo["set"]["robelpric"];
$servisss = $str ;
   $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("../../data/prics2/$vvv.json"),true);
        $sssw = (ceil($jsettting["$servisss"]["amount"]) * $zarib)+$zaribbb;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 0;$z <= 28;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
   $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

     jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat27 ", 'callback_data' => "text"], ['text' => "$cost27", 'callback_data' => "text"], ['text' => "$statt27", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat28 ", 'callback_data' => "text"], ['text' => "$cost28", 'callback_data' => "text"], ['text' => "$statt28", 'callback_data' => "text"]
                    ],
                                        [
                       
                    ],
                                         [
                        ['text' => "⤴️ صفحه آخر", 'callback_data' => "pag7"], ['text' => "▶️ صفحه 2", 'callback_data' => "pag2"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]);   
}
elseif ($data == "pag2") {
     
   
    
         $str = $jusert["service"];
   $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $str);
     $userservicp = $jusert["panel"];
    $str5 = $jusert["service"];
    
    
   //=============================================================
 
 
   $zaribbb = $jseting["set"]["robelpric"];
 $ttt = $jsetingo["set"]["up"]["time"];
  $ddd = $jsetingo["set"]["up"]["data"];
$zarib = $jsetingo["set"]["robelpric"];
$servisss = $str ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("../../data/prics2/$vvv.json"),true);
       $sssw = (ceil($jsettting["$servisss"]["amount"]) * $zarib)+$zaribbb;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm ==""  or $sssw !="---" or $sssw !=""){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 29;$z <= 56;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
   $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

    jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat27 ", 'callback_data' => "text"], ['text' => "$cost27", 'callback_data' => "text"], ['text' => "$statt27", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat28 ", 'callback_data' => "text"], ['text' => "$cost28", 'callback_data' => "text"], ['text' => "$statt28", 'callback_data' => "text"]
                    ],
                                        [
                       
                    ],
                                        [
                        ['text' => "صفحه 1 ◀️", 'callback_data' => "pag1"], ['text' => "▶️ صفحه 3", 'callback_data' => "pag3"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]); 
}
elseif ($data == "pag3") {
     
   
    
      $str = $jusert["service"];
   
    
     $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $str);
    $userservicp = $jusert["panel"];
    $str5 = $jusert["service"];
    
  //=============================================================
 
 
   $zaribbb = $jseting["set"]["robelpric"];
 $ttt = $jsetingo["set"]["up"]["time"];
  $ddd = $jsetingo["set"]["up"]["data"];
$zarib = $jsetingo["set"]["robelpric"];
$servisss = $str ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("../../data/prics2/$vvv.json"),true);
        $sssw = (ceil($jsettting["$servisss"]["amount"]) * $zarib)+$zaribbb;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 57;$z <= 83;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
 $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

    jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                   
                                        [
                        ['text' => "صفحه 2 ◀️", 'callback_data' => "pag2"], ['text' => "▶️ صفحه 4", 'callback_data' => "pag4"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]);     

}
elseif ($data == "pag4") {
     
   
    
      $str = $jusert["service"];
   
    
     $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $str);
    $userservicp = $jusert["panel"];
    $str5 = $jusert["service"];
    
  //=============================================================
 
 
   $zaribbb = $jseting["set"]["robelpric"];
 $ttt = $jsetingo["set"]["up"]["time"];
  $ddd = $jsetingo["set"]["up"]["data"];
$zarib = $jsetingo["set"]["robelpric"];
$servisss = $str ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("../../data/prics2/$vvv.json"),true);
       $sssw = (ceil($jsettting["$servisss"]["amount"]) * $zarib)+$zaribbb;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 84;$z <= 110;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
 $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

    jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                   
                                        [
                        ['text' => "صفحه 3 ◀️", 'callback_data' => "pag3"], ['text' => "▶️ صفحه 5", 'callback_data' => "pag5"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],
                ],
            
        ])
        
    ]);        

}
elseif ($data == "pag5") {
     
   
    
      $str = $jusert["service"];
   
    
     $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $str);
    $userservicp = $jusert["panel"];
    $str5 = $jusert["service"];
    
  //=============================================================
 
 
   $zaribbb = $jseting["set"]["robelpric"];
 $ttt = $jsetingo["set"]["up"]["time"];
  $ddd = $jsetingo["set"]["up"]["data"];
$zarib = $jsetingo["set"]["robelpric"];
$servisss = $str ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("../../data/prics2/$vvv.json"),true);
       $sssw = (ceil($jsettting["$servisss"]["amount"]) * $zarib)+$zaribbb;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 111;$z <= 137;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
 $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

    jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                                      [
                        ['text' => "صفحه 4 ◀️", 'callback_data' => "pag4"], ['text' => "▶️ صفحه 6", 'callback_data' => "pag6"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]);   
   

}
elseif ($data == "pag6") {
     
   
    
      $str = $jusert["service"];
   
    
     $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $str);
    $userservicp = $jusert["panel"];
    $str5 = $jusert["service"];
    
  //=============================================================
 
 
   $zaribbb = $jseting["set"]["robelpric"];
 $ttt = $jsetingo["set"]["up"]["time"];
  $ddd = $jsetingo["set"]["up"]["data"];
$zarib = $jsetingo["set"]["robelpric"];
$servisss = $str ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("../../data/prics2/$vvv.json"),true);
       $sssw = (ceil($jsettting["$servisss"]["amount"]) * $zarib)+$zaribbb;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 138;$z <= 165;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
 $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

    jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat21 ", 'callback_data' => "text"], ['text' => "$cost21", 'callback_data' => "text"], ['text' => "$statt21", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat22 ", 'callback_data' => "text"], ['text' => "$cost22", 'callback_data' => "text"], ['text' => "$statt22", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat23 ", 'callback_data' => "text"], ['text' => "$cost23", 'callback_data' => "text"], ['text' => "$statt23", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat24 ", 'callback_data' => "text"], ['text' => "$cost24", 'callback_data' => "text"], ['text' => "$statt24", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat25 ", 'callback_data' => "text"], ['text' => "$cost25", 'callback_data' => "text"], ['text' => "$statt25", 'callback_data' => "text"]
                    ],
                                        [
                        ['text' => "$stat26 ", 'callback_data' => "text"], ['text' => "$cost26", 'callback_data' => "text"], ['text' => "$statt26", 'callback_data' => "text"]
                    ],
                   
                                        [
                        ['text' => "صفحه 5 ◀️", 'callback_data' => "pag5"], ['text' => "▶️ صفحه 7", 'callback_data' => "pag7"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]);     

}
elseif ($data == "pag7") {
     
   
    
      $str = $jusert["service"];
   
    
     $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $str);
    $userservicp = $jusert["panel"];
    $str5 = $jusert["service"];
    
  //=============================================================
 
 
   $zaribbb = $jseting["set"]["robelpric"];
 $ttt = $jsetingo["set"]["up"]["time"];
  $ddd = $jsetingo["set"]["up"]["data"];
$zarib = $jsetingo["set"]["robelpric"];
$servisss = $str ;
  $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
   $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
   
    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("../../data/prics2/$vvv.json"),true);
        $sssw = (ceil($jsettting["$servisss"]["amount"]) * $zarib)+$zaribbb;
         $ssswm = $jsettting["$servisss"]["count"];
         $zzzz = $countryss2[$key];
         if( $ssswm =="0" or $ssswm =="❌"  or $ssswm =="" ){ $fff = "1000000" ; $xxx = 500000;}
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌" ){ $fff =$sssw ; $xxx = $ssswm;}
        
       
$result[]=$vvv;
$result2[]=$fff;
$result3[]=$fff;
$result4[]=$xxx;
$result5[]=$zzzz;

        
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
 
 for($z = 166;$z <= 186;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];

$stat20 = $result4[$gets2];
$zplus = $z + 1 ;
if($result2[$z] == "1000000"){ $n1 = "❗";};
if($result2[$z] != "1000000"){ $n1 = $result2[$z];};

if($stat20 == "500000"){ $n2 = "❌";};
if($stat20 != "500000"){ $n2 = $stat20;};

$topname = $topname."$stat2"."\n";   
$topcust = $topcust."$n1"."\n"; 
$topmont = $topmont."$n2"."\n"; 
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);
 $ncust = explode("\n", $topcust);
 $nmont = explode("\n", $topmont);
 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
    
  //================= قیمت ها
  $cost1 = $ncust[0];
  $cost2 = $ncust[1];
  $cost3 = $ncust[2];
  $cost4 = $ncust[3];
  $cost5 = $ncust[4];
  $cost6 = $ncust[5];
  $cost7 = $ncust[6];
  $cost8 = $ncust[7];
  $cost9 = $ncust[8];
  $cost10 = $ncust[9];
  $cost11 = $ncust[10];
  $cost12 = $ncust[11];
  $cost13 = $ncust[12];
  $cost14 = $ncust[13];
  $cost15 = $ncust[14];
  $cost16 = $ncust[15];
  $cost17 = $ncust[16];
  $cost18 = $ncust[17];
  $cost19 = $ncust[18];
  $cost20 = $ncust[19];
  $cost21 = $ncust[20];
  $cost22 = $ncust[21];
  $cost23 = $ncust[22];
  $cost24 = $ncust[23];
  $cost25 = $ncust[24];
  $cost26 = $ncust[25];
  $cost27 = $ncust[26];
  $cost28 = $ncust[27];
 
  //================= تعداد
  
 $statt1 = $nmont[0];
   $statt2 = $nmont[1];
   $statt3 = $nmont[2];
   $statt4 = $nmont[3];
   $statt5 = $nmont[4];
   $statt6 = $nmont[5];
   $statt7 = $nmont[6];
   $statt8 = $nmont[7];
   $statt9 = $nmont[8];
   $statt10 = $nmont[9];
   $statt11 = $nmont[10];
   $statt12= $nmont[11];
   $statt13 = $nmont[12];
   $statt14 = $nmont[13];
   $statt15 = $nmont[14];
   $statt16 = $nmont[15];
   $statt17 = $nmont[16];
   $statt18 = $nmont[17];
   $statt19 = $nmont[18];
   $statt20 = $nmont[19];
   $statt21 = $nmont[20];
   $statt22 = $nmont[21];
   $statt23 = $nmont[22];
   $statt24 = $nmont[23];
   $statt25 = $nmont[24];
   $statt26 = $nmont[25];
   $statt27 = $nmont[26];
   $statt28 = $nmont[27];
//============================================================

    jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
        'text' => "
☑️ لیست شماره ها ، قیمت و استعلام موجودی شماره ها برای سرویس #$str2 :
⏱ استعلام شماره ها هر 10 دقيقه  بار بروز مي شود .
❄️ شماره ها به طور مداوم در حال شارژ شدن هستند ، هر چند مدت یکبار لیست را چک کنید که در صورت موجود بودن شماره مورد نظر خود آن را خریداری کنید .



 ♻️ آخرین بروزرسانی :
$ttt
$ddd
.
        ",
                    'reply_markup' => json_encode([
                        'resize_keyboard'=>true,
                    'inline_keyboard' => [
                    [
                        ['text' => "🌏 کشور", 'callback_data' => "text"], ['text' => "💰 قیمت", 'callback_data' => "text"], ['text' => "☑️ استعلام", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat1 ", 'callback_data' => "text"], ['text' => "$cost1", 'callback_data' => "text"], ['text' => "$statt1", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat2 ", 'callback_data' => "text"], ['text' => "$cost2", 'callback_data' => "text"], ['text' => "$statt2", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat3 ", 'callback_data' => "text"], ['text' => "$cost3", 'callback_data' => "text"], ['text' => "$statt3", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat4 ", 'callback_data' => "text"], ['text' => "$cost4", 'callback_data' => "text"], ['text' => "$statt4", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat5 ", 'callback_data' => "text"], ['text' => "$cost5", 'callback_data' => "text"], ['text' => "$statt5", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat6 ", 'callback_data' => "text"], ['text' => "$cost6", 'callback_data' => "text"], ['text' => "$statt6", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat7 ", 'callback_data' => "text"], ['text' => "$cost7", 'callback_data' => "text"], ['text' => "$statt7", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat8 ", 'callback_data' => "text"], ['text' => "$cost8", 'callback_data' => "text"], ['text' => "$statt8", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat9 ", 'callback_data' => "text"], ['text' => "$cost9", 'callback_data' => "text"], ['text' => "$statt9", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat10 ", 'callback_data' => "text"], ['text' => "$cost10", 'callback_data' => "text"], ['text' => "$statt10", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat11 ", 'callback_data' => "text"], ['text' => "$cost11", 'callback_data' => "text"], ['text' => "$statt11", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat12 ", 'callback_data' => "text"], ['text' => "$cost12", 'callback_data' => "text"], ['text' => "$statt12", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat13 ", 'callback_data' => "text"], ['text' => "$cost13", 'callback_data' => "text"], ['text' => "$statt13", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat14 ", 'callback_data' => "text"], ['text' => "$cost14", 'callback_data' => "text"], ['text' => "$statt14", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat15 ", 'callback_data' => "text"], ['text' => "$cost15", 'callback_data' => "text"], ['text' => "$statt15", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat16 ", 'callback_data' => "text"], ['text' => "$cost16", 'callback_data' => "text"], ['text' => "$statt16", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat17 ", 'callback_data' => "text"], ['text' => "$cost17", 'callback_data' => "text"], ['text' => "$statt17", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat18 ", 'callback_data' => "text"], ['text' => "$cost18", 'callback_data' => "text"], ['text' => "$statt18", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat19 ", 'callback_data' => "text"], ['text' => "$cost19", 'callback_data' => "text"], ['text' => "$statt19", 'callback_data' => "text"]
                    ],
                    [
                        ['text' => "$stat20 ", 'callback_data' => "text"], ['text' => "$cost20", 'callback_data' => "text"], ['text' => "$statt20", 'callback_data' => "text"]
                    ],
                   
                      
                     
                                      [
                        ['text' => "صفحه 6 ◀️", 'callback_data' => "pag6"], ['text' => "⤴️ صفحه اول", 'callback_data' => "pag1"]
                    ],
[
                        ['text' => "🔙 برگشت", 'callback_data' => "backpricservis"],['text' => "✖️ خروج", 'callback_data' => "ex"],
                    ],

                ],
            
        ])
        
    ]);       

}

?>