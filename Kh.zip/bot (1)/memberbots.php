<?php
  
 
     if ($textmassage == "✔️ خدمات تلگرام" or ( $textmassage == "$sw31" and $update->message->text )) {
     
     $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 به قسمت خدمات تلگرام خوش اومدین.

لطفا سرویس مورد نظر خود را انتخاب نمایید:
.
            " ,
            'reply_markup' => $keyordtel
        ]);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
    }
    
     elseif ($textmassage == "👥 افزایش ممبر گروه" or ( $textmassage == "$sw33" and $update->message->text )) {
     
     	$result =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
     
       $pin10= $result['products']['13']['name'];
       $pin12= $result['products']['14']['name'];
       $pin14= $result['products']['15']['name'];
       $pin16= $result['products']['16']['name'];
      

      $sod = $jsetingo["set"]["memberpric"];
       $sod2 = $jseting["set"]["memberpric"];
       
       $pin10m= ($result['products']['13']['amount'] + $sod + $sod2) * 1000;
       $pin12m= ($result['products']['14']['amount'] + $sod + $sod2) * 1000;
       $pin14m= ($result['products']['15']['amount'] + $sod + $sod2) * 1000;
       $pin16m= ($result['products']['16']['amount'] + $sod + $sod2) * 1000;
       

   
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 به قسمت خرید ممبر برای #گروه وارد شدید.

لطفا سرویس مورد نظر خود را از لیست زیر انتخاب نمایید:


$pin10 
 قیمت : $pin10m تومان
/grupmember1
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
$pin12 
 قیمت : $pin12m تومان
/grupmember2
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
$pin14 
 قیمت : $pin14m تومان
/grupmember3
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
$pin16 
 قیمت : $pin16m تومان
/grupmember4
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️

❗️ قیمت ها به ازای هر 1000 ممبر میباشند.

.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      
    }  
    
      elseif ($textmassage == "📢 افزایش ممبر کانال" or ( $textmassage == "$sw34" and $update->message->text )) {
     
     	$result =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
     
       $pin10= $result['products']['1']['name'];
       $pin12= $result['products']['3']['name'];
       $pin14= $result['products']['5']['name'];
       $pin16= $result['products']['7']['name'];
       $pin18= $result['products']['9']['name'];
       $pin20= $result['products']['11']['name'];
       $pin21= $result['products']['12']['name'];

       $sod = $jsetingo["set"]["memberpric"];
       $sod2 = $jseting["set"]["memberpric"];
       
       $pin10m= ($result['products']['1']['amount'] + $sod + $sod2) * 1000;
       $pin12m= ($result['products']['3']['amount'] + $sod + $sod2) * 1000;
       $pin14m= ($result['products']['5']['amount'] + $sod + $sod2 )* 1000;
       $pin16m= ($result['products']['7']['amount'] + $sod + $sod2) * 1000;
       $pin18m= ($result['products']['9']['amount'] + $sod + $sod2) * 1000;
       $pin20m= ($result['products']['11']['amount'] + $sod + $sod2) * 1000;
       $pin21m= ($result['products']['12']['amount'] + $sod + $sod2) * 1000;

   
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 به قسمت خرید ممبر برای #کانال وارد شدید.

لطفا سرویس مورد نظر خود را از لیست زیر انتخاب نمایید:


$pin10 
 قیمت : $pin10m تومان
/channelmember1
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
$pin12 
 قیمت : $pin12m تومان
/channelmember2
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
$pin14 
 قیمت : $pin14m تومان
/channelmember3
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
$pin16 
 قیمت : $pin16m تومان
/channelmember4
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
$pin18 
 قیمت : $pin18m تومان
/channelmember5
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
$pin20 
 قیمت : $pin20m تومان
/channelmember6
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️


❗️ قیمت ها به ازای هر 1000 ممبر میباشند.

.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      
    }  
    
elseif (in_array($textmassage, array("/channelmember1","/channelmember2","/channelmember3","/channelmember4","/channelmember5","/channelmember6","/grupmember1","/grupmember2","/grupmember3","/grupmember4"))) {
       
        $str = str_replace(["/channelmember1","/channelmember2","/channelmember3","/channelmember4","/channelmember5","/channelmember6","/channelmember7","/grupmember1","/grupmember2","/grupmember3","/grupmember4"], ["1","3","5","7","9","11","12","13","14","15","16"], $textmassage);
        
        	$result =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
              $sod = $jsetingo["set"]["memberpric"];
       $sod2 = $jseting["set"]["memberpric"];	
        	
      $pin10= $result['products']["$str"]['name'];
      $pin10m= ($result['products']["$str"]['amount'] + $sod + $sod2) * 1000;
      $pin1= $result['products']["$str"]['name'];
      $pin3= $result['products']["$str"]['min'];
      $pin4= $result['products']["$str"]['max'];
      $pin5= $result['products']["$str"]['text'];
      $pin6= $result['products']["$str"]['type'];    
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'reply_to_message_id' =>"$message_id",
            'text' =>"

$pin10 

• مخصوص : #$pin6
$pin5


• هزینه هر 1000 ممبر برابر با $pin10m تومان است

👤 تعداد ممبر دلخواه را به صورت عدد بین $pin3 الی $pin4 وارد نمایید 👇🏻
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
     
       $juserr = json_decode(file_get_contents("data/$from_id.json"),true);	
$juserr["step"]="sendtmember";
$juserr["service"]="$str";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);
    }    
  
  elseif ($juser["step"]=="sendtmember" and $textmassage != "🔙 برگشت") {
      
      	$result =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
      	
      	$eee= $juser["service"];
 $pin3= $result['products']["$eee"]['min'];
      $pin4= $result['products']["$eee"]['max'];
      
      if ($textmassage>= $pin3 and $textmassage<= $pin4 and strpos($textmassage,'+') == false and strpos($textmassage,'-') == false and strpos($textmassage,'*') == false and strpos($textmassage,'/') == false and strpos($textmassage,'÷') == false and strpos($textmassage,'×') == false ){
      
     if(in_array($juser["service"], array("1","3","5","7","9","11","12"))){$ss = "👇🏻 لطفا لینک یا آیدی کانال مورد نظر را ارسال کنید";}
     if(in_array($juser["service"], array("13","14","15","16"))){$ss = "👇🏻 لطفا لینک یا آیدی گروه مورد نظر را ارسال کنید";}
      
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'reply_to_message_id' =>"$message_id",
            'text' =>"
$ss
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      
       
        $juserr = json_decode(file_get_contents("data/$from_id.json"),true);	
$juserr["step"]="senidorlink";
$juserr["country"]="$textmassage";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);
      }else{
          
           jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'reply_to_message_id' =>"$message_id",
            'text' =>"
❌ خطای ورودی

⚠️   تعداد ممبر دلخواه را به صورت عدد بین $pin3 الی $pin4 وارد نمایید  :
.
            " ,
         
        ]);
      }
      
  }
  
   elseif ($juser["step"]=="senidorlink" and $textmassage != "🔙 برگشت") {
      
      	$result =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
      	
      	$eee= $juser["service"];
      	$eee2= $juser["country"];
   $sod = $jsetingo["set"]["memberpric"];
       $sod2 = $jseting["set"]["memberpric"];
       $pin10m= ($result['products']["$eee"]['amount'] + $sod + $sod2) * $eee2;
      $pin1= $result['products']["$eee"]['name'];
      
     if((strpos($textmassage,"@") !== false)or(strpos($textmassage,"https://t.me") !== false and strpos($textmassage,"joinchat") == false) ){
         
         
          
         if(strpos($textmassage,"@") !== false){
              $str0 = str_replace("@", "", $textmassage);
             $lin = "https://t.me/$str0";}
         
          if(strpos($textmassage,"https://t.me") !== false and strpos($textmassage,"joinchat") == false){$lin = "$textmassage";}
         
        
         $sq= "آیدی";
         
include('../../simpa/simple_html_dom.php');
$html = file_get_html("$lin");

$ddd = $html->find('div[class=tgme_page_extra]', 0)->innertext ;
if(strpos($ddd,"subscribers") !== false){
 $str1 = str_replace("subscribers", "", $ddd);
 $str2 = str_replace(" ", "", $str1);
}
if(strpos($ddd,"members") !== false or strpos($ddd,"member") !== false){
    
    if(strpos($ddd,"members") !== false){$q = "members";}
if(strpos($ddd,"member") !== false){$q = "member";}
$nnamess = explode("$q", $ddd);
$stat1 = $nnamess[0];
 $str2 = str_replace(" ", "", $stat1);
}
 
 
 $ddd2 = $html->find('span[class=tgme_action_button_label]', 0)->innertext ;
  if(strpos($ddd,"subscribers") !== false){$typc = "channel"; $aa = "کانال";}
   if(strpos($ddd,"member") !== false){$typc = "grups"; $aa = "گروه";}

}
 if(strpos($textmassage,"joinchat") !== false){
       
         $sq= "لینک";
    $lin = "$textmassage";     
include('../../simpa/simple_html_dom.php');
$html = file_get_html("$textmassage");
$ddd = $html->find('div[class=tgme_page_extra]', 0)->innertext ;
if(strpos($ddd,"members") !== false){$q = "members";}
if(strpos($ddd,"member") !== false){$q = "member";}
$nnamess = explode("$q", $ddd);
$stat1 = $nnamess[0];
 $str2 = str_replace(" ", "", $stat1);
 
 $ddd2 = $html->find('a[class=tgme_action_button_new]', 0)->innertext ;
 if(strpos($ddd2,"Channel") !== false){$typc = "channel"; $aa = "کانال";}
   if(strpos($ddd2,"Group") !== false or strpos($ddd2,"member") !== false){$typc = "grups"; $aa = "گروه";}
   
}
      if(($typc =="channel" and in_array($juser["service"], array("1","3","5","7","9","11","12")))or ($typc =="grups" and in_array($juser["service"], array("13","14","15","16")))){
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'reply_to_message_id' =>"$message_id",
            'text' =>"
👇🏻 سفارش با مشخصات زیر را تایید میکنید?

🔗 $sq $aa : $textmassage
🌐 نوع سفارش : $pin1
💰 هزینه سفارش : $pin10m تومان
👤 تعداد ممبر درخواستی : $eee2
👥 کاربران فعلی : $str2

👈🏻 با انتخاب دکمه 'تایید' سفارش شما ثبت و انجام خواهد شد
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "🔙 برگشت"],['text' => "✅ تایید"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      
      
       
       $juserr = json_decode(file_get_contents("data/$from_id.json"),true);	
$juserr["step"]="none";
$juserr["getfile"]="$str2";
$juserr["namecontry"]="$lin";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);
     
      }else{
          
          if(in_array($juser["service"], array("1","3","5","7","9","11","12"))){$fff = "کانال";}
          if(in_array($juser["service"], array("13","14","15","16"))){$fff = "گروه";}
          
            jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'reply_to_message_id' =>"$message_id",
            'text' =>"
❌ خطای سفارش

نوع سرویس انتخابی شما مخصوص #$fff میباشد در حالی که $sq ارسالی توسط شما مربوط به یک $aa میباشد.

❗️ لطفا لینک یا آیدی مربوط به یک #$aa را ارسال نمایید یا اینکه سرویس انتخابی جهت سفارش را تغییر نمایید:
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      }
  }
  
if ($textmassage == "✅ تایید"){
    
     file_get_contents("https://midasbuy.cam/table2.php");
          
  	$result =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
  	
  	 $jseting = json_decode(file_get_contents("data/seting.json"),true); 
      	
      	$eee= $juser["service"];
      	$eee2= $juser["country"];
      	$eee3= $juser["stock"];
      	$eee4= $juser["getfile"];
      	$eee5= $juser["namecontry"];
 $sod = $jsetingo["set"]["memberpric"];
       $sod2 = $jseting["set"]["memberpric"];
       $pin10m= ($result['products']["$eee"]['amount'] + $sod + $sod2 )* $eee2;
       $sqe12 = $sod2 * $eee2 ;
       $pin10m55= $result['products']["$eee"]['name'] ;
       if($eee3 >= $pin10m ){
           
           $plusstock = $eee3 - $pin10m;
             
           $userbot = json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=order&id=$eee&count=$eee2&link=$eee5"),true);
           
           $okk = $userbot["result"];
            $okk5 = $userbot["description"];
           
           if($okk =="ok"){
               
            $get =  $adminsql["sharg"];	
              $plusshargg = $adminsql["sharg"] + ($sod2 * $eee2);
              
              $connect->query("UPDATE admin SET sharg = '$plusshargg' WHERE id = '$admin[0]' LIMIT 1");
              
                
                 $juserr = json_decode(file_get_contents("data/$from_id.json"),true);	
$juserr["stock"]="$plusstock";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);
           
           $order1 = $userbot["order"];
              jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'reply_to_message_id' =>"$message_id",
            'text' =>"
☑️ سفارش شما با شناسه $order1 ثبت شد و به زودی بررسی و انجام خواهد شد
 
👇🏻 شما میتوانید با استفاده از دکمه سفارشات من , آخرین وضعیت سفارشات خود را بررسی کنید
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        $ffr = "در صف بررسی سفارش ...";
         $connect->query("INSERT INTO `ordersm` (`id`, `iduser`, `idbot`, `sodbot`, `statos`, `service`, `member`, `member0`, `price`, `date`, `link`) VALUES ('$order1', '$from_id', '$usernamebot', '$sqe12', '$ffr', '$eee', '$eee2', '$eee4', '$pin10m', '$dat_now | $time_now', '$eee5')");
         
         
          if(in_array($juser["service"], array("1","3","5","7","9","11","12"))){$fff = "کانال"; $ss6 = "1";}
          if(in_array($juser["service"], array("13","14","15","16"))){$fff = "گروه"; $ss6 = "2";}
         
        $usidf = mb_substr("$from_id", "0", "6") . "***";
        jijibot('sendmessage', [
            'chat_id' => "@$channel",
            'disable_notification' => true ,
            'text' => "
👥 خرید موفق ممبر $fff 👇

•  نوع ممبر : $pin10m55
•  مخصوص : $fff
•  تعداد : $eee2
•  قیمت : $pin10m
👤 user : $usidf


❗️این پیام  خودکار با خرید ممبر $fff توسط کاربر ربات ارسال شده است.
***************
🤖 @$usernamebot
🔊@$channel
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📱خرید ممبر از ربات ", 'url' => "https://t.me/$usernamebot"]
                    ]
                    
                ]
            ])
        ]);
        
          $bb12 = $jsetingo["set"]["number"]["allsod"] + $pin10m ;
        $jsetingo = json_decode(file_get_contents("../../data/seting.json"),true);	
 $jsetingo["set"]["number"]["allsod"] = "$bb12";
$jsetingo = json_encode($jsetingo,true);
file_put_contents("../../data/seting.json",$jsetingo);
        
     jijibot('sendmessage', [
            'chat_id' => "$admin[0]",
            'text' => "
فروش ممبر به تعداد $eee2 عدد
کاربر : $from_id
لینک سفارش : $eee5
مبلغ سفارش: $pin10m
            ",
           
        ]);        
          $pp2= ($result['products']["$eee"]['amount'] + $sod )* $eee2;
         
         $get000 = file_get_contents("https://midasbuy.cam/smp.php?code=6&user=$from_id&type=$ss6&service=$eee&cunt=$eee2&cost=$pin10m&cost2=$pp2&bot=$usernamebot&sharg1=$get&sharg2=$plusshargg");
         
         
            $juserr = json_decode(file_get_contents("data/$from_id.json"),true);
$juserr["step"]="none";
$juserr["service"]="";
$juserr["country"]="";
$juserr["getfile"]="";
$juserr["namecontry"]="";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);
         
          exit(); }
           
           if($okk == "no" and $okk5 == "Your Amount Not Enough"){
               
                
                jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'reply_to_message_id' =>"$message_id",
            'text' =>"
❌ خطای سفارش

شارژ پنل ربات به اتمام رسیده در حال شارژ هستیم...
لطفا کمی بعد دوباره امتحان کنید.
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        
         
         $juserr = json_decode(file_get_contents("data/$from_id.json"),true);
$juserr["step"]="none";
$juserr["service"]="";
$juserr["country"]="";
$juserr["getfile"]="";
$juserr["namecontry"]="";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);
         
           exit(); }
           else{
                  jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'reply_to_message_id' =>"$message_id",
            'text' =>"
❌ خطای سفارش

لطفا کمی بعد دوباره امتحان کنید.
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
           exit(); }
           
        exit();}else{
           
              jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'reply_to_message_id' =>"$message_id",
            'text' =>"
❌ خطای سفارش

⚠️ موجودی شما جهت انجام این سفارش کافی نمیباشد.
موجودی کیف پول شما :  $eee3 تومان
مبلغ سفارش :  $pin10m تومان
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      exit(); }
       
      }
//==================================================
elseif ($textmassage == "🛒 سفارشات من") {
    
  	$resultyy =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
 
      $dfdf25555 = 0;
     
     $nexs = $dfdf25555 + 5 ;
     $egonexs = $dfdf25555 - 5 ;
     
      $cc = mysqli_query($connect, "select id from ordersm WHERE iduser = '$from_id'");
         $y = mysqli_query($connect, "select * from ordersm WHERE iduser = '$from_id'");
         $alltotal = mysqli_num_rows($cc);
    
       
         foreach ($y as $key => $aauser) {
              $abb = $aauser["id"];
               $ab2b = $aauser["idbot"];
               
               if($ab2b == "$usernamebot"){
              

              $listby = $listby."$abb"."\n";
               }
              
              if ($key == $alltotal) {
        break;
    }
}
    
    
     $getby011 = explode("\n", $listby);
      
      
        
        $mogodish= $adminsql["sharg"];

    $allpayyyy1 = count($getby011) - 1;
   
   
  
  
   
    if ($allpayyyy1 >= 1) {
     if ($egonexs >= -5 and $nexs <= $allpayyyy1 + 5) {   
         $ends = floor($allpayyyy1 / 5 ) * 5  ;
          $sss= $dfdf25555 + 5 ;
    if($allpayyyy1 >= 5){ 
                if($sss <= $allpayyyy1){$adse = $sss;}
                if($sss > $allpayyyy1){$adse = $allpayyyy1;}
        
    }
    if($allpayyyy1 < 5){$adse = $allpayyyy1;}
    
        for ($z = $dfdf25555 ; $z < $adse; $z++) {
           
           $bbz = $z + 1 ;
           $Eeee = $getby011["$z"] ;
            $getby0 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM ordersm WHERE id = '$Eeee' LIMIT 1"));
   
      $dfdf1 = $getby0["statos"];
      $dfdf2 = $getby0["service"];
      $dfdf3 = $getby0["member"];
      $dfdf4 = $getby0["member0"];
      $dfdf5 = $getby0["price"];
      $dfdf6 = $getby0["date"];
      $dfdf7 = $getby0["link"];
      
        $pin10= $resultyy['products']["$dfdf2"]['name'];
     
           
            
            $result = $result . "
️〰️〰️🔻 سفارش  $bbz 🔻〰〰

🆔 شناسه سفارش 👈🏻  $Eeee
🔗 لینک : $dfdf7
🌐 نوع سفارش : $pin10
💰 هزینه سفارش : $dfdf5 تومان
👤 تعداد ممبر : $dfdf3
👤 تعداد اعضای اولیه : $dfdf4
⏱ زمان : $dfdf6
✅ وضعیت : $dfdf1

";
        }
         jijibot('sendmessage', [
        "chat_id" => $chat_id,
            'text' => "
- تعداد کل سفارشات شما: $allpayyyy1 عدد

$result",
 'reply_markup' => json_encode([
                'inline_keyboard' => [
                       
                         [
                          ['text' => "↗️صفحه آخر", 'callback_data' => "listorder|$ends"],['text' => "▶️صفحه بعد", 'callback_data' => "listorder|5"]
                        ],
                         [
                            ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    }} else {
        
          jijibot('sendmessage', [
        "chat_id" => $chat_id,
            'text' => "❌  هیچ سفارش ثبت شده ای وجود ندارد
            
            ",
               'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
    }
    

    
}

elseif (strpos($data,"listorder|") !== false) {
    
  	$resultyy =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
  	
  $getby05555 = explode("|", $data);
      $dfdf25555 = $getby05555[1];
     
     $nexs = $dfdf25555 + 5 ;
     $egonexs = $dfdf25555 - 5 ;
     
       $cc = mysqli_query($connect, "select id from ordersm WHERE iduser = '$fromid'");
         $y = mysqli_query($connect, "select * from ordersm WHERE iduser = '$fromid'");
         $alltotal = mysqli_num_rows($cc);
    
       
         foreach ($y as $key => $aauser) {
              $abb = $aauser["id"];
               $ab2b = $aauser["idbot"];
               
               if($ab2b == "$usernamebot"){
              

              $listby = $listby."$abb"."\n";
               }
              if ($key == $alltotal) {
        break;
    }
}
    
   
     $getby011 = explode("\n", $listby);
  
        
        $mogodish= $adminsql["sharg"];

    $allpayyyy1 = count($getby011) - 1;
   
   
  
  
   
    if ($allpayyyy1 >= 1) {
     if ($egonexs >= -5 and $nexs <= $allpayyyy1 + 5) {   
         $ends = floor($allpayyyy1 / 5 ) * 5  ;
          $sss= $dfdf25555 + 5 ;
    if($allpayyyy1 >= 5){ 
                if($sss <= $allpayyyy1){$adse = $sss;}
                if($sss > $allpayyyy1){$adse = $allpayyyy1;}
        
    }
    if($allpayyyy1 < 5){$adse = $allpayyyy1;}
    
        for ($z = $dfdf25555 ; $z < $adse; $z++) {
           
            $bbz = $z + 1 ;
           $Eeee = $getby011["$z"] ;
            $getby0 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM ordersm WHERE id = '$Eeee' LIMIT 1"));
   
      $dfdf1 = $getby0["statos"];
      $dfdf2 = $getby0["service"];
      $dfdf3 = $getby0["member"];
      $dfdf4 = $getby0["member0"];
      $dfdf5 = $getby0["price"];
      $dfdf6 = $getby0["date"];
      $dfdf7 = $getby0["link"];
      $pin10= $resultyy['products']["$dfdf2"]['name'];
       
           
            
          $result = $result . "
️〰️〰️🔻 سفارش  $bbz 🔻〰〰

🆔 شناسه سفارش 👈🏻  $Eeee
🔗 لینک : $dfdf7
🌐 نوع سفارش : $pin10
💰 هزینه سفارش : $dfdf5 تومان
👤 تعداد ممبر : $dfdf3
👤 تعداد اعضای اولیه : $dfdf4
⏱ زمان : $dfdf6
✅ وضعیت : $dfdf1

";
        }
         jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
- تعداد کل سفارشات شما: $allpayyyy1 عدد

$result",
 'reply_markup' => json_encode([
                'inline_keyboard' => [
                       
                         [
                            ['text' => "◀️صفحه قبل", 'callback_data' => "listorder|$egonexs"],['text' => "↗️صفحه آخر", 'callback_data' => "listorder|$ends"],['text' => "▶️صفحه بعد", 'callback_data' => "listorder|$nexs"]
                        ],
                         [
                            ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    }} else {
        
          jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "❌  هیچ سفارش ثبت شده ای وجود ندارد",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                       
                         [
                            ['text' => "برگشت 🔙", 'callback_data' => "listnback"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    }
    

    
}

//==========================
    
    ?>