<?php
include("../bottpodkrtirtoy.php");
$MerchantID = '724f776b-500b-4559-9b2c';
$Amount = 20000;
$Authority = $_GET['Authority'];
$user = $_GET['user'];
if ($_GET['Status'] == 'OK'){
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']); // ادرس درگاه
$result = $client->PaymentVerification(
[
'MerchantID' => $MerchantID,
'Authority' => $Authority,
'Amount' => $Amount,
]
);

if ($result->Status == 100){
echo 'پرداخت با موفقیت انجام شد و حساب شما شارژ شد ✅';
$userget = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));
 $stoockk = $userget["stock"];
 
             
$coinplus = $stoockk + $Amount;
$coin = $stoockk ;
jijibot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"#پرداخت موفق ✅
	
💰 مقدار خرید : $Amount تومان
📥 موجودی جدید کیف پول طلایی شما : $coinplus تومان
🎈 موجودی قبلی : $coin تومان",
            ]);
jijibot('sendmessage',[
	'chat_id'=>$admin[0],
	'text'=>"#پرداخت موفق ✅
	
💰 مقدار خرید : $Amount تومان
📥 موجودی جدید طلایی کاربر : $coinplus تومان
👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
            jijibot('sendmessage',[
	'chat_id'=>$admin[1],
	'text'=>"#پرداخت موفق ✅
	
💰 مقدار خرید : $Amount تومان
📥 موجودی جدید کاربر : $coinplus تومان
👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
$connect->query("UPDATE user SET stock = '$coinplus' WHERE id = '$user' LIMIT 1");	
if($userget["inviter"] == true){
    $Amountt = $Amount / 3 ;
$inviter = $userget["inviter"];
$userinviter = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$inviter' LIMIT 1"));

$stoockk = $userinviter["stock"];
 
             
$coininviter = $stoockk;
$porsantt = ($Amountt * 10) / 100 ;
$porsant = round($porsantt);
$coinplusinviter = $coininviter + $porsant ;
jijibot('sendmessage',[
	'chat_id'=>$inviter,
	'text'=>"👥 زیر مجموعه شما از ربات خرید کرد و 10 درصد از موجودی خریداری شده به عنوان پورسانت به شما تعلق میگرید
	
💰 موجودی خریداری شده : $Amountt
📥 موجودی جدید شما : $coinplusinviter
🎈 موجودی قبلی : $coininviter
❄️ مقدار پورسانت : $porsant
👤 خرید توسط : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
$connect->query("UPDATE user SET stock = '$coinplusinviter' WHERE id = '$inviter' LIMIT 1");
}	
} else {
echo 'پرداخت شما قبلا ثبت شده است';

}
} else {
echo 'پرداخت انجام نشد';
}
?>