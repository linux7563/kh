<?php
include("../bottpodkrtirtoy.php");

$user = $_GET['user'];
$userget = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));
$pp = $userget["price"];
$MerchantID = '724f776b-500b-4559-9b2c';
$Amount = $userget["price"];
$Authority = $_GET['Authority'];
if ($_GET['Status'] == 'OK'){
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification(
[
'MerchantID' => $MerchantID,
'Authority' => $Authority,
'Amount' => $Amount,
]
);

if ($result->Status == 100){
echo 'پرداخت با موفقیت انجام شد ✅';
$userget = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));

            
jijibot('sendmessage',[
	'chat_id'=>$admin[0],
	'text'=>"#پرداخت آنلاین موفق ✅
	
💰 مقدار خرید : $pp تومان

بابت  ساخت ربات شماره مجازی نقره ای

👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
 jijibot('sendmessage',[
	'chat_id'=>$admin[1],
	'text'=>"#پرداخت آنلاین موفق ✅
	
💰 مقدار خرید : $pp تومان

بابت  ساخت ربات شماره مجازی نقره ای

👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);           
       
       jijibot('sendmessage', [
        "chat_id" => $user,
        "text" => "
✅ پرداخت به مبلغ $pp موفق .


💢 برای ساخت ربات شماره مجازی نقره ای توکن ربات خود را که در بوت فادر ساخته اید ارسال نمایید 
مانند نمونه زیر:

900371469:AAFo1LEF5Yjy8T5ZARmgYM3RqZ74-Jz7Tu9
        ",
        
    ]);
    $connect->query("UPDATE user SET step = 'sendtoken' , price = '' WHERE id = '$user' LIMIT 1");
        
    

	

	
 }else {
echo 'پرداخت شما قبلا ثبت شده است';

 }   
} else {
echo 'پرداخت انجام نشد';
}
?>