<?php
include("../bottpodkrtirtoy.php");

$user = $_GET['user'];
$userget = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));
$pp = $userget["price"];
$MerchantID = '724f776b-500b-4559-9b2c';
$Amount = $userget["price"];
$Authority = $_GET['Authority'];
if ($_GET['Status'] == 'OK'){
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification(
[
'MerchantID' => $MerchantID,
'Authority' => $Authority,
'Amount' => $Amount,
]
);

if ($result->Status == 100){
echo 'پرداخت با موفقیت انجام شد ✅';

$connect->query("UPDATE user SET step = 'sendtokent' , price = '' WHERE id = '$user' LIMIT 1");

$userget = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));

            
              $dat_nowt = "$dat_yer/$dat_mahn/$dat_day" ;
          $time_nowt = "$dat_h:$dat_min";
           
            
    $payw = "amunt: $pp => user: $user => ($dat_nowt)($time_nowt) => bot: @$usernamebot \n[*new*]";
            $source55 = file_get_contents("../data/listpayy.txt");
     $source55 = str_replace("[*new*]",$payw,$source55);
     file_put_contents("../data/listpayy.txt",$source55); 
            
jijibot('sendmessage',[
	'chat_id'=>$admin[0],
	'text'=>"#پرداخت آنلاین موفق ✅
	
💰 مقدار خرید : $pp تومان

بابت  ساخت ربات شماره مجازی طلایی

👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
 jijibot('sendmessage',[
	'chat_id'=>$admin[1],
	'text'=>"#پرداخت آنلاین موفق ✅
	
💰 مقدار خرید : $pp تومان

بابت  ساخت ربات شماره مجازی طلایی

👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);           
       
       jijibot('sendmessage', [
        "chat_id" => $user,
        "text" => "
✅ پرداخت به مبلغ $pp موفق .


💢 برای ساخت ربات شماره مجازی طلایی توکن ربات خود را که در بوت فادر ساخته اید ارسال نمایید 
مانند نمونه زیر:

900371469:AAFo1LEF5Yjy8T5ZARmgYM3RqZ74-Jz7Tu9
        ",
        
    ]);
    
        
    

	

	
 }else {
echo 'پرداخت شما قبلا ثبت شده است';

 }   
} else {
echo 'پرداخت انجام نشد';
}
?>