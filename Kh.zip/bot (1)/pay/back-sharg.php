<?php
include("../bottpodkrtirtoy.php");
$user = $_GET['user'];
$userget = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));
$pp = $userget["price"];
$MerchantID = '724f776b-500b-4559-9b2c';
$Amount = (($userget["price"] / 100) * 9) + $user["price"]; 
$Authority = $_GET['Authority'];

if ($_GET['Status'] == 'OK'){
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification(
[
'MerchantID' => $MerchantID,
'Authority' => $Authority,
'Amount' => $Amount,
]
);

if ($result->Status == 100){
echo 'پرداخت با موفقیت انجام شد ✅';
$userget = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));
$stoockk = $userget["stock"];

  $dat_nowt = "$dat_yer/$dat_mahn/$dat_day" ;
          $time_nowt = "$dat_h:$dat_min";
           
            
    $payw = "amunt: $pp => user: $user => ($dat_nowt)($time_nowt) => bot: @$usernamebot \n[*new*]";
            $source55 = file_get_contents("../data/listpayy.txt");
     $source55 = str_replace("[*new*]",$payw,$source55);
     file_put_contents("../data/listpayy.txt",$source55); 
         
         jijibot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"#پرداخت موفق ✅
	
💰 مقدار خرید : $pp تومان",
            ]);           
            
jijibot('sendmessage',[
	'chat_id'=>$admin[0],
	'text'=>"#پرداخت آنلاین موفق ✅
خرید شارژ
💰 مقدار خرید : $pp تومان

👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
 
            
             $operator = $userget["panel"]; 
      $ab12 = $userget["service"]; 
      $charge_type = $userget["namecontry"]; 
      $ab14 = $userget["price"];
       $mobile = $userget["country"];
         $ab144 = (($userget["price"] / 100) * 9) + $userget["price"]; 
       $str1 = str_replace(["MTN", "MCI", "RTL"], [" ایرانسل"," همراه اول"," رایتل"], $operator);
       

       $str3 = str_replace(["topup", "pin"], [" مستقیم", " دریافت کد شارژ"], $ab12);

        $str4 = str_replace(["normal", "amazing"], [" معمولی"," شگفت انگیز"], $charge_type);
        
 
    
    $stock = $userget["stock"];
     
   
       
       
      $timee = time();
      $tattt = "$dat_yer$dat_mahn$dat_day" ;
             $order_id = "$user$timee";
		
	
			
		
		
		
		$result =  json_decode(file_get_contents("https://inax.ir/webservice.php?method=topup&username=$usersharg&password=$passsharg&amount=$ab14&mobile=$mobile&operator=$operator&charge_type=$charge_type&order_id=$order_id&company=eee"),true);
     $srsws = $result['msg'];
     $dfdfd= $result['ref_code'];
     
      if ($result['code']== "1"){
				 jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
✅ عملیات خرید شارژ موفق.

📟 کد پیگیری : $dfdfd
",
'reply_markup' => json_encode([
                'keyboard' => [
                [
                   ['text' => "📲 خرید شارژ سیمکارت"], ['text' => "📲 خرید شماره مجازی"]
                ],
                
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "💸 شارژ حساب"]
                ]
                ,
                [
                     ['text' => "🤖 ربات شماره مجازی شما [ربات نمایندگی]"] 
                    ],
                     [
                   ['text' => "👥 زیرمجموعه گیری"]
                    ],
                     [
                    ['text' => "🛍 خرید های من"], ['text' => "👤 اطلاعات حساب"]
                    ],
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
                'resize_keyboard' => true
            ])
            ]);
             $mobilee = mb_substr("$mobile", "0", "8") . "***";
             $usidf = mb_substr("$user", "0", "6") . "***";
             jijibot('sendmessage', [
            'chat_id' => "@$channel",
            'text' =>"
✅ یک عدد شارژ سیمکارت اعتباری $str1 خریداری شد.

اطلاعات شارژ خریداری شده👇

〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
✳️ اوپراطور : $str1
✳️ روش شارژ : $str3
✳️ نوع شارژ : $str4
✳️ مبلغ شارژ :  $ab14 تومان

📱 mobile : $mobilee
👤 USER : $usidf
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️

❗️روش خرید شارژ سیمکارت اعتباری :
۱-وارد ربات @$usernamebot شوید.
۲-اعتبار خود را $ab144 تومان افزایش دهید.
۳-شارژ سیمکارت اعتباری خریداری کنید.
☝️شارژ های سیمکارت اعتباری ثبت نشده هستند و  اتومات توسط کاربران ربات @$usernamebot نامبرینو به صورت کاملا خودکار دریافت و شارژ می شوند.
این پیام  خودکار با خرید شارژ سیمکارت اعتباری توسط کاربر ربات نامبرینو  ارسال شده است.
***************
🤖 @$usernamebot
🔊@$channel
.
            " ]);
           
            $tttt = "📱 شماره سیمکارت : $mobile
💰 مبلغ شارژ : $ab14
⏰ ساعت : $time_now   ⏳ تاریخ : $dat_now
📟شماره پیگیری : $dfdfd
*";
              $jbuy = json_decode(file_get_contents("data/listbuy.json"),true);	
$jbuy["$user"]["sharg"]="$tttt";
$jbuy = json_encode($jbuy,true);
file_put_contents("data/listbuy.json",$jbuy);

 $connect->query("UPDATE user SET step ='none',  price = '' , panel = '', service = '', namecontry = '', country = '', stock = '$stock'  WHERE id = '$user' LIMIT 1");
            
		}
		$dddd = $result['code'];
    if ( in_array($dddd, array("-11","-12","-18","-55","-66","-67","-91"))){
				 jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
❌ خطا در خرید .

$srsws

مبلغ پرداختی به کیف پول شما منتقل شد.
",
'reply_markup' => json_encode([
                'keyboard' => [
                       
                         [
                            ['text' => "🔙 برگشت"]
                        ]
                    ],
                'resize_keyboard' => true
            ])
            ]);
            $stock = $userget["stock"] + $ab144;
            $connect->query("UPDATE user SET step ='none',  price = '' , panel = '', service = '', namecontry = '', country = '', stock = '$stock'  WHERE id = '$user' LIMIT 1");
		}    

else {
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
❌ خطا در خرید .

لطفا مجددا تلاش کنید.

مبلغ پرداختی به کیف پول شما منتقل شد.

",
'reply_markup' => json_encode([
                'keyboard' => [
                       
                         [
                            ['text' => "🔙 برگشت"]
                        ]
                    ],
                'resize_keyboard' => true
            ])
            ]);
        
              jijibot('sendmessage', [
                'chat_id' => @$channelbc,
                'text' => "
❌ خطا در خرید .

$srsws
.
",]);
    
    $stock = $userget["stock"] + $ab144;
    $connect->query("UPDATE user SET step ='none',  price = '' , panel = '', service = '', namecontry = '', country = '', stock = '$stock'  WHERE id = '$user' LIMIT 1");
}
    
 }else {
echo 'پرداخت شما قبلا ثبت شده است';

 }   
} else {
echo 'پرداخت انجام نشد';
}
?>