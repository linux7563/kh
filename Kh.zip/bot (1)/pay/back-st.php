<?php
include("../bottpodkrtirtoy.php");
$user = $_GET['user'];
$userget = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));
$pp = $userget["price"];
$MerchantID = '724f776b-500b-4559-9b2c';
$Amount = $userget["price"];
$Authority = $_GET['Authority'];

if ($_GET['Status'] == 'OK'){
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification(
[
'MerchantID' => $MerchantID,
'Authority' => $Authority,
'Amount' => $Amount,
]
);

if ($result->Status == 100){
echo 'پرداخت با موفقیت انجام شد ✅';
$userget = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));
$stoockk = $userget["stock"];

 $plusstock = $pp + $stoockk;
         
         jijibot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"#پرداخت موفق ✅
	
💰 مقدار خرید : $pp تومان

موجودی کیف پول شما : $plusstock تومان
",
            ]);           
            
jijibot('sendmessage',[
	'chat_id'=>$admin[0],
	'text'=>"#پرداخت آنلاین موفق ✅
	
💰 مقدار خرید : $pp تومان


موجودی کیف پول کاربر : $plusstock تومان


👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
  
            
          
       
              
          $dat_nowt = "$dat_yer/$dat_mahn/$dat_day" ;
          $time_nowt = "$dat_h:$dat_min";
           
            
    $payw = "amunt: $pp => user: $user => ($dat_nowt)($time_nowt) => bot: @$usernamebot \n[*new*]";
            $source55 = file_get_contents("../data/listpayy.txt");
     $source55 = str_replace("[*new*]",$payw,$source55);
     file_put_contents("../data/listpayy.txt",$source55); 
    

            
          
           
         
         
         
             $connect->query("UPDATE user SET step = 'none' ,  stock = '$plusstock'  WHERE id = '$user' LIMIT 1");
        
            
        
    

	

	
 }else {
echo 'پرداخت شما قبلا ثبت شده است';

 }   
} else {
echo 'پرداخت انجام نشد';
}
?>