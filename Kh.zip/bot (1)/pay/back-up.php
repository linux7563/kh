<?php
include("../bottpodkrtirtoy.php");
$user = $_GET['user'];
$userget = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));
$usergettt = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM admin WHERE id = '$user' LIMIT 1"));
$pp = $userget["price"];
$MerchantID = '724f776b-500b-4559-9b2c';
$Amount = $userget["price"];
$Authority = $_GET['Authority'];

if ($_GET['Status'] == 'OK'){
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification(
[
'MerchantID' => $MerchantID,
'Authority' => $Authority,
'Amount' => $Amount,
]
);

if ($result->Status == 100){
echo 'پرداخت با موفقیت انجام شد و حساب شما شارژ شد ✅';

 $stoockk = $usergettt["sharg"];
 $stoockkboot = $usergettt["userbot"];
             
$coinplus = $stoockk + $Amount;
$coin = $stoockk ;
jijibot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"#پرداخت موفق ✅
	
💰 مقدار خرید : $Amount تومان
📥 موجودی جدید پنل شما : $coinplus تومان
🎈 موجودی قبلی : $coin تومان",
            ]);
jijibot('sendmessage',[
	'chat_id'=>$admin[0],
	'text'=>"#پرداخت موفق ✅
	
💰 مقدار خرید : $Amount تومان
📥 موجودی جدید پنل کاربر : $coinplus تومان
👤 کاربر : [$user](tg://user?id=$user)
آیدی ربات : @$stoockkboot
",
'parse_mode'=>'Markdown',
            ]);
            jijibot('sendmessage',[
	'chat_id'=>$admin[1],
	'text'=>"#پرداخت موفق ✅
	
💰 مقدار خرید : $Amount تومان
📥 موجودی جدید پنل کاربر : $coinplus تومان
👤 کاربر : [$user](tg://user?id=$user)
آیدی ربات : @$stoockkboot
",
'parse_mode'=>'Markdown',
            ]);
$connect->query("UPDATE admin SET sharg = '$coinplus' WHERE id = '$user' LIMIT 1");	
	
	  $dat_nowt = "$dat_yer/$dat_mahn/$dat_day" ;
          $time_nowt = "$dat_h:$dat_min";
           
            
    $payw = "amunt: $pp => user: $user => ($dat_nowt)($time_nowt) => bot: @$usernamebot \n[*new*]";
            $source55 = file_get_contents("../data/listpayy.txt");
     $source55 = str_replace("[*new*]",$payw,$source55);
     file_put_contents("../data/listpayy.txt",$source55); 
	
	
} else {
echo 'پرداخت شما قبلا ثبت شده است';

}
} else {
echo 'پرداخت انجام نشد';
}
?>