<?php
include("../../bot.php");
$MerchantID = '05b4c02a-c2ee-4195-a45a-ef0c721c11fb';
$Amount = $_GET['amount'];
$trans_id = $_GET['trans_id'];
$user = $_GET['user'];
$parameters = array ("api_key"=>$MerchantID,"order_id"=>1,"amount"=>$Amount,"trans_id"=>$trans_id);
$client = new SoapClient('http://api.nextpay.org/gateway/verify.wsdl');  
$verify_obj = $client->PaymentVerification($parameters); 
$code = $verify_obj->PaymentVerificationResult->code;
if($code == 0){
$userget = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));
$pluscoin = $userget["stock"]  +  $Amount;
jijibot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"✅ #پرداخت موفق	
💎 مقدار خرید : $Amount تومان
💰 موجودی جدید شما : $pluscoin تومان
❄️ موجودی قبلی : {$user["stock"]} تومان

❤️ از خرید شما متشکریم . در صورت وجود هر گونه مشکل با پشتیبانی در تماس باشید
🌟 موجودی شما با موفقیت افزایش یافت !",
            ]);
$connect->query("UPDATE user SET  stock = '$pluscoin' WHERE id = '$user' LIMIT 1");	
jijibot('sendmessage',[
	'chat_id'=>$admin[0],
	'text'=>"✅ #پرداخت موفق
	
💎 مقدار خرید : $Amount تومان
👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
if($userget["inviter"] == true){
$userinviter = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '{$userget["inviter"]}' LIMIT 1"));
$porsant = ($Amount * 5) / 100 ;
$coinplusinviter = $userinviter["stock"] + $porsant;
jijibot('sendmessage',[
	'chat_id'=>$userget["inviter"],
	'text'=>"✅ تبریک ! زیر مجموعه شما از ربات خرید کرد و 5 درصد از موجودی خریداری شده به عنوان هدیه به شما تعلق گرفت
	
🛍 موجودی خریداری شده : $Amount تومان
💰 موجودی جدید شما : $coinplusinviter تومان
❄️ موجودی قبلی : {$userinviter["stock"]} تومان
🎁 مقدار هدیه : $porsant تومان
👤 خرید توسط : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
$connect->query("UPDATE user SET stock = '$coinplusinviter' WHERE id = '{$userget["inviter"]}' LIMIT 1");
}
header("Location: https://t.me/$usernamebot");
} else {
echo 'پرداخت انجام نشد';
}
?>