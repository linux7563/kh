<!DOCTYPE HTML>
<!--
in the name of God 
source of sellnumber
by php and html
v.1
dev : mohammadrezajafari [@mohammadrezajiji]
-->
<?php 
include "../../bot.php";
$user = $_GET['id'];
$name = jijibot('getChatMember',['chat_id'=>"$user",'user_id'=>"$user"])->result->user->first_name;
//==================================================
$amount = $_GET['amount'];
$MerchantID = '05b4c02a-c2ee-4195-a45a-ef0c721c11fb';
//=======================
$order_id = time();
$parameters = array("api_key"=>$MerchantID,"order_id"=>$order_id,"amount"=>$amount,"callback_uri"=>$CallbackURL); 
 
$client = new SoapClient('http://api.nextpay.org/gateway/token.wsdl');  
$token_obj = $client->TokenGenerator($parameters);  
$trans_id = $token_obj->TokenGeneratorResult->trans_id;  
$code = $token_obj->TokenGeneratorResult->code; 
$CallbackURL = "$web/pay/n/back.php?user=$user&amount=$amount&trans_id=$trans_id&order_id=1";

//==================================================
if($code == -1){
$payy = "http://api.nextpay.org/gateway/payment/$trans_id";
}
?>
<html>
	<head>
		<title>ربات خرید شماره مجازی</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<link rel="stylesheet" href="assets/css/rtl.css" />
	</head>
	<body>

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Header -->
					<header id="header" class="alt">
						<span class="logo"><img src="images/cutmypic.png" alt="" /></span>
						<h1>ربات خرید شماره مجازی</h1>
						<p>صحفه افزایش موجودی برای حساب</p>
					</header>


				<!-- Main -->
					<div id="main">
					<!-- First Section -->
										<section id="intro" class="main">
								<div class="spotlight">
									<div class="content">
										<header class="major">
											<h2>افزایش موجودی برای شناسه <?php echo "'$user'";?></h2>
										</header>
										<h3><?php echo "$name عزیز
$trans_id
										";?></h3>
										<p>برای افزایش موجودی حساب خود کافیست از دکمه زیر استفاده کنید تا به صحفه پرداخت مطمئن منتقل شوید و پس از خرید موجودی به 
									صورت خودکار به حساب شما افزوده خواهد شد</p>
								
										<ul class="actions">
											<li><a href="<?php echo "$payy";?>" class="button">خرید <?php echo $coin;?> | <?php echo $amount;?> تومان</a></li>
											<li><a href="<?php echo "https://t.me/$usernamebot";?>" class="button">ورود به ربات</a></li>
										</ul>
									</div>
								</div>
							</section>
					</div>
				<!-- Footer -->
					<footer id="footer">
						<p class="copyright">&copy; کلیه حقوق سایت برای ربات خرید شماره مجازی محفوظ است</a>.</p>
					</footer>
			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>
	</body>
</html>