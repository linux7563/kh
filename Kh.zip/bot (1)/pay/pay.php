<?php
include("../config.php");
$MerchantID = '724f776b-500b-4559-9b2c';
$Amount = $_GET['amount']; 
$userpp = $_GET['user'];
$ramz = $_GET['r'];
$userget = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$userpp' LIMIT 1"));
$Description = "$userpp";
$Email = ''; //جیمیل
$Mobile = ' '; /// شماره موبایل
$CallbackURL = $_GET['callback'];
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']); /// ادرس درگاه

$result = $client->PaymentRequest(
[
'MerchantID' => $MerchantID,
'Amount' => $Amount,
'Description' => $Description,
'Email' => $Email,
'Mobile' => $Mobile,
'CallbackURL' => $CallbackURL,
]
);
if ($result->Status == 100) {
    
    if ($ramz == $userget["getfile"]) {
         $connect->query("UPDATE user SET getfile = '' WHERE id = '$userpp' LIMIT 1");
Header('Location: https://www.zarinpal.com/pg/StartPay/'.$result->Authority);/// ادرس درگاه

}

else{
    echo "خطا در پرداخت! \n  لینک پرداخت باطل شده است لطفا دوباره اقدام به ساخت لینک جدید پرداخت نمایید.";
}

} else {
echo'ERR: '.$result->Status;
}
?>