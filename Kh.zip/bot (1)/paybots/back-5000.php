<?php
include("../bot.php");
$MerchantID = '724f776b-500b-4559-9b2c';
$Amount = 5000;
$Authority = $_GET['Authority'];
$user = $_GET['user'];
if ($_GET['Status'] == 'OK'){
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification(
[
'MerchantID' => $MerchantID,
'Authority' => $Authority,
'Amount' => $Amount,
]
);

if ($result->Status == 100){
echo 'پرداخت با موفقیت انجام شد و حساب شما شارژ شد ✅';
$juserr = json_decode(file_get_contents("../data/$user.json"),true);

 $stoockk = $juserr["stock"];
 
             
$coinplus = $stoockk + $Amount;
$coin = $stoockk ;
jijibot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"#پرداخت موفق ✅
	
💰 مقدار خرید : $Amount تومان
📥 موجودی جدید کیف پول شما : $coinplus تومان
🎈 موجودی قبلی : $coin تومان",
            ]);
jijibot('sendmessage',[
	'chat_id'=>$admin[0],
	'text'=>"#پرداخت موفق ✅
	
💰 مقدار خرید : $Amount تومان
📥 موجودی جدید کاربر : $coinplus تومان
👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
            jijibot('sendmessage',[
	'chat_id'=>"@$channelbc",
	'text'=>"#پرداخت موفق ✅
	
💰 مقدار خرید : $Amount تومان
📥 موجودی جدید کاربر : $coinplus تومان
👤 کاربر : [$user](tg://user?id=$user)

توسط ربات : @$usernamebot
",
'parse_mode'=>'Markdown',
            ]);
            
 $juserr = json_decode(file_get_contents("../data/$user.json"),true);
$juserr["stock"]="$coinplus";
$juserr = json_encode($juserr,true);
file_put_contents("../data/$user.json",$juserr);

} else {
echo 'پرداخت شما قبلا ثبت شده است';

}
} else {
echo 'پرداخت انجام نشد';
}
?>