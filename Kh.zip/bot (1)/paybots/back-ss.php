<?php
include("../bot.php");
$user = $_GET['user'];
$juserr = json_decode(file_get_contents("../data/$user.json"),true);
$pp = $juserr["price"];
$MerchantID = '[*MAR*]';
$Amount = $pp;
$Authority = $_GET['Authority'];
if ($_GET['Status'] == 'OK'){
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification(
[
'MerchantID' => $MerchantID,
'Authority' => $Authority,
'Amount' => $Amount,
]
);

if ($result->Status == 100){
echo 'پرداخت با موفقیت انجام شد ✅';
$juserr = json_decode(file_get_contents("../data/$user.json"),true);
$stoockk = $juserr["stock"];
 
         
         jijibot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"#پرداخت موفق ✅
	
💰 مقدار خرید : $pp تومان",
            ]);           
            
jijibot('sendmessage',[
	'chat_id'=>$admin[0],
	'text'=>"#پرداخت آنلاین موفق ✅
	
💰 مقدار خرید : $pp تومان

👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
  jijibot('sendmessage',[
	'chat_id'=>"@$channelbc",
	'text'=>"#پرداخت آنلاین موفق ✅
	
💰 مقدار خرید : $Amount تومان

👤 کاربر : [$user](tg://user?id=$user)

توسط ربات : @$usernamebot
",
'parse_mode'=>'Markdown',
            ]);   
            
             $namecontry = $juserr["namecontry"];
          $countryy = str_replace(["🇷🇺 روسیه","🇺🇦 اکراین","🇰🇿 قزاقستان","🇮🇷 ایران","🇨🇳 چین","🇵🇭 فیلیپین","🇲🇲 میانمار","🇮🇩 اندونزی","🇲🇾 مالزی","🇰🇪 کنیا","🇹🇿 اسرائیل","🇻🇳 ویتنام","🇬🇧 انگلستان","🇱🇻 لتونی","🇷🇴 رومانی","🇪🇪 استونی","🇺🇸 آمریکا","🇰🇬 قرقیزستان","🇫🇷 فرانسه","🇵🇸 انگولا","🇰🇭 کامبوج","🇲🇴 ماکائو","🇭🇰 هنگ کنگ","🇧🇷 برزیل","🇵🇱 لهستان","🇵🇾 پاراگوئه","🇳🇱 هلند","🇱🇻 لیتوانی","🇲🇬 ماداگاسکار","🇨🇩 کنگو","🇳🇬 نیجریه","🇿🇦 آفریقا","🇵🇦 قبرس","🇪🇬 مصر","🇮🇳 هند","🇮🇪 ایرلند","🇨🇮 ساحل عاج","🇷🇸 صربستان","🇱🇦 لائوس","🇲🇦 مراکش","🇾🇪 یمن","🇬🇭 غنا","🇨🇦 کانادا","🇦🇷 آرژانتین","🇮🇶 عراق","🇩🇪 آلمان","🇨🇲 کامرون","🇹🇷 ترکیه","🇳🇿 نیوزیلند","🇦🇹 اتریش","🇨🇴 کلمبیا","🇻🇪 ونزوئلا","🇭🇹 هائیتی","🇺🇸 پاپوا","🇲🇩 مولداوی","🇲🇿 موزامبیک","🇬🇲 گامبیا","🇦🇫 اففانستان","🇺🇬 اوگاندا","🇦🇺 نپال","🇸🇦 عربستان","🇲🇽 مکزیک","🇪🇸 اسپانیا","🇩🇿 الجزائر","🇸🇮 اسلوونی","🇭🇷 کرواسی","🇧🇾 بلاروس","🇫🇮 بلژیک","🇸🇪 سوئد","🇬🇪 بلغارستان","🇪🇹 اتیوپی","🇿🇲 مجارستان","🇵🇰 پاکستان","🇹🇭 تایلند","🇹🇼 تایوان","🇵🇪 پرو","🇵🇬 تونس","🇹🇩 چاد","🇲🇱 مالی","🇧🇩 بنگلادش","🇬🇳 گینه","🇱🇰 سری‌لانکا","🇺🇿 ازبکستان","🇸🇳 سنگال"], ["0","1","2","57","3","4","5","6","7","8","13","10","16","44","32","34","12","11","78","76","24","20","14","73","15","87","48","44","17","18","19","31","77","21","22","23","27","29","25","37","30","38","36","39","47","43","41","62","67","50","33","70","26","79","85","80","28","74","75","81","53","54","56","58","59","45","51","82","46","83","71","84","66","52","55","65","89","42","69","60","68","64","40","61"], $namecontry);
        $userservic = $juserr["service"];
         $userservicop = $juserr["panel"];
      
               $userservic = $juserr["service"];
             $get = file_get_contents("https://sms-activate.ru/stubs/handler_api.php?api_key=$api_key&action=getNumber&service=$userservic&country=$countryy");
        $alll = explode(":", $get);
             $ooknumber = "$alll[0]";
             $idnumber = "$alll[1]";
             $numberfon = "$alll[2]";
             
             
         $strservic = str_replace(["tg", "ig", "wa", "go", "vi", "wb", "fb" , "tw" , "mb", "im", "tn", "me", "vk", "mm", "am" , "ot" ], ["💎 تلگرام", "📸 اینستاگرام", "📞 واتساپ", "🔍 گوگل", "💡 وایبر", "💬 ویچت", "📪 فیسبوک", "🐦 توییتر", "📨 یاهو","💭 ایمو", "♨️ لینک دین", "📬 ویکی", "📗 لاین", "💻 ماکروسافت", "🛒 آمازون", "🌐 دیگر سرویس ها"], $userservice);
        if ($ooknumber == "ACCESS_NUMBER")
        {
              
           jijibot('sendmessage', [
            'chat_id' => $user,
                'text' => "
 ✅	شماره کشور مورد نظر با موفقیت ساخته شد 		
📞 شماره مجازی شما :
🅿️ +$numberfon

پیش شماره کشور $namecontry : +$numberfonpish
 شماره را همراه با پیش شماره در سرویس $strservic وارد کنید و پس از 45 ثانیه روی دریافت کد ضربه بزنید !

.
",
             
                   'reply_markup' => json_encode([
                'keyboard' => [
                        [
                        ['text' => "❌ لغو شماره"], ['text' => "💬 دریافت کد"]
                        ],
                         [
                             ['text' => "⛔️ اعلام مسدودی شماره"],
                        ]
                    ],
                    'resize_keyboard' => true
                ])
            ]);
            
            $juserr = json_decode(file_get_contents("../data/$user.json"),true); 
$juserr["stock"]="$plusstock";
$juserr["country"]="+$numberfon";
$juserr["numberid"]="$idnumber";
$juserr = json_encode($juserr,true);
file_put_contents("../data/$user.json",$juserr);
            
        } else {
            $plusstock = $pp + $stoockk;
            jijibot('sendmessage',[
	'chat_id'=>$admin[0],
	'text'=>"#پرداخت آنلاین نا_موفق 
	
💰 مقدار خرید : $pp تومان

به کیف پول کاربر برگشت داده شد

👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
             jijibot('sendmessage',[
	'chat_id'=>$admin[1],
	'text'=>"#پرداخت آنلاین نا_موفق 
	
💰 مقدار خرید : $pp تومان

به کیف پول کاربر برگشت داده شد

👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
            jijibot('sendmessage', [
                'chat_id' => $user,
                'text' => "⚠️ کشور مورد نطر در حال حاظر موجود نمیباشد !
			
🌟 لطفا کشور دیگری را انتخاب کنید یا ساعاتی دیگر مجدد امتحان کنید

مبلغ $pp تومان به کیف پول شما افزوده شد
",
'reply_markup' => json_encode([
                'keyboard' => [
                [
                    ['text' => "📲 خرید شماره مجازی"]
                ],
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "👤 اطلاعات حساب"]
                ],
                [
                     ['text' => "👥 زیرمجموعه گیری"]
                    
                    ],
                [
                    ['text' => "↗️ انتقال موجودی"], ['text' => "💸 شارژ حساب"], 
                    
                ],
                [
                    ['text' => "💳 درخواست تسویه حساب "]
                    ],
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
                'resize_keyboard' => true
            ])
            ]);
            
              $juserr = json_decode(file_get_contents("../data/$user.json"),true); 
$juserr["stock"]="$plusstock";
$juserr["step"]="none";
$juserr["service"]="";
$juserr["panel"]="";
$juserr["getfile"]="";
$juserr = json_encode($juserr,true);
file_put_contents("../data/$user.json",$juserr);
        }
            
	
 }else {
echo 'پرداخت شما قبلا ثبت شده است';

 }   
} else {
echo 'پرداخت انجام نشد';
}
?>