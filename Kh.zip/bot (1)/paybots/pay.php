<?php

$MerchantID = '724f776b-500b-4559-9b2c';
$Amount = $_GET['amount']; 
$Description = 'شارژ';
$Email = ''; //جیمیل
$Mobile = ' '; /// شماره موبایل
$CallbackURL = $_GET['callback'];

$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']); /// ادرس درگاه

$result = $client->PaymentRequest(
[
'MerchantID' => $MerchantID,
'Amount' => $Amount,
'Description' => $Description,
'Email' => $Email,
'Mobile' => $Mobile,
'CallbackURL' => $CallbackURL,
]
);
if ($result->Status == 100) {
Header('Location: https://www.zarinpal.com/pg/StartPay/'.$result->Authority);/// ادرس درگاه
} else {
echo'ERR: '.$result->Status;
}
?>