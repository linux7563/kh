<?php
include("../bottpodkrtirtoy.php");
include "../../../config.php";

$user = $_GET['user'];
$userget = json_decode(file_get_contents("../data/$user.json"),true);
$pp = $userget["price"];
$MerchantID = '[*MAR*]';
$Amount = $userget["price"];
$Authority = $_GET['Authority'];
if ($_GET['Status'] == 'OK'){
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification(
[
'MerchantID' => $MerchantID,
'Authority' => $Authority,
'Amount' => $Amount,
]
);

if ($result->Status == 100){
echo 'پرداخت با موفقیت انجام شد ✅';
$userget = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));

            
              $dat_nowt = "$dat_yer/$dat_mahn/$dat_day" ;
          $time_nowt = "$dat_h:$dat_min";
           
            
    $payw = "amunt: $pp => user: $user => ($dat_nowt)($time_nowt) => bot: @$usernamebot \n[*new*]";
            $source55 = file_get_contents("../../../data/listpayy.txt");
     $source55 = str_replace("[*new*]",$payw,$source55);
     file_put_contents("../../../data/listpayy.txt",$source55); 
            $Sdsd = $pp / 2 ;
jijibot('sendmessage',[
	'chat_id'=>$admin[0],
	'text'=>"#پرداخت آنلاین موفق ✅
	
💰 مقدار خرید : $pp تومان

مبلغ $Sdsd تومان به صندوق شما اضافه شد.

بابت  ساخت ربات شماره مجازی طلایی

👤 کاربر : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
$adminsql = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE id = '$admin[0]' LIMIT 1"));
 $plussharglev2 = $adminsql["sharg"] + $Sdsd ;
             $connect->query("UPDATE admin SET sharg = '$plussharglev2'  WHERE id = '$admin[0]' LIMIT 1");
             
             jijibot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"

✅ پرداخت به مبلغ $pp موفق .


💢 برای ساخت ربات شماره مجازی طلایی توکن ربات خود را که در بوت فادر ساخته اید ارسال نمایید 
مانند نمونه زیر:

900371469:AAFo1LEF5Yjy8T5ZARmgYM3RqZ74-Jz7Tu9
",
            ]);
       
      
   
        
    $juserr = json_decode(file_get_contents("../data/$user.json"),true);	
$juserr["step"]="sendtokent";
$juserr = json_encode($juserr,true);
file_put_contents("../data/$user.json",$juserr);

	

	
 }else {
echo 'پرداخت شما قبلا ثبت شده است';

 }   
} else {
echo 'پرداخت انجام نشد';
}
?>