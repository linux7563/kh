
<?php
include("../bottpodkrtirtoy.php");
$user = $_GET['user'];
$juserr = json_decode(file_get_contents("../data/$user.json"),true);
$pp = $juserr["price"];
$MerchantID = '[*MAR*]';
$Amount = $pp;
$Authority = $_GET['Authority'];

if ($_GET['Status'] == 'OK'){
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification(
[
'MerchantID' => $MerchantID,
'Authority' => $Authority,
'Amount' => $Amount,
]
);

if ($result->Status == 100){
echo 'پرداخت با موفقیت انجام شد ✅';
$juserr = json_decode(file_get_contents("../data/$user.json"),true);
$stoockk = $juserr["stock"];
 
 $plusstock = $pp + $stoockk;
         
         jijibot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"#پرداخت موفق ✅
	
💰 مقدار خرید : $pp تومان

موجودی کیف پول شما : $plusstock تومان
",
            ]);           
            

  
            
          
       
              
          $dat_nowt = "$dat_yer/$dat_mahn/$dat_day" ;
          $time_nowt = "$dat_h:$dat_min";
           
            
    $payw = "amunt: $pp => user: $user => ($dat_nowt)($time_nowt) => bot: @$usernamebot \n[*new*]";
            $source55 = file_get_contents("../../../data/listpayy.txt");
     $source55 = str_replace("[*new*]",$payw,$source55);
     file_put_contents("../../../data/listpayy.txt",$source55); 
    

            
          
              $juserr = json_decode(file_get_contents("../data/$user.json"),true); 
$juserr["stock"]="$plusstock";
$juserr["step"]="none";
$juserr = json_encode($juserr,true);
file_put_contents("../data/$user.json",$juserr);
       
            
	
 }else {
echo 'پرداخت شما قبلا ثبت شده است';

 }   
} else {
echo 'پرداخت انجام نشد';
}
?>

