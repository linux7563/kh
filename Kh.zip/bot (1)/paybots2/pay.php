<?php
$Amount0 = $_GET['amount']; 
  $alll = explode(".", $Amount0);
             $cros000 = $alll[0];
             $cod000 = $alll[1];
              $cod00025 = $alll[2];
               $cod000250 = $alll[3];

  if( $cod000250 == "1"){ $backlink = "https://midasbuy.cam/bots/numberino/bots/$cod000/pay/back-ss.php?user=$cod00025" ;}
   if( $cod000250 == "2"){ $backlink = "https://midasbuy.cam/bots/numberino/bots/$cod000/pay/back-up.php?user=$cod00025" ;}
    if( $cod000250 == "3"){ $backlink = "https://midasbuy.cam/bots/numberino/bots/$cod000/pay/back-bottala.php?user=$cod00025" ;}
$MerchantID = '[*MAR*]';
$Amount = $cros000;
$Description = 'شارژ';
$Email = ''; //جیمیل
$Mobile = ' '; /// شماره موبایل
$CallbackURL = "$backlink";

$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']); /// ادرس درگاه

$result = $client->PaymentRequest(
[
'MerchantID' => $MerchantID,
'Amount' => $Amount,
'Description' => $Description,
'Email' => $Email,
'Mobile' => $Mobile,
'CallbackURL' => $CallbackURL,
]
);
if ($result->Status == 100) {
Header('Location: https://www.zarinpal.com/pg/StartPay/'.$result->Authority);/// ادرس درگاه
} else {
echo'ERR: '.$result->Status;
}
?>