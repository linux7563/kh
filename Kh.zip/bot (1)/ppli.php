<?php
error_reporting(0);
include "bottpodkrtirtoy.php";
 set_time_limit(1200);
// ==============================================

$operator = array("019","activ","altel","beeline","claro","ee","globe","itelecom","kcell","kyivstar","lycamobile","matrix","megafon","movistar","mts","orange","pildyk","play","range1","redbull","redbullmobile","rostelecom","smart","sun","tele2","three","tigo","tmobile","tnt","virginmobile","virtual11","virtual12","virtual15","virtual16","virtual17","virtual18","virtual19","virtual2","virtual20","virtual21","virtual22","virtual23","virtual24","virtual4","virtual5","virtual6","virtual7","virtual8","virtual9","vodafone","yota","zz");

$servisss = array("1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","alibaba","aliexpress","alipay","amasia","amazon","aol","avito","azino","b4ucabs","bigcash","bigolive","bitclout","bittube","blablacar","blizzard","blockchain","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","discord","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","facebook","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","google","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","imo","ininal","instagram","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","line","linkedin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","microsoft","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","other","ozon","pairs","papara","paycell","paymaya","paypal","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pubg","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","snapchat","steam","swvl","taksheel","tango","tantan","taobao","telegram","tencentqq","tiktok","tinder","tosla","totalcoin","touchance","trendyol","truecaller","twitter","uber","uploaded","vernyi","viber","vkontakte","voopee","wechat","weibo","weku","whatsapp","winston","wish","yahoo","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","digikala","divar","hamrahaval","irancell","zomato");

$countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
$zarib = $jseting["set"]["robelpric"];

   $api_key = "000";
     $get = json_decode(file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getPrices"),true);

    foreach ($servisss as $key1 => $vvvs) {
        
     
        
 foreach ($countryss as $key2 => $vvv) {

   
   
    foreach ($operator as $key3 => $vvvop) {
        
        
       
       
            $sssw = $get["$vvv"]["$vvvs"]["$vvvop"]["cost"];
         $ssswm = $get["$vvv"]["$vvvs"]["$vvvop"]["count"];
       
        if( $sssw !="" and  $sssw != "0" and  $ssswm !="" and  $ssswm != "0"){
        
       
$result[]=$vvvop;
$result2[]=$sssw;
$result3[]=$sssw;
$result4[]=$ssswm;

        }
        
      
        
       if ($vvvop == 'zz') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
  
     
     
  $gets2 = array_search($result2[0],$result3);
$stat2 = $result[$gets2];

$stat20 = $result4[$gets2];



 

 $sssw1 = $get["$vvv"]["$vvvs"]["$stat2"]["cost"];
         $ssswm1 = $get["$vvv"]["$vvvs"]["$stat2"]["count"];
         
          if( $sssw1 !="" and  $sssw1 != "0" and  $ssswm1 !="" and  $ssswm1 != "0"){ 
  
  $jsetting = json_decode(file_get_contents("data/prics2/$vvv.json"),true);	
$jsetting["$vvvs"]["count"]="✅ $ssswm1  عدد";
$jsetting["$vvvs"]["amount"]="$sssw1";
$jsetting = json_encode($jsetting,true);
file_put_contents("data/prics2/$vvv.json",$jsetting);
}

   if(   $ssswm1 =="" or  $ssswm1 == "0"){
             
             $jsetting = json_decode(file_get_contents("data/prics2/$vvv.json"),true);	
$jsetting["$vvvs"]["count"]="❌";
$jsetting["$vvvs"]["operator"]="$stat2";
$jsetting = json_encode($jsetting,true);
file_put_contents("data/prics2/$vvv.json",$jsetting);
             
         }
         if( $sssw1 =="" or  $sssw1 == "0"){
             
              $jsetting = json_decode(file_get_contents("data/prics2/$vvv.json"),true);	
$jsetting["$vvvs"]["count"]="❌";
$jsetting["$vvvs"]["amount"]="❗️";
$jsetting = json_encode($jsetting,true);
file_put_contents("data/prics2/$vvv.json",$jsetting); 
         }

   unset($result2[0]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);   



if ($vvv == 'zimbabwe') {
        break;
    }
}


if ($vvvs == 'zomato') {
        break;
    }
}
//==============================================



//==============================================
$timee = " $dat_h : $dat_min " ;
$dattt = "$dat_yer/$dat_mahn/$dat_day" ;
$jsetting = json_decode(file_get_contents("data/seting.json"),true);
$jsetting["set"]["up"]["time"]="$timee";
$jsetting["set"]["up"]["data"]="$dattt";
$jsetting = json_encode($jsetting,true);
file_put_contents("data/seting.json",$jsetting);
//===============================================
?>