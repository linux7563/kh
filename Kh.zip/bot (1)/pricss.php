<?php

include "bottpodkrtirtoy.php";

// ==============================================

$servisss = array("vk", "wa", "vi", "tg", "wb", "go", "fb" , "tw" , "ig", "mm", "me", "mb", "tn", "im", "am" , "ot");
$countryss = array("0","1","2","3","4","5","6","7","8","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58","59","60","61","62","63","64","65","66","67","68","69","70","71","73","74","75","76","77","78","79","80","81","82","83","84","85","86","87","88","89","90","91","92","93","94","95","96","97","98","99");
$zarib = $jseting["set"]["robelpric"];

    
 foreach ($countryss as $key => $vvv) {
$api_key="f948A05Af7cAeAb3e2Ae6d87c18c699f";
   $ross = json_decode(file_get_contents("https://sms-activate.ru/stubs/handler_api.php?api_key=$api_key&action=getPrices&country=$vvv"),true);
   
     $vk = $ross["$vvv"]["vk"]["count"];
     $wa = $ross["$vvv"]["wa"]["count"];
     $vi = $ross["$vvv"]["vi"]["count"];
     $tg = $ross["$vvv"]["tg"]["count"];
     $wb = $ross["$vvv"]["wb"]["count"];
     $go = $ross["$vvv"]["go"]["count"];
     $fb = $ross["$vvv"]["fb"]["count"];
     $tw = $ross["$vvv"]["tw"]["count"];
     $ig = $ross["$vvv"]["ig"]["count"];
     $mm = $ross["$vvv"]["mm"]["count"];
     $me = $ross["$vvv"]["me"]["count"];
     $mb = $ross["$vvv"]["mb"]["count"];
     $tn = $ross["$vvv"]["tn"]["count"];
     $im = $ross["$vvv"]["im"]["count"];
     $am = $ross["$vvv"]["am"]["count"];
     $ot = $ross["$vvv"]["ot"]["count"];
       
     $vkt = ceil($ross["$vvv"]["vk"]["cost"]);
     $wat = ceil($ross["$vvv"]["wa"]["cost"]);
     $vit = ceil($ross["$vvv"]["vi"]["cost"]);
     $tgt = ceil($ross["$vvv"]["tg"]["cost"]);
     $wbt = ceil($ross["$vvv"]["wb"]["cost"]);
     $got = ceil($ross["$vvv"]["go"]["cost"]);
     $fbt = ceil($ross["$vvv"]["fb"]["cost"]);
     $twt = ceil($ross["$vvv"]["tw"]["cost"]);
     $igt = ceil($ross["$vvv"]["ig"]["cost"]);
     $mmt = ceil($ross["$vvv"]["mm"]["cost"]);
     $met = ceil($ross["$vvv"]["me"]["cost"]);
     $mbt = ceil($ross["$vvv"]["mb"]["cost"]);
     $tnt = ceil($ross["$vvv"]["tn"]["cost"]);
     $imt = ceil($ross["$vvv"]["im"]["cost"]);
     $amt = ceil($ross["$vvv"]["am"]["cost"]);
     $ott = ceil($ross["$vvv"]["ot"]["cost"]);
    
$jsetting = json_decode(file_get_contents("data/prics/$vvv.json"),true);	

$jsetting["vk"]["count"]="✅ $vk عدد";
$jsetting["wa"]["count"]="✅ $wa عدد";
$jsetting["vi"]["count"]="✅ $vi عدد";
$jsetting["tg"]["count"]="✅ $tg عدد";
$jsetting["wb"]["count"]="✅ $wb عدد";
$jsetting["go"]["count"]="✅ $go عدد";
$jsetting["fb"]["count"]="✅ $fb عدد";
$jsetting["tw"]["count"]="✅ $tw عدد";
$jsetting["ig"]["count"]="✅ $ig عدد";
$jsetting["mm"]["count"]="✅ $mm عدد";
$jsetting["me"]["count"]="✅ $me عدد";
$jsetting["mb"]["count"]="✅ $mb عدد";
$jsetting["tn"]["count"]="✅ $tn عدد";
$jsetting["im"]["count"]="✅ $im عدد";
$jsetting["am"]["count"]="✅ $am عدد";
$jsetting["ot"]["count"]="✅ $ot عدد";

$jsetting["vk"]["amount"]="$vkt";
$jsetting["wa"]["amount"]="$wat";
$jsetting["vi"]["amount"]="$vit";
$jsetting["tg"]["amount"]="$tgt";
$jsetting["wb"]["amount"]="$wbt";
$jsetting["go"]["amount"]="$got";
$jsetting["fb"]["amount"]="$fbt";
$jsetting["tw"]["amount"]="$twt";
$jsetting["ig"]["amount"]="$igt";
$jsetting["mm"]["amount"]="$mmt";
$jsetting["me"]["amount"]="$met";
$jsetting["mb"]["amount"]="$mbt";
$jsetting["tn"]["amount"]="$tnt";
$jsetting["im"]["amount"]="$imt";
$jsetting["am"]["amount"]="$amt";
$jsetting["ot"]["amount"]="$ott";
$jsetting = json_encode($jsetting,true);
file_put_contents("data/prics/$vvv.json",$jsetting);


if ($key == '98') {
        break;
    }
}
//==============================================

foreach ($countryss as $key => $vvv) {

   
     foreach ($servisss as $key => $serrr) {
         
    $jsettting = json_decode(file_get_contents("data/prics/$vvv.json"),true);

        if( $jsettting["$serrr"]["count"] == "✅  عدد" or $jsettting["$serrr"]["count"] == "✅ 0 عدد"){

            $jsetting = json_decode(file_get_contents("data/prics/$vvv.json"),true);	

$jsetting["$serrr"]["count"]="❌";

$jsetting = json_encode($jsetting,true);
file_put_contents("data/prics/$vvv.json",$jsetting);}

        if( $jsettting["$serrr"]["amount"] == "" or $jsettting["$serrr"]["amount"] == "0"){
   
            $jsetting = json_decode(file_get_contents("data/prics/$vvv.json"),true);	
$jsetting["$serrr"]["amount"]="---";


$jsetting = json_encode($jsetting,true);
file_put_contents("data/prics/$vvv.json",$jsetting);}
        
          
if ($key == '16') {
        break;
    }
         
     }
if ($key == '98') {
        break;
    }
}

//==============================================
$timee = " $dat_h : $dat_min " ;
$dattt = "$dat_yer/$dat_mahn/$dat_day" ;
$jsetting = json_decode(file_get_contents("data/seting.json"),true);
$jsetting["set"]["up"]["time"]="$timee";
$jsetting["set"]["up"]["data"]="$dattt";
$jsetting = json_encode($jsetting,true);
file_put_contents("data/seting.json",$jsetting);
//===============================================
?>