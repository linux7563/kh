<?php

 if ($textmassage == "✔️ خدمات سیمکارت اعتباری") {
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 به قسمت خدمات سیمکارت های اعتباری خوش آمدید.

🌐 سرویس مورد نظر را انتخاب نمایید :

.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🌐 خرید بسته اینترنت"],['text' => "📲 خرید شارژ"]
                    ],
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      
    }
    
if ($textmassage == "🌐 خرید بسته اینترنت") {
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 این بخش به زودی اضافه میشود ...

.
            " ,
           
        ]);
      
    }
 if ($textmassage == "📲 خرید شارژ") {
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 به قسمت خرید شارژ برای سیمکارت های اعتباری خوش آمدید.

🌐 جهت خرید شارژ ابتدا اوپراطور سیمکارت مورد نظر برای شارژ رو انتخاب کنید:

.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🕹 ایرانسل"],['text' => "🕹 همراه اول"]
                    ],
                    [
                    ['text' => "🔙 برگشت"], ['text' => "🕹 رایتل"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      
    }
elseif (in_array($textmassage, array("🕹 ایرانسل","🕹 همراه اول","🕹 رایتل"))) {
       
        $str = str_replace(["🕹 ایرانسل","🕹 همراه اول","🕹 رایتل"], ["MTN", "MCI", "RTL"], $textmassage);
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 مبلغ شارژ را انتخاب کنید :

.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "💵 2,000 تومان"],['text' => "💵 1,000 تومان"]
                    ],
                    [
                    ['text' => "💵 10,000 تومان"], ['text' => "💵 5,000 تومان"]
                    ],
                    [
                    ['text' => "🔙 برگشت"], ['text' => "💵 20,000 تومان"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      $connect->query("UPDATE user SET panel = '$str' WHERE id = '$from_id' LIMIT 1");
    }
elseif (in_array($textmassage, array("💵 1,000 تومان","💵 2,000 تومان","💵 5,000 تومان","💵 10,000 تومان","💵 20,000 تومان"))) {
       
        $str = str_replace(["💵 1,000 تومان","💵 2,000 تومان","💵 5,000 تومان","💵 10,000 تومان","💵 20,000 تومان"], ["1000", "2000", "5000", "10000", "20000"], $textmassage);
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 روش شارژ را انتخاب کنید :
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "💳 دریافت کد شارژ"],['text' => "📲 مستقیم"]
                    ],
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      $connect->query("UPDATE user SET price = '$str' WHERE id = '$from_id' LIMIT 1");
    }    
elseif (in_array($textmassage, array("📲 مستقیم","💳 دریافت کد شارژ"))) {
       
        $str = str_replace(["📲 مستقیم", "💳 دریافت کد شارژ"], ["topup", "pin"], $textmassage);
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 نوع شارژ را انتخاب کنید :

.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🚀 شگفت انگیز"],['text' => "🚁 معمولی"]
                    ],
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      $connect->query("UPDATE user SET service = '$str' WHERE id = '$from_id' LIMIT 1");
    }    
elseif (in_array($textmassage, array("🚁 معمولی","🚀 شگفت انگیز"))) {
       
        $str = str_replace(["🚁 معمولی","🚀 شگفت انگیز"], ["normal", "amazing"], $textmassage);
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 شماره سیمکارت مورد نظر برای شارژ رو ارسال کنید :

⚠️ در وارد کردن شماره دقت لازمه رو داشته باشید . دیگر قابل ویرایش نمیباشد.

برای مثال :
09102223355
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      $connect->query("UPDATE user SET namecontry = '$str' , step = 'shargnumber' WHERE id = '$from_id' LIMIT 1");
    }    
elseif ( $user["step"] == "shargnumber") {
      
      $ab1 = $user["panel"]; 
      $ab12 = $user["service"]; 
      $ab13 = $user["namecontry"]; 
      $ab14 = $user["price"]; 
         $ab144 = (($user["price"] / 100) * 9) + $user["price"]; 
       $str1 = str_replace(["MTN", "MCI", "RTL"], [" ایرانسل"," همراه اول"," رایتل"], $ab1);
       

       $str3 = str_replace(["topup", "pin"], [" مستقیم", " دریافت کد شارژ"], $ab12);

        $str4 = str_replace(["normal", "amazing"], [" معمولی"," شگفت انگیز"], $ab13);
        
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 شما قصد خرید شارژ با مشخصات زیر را دارید :

〰️〰️〰️〰️〰️〰️〰️〰〰️〰
✳️ اوپراطور : $str1
✳️ روش شارژ : $str3
✳️ نوع شارژ : $str4
✳️ مبلغ شارژ :  $ab14 تومان
✳️ شماره سیمکارت : $textmassage 

💵 مبلغ قابل پرداخت : $ab144 تومان
(مبلغ شارژ + 9% مالیات)
〰️〰️〰️〰️〰〰️〰️〰️〰️〰
آیا اطلاعات فوق را تایید و مایل به ادامه دادن میباشید؟
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "خیر منصرف شدم 👎"], ['text' => "بله میخوام  👍"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      $connect->query("UPDATE user SET country = '$textmassage' , step = 'none' WHERE id = '$from_id' LIMIT 1");
    }   

elseif ($textmassage == "بله میخوام  👍") {
    $stock = $user["stock"];
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
لطفا نوع پرداخت رو انتخاب کنید :

💳 پرداخت آنلاین : متصل شدن به درگاه پرداخت ، پرداخت وجه به مقدار قیمت شارژ.
💰 پرداخت از کیف پول : پرداخت وجه از کیف پول شما 

موجودی کیف پول شما : $stock تومان
",
             
                   'reply_markup' => json_encode([
                'keyboard' => [
                        [
                            ['text' => "💰  پرداخت از کیف پول"],
                            ['text' => "💳  پرداخت آنلاین"]
                        ],
                         [
                            ['text' => "🔙 برگشت"]
                        ]
                    ],
                    'resize_keyboard' => true
                ])
            ]);
    
}
elseif ($textmassage == "💳  پرداخت آنلاین") {
     if ($blaklist["id"] != true){
         if ($activesell == "1"){
    $stock = $user["stock"];
     $pp = (($user["price"] / 100) * 9) + $user["price"];
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
✅ لینک درگاه پرداخت شما ساخته شد.

مبلغ : $pp تومان
 
از طریق دکمه زیر پرداخت کنید 👇👇
",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "💰 $pp تومان", 'url' => "$web/pay/pay.php?amount=$pp&callback=$web/pay/back-sharg.php?user=$from_id"]
                        ],
                         [
                            ['text' => "❌ انصراف", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
                
            ]);
         }else {
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️ فروش به صورت موقت توسط مدیر غیر فعال شده است.
لطفا بعدا دوباره امتحان کنید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
         }
    else { 
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📛 متاسفانه شما از استفاده از ربات محروم شده اید.

در صورتی که اشتباهی رخ داده با پشتیبانی در ارتباط باشید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
    
}
elseif ($textmassage == "💰  پرداخت از کیف پول") { 
    
     $operator = $user["panel"]; 
      $ab12 = $user["service"]; 
      $charge_type = $user["namecontry"]; 
      $ab14 = $user["price"];
       $mobile = $user["country"];
         $ab144 = (($user["price"] / 100) * 9) + $user["price"]; 
       $str1 = str_replace(["MTN", "MCI", "RTL"], [" ایرانسل"," همراه اول"," رایتل"], $operator);
       

       $str3 = str_replace(["topup", "pin"], [" مستقیم", " دریافت کد شارژ"], $ab12);

        $str4 = str_replace(["normal", "amazing"], [" معمولی"," شگفت انگیز"], $charge_type);
        
 
    
    $stock = $user["stock"];
    $stock2 = $stock - $ab144;
     if ($blaklist["id"] != true){
         if ($activesell == "1" or $from_id == "$admin[0]"){
    if ($stock >= $ab144) {
       
        jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
درحال انجام پروسه...
صبور باشید
",]);
      $timee = time();
      $tattt = "$dat_yer$dat_mahn$dat_day" ;
             $order_id = "$from_id$timee";
		
	 
	
	
     if ($ab12 == "topup"){
		$result =  json_decode(file_get_contents("https://inax.ir/webservice.php?method=topup&username=$usersharg&password=$passsharg&amount=$ab14&mobile=$mobile&operator=$operator&charge_type=$charge_type&order_id=$order_id&company=eee"),true);
     $srsws = $result['msg'];
     $dfdfd= $result['ref_code'];
     $pin= $result['buy_info']['pin'];
     $seryal= $result['buy_info']['serial'];}
     
if ($ab12 == "pin"){
    	$result =  json_decode(file_get_contents("https://inax.ir/webservice.php?method=pin&username=$usersharg&password=$passsharg&amount=$ab14&mobile=$mobile&operator=$operator&charge_type=$charge_type&order_id=$order_id&count=1"),true);
     $srsws = $result['msg'];
     $dfdfd= $result['ref_code'];
     $pin= $result['buy_info'][0]['pin'];
     $seryal= $result['buy_info'][0]['serial'];
     $pinn= $result['buy_info'];
      jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
درحال انجام پروسه...
صبور باشید
$pinn
$srsws
",]);
     
}
     
     if ($result['code']== "1"){
         
         if ($ab12 == "topup"){
				 jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
✅ عملیات خرید شارژ موفق.

📟 کد پیگیری : $dfdfd
",
'reply_markup' => json_encode([
                'keyboard' => [
                [
                    ['text' => "📲 خرید شماره مجازی"]
                ],
                 [
                     ['text' => "📲 خرید شارژ سیمکارت اعتباری"]
                    
                    ],
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "💸 شارژ حساب"]
                ]
                ,
                [
                     ['text' => "🤖 ربات شماره مجازی شما [ربات نمایندگی]"] 
                    ],
                     [
                   ['text' => "👥 زیرمجموعه گیری"]
                    ],
                     [
                    ['text' => "🛍 خرید های من"], ['text' => "👤 اطلاعات حساب"]
                    ],
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
                'resize_keyboard' => true
            ])
            ]);
         }
          if ($ab12 == "pin"){
              
				 jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
✅ عملیات خرید شارژ موفق.

مشخصات شارژ 👇👇➖➖➖➖➖➖

📲 کد شارژ : $pin
💳 سریال شارژ : $seryal
📟 کد پیگیری : $dfdfd
$ddddd
نامبرینو ➖➖➖➖➖➖➖➖➖.
",
'reply_markup' => json_encode([
                'keyboard' => [
                [
                   ['text' => "📲 خرید شارژ سیمکارت"], ['text' => "📲 خرید شماره مجازی"]
                ],
                
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "💸 شارژ حساب"]
                ]
                ,
                [
                     ['text' => "🤖 ربات شماره مجازی شما [ربات نمایندگی]"] 
                    ],
                     [
                   ['text' => "👥 زیرمجموعه گیری"]
                    ],
                     [
                    ['text' => "🛍 خرید های من"], ['text' => "👤 اطلاعات حساب"]
                    ],
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
                'resize_keyboard' => true
            ])
            ]);
              
          }
            $mobilee = mb_substr("$mobile", "0", "8") . "***";
             $usidf = mb_substr("$from_id", "0", "6") . "***";
             jijibot('sendmessage', [
            'chat_id' => "@$channel",
            'text' =>"
✅ یک عدد شارژ سیمکارت اعتباری $str1 خریداری شد.

اطلاعات شارژ خریداری شده👇

〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
✳️ اوپراطور : $str1
✳️ روش شارژ : $str3
✳️ نوع شارژ : $str4
✳️ مبلغ شارژ :  $ab14 تومان

📱 mobile : $mobilee
👤 USER : $usidf
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️

🤖 @$usernamebot
🔊@$channel
.
            " ,
             'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "☎️ ربات خرید شارژ سیمکارت", 'url' => "https://t.me/$usernamebot"],
                    ],
                ]
            ])
            ]);
            $dat_nowt = "$dat_yer/$dat_mahn/$dat_day" ;
          $time_nowt = "$dat_h:$dat_min";
               $payw = "مبلغ : $ab14 تومان | اپراتور : $str1 | روش شارژ : $str3 | تاریخ : $dat_nowt | ساعت : $time_nowt | آیدی خریدار : $from_id | آیدی ربات : @$usernamebot | موبایل : $mobile"."\n[*new*]";
            $source55 = file_get_contents("data/listsharg.txt");
     $source55 = str_replace("[*new*]",$payw,$source55);
     file_put_contents("data/listsharg.txt",$source55);
     
     
      $bb12 = $jseting["set"]["number"]["allsod"] + $ab144 ;
        $jseting = json_decode(file_get_contents("data/seting.json"),true);	
 $jseting["set"]["number"]["allsod"] = "$bb12";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

 $connect->query("UPDATE user SET step ='none',  price = '' , panel = '', service = '', namecontry = '', country = '', stock = '$stock2'  WHERE id = '$from_id' LIMIT 1");
            
		}
		$dddd = $result['code'];
    if ( in_array($dddd, array("-11","-12","-18","-55","-66","-67","-91"))){
				 jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
❌ خطا در خرید .

$srsws
",
'reply_markup' => json_encode([
                'keyboard' => [
                       
                         [
                            ['text' => "🔙 برگشت"]
                        ]
                    ],
                'resize_keyboard' => true
            ])
            ]);
		}  
			
				
				
				
		$dddd = $result['code'];
    if ( in_array($dddd, array("-11","-12","-18","-55","-66","-67","-91"))){
				 jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
❌ خطا در خرید .

$srsws
",
'reply_markup' => json_encode([
                'keyboard' => [
                       
                         [
                            ['text' => "🔙 برگشت"]
                        ]
                    ],
                'resize_keyboard' => true
            ])
            ]);
		}  
     
			
          


    }     
     else {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "💳 موجودی کیف پول شما برای خرید کافی نمیباشد !
			
💎 قیمت شماره مورد نظر : $str تومان
💰 موجودی کیف پول شما : $stock تومان

💳 برای افزایش موجودی کیف پول کافیست از دکمه شارژ حساب استفاده کنید سپس میتوانید نسبت به خرید اقدام کنید
ℹ

💳 پرداخت آنلاین : متصل شدن به درگاه پرداخت ، پرداخت وجه به مقدار قیمت شماره.
",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "💳 پرداخت آنلاین "]
                        ],
                    [
                       ['text' => "🔙 برگشت"], ['text' => "💸 شارژ حساب"] 
                       
                    ],
                   
                ],
                'resize_keyboard' => true
            ])
        ]);
         
       
        }
        
    
             }else {
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️ فروش به صورت موقت توسط مدیر غیر فعال شده است.
لطفا بعدا دوباره امتحان کنید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
}
    else { 
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📛 متاسفانه شما از استفاده از ربات محروم شده اید.

در صورتی که اشتباهی رخ داده با پشتیبانی در ارتباط باشید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
}
?>