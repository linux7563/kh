<?php

 $juseryy = json_decode(file_get_contents("data/setbotten.json"),true);
$sw20 = $juseryy["sw20"];
$sw21 = $juseryy["sw21"];
$sw22 = $juseryy["sw22"];


if($sw20==""){$sw20="🕹 همراه اول";}
if($sw21==""){$sw21="🕹 ایرانسل";}
if($sw22==""){$sw22="🕹 رایتل";}

if(strpos($textmassage,"'") == false or strpos($textmassage,'"') == false or strpos($textmassage,"}") == false or strpos($textmassage,"{") == false or strpos($textmassage,")'") == false or strpos($textmassage,"(") == false or  strpos($textmassage,'$') == false){ 
    
     if($ss1 == "✅ روشن"  or $ss1 == ""  or $from_id  == "$admin[0]" or $fromid  == "$admin[0]"){
         
           if($ss2 == "✅ روشن"  or $ss2 == ""  or $from_id  == "$admin[0]" or $fromid  == "$admin[0]"){
               
     if ($textmassage == "✔️ خدمات سیمکارت اعتباری" or ( $textmassage == "$sw30" and $update->message->text )) {
         
          $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 به قسمت خدمات سیمکارت های اعتباری خوش آمدید.

🌐 سرویس مورد نظر را انتخاب نمایید :

.
            " ,
            'reply_markup' => $keybordsim
        ]);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
    }
    
if ($textmassage == "🌐 خرید بسته اینترنت"  or ( $textmassage == "$sw32" and $update->message->text )) {
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 این بخش به زودی اضافه میشود ...

.
            " ,
           
        ]);
      
    }           
    
 if ($textmassage == "📲 خرید شارژ"or ( $textmassage == "$sw11" and $update->message->text ) ){
       $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 به قسمت خرید شارژ برای سیمکارت های اعتباری خوش آمدید.

🌐 جهت خرید شارژ ابتدا اوپراطور سیمکارت مورد نظر برای شارژ رو انتخاب کنید:

.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "$sw21"],['text' => "$sw20"]
                    ],
                    [
                    ['text' => "🔙 برگشت"], ['text' => "$sw22"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
      
    }
elseif (in_array($textmassage, array("🕹 ایرانسل","🕹 همراه اول","🕹 رایتل"))or (in_array($textmassage, array("$sw20","$sw21","$sw22")) and $update->message->text ) ) {
       
       if(in_array($textmassage, array("🕹 ایرانسل","🕹 همراه اول","🕹 رایتل"))){
        $str = str_replace(["🕹 ایرانسل","🕹 همراه اول","🕹 رایتل"], ["MTN", "MCI", "RTL"], $textmassage);
       }
         if(in_array($textmassage, array("$sw20","$sw21","$sw22"))){
        $str = str_replace(["$sw20","$sw21","$sw22"], ["MCI", "MTN", "RTL"], $textmassage);
       }
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 مبلغ شارژ را انتخاب کنید :

.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "💵 2,000 تومان"],['text' => "💵 1,000 تومان"]
                    ],
                    [
                    ['text' => "💵 10,000 تومان"], ['text' => "💵 5,000 تومان"]
                    ],
                    [
                    ['text' => "🔙 برگشت"], ['text' => "💵 20,000 تومان"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      
       $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["panel"]="$str";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }
elseif (in_array($textmassage, array("💵 1,000 تومان","💵 2,000 تومان","💵 5,000 تومان","💵 10,000 تومان","💵 20,000 تومان"))) {
       
        $str = str_replace(["💵 1,000 تومان","💵 2,000 تومان","💵 5,000 تومان","💵 10,000 تومان","💵 20,000 تومان"], ["1000", "2000", "5000", "10000", "20000"], $textmassage);
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 روش شارژ را انتخاب کنید :
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "💳 دریافت کد شارژ"],['text' => "📲 مستقیم"]
                    ],
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
     
       $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["price"]="$str";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }    
elseif (in_array($textmassage, array("📲 مستقیم","💳 دریافت کد شارژ"))) {
       
        $str = str_replace(["📲 مستقیم", "💳 دریافت کد شارژ"], ["topup", "pin"], $textmassage);
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 نوع شارژ را انتخاب کنید :

.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🚀 شگفت انگیز"],['text' => "🚁 معمولی"]
                    ],
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      
      $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["service"]="$str";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }    
elseif (in_array($textmassage, array("🚁 معمولی","🚀 شگفت انگیز"))) {
       
        $str = str_replace(["🚁 معمولی","🚀 شگفت انگیز"], ["normal", "amazing"], $textmassage);
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 شماره سیمکارت مورد نظر برای شارژ رو ارسال کنید :

⚠️ در وارد کردن شماره دقت لازمه رو داشته باشید . دیگر قابل ویرایش نمیباشد.

برای مثال :
09102223355
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      
       $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["namecontry"]="$str";
$juser["step"]="shargnumber";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }    
elseif ( $juser["step"] == "shargnumber") {
      
      $ab1 = $juser["panel"]; 
      $ab12 = $juser["service"]; 
      $ab13 = $juser["namecontry"]; 
      $ab14 = $juser["price"]; 
         $ab144 = (($juser["price"] / 100) * 9) + $juser["price"]; 
       $str1 = str_replace(["MTN", "MCI", "RTL"], [" ایرانسل"," همراه اول"," رایتل"], $ab1);
       

       $str3 = str_replace(["topup", "pin"], [" مستقیم", " دریافت کد شارژ"], $ab12);

        $str4 = str_replace(["normal", "amazing"], [" معمولی"," شگفت انگیز"], $ab13);
        
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
💢 شما قصد خرید شارژ با مشخصات زیر را دارید :

〰️〰️〰️〰️〰️〰️〰️〰〰️〰
✳️ اوپراطور : $str1
✳️ روش شارژ : $str3
✳️ نوع شارژ : $str4
✳️ مبلغ شارژ :  $ab14 تومان
✳️ شماره سیمکارت : $textmassage 

💵 مبلغ قابل پرداخت : $ab144 تومان
(مبلغ شارژ + 9% مالیات)
〰️〰️〰️〰️〰〰️〰️〰️〰️〰
آیا اطلاعات فوق را تایید و مایل به ادامه دادن میباشید؟
.
            " ,
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "خیر منصرف شدم 👎"], ['text' => "بله  میخوام  👍"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      
      $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser["country"]="$textmassage";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }   


elseif ($textmassage == "بله  میخوام  👍") { 
    
     $operator = $juser["panel"]; 
      $ab12 = $juser["service"]; 
      $charge_type = $juser["namecontry"]; 
      $ab14 = $juser["price"];
       $mobile = $juser["country"];
         $ab144 = (($juser["price"] / 100) * 9) + $juser["price"]; 
       $str1 = str_replace(["MTN", "MCI", "RTL"], [" ایرانسل"," همراه اول"," رایتل"], $operator);
       

       $str3 = str_replace(["topup", "pin"], [" مستقیم", " دریافت کد شارژ"], $ab12);

        $str4 = str_replace(["normal", "amazing"], [" معمولی"," شگفت انگیز"], $charge_type);
        
 
     $ab144pp = (($juser["price"] / 100) * 4) + $juser["price"]; 
    $stock = $juser["stock"];
    $shargp = $adminsql["sharg"];
     if ($shargp >= $ab144pp){
         if ($activesell == "1" ){
    if ($stock >= $ab144) {
       
        jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
درحال انجام پروسه...
صبور باشید
",]);
      $timee = time();
      $tattt = "$dat_yer$dat_mahn$dat_day" ;
             $order_id = "$from_id$timee";
		
	 
	
	
     if ($ab12 == "topup"){
		$result =  json_decode(file_get_contents("https://inax.ir/webservice.php?method=topup&username=$usersharg&password=$passsharg&amount=$ab14&mobile=$mobile&operator=$operator&charge_type=$charge_type&order_id=$order_id&company=eee"),true);
     $srsws = $result['msg'];
     $dfdfd= $result['ref_code'];
     $pin= $result['buy_info']['pin'];
     $seryal= $result['buy_info']['serial'];
         
         
     }
     
if ($ab12 == "pin"){
    	$result =  json_decode(file_get_contents("https://inax.ir/webservice.php?method=pin&username=$usersharg&password=$passsharg&amount=$ab14&mobile=$mobile&operator=$operator&charge_type=$charge_type&order_id=$order_id&count=1"),true);
     $srsws = $result['msg'];
     $dfdfd= $result['ref_code'];
     $pin= $result['buy_info'][0]['pin'];
     $seryal= $result['buy_info'][0]['serial'];
     $pinn= $result['buy_info'];
     
     
}
     
     if ($result['code']== "1"){
         
          
           
           
         
         if ($ab12 == "topup"){
				 jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
✅ عملیات خرید شارژ موفق.

📟 کد پیگیری : $dfdfd
",
'reply_markup' => $keyborduser,
            ]);
         }
          if ($ab12 == "pin"){
              
				 jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
✅ عملیات خرید شارژ موفق.

مشخصات شارژ 👇👇➖➖➖➖➖➖

📲 کد شارژ : $pin
💳 سریال شارژ : $seryal
📟 کد پیگیری : $dfdfd

➖➖➖➖➖➖➖➖➖.
",
'reply_markup' => $keyborduser,
            ]);
              
          }
            $mobilee = mb_substr("$mobile", "0", "8") . "***";
             $usidf = mb_substr("$from_id", "0", "6") . "***";
             jijibot('sendmessage', [
            'chat_id' => "@$channel",
            'text' =>"
✅ یک عدد شارژ سیمکارت اعتباری $str1 خریداری شد.

اطلاعات شارژ خریداری شده👇

〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
✳️ اوپراطور : $str1
✳️ روش شارژ : $str3
✳️ نوع شارژ : $str4
✳️ مبلغ شارژ :  $ab14 تومان

📱 mobile : $mobilee
👤 USER : $usidf
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️

🤖 @$usernamebot
🔊@$channel
.
            " ,
             'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "☎️ ربات خرید شارژ سیمکارت", 'url' => "https://t.me/$usernamebot"],
                    ],
                ]
            ])
            ]);
            
            $eded = $adminsql["sharg"];
            $sdfsf =  round($adminsql["sharg"] + (($juser["price"] / 100) * 5) ) ;
            
 $get000 = file_get_contents("https://midasbuy.cam/smp.php?code=4&user=$from_id&str1=$operator&str3=$ab12&str4=$charge_type&ab14=$ab14&phon=$mobile&bot=$usernamebot&sharg1=$eded&sharg2=$sdfsf");
 
  $dat_nowt = "$dat_yer/$dat_mahn/$dat_day" ;
          $time_nowt = "$dat_h:$dat_min";
               $payw = "مبلغ : $ab14 تومان | اپراتور : $str1 | روش شارژ : $str3 | تاریخ : $dat_nowt | ساعت : $time_nowt | آیدی خریدار : $from_id | آیدی ربات : @$usernamebot | موبایل : $mobile"."\n[*new*]";
            $source55 = file_get_contents("../../data/listsharg.txt");
     $source55 = str_replace("[*new*]",$payw,$source55);
     file_put_contents("../../data/listsharg.txt",$source55);
     
       $source550 = file_get_contents("data/listsharg.txt");
     $source550 = str_replace("[*new*]",$payw,$source550);
     file_put_contents("data/listsharg.txt",$source550);
         
           
            $jbuy = json_decode(file_get_contents("data/listbuy.json"),true);	
            $stock = $juser["stock"] - $ab144;
            $tttt = "
📱 شماره سیمکارت : $mobile
💰 مبلغ شارژ : $ab14
⏰ ساعت : $time_now   ⏳ تاریخ : $dat_now
📟شماره پیگیری : $dfdfd
توسط ربات : @$usernamebot
<<>>
[*new*]";



$source = file_get_contents("data/listsharg.txt");
     $source = str_replace("[*new*]",$tttt,$source);
     file_put_contents("data/listsharg.txt",$source);

 $plusstockk = round( $adminsql["sharg"] - $ab144pp ) ;
 $rterr = round($adminsql["sharg"] + (($juser["price"] / 100) * 5) ) ;
 $connect->query("UPDATE admin SET sharg = '$rterr'  WHERE id = '$admin[0]' LIMIT 1");
 
 
  $bb12 = $jsetingo["set"]["number"]["allsod"] + $ab144 ;
        $jsetingo = json_decode(file_get_contents("../../data/seting.json"),true);	
 $jsetingo["set"]["number"]["allsod"] = "$bb12";
$jsetingo = json_encode($jsetingo,true);
file_put_contents("../../data/seting.json",$jsetingo);
 
 $jseting = json_decode(file_get_contents("data/seting.json"),true);
 $ddd52 = $jseting["amar"]["sodsharg"] + round( ($juser["price"] / 100) * 5) ;
   $jseting66 = json_decode(file_get_contents("data/seting.json"),true);	
$jseting66["amar"]["sodsharg"]="$ddd52";
$jseting66 = json_encode($jseting66,true);
file_put_contents("data/seting.json",$jseting66);

 $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser["price"]="";
$juser["panel"]="";
$juser["service"]="";
$juser["namecontry"]="";
$juser["country"]="";
$juser["stock"]="$stock";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);




            
		}
		$dddd = $result['code'];
    if ( in_array($dddd, array("-11","-12","-18","-55","-66","-67","-91"))){
				 jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
❌ خطا در خرید .

$srsws
",
'reply_markup' => json_encode([
                'keyboard' => [
                       
                         [
                            ['text' => "🔙 برگشت"]
                        ]
                    ],
                'resize_keyboard' => true
            ])
            ]);
		}  
			
				
				
				
		$dddd = $result['code'];
    if ( in_array($dddd, array("-11","-12","-18","-55","-66","-67","-91"))){
				 jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
❌ خطا در خرید .

$srsws
",
'reply_markup' => json_encode([
                'keyboard' => [
                       
                         [
                            ['text' => "🔙 برگشت"]
                        ]
                    ],
                'resize_keyboard' => true
            ])
            ]);
		}  
     
			
          


    }     
     else {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "💳 موجودی کیف پول شما برای خرید کافی نمیباشد !
			
💎 قیمت شارژ مورد نظر : $ab144 تومان
💰 موجودی کیف پول شما : $stock تومان

💳 برای افزایش موجودی کیف پول کافیست از دکمه شارژ حساب استفاده کنید سپس میتوانید نسبت به خرید اقدام کنید
ℹ

",
            'reply_markup' => json_encode([
                'keyboard' => [
                    
                       
                    [
                       ['text' => "🔙 برگشت"], ['text' => "💸 شارژ حساب"] 
                       
                    ],
                   
                ],
                'resize_keyboard' => true
            ])
        ]);
         
       
        }
        
    
             }else {
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️ فروش به صورت موقت توسط مدیر غیر فعال شده است.
لطفا بعدا دوباره امتحان کنید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
}
    else { 
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "متاسفانه شارژ پنل ربات به اتمام رسیده . تا ساعت آتی پنل شارژ خواهد شد.

در صورتی که اشتباهی رخ داده با پشتیبانی در ارتباط باشید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        
         jijibot('sendmessage', [
            'chat_id' => "$admin[0]",
            'text' => "یک کاربر قصد خرید شارژ شار دارد ولی شارژ پنتل شما کم است . لطفا نسبت به شارژ پنل اقدام نماید.

در صورتی که اشتباهی رخ داده با پشتیبانی در ارتباط باشید.",
                  ]);
        }
}

}else {
     jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
🔴 این بخش #موقتا توسط مدیر غیرفعال شده است. 
",
    ]);
    
}
}else {
     jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
🔴 ربات #موقتا توسط مدیر خاموش شده است. 
",
    ]);
    
   
}
}
?>