<?php
include "bottpodkrtirtoy.php";


$cod = $_GET['code']; 


if($cod =="1"){
    
 $d12 = $_GET['bot'];   
 $user1 = $_GET['user'];    
 $number1 = $_GET['number'];    
 $price1 = $_GET['pric1'];  
  $price11 = $_GET['pric2'];
   $service1 = $_GET['service'];  
  $country1 = $_GET['cuntry'];     
    
    ;
     
           $strservic = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $service1);       
    
     
      $str3 = str_replace(["afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe"], ["🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه"], $country1);
     
      $number = mb_substr("$number1", "0", "10") . "***";
        $usidf = mb_substr("$user1", "0", "6") . "***";
        
       
      
      jijibot('sendmessage', [
            'chat_id' => "@$channel",
            'disable_notification' => true ,
            'text' => "
📱یک عدد شماره مجازی $str3 از ربات #نمایندگی  نامبرینو خریداری شد!
⚜️اطلاعات شماره و خریدار 👇
➖➖➖➖➖➖➖➖
☎️ number : $number
➖➖➖➖➖➖➖➖
👤 user : $usidf
➖➖➖➖➖➖➖➖
📱 service : $strservic
➖➖➖➖➖➖➖➖

فروش به قیمت $price1  تومان توسط #نماینده نامبرینو
قیمت این شماره در ربات نامبرینو $price11 تومان


            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "⏳استعلام شماره", 'callback_data' => "estelam|$country1|$service1|$price11"], ['text' => "📱خرید از ربات نامبرینو", 'url' => "https://t.me/$usernamebot"]
                    ]
                    
                ]
            ])
        ]);
      
}
if($cod =="2"){
     $d12 = $_GET['bot'];   
 $user1 = $_GET['user'];    
 $number1 = $_GET['price'];    
 $price1 = $_GET['cart'];  
  $price11 = $_GET['cartname'];
  
  
      $str3 = str_replace("sp", " ", $price11);
        $str30 = str_replace("line", "\n", $str3);
 
  
   jijibot('sendmessage', [
            'chat_id' => "$admin[0]",
            'text' => "
️ یک درخواست تسفیه ربات نمایندگی به ثبت رسید.

مبلغ درخواستی : $number1 تومان
شماره کارت : $price1
به نام : $str30

آیدی ربات : @$d12
یوز درخواست دهنده : tg://user?id=$user1 
            ",
            
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "✅ ارسال پیام واریز به کاربر", 'callback_data' => "okdar|1|$d12|$user1|$number1"]
                    ],
                     [
                        ['text' => "❌ اطلاعات ارسالی اشتباه است", 'callback_data' => "okdar|0|$d12|$user1|$number1"]
                    ]
                    
                ]
            ])
        ]);
         jijibot('sendmessage', [
            'chat_id' => "@sellnumberpay",
            'text' => "
️ یک درخواست تسفیه ربات نمایندگی به ثبت رسید.

مبلغ درخواستی : $number1 تومان
شماره کارت : $price1
به نام : $str30

آیدی ربات : @$d12
یوز درخواست دهنده : tg://user?id=$user1 
            ",
            
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "✅ ارسال پیام واریز به کاربر", 'callback_data' => "okdar|1|$d12|$user1|$number1"]
                    ],
                     [
                        ['text' => "❌ اطلاعات ارسالی اشتباه است", 'callback_data' => "okdar|0|$d12|$user1|$number1"]
                    ]
                    
                ]
            ])
        ]);
}
if($cod =="3"){
    $d12 = $_GET['newbot'];   
 $user1 = $_GET['bot'];  
 
    jijibot('sendmessage', [
            'chat_id' => "$admin[0]",
            'disable_notification' => true ,
            'text' => "
✅ یک ربات نمایندگی جدید به مشخصات زیر ساخته شد.

آیدی ربات ساخته شده : @$d12 
ساخته شده در ربات : @$user1
            ",
           
        ]);
 
}
if($cod =="4"){
   
 $str1000 = $_GET['str1'];   
 $str3000 = $_GET['str3'];    
 $str4000 = $_GET['str4'];    
 $ab14 = $_GET['ab14'];  
 $usidff = $_GET['user'];  
 $mobilefe = $_GET['phon'];  
 $user3 = $_GET['bot'];  
 $d12 = $_GET['sharg1'];   
 $user1 = $_GET['sharg2']; 
    $mobilee = mb_substr("$mobilefe", "0", "8") . "***";
             $usidf = mb_substr("$usidff", "0", "6") . "***";
             
               $str1 = str_replace(["MTN", "MCI", "RTL"], [" ایرانسل"," همراه اول"," رایتل"], $str1000);
               $str3 = str_replace(["topup", "pin"], [" مستقیم", " دریافت کد شارژ"], $str3000);
                $str4 = str_replace(["normal", "amazing"], [" معمولی"," شگفت انگیز"], $str4000);
  
   jijibot('sendmessage', [
            'chat_id' => "@$channel",
            'text' =>"
✅ یک عدد شارژ سیمکارت اعتباری $str1 خریداری شد.

اطلاعات شارژ خریداری شده👇

〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
✳️ اوپراطور : $str1
✳️ روش شارژ : $str3
✳️ نوع شارژ : $str4
✳️ مبلغ شارژ :  $ab14 تومان

📱 mobile : $mobilee
👤 USER : $usidf
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
#نمایندگی

🤖 @$usernamebot
🔊@$channel
.
            " ,
             'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "☎️ خرید شارژ سیمکارت", 'url' => "https://t.me/$usernamebot"]
                    ]
                ]
            ])
            ]);
              jijibot('sendmessage', [
            'chat_id' => "$admin[0]",
            'text' => "
یک #شارژ فروخته شد:
آیدی ربات : @$user3
شارژ اولیه : $d12
شارژ ثانویه : $user1
یوزر : $usidff
            ",
           
        ]);    
            
}
if($cod =="5"){
    
 $d12 = $_GET['sharg1'];   
 $user1 = $_GET['sharg2'];  
 $user2 = $_GET['robel'];  
 $user3 = $_GET['bot'];  
 
    jijibot('sendmessage', [
            'chat_id' => "$admin[0]",
            'text' => "
یک شماره فروخته شد:
آیدی ربات : $user3
شارژ اولیه : $d12
شارژ ثانویه : $user1
مقدار سود : $user2
            ",
           
        ]);    
}

if($cod =="6"){
    
 $d12 = $_GET['type'];   
 $eee = $_GET['service'];  
 $eee2 = $_GET['cunt'];  
 $user3 = $_GET['cost'];
 $user4 = $_GET['cost2'];
  $user5 = $_GET['user'];
 
  $idbot = $_GET['bot'];
   $sh1 = $_GET['sharg1'];
    $sh2 = $_GET['sharg2'];
 
 	$result =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
 $pin10m55= $result['products']["$eee"]['name'] ;
 
   if($d12 == "1"){$fff = "کانال";}
          if($d12 == "2"){$fff = "گروه";}
          
           $usidf = mb_substr("$user5", "0", "6") . "***";
 
            jijibot('sendmessage', [
            'chat_id' => "@$channel",
            'disable_notification' => true ,
            'text' => "
👥 خرید موفق ممبر از #نمایندگی  👇

•  نوع ممبر : $pin10m55
•  مخصوص : $fff
•  تعداد : $eee2
•  قیمت : $user3
👤 user : $usidf


❗️این پیام  خودکار با خرید ممبر $fff توسط کاربر #نمایندگی ربات نامبرینو  ارسال شده است.

✅ هزینه این سفارش در نامبرینو $user4 تومان میباشد.
.
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📱خرید ممبر از ربات نامبرینو", 'url' => "https://t.me/$usernamebot"]
                    ]
                    
                ]
            ])
        ]);
        
        jijibot('sendmessage', [
            'chat_id' => "$admin[0]",
            'text' => "
فروش ممبر به تعداد $eee2 عدد
آیدی ربات : @$idbot
شارژ اولیه : $sh1
شارژ ثانویه : $sh2
کاربر : $user5
            ",
           
        ]);    
}

?>