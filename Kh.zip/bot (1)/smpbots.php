<?php
include "bottpodkrtirtoy.php";
error_reporting(0);

$cod = $_GET['code']; 

include "../../soorsmpbots.php";

?>