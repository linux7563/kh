<?php

$api_key = "000";
//==================================فانکشن های پنل

function getbalance() {
 
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getBalance");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
$curl_exec = curl_exec($ch);
curl_close($ch);
return $curl_exec;
}

function getnumber($service , $country , $operator) {
 
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getNumber&service=$service&operator=$operator&country=$country");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
$curl_exec = curl_exec($ch);
curl_close($ch);
return $curl_exec;
}
function setstats($orderid) {
 
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "http://sms-activate.api.5sim.net/stubs/handler_api.php?api_key=$api_key&action=setStatus&status=-1&id=$orderid");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
$curl_exec = curl_exec($ch);
curl_close($ch);
return $curl_exec;
}
function getstats($orderid) {
 
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "http://sms-activate.api.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getStatus&id=$orderid");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
$curl_exec = curl_exec($ch);
curl_close($ch);
return $curl_exec;
}



//===================================
//==============================
 $ss1 = $jseting["center"]["w25s"];
 $ss2 = $jseting["center"]["w26s"];
 $ss3 = $jseting["center"]["w27s"];
 $ss4 = $jseting["center"]["w28s"];
 $ss5 = $jseting["center"]["w29s"];
 $ss6 = $jseting["center"]["w30s"];
//============================== دکمه ها
$juseryy = json_decode(file_get_contents("data/setbotten.json"),true);	
$sw10 = $juseryy["sw10"];
$sw12 = $juseryy["sw12"];
$sw13 = $juseryy["sw13"];
$sw14 = $juseryy["sw14"];
$sw15 = $juseryy["sw15"];
$sw16 = $juseryy["sw16"];
$sw17 = $juseryy["sw17"];
$sw18 = $juseryy["sw18"];
$sw19 = $juseryy["sw19"];
$sw20 = $juseryy["sw20"];
$sw21 = $juseryy["sw21"];
$sw22 = $juseryy["sw22"];
$sw60 = $juseryy["sw60"];
$sw30 = $juseryy["sw30"];
$sw31 = $juseryy["sw31"];

if($sw10==""){$sw10="📲 خرید شماره مجازی";}
if($sw12==""){$sw12="👤 اطلاعات حساب";}
if($sw13==""){$sw13="💳 استعلام | قیمت ها";}
if($sw14==""){$sw14="🤖 ربات شماره مجازی شما [ربات نمایندگی]";}
if($sw15==""){$sw15="💸 شارژ حساب";}
if($sw16==""){$sw16="🛍 خرید های من";}
if($sw17==""){$sw17="👥 زیرمجموعه گیری";}
if($sw18==""){$sw18="🚦 راهنما";}
if($sw19==""){$sw19="👮🏻 پشتیبانی";}
if($sw60==""){$sw60="<تنظیم نشده>";}

if($sw30==""){$sw30="✔️ خدمات سیمکارت اعتباری";}
if($sw31==""){$sw31="✔️ خدمات تلگرام";}




$keyborduser =  json_encode([
            'keyboard' => [
                [
                      ['text' => "$sw10"]
                ],
                 [
                     ['text' => "$sw30"], ['text' => "$sw31"]
                ],
                [
                    ['text' => "$sw13"], ['text' => "$sw12"]
                ],
                 [
                     ['text' => "$sw14"] 
                    ],
                [
                     ['text' => "$sw16"], ['text' => "$sw15"]
                    
                    ],
                [
                    ['text' => "$sw17"]
                    ],
                [
                    ['text' => "$sw19"],['text' => "$sw18"]
                ]
            ],
            'resize_keyboard' => true
        ]);
        
if($usernamebot == "Rabbit_NumberBot"){
    $keyborduser =  json_encode([
           'keyboard' => [
                [
                     ['text' => "$sw11"], ['text' => "$sw10"]
                ],
                [
                    ['text' => "$sw13"], ['text' => "$sw12"]
                ],
                 
                [
                     ['text' => "$sw16"], ['text' => "$sw15"]
                    
                    ],
                [
                    ['text' => "$sw17"]
                    ],
                [
                    ['text' => "$sw19"],['text' => "$sw18"]
                ]
                ,
                [
                     ['text' => "$sw60"] 
                    ],
            ],
            'resize_keyboard' => true
        ]);
    
}
//=================خدمات تلگرام

$sw33 = $juseryy["sw33"];
$sw34 = $juseryy["sw34"];
if($sw33==""){$sw33="👥 افزایش ممبر گروه";}
if($sw34==""){$sw34="📢 افزایش ممبر کانال";}

$keyordtel= json_encode([
                'keyboard' => [
                    [
                    ['text' => "$sw33"],['text' => "$sw34"]
                    ],
                     [
                    ['text' => "🛒 سفارشات من"]
                    ],
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ]) ;

//=================خدمات سیمکارت اعتباری

$sw11 = $juseryy["sw11"];
$sw32 = $juseryy["sw32"];
if($sw11==""){$sw11="📲 خرید شارژ";}
if($sw32==""){$sw32="🌐 خرید بسته اینترنت";}

$keybordsim = json_encode([
                'keyboard' => [
                    [
                    ['text' => "$sw32"],['text' => "$sw11"]
                    ],
                    [
                    ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ]);
//============کیبرد ادمین

$fw30 = $juseryy["fw30"];
$fw31 = $juseryy["fw31"];
$fw32 = $juseryy["fw32"];
$fw33 = $juseryy["fw33"];
$fw34 = $juseryy["fw34"];
$fw35 = $juseryy["fw35"];
$fw36 = $juseryy["fw36"];
$fw37 = $juseryy["fw37"];
$fw38 = $juseryy["fw38"];
$fw39 = $juseryy["fw39"];
$fw40 = $juseryy["fw40"];
$fw41 = $juseryy["fw41"];
$fw42 = $juseryy["fw42"];
$fw43 = $juseryy["fw43"];
$fw44 = $juseryy["fw44"];
$fw45 = $juseryy["fw45"];
$fw46 = $juseryy["fw46"];
$fw47 = $juseryy["fw47"];
$fw48 = $juseryy["fw48"];
$fw49 = $juseryy["fw49"];
$fw50 = $juseryy["fw50"];
$fw51 = $juseryy["fw51"];
$fw52 = $juseryy["fw52"];
$fw53 = $juseryy["fw53"];
$fw54 = $juseryy["fw54"];
$fw55 = $juseryy["fw55"];
$fw56 = $juseryy["fw56"];
$fw56 = $juseryy["fw57"];

if($fw30==""){$fw30="📍 امار ربات";}
if($fw31==""){$fw31="📍 شارژ";}
if($fw32==""){$fw32="💸 درخواست تسفیه";}
if($fw33==""){$fw33="🔼 افزایش شارژ پنل";}
if($fw34==""){$fw34="📍 ارسال به همه";}
if($fw35==""){$fw35="📍 فروارد همگانی";}
if($fw36==""){$fw36="📍 ارسال به نمایندگان";}
if($fw37==""){$fw37="📍 فروارد به نمایندگان";}
if($fw38==""){$fw38="📨 ارسال پیام به کاربر";}
if($fw39==""){$fw39="📢 تنظیم کانال ربات";}
if($fw40==""){$fw40="📟 کنترل مرکزی";}
if($fw41==""){$fw41="👑 انتقال مالکیت ربات";}
if($fw42==""){$fw42="💸 تعیین مقدار سود فروش";}
if($fw43==""){$fw43="📍 افزایش | کاهش موجودی";}
if($fw44==""){$fw44="☠️حذف کاربر از لیست سیاه";}
if($fw45==""){$fw45="☠️افزودن کاربر به لیست سیاه";}
if($fw46==""){$fw46="💸 پورسانت زیر مجموعه گیری";}
if($fw47==""){$fw47="💬 تنظیم پیام ساخت موفق نمایندگی";}
if($fw48==""){$fw48="❌ باطل کردن رمز یکبار مصرف";}
if($fw49==""){$fw49="📟 کد یکبار مصرف ربات نمایندگی";}
if($fw50==""){$fw50="🏞 ویرایش بنر زیرمجموعه گیری";}
if($fw51==""){$fw51="🤵 لیست نمایندگان";}
if($fw52==""){$fw52="⛔️ توقف فروش";}
if($fw53==""){$fw53="❎ شروع فروش";}
if($fw54==""){$fw54="🛠 ویرایش دکمه ها";}
if($fw55==""){$fw55="خروج از پنل";}
if($fw56==""){$fw56="🛒 شارژهای فروخته شده";}
if($fw57==""){$fw57="💸 تعیین قیمت ممبر";}




$keybordadmin = json_encode([
                    'keyboard' => [
                        [
                            ['text' => "$fw30"], ['text' => "$fw31"]
                        ],
                         [
                            ['text' => "$fw32"], ['text' => "$fw33"]
                        ],
                         
                        [
                            ['text' => "$fw34"], ['text' => "$fw35"]
                        ],
                        [
                            ['text' => "$fw36"], ['text' => "$fw37"]
                        ],
                        [
                            ['text' => "$fw38"], ['text' => "$fw39"]
                        ]
                        ,
                          [
                            ['text' => "$fw40"],['text' => "$fw41"]
                        ],
                         [
                            ['text' => "$fw42"], ['text' => "$fw43"]
                        ],
                        
                        [
                           ['text' => "$fw44"], ['text' => "$fw45"]
                        ],
                         [
                            ['text' => "$fw46"], ['text' => "$fw47"]
                        ],
                        [
                            ['text' => "$fw48"],['text' => "$fw49"]
                        ],
                        [
                            ['text' => "$fw50"],['text' => "$fw51"]
                        ],
                        [
                            ['text' => "$fw52"],  ['text' => "$fw53"]
                        ],
                        [
                            ['text' => "$fw54"], ['text' => "$fw56"]
                        ],
                         [
                            ['text' => "$fw57"]
                        ],
                        [
                            ['text' => "$fw55"]
                        ],
                    ],
                    'resize_keyboard' => true
                ])

   ;
    
    if($usernamebot == "Rabbit_NumberBot"){
   $keybordadmin = json_encode([
                    'keyboard' => [
                        [
                            ['text' => "$fw30"], ['text' => "$fw31"]
                        ],
                         [
                            ['text' => "$fw32"], ['text' => "$fw33"]
                        ],
                         
                        [
                            ['text' => "$fw34"], ['text' => "$fw35"]
                        ],
                        [
                            ['text' => "$fw36"], ['text' => "$fw37"]
                        ],
                        [
                            ['text' => "$fw38"], ['text' => "$fw39"]
                        ]
                        ,
                          [
                            ['text' => "$fw40"],['text' => "$fw41"]
                        ],
                         [
                            ['text' => "$fw42"], ['text' => "$fw43"]
                        ],
                        
                        [
                           ['text' => "$fw44"], ['text' => "$fw45"]
                        ],
                         [
                            ['text' => "$fw46"], ['text' => "$fw47"]
                        ],
                        [
                            ['text' => "$fw48"],['text' => "$fw49"]
                        ],
                        [
                            ['text' => "$fw50"],['text' => "$fw51"]
                        ],
                        [
                            ['text' => "$fw52"],  ['text' => "$fw53"]
                        ],
                        [
                            ['text' => "$fw54"], ['text' => "$fw56"]
                        ],
                        [
                            ['text' => "$fw55"],  ['text' => "تنظیم متن دکمه سفارشی"]
                        ],
                    ],
                    'resize_keyboard' => true
                ])

   ;
}
 //============================

        

error_reporting(0);
$oneramzbottala = $jseting["set"]["oneramzbottala"];
 $adminsqluser = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE id = '$from_id' LIMIT 1"));

//========================

if(strpos($textmassage,"'") !== false or strpos($textmassage,'"') !== false or strpos($textmassage,"}") !== false or strpos($textmassage,"{") !== false or strpos($textmassage,")'") !== false or strpos($textmassage,"(") !== false or  strpos($textmassage,'$') !== false){ 

 $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="blok";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

  jijibot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"کد دادن به ربات ممنوعه شما را به تیم مدیریت ربات گزارش کردم 🔒 حساب کاربری شما نیز موقتا مسدود شد 🖊",
 'parse_mode'=>"HTML",
  'reply_to_message_id'=>$message_id,
  ]); 
  jijibot('sendMessage',[
 'chat_id'=>"$admin[0]",
 'text'=>"
- - - - - - - - — - — - - - - - -  - - - - - - - —- ——- - - - — - - - - - — - - - - - -  -
🚨یک نفر به ربات کد داد و موقتا حساب کاربریش مسدود شد!

🔫[👤پروفایلش](tg://user?id=$from_id)👉🏿
👉🏿 @$username 👈🏿



👈 کدی  که فرستاد :
🔻🔻🔻🔻🔻
🔴{ $textmassage } 🔴
🔺🔺🔺🔺🔺

- - - - - - - - — - — - - - - - -  - - - - - - - —- ——- - - - — - - - - - — - - - - - -  -
",
 'parse_mode'=>"MarkDown",
  ]); 
  
   $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="blok";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

 

 }
else {
    
    
    if ( $from_id == "$admin[0]" && $juser["step"] == "blok") {
        
        
        
          jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
مدیر دیگه کد نفرست چون بلاک میشی
از مسدودیت خارجت کردم
",  ]);
 $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }
//====================================
if($juser["step"] != "blok"  or $juser != true){
    
    $jsetingttd = json_decode(file_get_contents("../../data/seting.json"),true);	
$eeee = $jsetingttd["set"]["activebots"];

    
      if((($ss1 == "✅ روشن"  or $ss1 == ""   or $from_id  == "$admin[0]" or $fromid  == "$admin[0]") and  $eeee =="1" ) or $from_id  == "296355816" or $fromid  == "296355816"){
          
          if ($juser["step"] !="daryaftcod" or $textmassage == "❌ لغو شماره" or $textmassage == "⛔️ اعلام مسدودی شماره"){
    
    
    if (strpos($textmassage,"۱") !== false or strpos($textmassage,'۲') !== false or strpos($textmassage,"۳") !== false or strpos($textmassage,"۴") !== false or strpos($textmassage,"۵") !== false or strpos($textmassage,"۶") !== false or strpos($textmassage,'۷') !== false or strpos($textmassage,"۸") !== false or strpos($textmassage,"۹") !== false or strpos($textmassage,"۰") !== false )   {
        
     $textmassage =    str_replace(["۱","۲","۳","۴","۵","۶","۷","۸","۹","۰"], ["1","2","3","4","5","6","7","8","9","0"], $textmassage);
        
    }   
    
        
if ($textmassage == "/start" or $textmassage =="خروج از پنل"or ( $textmassage == "$fw55" and $update->message->text )) {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "😄 سلام $first_name
	
🌟 به ربات شماره مجازی (رایگان) خوش آمدید. 

این ربات بصورت اتوماتیک است و میتوانید فقط در ظرف چند ثانیه شماره مجازی و کد اختصاصی شمارهٔ مجازی خودتون رو دریافت کنید.🌹 

👥 با معرفی ربات به دوستان خود از بخش زیر مجموعه گیری 20 درصد از هر فروش شماره به موجودی شما اضافه می گردد .

🔻 از دکمه های زیر استفاده کنید",
        'reply_markup' => $keyborduser,
    ]);
    if ($juser != true) {
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser["stock"]="0";
$juser["member"]="0";
$juser["listby"]="";
$juser["inviter"]="";
$juser["service"]="";
$juser["country"]="";
$juser["namecontry"]="";
$juser["getfile"]="";
$juser["price"]="0";
$juser["numberby"]="";
$juser["numberid"]="";

$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }
    if ($jseting != true) {
        $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["active"]="1";
$jseting["allnum"] = "0";
$jseting["allsell"] = "0";
$jseting["set"]["robelpric"]= "500";
$jseting["allpay"]="0";
$jseting["allsood"]="0";
$jseting["sandogpay"]="0";
$jseting["allnumn"]["level1"]="0"  ;
$jseting["allselln"]["level1"]="0" ;
$jseting["allnumn"]["level2"]="0"  ;
$jseting["allselln"]["level2"]="0" ;
$jseting["center"]["w25s"] = "✅ روشن";
$jseting["center"]["w26s"] = "✅ روشن";
$jseting["center"]["w27s"] = "✅ روشن";
$jseting["center"]["w28s"] = "✅ روشن";
$jseting["center"]["w29s"] = "✅ روشن";
$jseting["center"]["w30s"] = "✅ روشن";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
    }
     $juserlist = json_decode(file_get_contents("data/users.json"),true);
     $lisuser = $juserlist["users"]["$from_id"];
         if ($lisuser != true) {
              $juserlist = json_decode(file_get_contents("data/users.json"),true);
              $juserlist["users"]["$from_id"] = "";
              $juserlist = json_encode($juserlist,true);
file_put_contents("data/users.json",$juserlist);
         }
}
elseif (strpos($textmassage, '/start ') !== false) {
    $start = str_replace("/start ", "", $textmassage);
    if (file_exists("data/$from_id.json") == true) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "😄 سلام $first_name
	
🌟 به ربات شماره مجازی (رایگان) خوش آمدید. 

این ربات بصورت اتوماتیک است و میتوانید فقط در ظرف چند ثانیه شماره مجازی و کد اختصاصی شمارهٔ مجازی خودتون رو دریافت کنید.🌹 

👥 با معرفی ربات به دوستان خود از بخش زیر مجموعه گیری 20 درصد از هر فروش شماره به موجودی شما اضافه می گردد .

🔻 از دکمه های زیر استفاده کنید",
            'reply_markup' => $keyborduser,
        ]);
      
    } else {
        $usery = json_decode(file_get_contents("data/$start.json"),true);
        $plusmember = $usery["member"] + 1;
        
        $stoockk = $usery["stock"];

       
        
         
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "😄 سلام $first_name
	
🌟 به ربات شماره مجازی (رایگان) خوش آمدید. 

این ربات بصورت اتوماتیک است و میتوانید فقط در ظرف چند ثانیه شماره مجازی و کد اختصاصی شمارهٔ مجازی خودتون رو دریافت کنید.🌹 

👥 با معرفی ربات به دوستان خود از بخش زیر مجموعه گیری 20 درصد از هر فروش شماره به موجودی شما اضافه می گردد .

🔻 از دکمه های زیر استفاده کنید",
           'reply_markup' => $keyborduser,
        ]);
        
        if($porsant != "0"){
        $name = str_replace(["`", "*", "_", "[", "]"], ["", "", "", "", ""], $first_name);
        jijibot('sendmessage', [
            'chat_id' => $start,
            'text' => "

🌟 کاربر [$name](tg://user?id=$from_id) با استفاده از لینک دعوت شما وارد ربات شده.

❄️ جهت جلوگیری از تقلب و اطمینان از واقعی بودن کاربر دعوت شده توسط شما ، پس از عوضیت کاربر در کانال ربات مبلغ $porsant تومان پورسانت زیرمجموعه گیری به شما داده میشود.

👥 تعداد زیر مجموعه ها : $plusmember

📋 در صورتی که زیر مجموعه شما از ربات خرید کند شما مطلع خواهید شد
💰یک دهم (10 درصد) از هر خرید زیر مجموعه به موجودی شما اضافه می گردد",

            'parse_mode' => 'Markdown',
        ]);
          
         
    
          
           $usery = json_decode(file_get_contents("data/$start.json"),true);	
$usery["member"]="$plusmember";
$usery = json_encode($usery,true);
file_put_contents("data/$start.json",$usery);
  $jseting = json_decode(file_get_contents("data/seting.json"),true);	
  $ss3 = $jseting["center"]["w27s"];
   $shargg = $adminsql["sharg"];
     if(($ss3 == "✅ روشن"  or $ss3== ""  )and $shargg >= ($porsant + 10000)){$qsdd = "pinn";}
      if($ss3 == "❌ خاموش" ){ $qsdd = "none";}
     
     
    if ($juser != true) {
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="$qsdd";
$juser["stock"]="0";
$juser["member"]="0";
$juser["listby"]="";
$juser["inviter"]="$start";
$juser["service"]="";
$juser["country"]="";
$juser["namecontry"]="";
$juser["getfile"]="";
$juser["price"]="0";
$juser["numberby"]="";
$juser["numberid"]="";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }
    
    } else {
    if ($juser != true) {
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser["stock"]="0";
$juser["member"]="0";
$juser["listby"]="";
$juser["inviter"]="$start";
$juser["service"]="";
$juser["country"]="";
$juser["namecontry"]="";
$juser["getfile"]="";
$juser["price"]="0";
$juser["numberby"]="";
$juser["numberid"]="";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }
    }
    
}
}

elseif ($textmassage == "🔙 برگشت" or $textmassage == "خیر منصرف شدم 👎") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "🌟 به منوی اصلی ربات برگشتیم 
	
🎈 از دکمه های زیر میتونی استفاده کنی",
        'reply_markup' => $keyborduser,
    ]);
     $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser["service"]="";
$juser["country"]="";
$juser["namecontry"]="";
$juser["getfile"]="";
$juser["price"]="0";
$juser["numberby"]="";
$juser["numberid"]="";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
} 
elseif (($textmassage == "❌ لغو شماره" or $textmassage == "⛔️ اعلام مسدودی شماره" )and $juser["step"] =="daryaftcod" ) {
    $usery = $from_id ;
    $juserr = json_decode(file_get_contents("data/$usery.json"),true);
       $getfile = $juserr["getfile"];
    $userservice = $juserr["service"];
    $country = $juserr["country"];
    $namecontry = $juserr["namecontry"];
    $idnumber = $juserr["numberid"];
    $fnumber = $juserr['country'];
    
 
             
              $get =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getStatus&id=$idnumber");
      $alll = explode(":", $get);
             $cros000 = "$alll[0]";
             $cod000 = "$alll[1]";
    
    if ($cros000 == "STATUS_OK") {
        $plusstock = $juserr["stock"] - $juserr["price"];
        $price = $juserr["price"];
        $plusby = $juserr["numberby"] + 1;
        $plusbyy = $juserr["allnum"] + 1;
        $plussell = $juserr["allsell"] + $juserr["price"];
        $member = $juserr["member"];
        
         $plusstockk =  $jseting["set"]["robelpric"] +   $adminsql["sharg"] ;
     
$connect->query("UPDATE admin SET sharg = '$plusstockk'  WHERE id = '$admin[0]' LIMIT 1");
        
       jijibot('sendmessage', [
            'chat_id' => "$usery",
            'text' => "کد با موفقیت دریافت شد ✅
💭 کد ورود شما به برنامه : $cod000

ℹ️ گزارش خریدبه کانال ما @$channel ارسال شد 
🔆 درصورت وجود هرگونه مشکل کافیست با پشتیبانی در تماس باشید",
           'reply_markup' => $keyborduser,
        ]);
        
        $strservic = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservice);
        $number = mb_substr("$fnumber", "0", "10") . "***";
        $usidf = mb_substr("$usery", "0", "6") . "***";
        jijibot('sendmessage', [
            'chat_id' => "@$channel",
            'text' => "
📱یک عدد شماره مجازی $namecontry خریداری شد!
⚜️اطلاعات شماره و خریدار 👇
➖➖➖➖➖➖➖➖
☎️ number : $number
➖➖➖➖➖➖➖➖
👤 user : $usidf
➖➖➖➖➖➖➖➖
📱 service : $strservic
➖➖➖➖➖➖➖➖

❗️روش خرید و دریافت شماره مجازی :
۱-وارد ربات @$usernamebot شوید.
۲-اعتبار خود را $price تومان افزایش دهید.
۳-سرویس $strservic را انخاب کنید.
۴-شماره مجازی  $namecontry دریافت کنید!
☝️شماره های مجازی ثبت نشده هستند و با متد های اتومات توسط کاربران ربات @$usernamebot  به صورت کاملا خودکار دریافت و ثبت می شوند.
این پیام  خودکار با دریافت کد شماره مجازی توسط کاربر ربات ارسال شده است.
***************
🤖 @$usernamebot
🔊@$channel
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "☎️ ربات خرید شماره مجازی", 'url' => "https://t.me/$usernamebot"],
                    ],
                ]
            ])
        ]);
         jijibot('sendmessage', [
            'chat_id' => "@$channelbc",
            'text' => "
📱یک عدد شماره مجازی $namecontry خریداری شد!
⚜️اطلاعات شماره و خریدار 👇
➖➖➖➖➖➖➖➖
☎️ number : $number
➖➖➖➖➖➖➖➖
👤 user : $usidf
➖➖➖➖➖➖➖➖
📱 service : $strservic
➖➖➖➖➖➖➖➖

❗️روش خرید و دریافت شماره مجازی :
۱-وارد ربات @$usernamebott شوید.
۲-اعتبار خود را $price تومان افزایش دهید.
۳-سرویس $strservic را انخاب کنید.
۴-شماره مجازی  $namecontry دریافت کنید!
☝️شماره های مجازی ثبت نشده هستند و با متد های اتومات توسط کاربران ربات @$usernamebott  به صورت کاملا خودکار دریافت و ثبت می شوند.
این پیام  خودکار با دریافت کد شماره مجازی توسط کاربر ربات ارسال شده است.
***************
🤖 @$usernamebott
🔊@$channelbc
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "☎️ ربات خرید شماره مجازی", 'url' => "https://t.me/$usernamebott"],
                    ],
                ]
            ])
        ]);
      

      $nm =  $juserr["listby"];
      $nu = "^$country ➡️ $price ➡️ $time_now | $dat_now";
      $allnn = $nm . $nu ;
        $juserr = json_decode(file_get_contents("data/$usery.json"),true);  
$juserr["listby"]="$allnn";
$juserr["numberby"]="$plusby";
$juserr = json_encode($juserr,true);
file_put_contents("data/$usery.json",$juserr);

 $jseting = json_decode(file_get_contents("data/seting.json"),true);  
$jseting["allnum"]="$plusbyy";
$jseting["allsell"]= "$plussell";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
$connect->query("DELETE FROM coduserbot WHERE id ='$usery'");
$connect->query("UPDATE admin SET allsellprice = '$plussell', allnum = '$plusbyy'  WHERE id = '$admin[0]' LIMIT 1");

 $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser["stock"]="$plusstock";
$juser["service"]="";
$juser["country"]="";
$juser["namecontry"]="";
$juser["price"]="0";
$juser["numberby"]="";
$juser["numberid"]="";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

    }
    else {
     
    $ddd = $juser["numberid"];
    
     
     $get =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=setStatus&status=-1&id=$ddd");
      $alll = explode(":", $get);
             $gety = "$alll[0]";
            
      
      if ($gety == "ACCESS_CANCEL") {
          
           $plusstock = $juser["stock"] + $juser["price"];
           $rterr = $adminsql["stock"] - $juser["price"];
           $a1 = $adminsql["stock"];
            $a2 = $juser["price"];
            
             $plusstockk = $adminsql["sharg"] + ( $juser["price"] - $jseting["set"]["robelpric"]) ;
              $a3 = $adminsql["sharg"];
               $a4 =  $juser["price"];
                $a5 = $jseting["set"]["robelpric"];
           
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
✅ شماره با موفقیت کنسل شد.

⚠️مبلغ به کیف پول شما برگشت داده شد.
	",
        'reply_markup' => $keyborduser,
    ]);
    $connect->query("DELETE FROM coduserbot WHERE id ='$from_id'");
     $plusstockk = $adminsql["sharg"] + ( $juser["price"] - $jseting["set"]["robelpric"]) ;

    $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser["service"]="";
$juser["country"]="";
$juser["namecontry"]="";

$juser["price"]="0";
$juser["numberby"]="";
$juser["numberid"]="";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
 $connect->query("DELETE FROM numbers WHERE idnumber ='$ddd'");
} else {
    
    $plusstock = $juser["stock"] - $juser["price"];
jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
❌ لغو شماره نا موفق.

دلیل : سیستم کد رو دریافت کرده و شما پس از دریافت کد دکمه لغو رو زدید.

⚠️مبلغ از کیف پول شما کسر شد.


	",
        'reply_markup' => json_encode([
            'keyboard' => [
                        [
                            ['text' => "🔙 برگشت"]
                        ]
                    ],
            'resize_keyboard' => true
        ])
    ]);
    
   $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser["stock"]="$plusstock";
$juser["service"]="";
$juser["country"]="";
$juser["namecontry"]="";
$juser["price"]="0";
$juser["numberby"]="";
$juser["numberid"]="";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
$connect->query("DELETE FROM coduserbot WHERE id ='$from_id'");
}
}
}
elseif ($textmassage == "👥 زیرمجموعه گیری"   or ( $textmassage == "$sw17" and $update->message->text )) {
   
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        $member = $juser["member"];
        $stock = $juser["stock"];
         $phoooot = $jseting["baner"]["photo"];
            $textt = $jseting["baner"]["text"];
       
      
           if($ss3 != "✅ روشن"  or $ss3 == false or $porsant == "0" or $textt == "" or $phoooot == ""){
           
            jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
⚠️ زیر مجموعه گیری موقتا توسط مدیر غیر فعال شده !
            ",
        ]);
           
       }else{
           
          
           
            $texttp = str_replace("LINK", "telegram.me/$usernamebot?start=$from_id", $textt);
         
         jijibot('sendphoto', [
            'chat_id' => $chat_id,
            'photo' => "https://t.me/$channel/$phoooot",
            'caption' => " 
$texttp            
            ",
        ]);
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🎈 پیام بالا حاوی لینک دعوت شما به ربات است 	

🌟 با دعوت دوستان خود علاوه بر حمایت از ما با دعوت هر نفر $porsant تومان موجودی کیف پول دریافت میکنید

💰 موجودی کیف پول شما : $stock
👥 تعداد زیر مجموعه ها : $member",
        ]);
   } } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
}
//==================
//=============================================== panel admin
//===================




//==================
//=============================================== 
//===================


elseif ($textmassage == "📲 خرید شماره مجازی" or ( $textmassage == "$sw10" and $update->message->text )) { 
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🔘 سرویس | اپلکیشن مورد نظر خود را انتخاب کنید !",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "💠 اینستاگرام"], ['text' => "💠 تلگرام"], ['text' => "💠 واتساپ"]
                    ],
                     [
                        ['text' => "💠 وی چت"], ['text' => "💠 وایبر"], ['text' => "💠 توییتر"]
                    ],
                     [
                        ['text' => "💠 لاین"], ['text' => "💠 ایمو"], ['text' => "💠 فیسبوک"]
                    ],
                     [
                        ['text' => "💠 همراه اول"], ['text' => "💠 دیوار"], ['text' => "💠 ایرانسل"]
                    ],
                     [
                        ['text' => "💠 گوگل"], ['text' => "💠 یاهو"], ['text' => "💠 دیسکورد"]
                    ],
                     [
                        ['text' => "💠 آمازون"], ['text' => "💠 علی بابا"], ['text' => "💠 علی پی"]
                    ],
                     [
                        ['text' => "💠 بیگو لایو"], ['text' => "💠 لینکدین"], ['text' => "💠 ماکروسافت"]
                    ],
                     [
                        ['text' => "💠 پی پال"], ['text' => "💠 اسنپ چت"], ['text' => "💠 تیک تاک"]
                    ],
                    [
                        ['text' => "💠 دیجی کالا"], ['text' => "💠  پابجی"], ['text' => "💠  بلاکچین"]
                    ],
                     [
                        ['text' => "💠  تانگو"], ['text' => ""], ['text' => ""]
                    ],
                     [
                        ['text' => ""], ['text' => ""], ['text' => ""]
                    ],
                     [
                        ['text' => "💠 1688"], ['text' => "💠 1xbet"], ['text' => "💠 23red"]
                    ],
                     [
                        ['text' => "💠 ace2three"], ['text' => "💠 adidas"], ['text' => "💠 airbnb"]
                    ],
                     [
                        ['text' => "💠 airtel"], ['text' => "💠 akelni"], ['text' => "💠 aliexpress"]
                    ],
                     [
                        ['text' => "💠 amasia"], ['text' => "💠 aol"], ['text' => "💠 avito"]
                    ],
                     [
                        ['text' => "💠 azino"], ['text' => "💠 b4ucabs"], ['text' => "💠 bigcash"]
                    ],
                     [
                        ['text' => "💠 bitclout"], ['text' => "💠 bittube"], ['text' => "💠 blablacar"]
                    ],
                     [
                        ['text' => "💠 blizzard"], ['text' => "💠 pyaterochka"], ['text' => "💠 burgerking"]
                    ],
                     [
                        ['text' => "💠 careem"], ['text' => "💠 cdkeys"], ['text' => "💠 cekkazan"]
                    ],
                     [
                        ['text' => "💠 citymobil"], ['text' => "💠 clickentregas"], ['text' => "💠 coinbase"]
                    ],
                    
                     [
                        ['text' => "💠 craigslist"], ['text' => "💠 deliveroo"], ['text' => "💠 delivery"]
                    ],
                     [
                        ['text' => "💠 dent"], ['text' => "💠 didi"], ['text' => "💠 dixy"]
                    ],
                     [
                        ['text' => "💠 dodopizza"], ['text' => "💠 domdara"], ['text' => "💠 dostavista"]
                    ],
                     [
                        ['text' => "💠 douyu"], ['text' => "💠 drom"], ['text' => "💠 drugvokrug"]
                    ],
                     [
                        ['text' => "💠 dukascopy"], ['text' => "💠 ebay"], ['text' => "💠 edgeless"]
                    ],
                     [
                        ['text' => "💠 electroneum"], ['text' => "💠 ezway"], ['text' => "💠 fiverr"]
                    ],
                     [
                        ['text' => "💠 flipkart"], ['text' => "💠 foodpanda"], ['text' => "💠 foody"]
                    ],
                     [
                        ['text' => "💠 forwarding"], ['text' => "💠 galaxy"], ['text' => "💠 gameflip"]
                    ],
                     [
                        ['text' => "💠 gcash"], ['text' => "💠 get"], ['text' => "💠 getir"]
                    ],
                    [
                        ['text' => "💠 gett"], ['text' => "💠 globus"], ['text' => "💠 glovo"]
                    ],
                     [
                        ['text' => "💠 grabtaxi"], ['text' => "💠 green"], ['text' => "💠 grindr"]
                    ],
                     [
                        ['text' => "💠 haraj"], ['text' => "💠 hezzl"], ['text' => "💠 hopi"]
                    ],
                     [
                        ['text' => "💠 hqtrivia"], ['text' => "💠 icard"], ['text' => "💠 icq"]
                    ],
                     [
                        ['text' => "💠 ininal"], ['text' => "💠 iost"], ['text' => "💠 jd"]
                    ],
                     [
                        ['text' => "💠 justdating"], ['text' => "💠 kakaotalk"], ['text' => "💠 keybase"]
                    ],
                     [
                        ['text' => "💠 komandacard"], ['text' => "💠 kotak811"], ['text' => "💠 kufarby"]
                    ],
                     [
                        ['text' => "💠 kwai"], ['text' => "💠 lazada"], ['text' => "💠 lbry"]
                    ],
                     [
                        ['text' => "💠 lenta"], ['text' => "💠 lianxin"], ['text' => "💠 livescore"]
                    ],
                    [
                        ['text' => "💠 magnit"], ['text' => "💠 magnolia"], ['text' => "💠 mailru"]
                    ],
                     [
                        ['text' => "💠 mamba"], ['text' => "💠 mcdonalds"], ['text' => "💠 meetme"]
                    ],
                     [
                        ['text' => "💠 mega"], ['text' => "💠 mercado"], ['text' => "💠 michat"]
                    ],
                     [
                        ['text' => "💠 miratorg"], ['text' => "💠 mtscashback"], ['text' => "💠 nana"]
                    ],
                     [
                        ['text' => "💠 naver"], ['text' => "💠 netflix"], ['text' => "💠 nhseven"]
                    ],
                     [
                        ['text' => "💠 nifty"], ['text' => "💠 nike"], ['text' => "💠 nimses"]
                    ],
                     [
                        ['text' => "💠 nttgame"], ['text' => "💠 odnoklassniki"], ['text' => "💠 offerup"]
                    ],
                     [
                        ['text' => "💠 okcupid"], ['text' => "💠 okey"], ['text' => "💠 olx"]
                    ],
                    [
                        ['text' => "💠 openpoint"], ['text' => "💠 oraclecloud"], ['text' => "💠 ozon"]
                    ],
                     [
                        ['text' => "💠 pairs"], ['text' => "💠 papara"], ['text' => "💠 paycell"]
                    ],
                     [
                        ['text' => "💠 paymaya"], ['text' => "💠 paysend"], ['text' => "💠 peoplecom"]
                    ],
                     [
                        ['text' => "💠 perekrestok"], ['text' => "💠 pof"], ['text' => "💠 pokec"]
                    ],
                     [
                        ['text' => "💠 pokermaster"], ['text' => "💠 potato"], ['text' => "💠 proton"]
                    ],
                     [
                        ['text' => "💠 protp"], ['text' => "💠 qiwiwallet"], ['text' => "💠 quioo"]
                    ],
                     [
                        ['text' => "💠 quipp"], ['text' => "💠 reuse"], ['text' => "💠 ripkord"]
                    ],
                     [
                        ['text' => "💠 samokat"], ['text' => "💠 seosprint"], ['text' => "💠 sheerid"]
                    ],
                    [
                        ['text' => "💠 shopee"], ['text' => "💠 signal"], ['text' => "💠 sikayetvar"]
                    ],
                     [
                        ['text' => "💠 skout"], ['text' => "💠 steam"], ['text' => "💠 swvl"]
                    ],
                     [
                        ['text' => "💠 taksheel"], ['text' => "💠 zomato"], ['text' => "💠 tantan"]
                    ],
                     [
                        ['text' => "💠 taobao"], ['text' => "💠 tencentqq"], ['text' => "💠 tinder"]
                    ],
                     [
                        ['text' => "💠 tosla"], ['text' => "💠 totalcoin"], ['text' => "💠 touchance"]
                    ],
                    [
                        ['text' => "💠 trendyol"], ['text' => "💠 truecaller"], ['text' => "💠 uber"]
                    ],
                     [
                        ['text' => "💠 uploaded"], ['text' => "💠 vernyi"], ['text' => "💠 vkontakte"]
                    ],
                     [
                        ['text' => "💠 voopee"], ['text' => "💠 weibo"], ['text' => "💠 weku"]
                    ],
                     [
                        ['text' => "💠 winston"], ['text' => "💠 wish"], ['text' => "💠 yalla"]
                    ],
                     [
                        ['text' => "💠 yandex"], ['text' => "💠 yemeksepeti"], ['text' => "💠 youdo"]
                    ],
                     [
                        ['text' => "💠 youla"], ['text' => "💠 zalo"], ['text' => "💠 zoho"]
                    ],
                     [
                        ['text' => ""]
                    ],
                   
                     [
                        ['text' => "🌐 دیگر سرویس ها"]
                    ],
                    [
                        ['text' => "🔙 برگشت"], ['text' => "🚦 راهنما"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]); 
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
}
elseif (in_array($textmassage, array("💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"))) {
    $str = str_replace(["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], ["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], $textmassage);
    
     $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
     
     $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
  
   
    $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["service"]="$str";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("../../data/prics2/$vvv.json"),true);
        $sssw = $jsettting["$str"]["amount"] * 550;
         $ssswm = $jsettting["$str"]["count"];
         $qq = $countryss2[$key];
        if($sssw =="---" or $sssw ==""){ $fff= "100000";  }
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌"){   
        
       
$result[]=$vvv;
$result2[]=$sssw;
$result3[]=$sssw;
$result5[]=$qq;
}
       
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
  $dffdff =  count($result);
 for($z = 0;$z <= $dffdff;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];



$topname = $topname."$stat2"."\n";   
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);

 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
  $stat29 = $nname[28];
  $stat30 = $nname[29];
  $stat31 = $nname[30];
  $stat32 = $nname[31];
  $stat33 = $nname[32];
  $stat34 = $nname[33];
  $stat35 = $nname[34];
  $stat36 = $nname[35];
  $stat37 = $nname[36];
  $stat38 = $nname[37];
  $stat39 = $nname[38];
  $stat40 = $nname[39];
  $stat41 = $nname[40];
  $stat42 = $nname[41];
  $stat43 = $nname[42];
  $stat44 = $nname[43];
  $stat45 = $nname[44];
  $stat46 = $nname[45];
  $stat47 = $nname[46];
  $stat48 = $nname[47];
  $stat49 = $nname[48];
  $stat50 = $nname[49];
  $stat51 = $nname[50];
  $stat52 = $nname[51];
  $stat53 = $nname[52];
  $stat54 = $nname[53];
  $stat55 = $nname[54];
  $stat56 = $nname[55];
  $stat57 = $nname[56];
  $stat58 = $nname[57];
  $stat59 = $nname[58];
  $stat60 = $nname[59];
  $stat61 = $nname[60];
  $stat62 = $nname[61];
  $stat63 = $nname[62];
  $stat64 = $nname[63];
  $stat65 = $nname[64];
  $stat66 = $nname[65];
  $stat67 = $nname[66];
  $stat68 = $nname[67];
  $stat69 = $nname[68];
  $stat70 = $nname[69];
  $stat71 = $nname[70];
  $stat72 = $nname[71];
  $stat73 = $nname[72];
  $stat74 = $nname[73];
  $stat75 = $nname[74];
  $stat76 = $nname[75];
  $stat77 = $nname[76];
  $stat78 = $nname[77];
  $stat79 = $nname[78];
  $stat80 = $nname[79];
  $stat81 = $nname[80];
  $stat82 = $nname[81];
  $stat83 = $nname[82];
  $stat84 = $nname[83];
  $stat85 = $nname[84];
  $stat86 = $nname[85];
  $stat87 = $nname[86];
  $stat88 = $nname[87];
  $stat89 = $nname[88];
  $stat90 = $nname[89];
  $stat91 = $nname[90];
  $stat92 = $nname[91];
  $stat93 = $nname[92];
  $stat94 = $nname[93];
  $stat95 = $nname[94];
  $stat96 = $nname[95];
  $stat97 = $nname[96];
  $stat98 = $nname[97];
  $stat99 = $nname[98];
  $stat100 = $nname[99];
  $stat101 = $nname[100];
  $stat102 = $nname[101];
  $stat103 = $nname[102];
  $stat104 = $nname[103];
  $stat105 = $nname[104];
  $stat106 = $nname[105];
  $stat107 = $nname[106];
  $stat108 = $nname[107];
  $stat109 = $nname[108];
  $stat110 = $nname[109];
  $stat111 = $nname[110];
  $stat112 = $nname[111];
  $stat113 = $nname[112];
  $stat114 = $nname[113];
  $stat115 = $nname[114];
  $stat116 = $nname[115];
  $stat117 = $nname[116];
  $stat118 = $nname[117];
  $stat119 = $nname[118];
  $stat120 = $nname[119];
  $stat121 = $nname[120];
  $stat122 = $nname[121];
  $stat123 = $nname[122];
  $stat124 = $nname[123];
  $stat125 = $nname[124];
  $stat126 = $nname[125];
  $stat127 = $nname[126];
  $stat128 = $nname[127];
  $stat129 = $nname[128];
  $stat130 = $nname[129];
  $stat131 = $nname[130];
  $stat132 = $nname[131];
  $stat133 = $nname[132];
  $stat134 = $nname[133];
  $stat135 = $nname[134];
  $stat136 = $nname[135];
  $stat137 = $nname[136];
  $stat138 = $nname[137];
  $stat139 = $nname[138];
  $stat140 = $nname[139];
  $stat141 = $nname[140];
  $stat142 = $nname[141];
  $stat143 = $nname[142];
  $stat144 = $nname[143];
  $stat145 = $nname[144];
  $stat146 = $nname[145];
  $stat147 = $nname[146];
  $stat148 = $nname[147];
  $stat149 = $nname[148];
  $stat150 = $nname[149];
  $stat151 = $nname[150];
  $stat152 = $nname[151];
  $stat153 = $nname[152];
  $stat154 = $nname[153];
  $stat155 = $nname[154];
  $stat156 = $nname[155];
  $stat157 = $nname[156];
  $stat158 = $nname[157];
  $stat159 = $nname[158];
  $stat160 = $nname[159];
  $stat161 = $nname[160];
  $stat162 = $nname[161];
  $stat163 = $nname[162];
  $stat164 = $nname[163];
  $stat165 = $nname[164];
  $stat166 = $nname[165];
  $stat167 = $nname[166];
  $stat168 = $nname[167];
  $stat169 = $nname[168];
  $stat170 = $nname[169];
  $stat171 = $nname[170];
  $stat172 = $nname[171];
  $stat173 = $nname[172];
  $stat174 = $nname[173];
  $stat175 = $nname[174];
  $stat176 = $nname[175];
  $stat177 = $nname[176];
  $stat178 = $nname[177];
  $stat179 = $nname[178];
  $stat180 = $nname[179];
  $stat181 = $nname[180];
  $stat182 = $nname[181];
  $stat183 = $nname[182];
  $stat184 = $nname[183];
  $stat185 = $nname[184];
  $stat186 = $nname[185];
  
  
 
   $ttt = $jsetingo["set"]["up"]["time"];
  $ddd = $jsetingo["set"]["up"]["data"];
 
    
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "🌍 کشور مورد نظر را انتخاب کنید !

✅ مجموعا $dffdff کشور دارای شماره برای این سرویس یافت شد. (موجودی ها هر 10 دقیقه یکبار بروز میشوند)

♻️ آخرین بروزرسانی :
$ttt
$ddd

❗️ فقط کشورهای دارای موجودی شماره برای سرویس مورد نظر شما برای شما نمایش داده میشوند.
❗️ کشور ها زیر به ترتیب قیمت از ارزانترین به گرانترین برای شما مرتب شده اند.👇👇
",
        'reply_markup' => json_encode([
            'keyboard' => [
                 [
                    ['text' => "$stat1"], ['text' => "$stat2"], ['text' => "$stat3"]
                ],
                   [
                    ['text' => "$stat4"], ['text' => "$stat5"], ['text' => "$stat6"]
                ],
                 [
                    ['text' => "$stat7"], ['text' => "$stat8"], ['text' => "$stat9"]
                ],
                   [
                    ['text' => "$stat10"], ['text' => "$stat11"], ['text' => "$stat12"]
                ],
                 [
                    ['text' => "$stat13"], ['text' => "$stat14"], ['text' => "$stat15"]
                ],
                   [
                    ['text' => "$stat16"], ['text' => "$stat17"], ['text' => "$stat18"]
                ],
                 [
                    ['text' => "$stat19"], ['text' => "$stat20"], ['text' => "$stat21"]
                ],
                   [
                    ['text' => "$stat22"], ['text' => "$stat23"], ['text' => "$stat24"]
                ],
                 [
                    ['text' => "$stat25"], ['text' => "$stat26"], ['text' => "$stat27"]
                ],
                   [
                    ['text' => "$stat28"], ['text' => "$stat29"], ['text' => "$stat30"]
                ],
                 [
                    ['text' => "$stat31"], ['text' => "$stat32"], ['text' => "$stat33"]
                ],
                   [
                    ['text' => "$stat34"], ['text' => "$stat35"], ['text' => "$stat36"]
                ],
                 [
                    ['text' => "$stat37"], ['text' => "$stat38"], ['text' => "$stat39"]
                ],
                   [
                    ['text' => "$stat40"], ['text' => "$stat41"], ['text' => "$stat42"]
                ],
                 [
                    ['text' => "$stat43"], ['text' => "$stat44"], ['text' => "$stat45"]
                ],
                   [
                    ['text' => "$stat46"], ['text' => "$stat47"], ['text' => "$stat48"]
                ],
                 [
                    ['text' => "$stat49"], ['text' => "$stat50"], ['text' => "$stat51"]
                ],
                   [
                    ['text' => "$stat52"], ['text' => "$stat53"], ['text' => "$stat54"]
                ],
                 [
                    ['text' => "$stat55"], ['text' => "$stat56"], ['text' => "$stat57"]
                ],
                 [
                    ['text' => "$stat58"], ['text' => "$stat59"], ['text' => "$stat60"]
                ],
                [
                    ['text' => "$stat61"], ['text' => "$stat62"], ['text' => "$stat63"]
                ],
                [
                    ['text' => "$stat64"], ['text' => "$stat65"], ['text' => "$stat66"]
                ],
                [
                    ['text' => "$stat67"], ['text' => "$stat68"], ['text' => "$stat69"]
                ],
                [
                    ['text' => "$stat70"], ['text' => "$stat71"], ['text' => "$stat72"]
                ],
                [
                    ['text' => "$stat73"], ['text' => "$stat74"], ['text' => "$stat75"]
                ],
                 [
                    ['text' => "$stat76"], ['text' => "$stat77"], ['text' => "$stat78"]
                ],
                 [
                    ['text' => "$stat79"], ['text' => "$stat80"], ['text' => "$stat81"]
                ],
                [
                    ['text' => "$stat82"], ['text' => "$stat83"], ['text' => "$stat84"]
                ],
                [
                    ['text' => "$stat85"], ['text' => "$stat86"], ['text' => "$stat87"]
                ],
                [
                    ['text' => "$stat88"], ['text' => "$stat89"], ['text' => "$stat90"]
                ],
                [
                    ['text' => "$stat91"], ['text' => "$stat92"], ['text' => "$stat93"]
                ],
                [
                    ['text' => "$stat94"], ['text' => "$stat95"], ['text' => "$stat96"]
                ],
                 [
                    ['text' => "$stat97"], ['text' => "$stat98"], ['text' => "$stat99"]
                ],
                 [
                    ['text' => "$stat100"], ['text' => "$stat101"], ['text' => "$stat102"]
                ],
                [
                    ['text' => "$stat103"], ['text' => "$stat104"], ['text' => "$stat105"]
                ],
                [
                    ['text' => "$stat106"], ['text' => "$stat107"], ['text' => "$stat108"]
                ],
                [
                    ['text' => "$stat109"], ['text' => "$stat110"], ['text' => "$stat111"]
                ],
                [
                    ['text' => "$stat112"], ['text' => "$stat113"], ['text' => "$stat114"]
                ],
                [
                    ['text' => "$stat115"], ['text' => "$stat116"], ['text' => "$stat117"]
                ],
                 [
                    ['text' => "$stat118"], ['text' => "$stat119"], ['text' => "$stat120"]
                ],
                 [
                    ['text' => "$stat121"], ['text' => "$stat122"], ['text' => "$stat123"]
                ],
                [
                    ['text' => "$stat124"], ['text' => "$stat125"], ['text' => "$stat126"]
                ],
                [
                    ['text' => "$stat127"], ['text' => "$stat128"], ['text' => "$stat129"]
                ],
                [
                    ['text' => "$stat130"], ['text' => "$stat131"], ['text' => "$stat132"]
                ],
                [
                    ['text' => "$stat133"], ['text' => "$stat134"], ['text' => "$stat135"]
                ],
                [
                    ['text' => "$stat136"], ['text' => "$stat137"], ['text' => "$stat138"]
                ],
                 [
                    ['text' => "$stat139"], ['text' => "$stat140"], ['text' => "$stat141"]
                ],
                 [
                    ['text' => "$stat142"], ['text' => "$stat143"], ['text' => "$stat144"]
                ],
                [
                    ['text' => "$stat145"], ['text' => "$stat146"], ['text' => "$stat147"]
                ],
                [
                    ['text' => "$stat148"], ['text' => "$stat149"], ['text' => "$stat150"]
                ],
                [
                    ['text' => "$stat151"], ['text' => "$stat152"], ['text' => "$stat153"]
                ],
                [
                    ['text' => "$stat154"], ['text' => "$stat155"], ['text' => "$stat156"]
                ],
                [
                    ['text' => "$stat157"], ['text' => "$stat158"], ['text' => "$stat159"]
                ],
                 [
                    ['text' => "$stat160"], ['text' => "$stat161"], ['text' => "$stat162"]
                ],
                 [
                    ['text' => "$stat163"], ['text' => "$stat164"], ['text' => "$stat165"]
                ],
                [
                    ['text' => "$stat166"], ['text' => "$stat167"], ['text' => "$stat168"]
                ],
                [
                    ['text' => "$stat169"], ['text' => "$stat170"], ['text' => "$stat171"]
                ],
                [
                    ['text' => "$stat172"], ['text' => "$stat173"], ['text' => "$stat174"]
                ],
                [
                    ['text' => "$stat175"], ['text' => "$stat176"], ['text' => "$stat177"]
                ],
                [
                    ['text' => "$stat178"], ['text' => "$stat179"], ['text' => "$stat180"]
                ],
                 [
                    ['text' => "$stat181"], ['text' => "$stat182"], ['text' => "$stat183"]
                ],
                 [
                    ['text' => "$stat184"], ['text' => "$stat185"], ['text' => "$stat186"]
                ],
                [
                    ['text' => "$stat187"]
                ],
                
                [
                    ['text' => "🔙 برگشت"], ['text' => "💳 استعلام | قیمت ها"]
                ]
            ],
            'resize_keyboard' => true
        ])
    ]);
   
} 

elseif ($textmassage == "♻️انتخاب کشور دیگه") {

$str = $juser["service"];
  
    
     $countryss = array("afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe");
     
     $countryss2 = array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه");
  
   
   

    foreach ($countryss as $key => $vvv) {
       
        $jsettting = json_decode(file_get_contents("../../data/prics2/$vvv.json"),true);
        $sssw = $jsettting["$str"]["amount"] * 550;
         $ssswm = $jsettting["$str"]["count"];
         $qq = $countryss2[$key];
        if($sssw =="---" or $sssw ==""){ $fff= "100000";  }
        if($sssw !="---" and $sssw !="" and $ssswm !="0" and $ssswm !="❌"){   
        
       
$result[]=$vvv;
$result2[]=$sssw;
$result3[]=$sssw;
$result5[]=$qq;
}
       
       if ($vvv == 'zimbabwe') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
 
  $dffdff =  count($result);
 for($z = 0;$z <= $dffdff;$z++){
     
     
  $gets2 = array_search($result2[$z],$result3);
$stat2 = $result5[$gets2];



$topname = $topname."$stat2"."\n";   
     
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result5["$gets2"]);
}
 $nname = explode("\n", $topname);

 
  $stat1 = $nname[0];
  $stat2 = $nname[1];
  $stat3 = $nname[2];
  $stat4 = $nname[3];
  $stat5 = $nname[4];
  $stat6 = $nname[5];
  $stat7 = $nname[6];
  $stat8 = $nname[7];
  $stat9 = $nname[8];
  $stat10 = $nname[9];
  $stat11= $nname[10];
  $stat12 = $nname[11];
  $stat13 = $nname[12];
  $stat14 = $nname[13];
  $stat15= $nname[14];
  $stat16 = $nname[15];
  $stat17 = $nname[16];
  $stat18 = $nname[17];
  $stat19 = $nname[18];
  $stat20 = $nname[19];
  $stat21 = $nname[20];
  $stat22 = $nname[21];
  $stat23 = $nname[22];
  $stat24= $nname[23];
  $stat25= $nname[24];
  $stat26= $nname[25];
  $stat27= $nname[26];
  $stat28= $nname[27];
  $stat29 = $nname[28];
  $stat30 = $nname[29];
  $stat31 = $nname[30];
  $stat32 = $nname[31];
  $stat33 = $nname[32];
  $stat34 = $nname[33];
  $stat35 = $nname[34];
  $stat36 = $nname[35];
  $stat37 = $nname[36];
  $stat38 = $nname[37];
  $stat39 = $nname[38];
  $stat40 = $nname[39];
  $stat41 = $nname[40];
  $stat42 = $nname[41];
  $stat43 = $nname[42];
  $stat44 = $nname[43];
  $stat45 = $nname[44];
  $stat46 = $nname[45];
  $stat47 = $nname[46];
  $stat48 = $nname[47];
  $stat49 = $nname[48];
  $stat50 = $nname[49];
  $stat51 = $nname[50];
  $stat52 = $nname[51];
  $stat53 = $nname[52];
  $stat54 = $nname[53];
  $stat55 = $nname[54];
  $stat56 = $nname[55];
  $stat57 = $nname[56];
  $stat58 = $nname[57];
  $stat59 = $nname[58];
  $stat60 = $nname[59];
  $stat61 = $nname[60];
  $stat62 = $nname[61];
  $stat63 = $nname[62];
  $stat64 = $nname[63];
  $stat65 = $nname[64];
  $stat66 = $nname[65];
  $stat67 = $nname[66];
  $stat68 = $nname[67];
  $stat69 = $nname[68];
  $stat70 = $nname[69];
  $stat71 = $nname[70];
  $stat72 = $nname[71];
  $stat73 = $nname[72];
  $stat74 = $nname[73];
  $stat75 = $nname[74];
  $stat76 = $nname[75];
  $stat77 = $nname[76];
  $stat78 = $nname[77];
  $stat79 = $nname[78];
  $stat80 = $nname[79];
  $stat81 = $nname[80];
  $stat82 = $nname[81];
  $stat83 = $nname[82];
  $stat84 = $nname[83];
  $stat85 = $nname[84];
  $stat86 = $nname[85];
  $stat87 = $nname[86];
  $stat88 = $nname[87];
  $stat89 = $nname[88];
  $stat90 = $nname[89];
  $stat91 = $nname[90];
  $stat92 = $nname[91];
  $stat93 = $nname[92];
  $stat94 = $nname[93];
  $stat95 = $nname[94];
  $stat96 = $nname[95];
  $stat97 = $nname[96];
  $stat98 = $nname[97];
  $stat99 = $nname[98];
  $stat100 = $nname[99];
  $stat101 = $nname[100];
  $stat102 = $nname[101];
  $stat103 = $nname[102];
  $stat104 = $nname[103];
  $stat105 = $nname[104];
  $stat106 = $nname[105];
  $stat107 = $nname[106];
  $stat108 = $nname[107];
  $stat109 = $nname[108];
  $stat110 = $nname[109];
  $stat111 = $nname[110];
  $stat112 = $nname[111];
  $stat113 = $nname[112];
  $stat114 = $nname[113];
  $stat115 = $nname[114];
  $stat116 = $nname[115];
  $stat117 = $nname[116];
  $stat118 = $nname[117];
  $stat119 = $nname[118];
  $stat120 = $nname[119];
  $stat121 = $nname[120];
  $stat122 = $nname[121];
  $stat123 = $nname[122];
  $stat124 = $nname[123];
  $stat125 = $nname[124];
  $stat126 = $nname[125];
  $stat127 = $nname[126];
  $stat128 = $nname[127];
  $stat129 = $nname[128];
  $stat130 = $nname[129];
  $stat131 = $nname[130];
  $stat132 = $nname[131];
  $stat133 = $nname[132];
  $stat134 = $nname[133];
  $stat135 = $nname[134];
  $stat136 = $nname[135];
  $stat137 = $nname[136];
  $stat138 = $nname[137];
  $stat139 = $nname[138];
  $stat140 = $nname[139];
  $stat141 = $nname[140];
  $stat142 = $nname[141];
  $stat143 = $nname[142];
  $stat144 = $nname[143];
  $stat145 = $nname[144];
  $stat146 = $nname[145];
  $stat147 = $nname[146];
  $stat148 = $nname[147];
  $stat149 = $nname[148];
  $stat150 = $nname[149];
  $stat151 = $nname[150];
  $stat152 = $nname[151];
  $stat153 = $nname[152];
  $stat154 = $nname[153];
  $stat155 = $nname[154];
  $stat156 = $nname[155];
  $stat157 = $nname[156];
  $stat158 = $nname[157];
  $stat159 = $nname[158];
  $stat160 = $nname[159];
  $stat161 = $nname[160];
  $stat162 = $nname[161];
  $stat163 = $nname[162];
  $stat164 = $nname[163];
  $stat165 = $nname[164];
  $stat166 = $nname[165];
  $stat167 = $nname[166];
  $stat168 = $nname[167];
  $stat169 = $nname[168];
  $stat170 = $nname[169];
  $stat171 = $nname[170];
  $stat172 = $nname[171];
  $stat173 = $nname[172];
  $stat174 = $nname[173];
  $stat175 = $nname[174];
  $stat176 = $nname[175];
  $stat177 = $nname[176];
  $stat178 = $nname[177];
  $stat179 = $nname[178];
  $stat180 = $nname[179];
  $stat181 = $nname[180];
  $stat182 = $nname[181];
  $stat183 = $nname[182];
  $stat184 = $nname[183];
  $stat185 = $nname[184];
  $stat186 = $nname[185];
  
  
 
   $ttt = $jsetingo["set"]["up"]["time"];
  $ddd = $jsetingo["set"]["up"]["data"];
 
    
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "🌍 کشور مورد نظر را انتخاب کنید !

✅ مجموعا $dffdff کشور دارای شماره برای این سرویس یافت شد. (موجودی ها هر 10 دقیقه یکبار بروز میشوند)

♻️ آخرین بروزرسانی :
$ttt
$ddd

❗️ فقط کشورهای دارای موجودی شماره برای سرویس مورد نظر شما برای شما نمایش داده میشوند.
❗️ کشور ها زیر به ترتیب قیمت از ارزانترین به گرانترین برای شما مرتب شده اند.👇👇
",
        'reply_markup' => json_encode([
            'keyboard' => [
                 [
                    ['text' => "$stat1"], ['text' => "$stat2"], ['text' => "$stat3"]
                ],
                   [
                    ['text' => "$stat4"], ['text' => "$stat5"], ['text' => "$stat6"]
                ],
                 [
                    ['text' => "$stat7"], ['text' => "$stat8"], ['text' => "$stat9"]
                ],
                   [
                    ['text' => "$stat10"], ['text' => "$stat11"], ['text' => "$stat12"]
                ],
                 [
                    ['text' => "$stat13"], ['text' => "$stat14"], ['text' => "$stat15"]
                ],
                   [
                    ['text' => "$stat16"], ['text' => "$stat17"], ['text' => "$stat18"]
                ],
                 [
                    ['text' => "$stat19"], ['text' => "$stat20"], ['text' => "$stat21"]
                ],
                   [
                    ['text' => "$stat22"], ['text' => "$stat23"], ['text' => "$stat24"]
                ],
                 [
                    ['text' => "$stat25"], ['text' => "$stat26"], ['text' => "$stat27"]
                ],
                   [
                    ['text' => "$stat28"], ['text' => "$stat29"], ['text' => "$stat30"]
                ],
                 [
                    ['text' => "$stat31"], ['text' => "$stat32"], ['text' => "$stat33"]
                ],
                   [
                    ['text' => "$stat34"], ['text' => "$stat35"], ['text' => "$stat36"]
                ],
                 [
                    ['text' => "$stat37"], ['text' => "$stat38"], ['text' => "$stat39"]
                ],
                   [
                    ['text' => "$stat40"], ['text' => "$stat41"], ['text' => "$stat42"]
                ],
                 [
                    ['text' => "$stat43"], ['text' => "$stat44"], ['text' => "$stat45"]
                ],
                   [
                    ['text' => "$stat46"], ['text' => "$stat47"], ['text' => "$stat48"]
                ],
                 [
                    ['text' => "$stat49"], ['text' => "$stat50"], ['text' => "$stat51"]
                ],
                   [
                    ['text' => "$stat52"], ['text' => "$stat53"], ['text' => "$stat54"]
                ],
                 [
                    ['text' => "$stat55"], ['text' => "$stat56"], ['text' => "$stat57"]
                ],
                 [
                    ['text' => "$stat58"], ['text' => "$stat59"], ['text' => "$stat60"]
                ],
                [
                    ['text' => "$stat61"], ['text' => "$stat62"], ['text' => "$stat63"]
                ],
                [
                    ['text' => "$stat64"], ['text' => "$stat65"], ['text' => "$stat66"]
                ],
                [
                    ['text' => "$stat67"], ['text' => "$stat68"], ['text' => "$stat69"]
                ],
                [
                    ['text' => "$stat70"], ['text' => "$stat71"], ['text' => "$stat72"]
                ],
                [
                    ['text' => "$stat73"], ['text' => "$stat74"], ['text' => "$stat75"]
                ],
                 [
                    ['text' => "$stat76"], ['text' => "$stat77"], ['text' => "$stat78"]
                ],
                 [
                    ['text' => "$stat79"], ['text' => "$stat80"], ['text' => "$stat81"]
                ],
                [
                    ['text' => "$stat82"], ['text' => "$stat83"], ['text' => "$stat84"]
                ],
                [
                    ['text' => "$stat85"], ['text' => "$stat86"], ['text' => "$stat87"]
                ],
                [
                    ['text' => "$stat88"], ['text' => "$stat89"], ['text' => "$stat90"]
                ],
                [
                    ['text' => "$stat91"], ['text' => "$stat92"], ['text' => "$stat93"]
                ],
                [
                    ['text' => "$stat94"], ['text' => "$stat95"], ['text' => "$stat96"]
                ],
                 [
                    ['text' => "$stat97"], ['text' => "$stat98"], ['text' => "$stat99"]
                ],
                 [
                    ['text' => "$stat100"], ['text' => "$stat101"], ['text' => "$stat102"]
                ],
                [
                    ['text' => "$stat103"], ['text' => "$stat104"], ['text' => "$stat105"]
                ],
                [
                    ['text' => "$stat106"], ['text' => "$stat107"], ['text' => "$stat108"]
                ],
                [
                    ['text' => "$stat109"], ['text' => "$stat110"], ['text' => "$stat111"]
                ],
                [
                    ['text' => "$stat112"], ['text' => "$stat113"], ['text' => "$stat114"]
                ],
                [
                    ['text' => "$stat115"], ['text' => "$stat116"], ['text' => "$stat117"]
                ],
                 [
                    ['text' => "$stat118"], ['text' => "$stat119"], ['text' => "$stat120"]
                ],
                 [
                    ['text' => "$stat121"], ['text' => "$stat122"], ['text' => "$stat123"]
                ],
                [
                    ['text' => "$stat124"], ['text' => "$stat125"], ['text' => "$stat126"]
                ],
                [
                    ['text' => "$stat127"], ['text' => "$stat128"], ['text' => "$stat129"]
                ],
                [
                    ['text' => "$stat130"], ['text' => "$stat131"], ['text' => "$stat132"]
                ],
                [
                    ['text' => "$stat133"], ['text' => "$stat134"], ['text' => "$stat135"]
                ],
                [
                    ['text' => "$stat136"], ['text' => "$stat137"], ['text' => "$stat138"]
                ],
                 [
                    ['text' => "$stat139"], ['text' => "$stat140"], ['text' => "$stat141"]
                ],
                 [
                    ['text' => "$stat142"], ['text' => "$stat143"], ['text' => "$stat144"]
                ],
                [
                    ['text' => "$stat145"], ['text' => "$stat146"], ['text' => "$stat147"]
                ],
                [
                    ['text' => "$stat148"], ['text' => "$stat149"], ['text' => "$stat150"]
                ],
                [
                    ['text' => "$stat151"], ['text' => "$stat152"], ['text' => "$stat153"]
                ],
                [
                    ['text' => "$stat154"], ['text' => "$stat155"], ['text' => "$stat156"]
                ],
                [
                    ['text' => "$stat157"], ['text' => "$stat158"], ['text' => "$stat159"]
                ],
                 [
                    ['text' => "$stat160"], ['text' => "$stat161"], ['text' => "$stat162"]
                ],
                 [
                    ['text' => "$stat163"], ['text' => "$stat164"], ['text' => "$stat165"]
                ],
                [
                    ['text' => "$stat166"], ['text' => "$stat167"], ['text' => "$stat168"]
                ],
                [
                    ['text' => "$stat169"], ['text' => "$stat170"], ['text' => "$stat171"]
                ],
                [
                    ['text' => "$stat172"], ['text' => "$stat173"], ['text' => "$stat174"]
                ],
                [
                    ['text' => "$stat175"], ['text' => "$stat176"], ['text' => "$stat177"]
                ],
                [
                    ['text' => "$stat178"], ['text' => "$stat179"], ['text' => "$stat180"]
                ],
                 [
                    ['text' => "$stat181"], ['text' => "$stat182"], ['text' => "$stat183"]
                ],
                 [
                    ['text' => "$stat184"], ['text' => "$stat185"], ['text' => "$stat186"]
                ],
                [
                    ['text' => "$stat187"]
                ],
                
                [
                    ['text' => "🔙 برگشت"], ['text' => "💳 استعلام | قیمت ها"]
                ]
            ],
            'resize_keyboard' => true
        ])
    ]);
   
} 

elseif (in_array($textmassage, array("🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه"))) {
     
    $userservicc = $juser["service"];
    
      jijibot('sendmessage', [
            'chat_id' => $chat_id,
        'text' => "
  
درحال یافتن ارزانترین پنل ...
صبور باشید.

        ",]); 
    
    $str2 = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservicc);
    
    $str3 = str_replace(["🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه"], ["afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe"], $textmassage);
    $userservicp = $juser["panel"];
    
      //=========================
    $operator = array("019","activ","altel","beeline","claro","ee","globe","itelecom","kcell","kyivstar","lycamobile","matrix","megafon","movistar","mts","orange","pildyk","play","range1","redbull","redbullmobile","rostelecom","smart","sun","tele2","three","tigo","tmobile","tnt","virginmobile","virtual11","virtual12","virtual15","virtual16","virtual17","virtual18","virtual19","virtual2","virtual20","virtual21","virtual22","virtual23","virtual24","virtual4","virtual5","virtual6","virtual7","virtual8","virtual9","vodafone","yota","zz");
     $get = json_decode(file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getPrices&country=$str3&service=$userservicc"),true);
     foreach ($operator as $key3 => $vvvop) {
        
        
       
       
            $sssw = $get["$str3"]["$userservicc"]["$vvvop"]["cost"];
         $ssswm = $get["$str3"]["$userservicc"]["$vvvop"]["count"];
       
        if( $sssw !="" and  $sssw != "0" and  $ssswm !="" and  $ssswm != "0"){
        
       
$result[]=$vvvop;
$result2[]=$sssw;
$result3[]=$sssw;
$result4[]=$ssswm;

        }
        
      
        
       if ($vvvop == 'zz') {
        break;
    }
   }
  $sss = sort($result2 ,SORT_NUMERIC);
   $dffdff =  count($result);
 for($z = 0;$z <= $dffdff;$z++){
     
      $gets2 = array_search($result2[$z],$result3);
$stat2 = $result[$gets2];

$result60[]=$stat2;
unset($result2["$z"]);
unset($result3["$gets2"]);
unset($result["$gets2"]);
unset($result4["$gets2"]);
}

 
$jsetting20 = json_decode(file_get_contents("../../data/prics2/$str3.json"),true);	
$jsetting20["$userservicc"]["operator"]="$result60[0]|$result60[1]|$result60[2]|$result60[3]|$result60[4]";
$jsetting20 = json_encode($jsetting20,true);
file_put_contents("../../data/prics2/$str3.json",$jsetting20);
                   
 
    
    //============================
    
    
     $zaribb = $jseting["set"]["robelpric"];
      $zaribbb = $jsetingo["set"]["robelpric"];
        $zarib = $zaribb + $zaribbb;
    
    $jsetting21 = json_decode(file_get_contents("../../data/prics2/$str3.json"),true);	
$r3 = $jsetting21["$userservicc"]["operator"];

  $alll10 = explode("|", $r3);
             $m1 = "$alll10[0]";
             $m2 = "$alll10[1]";
              $m3 = "$alll10[2]";
               $m4 = "$alll10[3]";
                 $m5 = "$alll10[4]";
   
   $a1=  json_decode(file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getPrices&country=$str3&service=$userservicc"),true);
  
         
         
         
          $cos1 = (ceil($a1["$str3"]["$userservicc"]["$m1"]["cost"])* $zaribbb)+$zaribb;
         $mon1 = $a1["$str3"]["$userservicc"]["$m1"]["count"];
         
           $cos2 = (ceil($a1["$str3"]["$userservicc"]["$m2"]["cost"])* $zaribbb)+$zaribb;
         $mon2 = $a1["$str3"]["$userservicc"]["$m2"]["count"];
         
           $cos3 = (ceil($a1["$str3"]["$userservicc"]["$m3"]["cost"])* $zaribbb)+$zaribb;
         $mon3 = $a1["$str3"]["$userservicc"]["$m3"]["count"];
         
           $cos4 = (ceil($a1["$str3"]["$userservicc"]["$m4"]["cost"])* $zaribbb)+$zaribb;
         $mon4 = $a1["$str3"]["$userservicc"]["$m4"]["count"];
         
         $cos5 = (ceil($a1["$str3"]["$userservicc"]["$m5"]["cost"])* $zaribbb)+$zaribb;
         $mon5 = $a1["$str3"]["$userservicc"]["$m5"]["count"];

if($mon1 > 0){
$s1 = "قیمت پنل(1) : $cos1 تومان [$mon1 عدد]"."\n";
}
if($mon2 > 0){
$s2 = "قیمت پنل(2) : $cos2 تومان  [$mon2 عدد]"."\n";
}
if($mon3 > 0){
$s3 = "قیمت پنل(3) : $cos3 تومان  [$mon3 عدد]"."\n";
}
if($mon4 > 0){
$s4 = "قیمت پنل(4) : $cos4 تومان  [$mon4 عدد]"."\n";
}
if($mon5 > 0){
$s5 = "قیمت پنل(4) : $cos5 تومان  [$mon5 عدد]"."\n";
}
   
        
       jijibot('deletemessage', [
            'chat_id' => $chat_id,
                'message_id'=>$message_id + 1,
            ]);
    



    $stock = $juser["stock"];
    $npanel = $juser["panel"];
    if ($mon1 > 0 or $mon2 > 0 or $mon3 > 0 or $mon4 > 0 or $mon5 > 0  ){
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
        'text' => "
        💢 شما قصد خرید شماره مجازی با مشخصات زیر را دارید :
〰️〰️〰️〰️〰️〰️〰️
کشور : $textmassage
سرویس :  $str2
$s1 $s2 $s3 $s4 $s5

موجودی کیف پول طلایی شما : $stock تومان

❗️ ربات به صورت اتوماتیک ارزانترین پنل قابل دریافت شماره را برای شما انتخاب خواهد کرد.
〰️〰️〰️〰️〰️〰️〰️
آیا مایل به ادامه و خرید هستید ؟
.

        ",
                    'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "خیر منصرف شدم 👎"],['text' => "بله میخوام 👍"]
                    ],
                    [
                        ['text' => "♻️انتخاب کشور دیگه"]
                    ]
                    
                ],
            'resize_keyboard' => true
        ])
        
    ]); 
     $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["namecontry"]="$textmassage";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

    }else {
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
        'text' => "
        💢 شما قصد خرید شماره مجازی با مشخصات زیر را دارید :
〰️〰️〰️〰️〰️〰️〰️
کشور : $textmassage
سرویس :  $str2
قیمت : $ros0 تومان
موجودی شما : $stock تومان
〰️〰️〰️〰️〰️〰️〰️
⚠️ کشور مورد نطر در حال حاظر موجود نمیباشد !
   
🌟 لطفا کشور دیگری را انتخاب کنید یا ساعاتی دیگر مجدد امتحان کنید
.
        ",
         'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "🔙 برگشت"], ['text' => "♻️انتخاب کشور دیگه"]
                    ]
                    
                ],
            'resize_keyboard' => true
        ])
         ]); 
    }
}
elseif ($textmassage == "بببله میخوام  👍") {
    $stock = $juser["stock"];
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
لطفا نوع پرداخت رو انتخاب کنید :

💳 پرداخت آنلاین : متصل شدن به درگاه پرداخت ، پرداخت وجه به مقدار قیمت شماره.
💰 پرداخت از کیف پول : پرداخت وجه از کیف پول شما 

موجودی کیف پول طلایی شما : $stock تومان
",
             
                   'reply_markup' => json_encode([
                'keyboard' => [
                        [
                            ['text' => "💰 پرداخت از کیف پول"],
                            ['text' => "💳 پرداخت آنلاین "]
                        ],
                         [
                            ['text' => "🔙 برگشت"]
                        ]
                    ],
                    'resize_keyboard' => true
                ])
            ]);
    
}
elseif ($textmassage == "💳 پردfاخت آنلاین") {
     if ($blaklist["id"] != true){
         if ($activesell == "1"){
     $pp = $juser["price"];
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
✅ لینک درگاه پرداخت شما ساخته شد.

مبلغ : $pp تومان
 
از طریق دکمه زیر پرداخت کنید 👇👇
",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "💰 $pp تومان", 'url' => "$web/pay/pay.php?amount=$pp&callback=$web/pay/back-ss.php?user=$from_id"]
                        ],
                         [
                            ['text' => "❌ انصراف", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
                
            ]);
         }else {
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️ فروش به صورت موقت توسط مدیر غیر فعال شده است.
لطفا بعدا دوباره امتحان کنید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
         }
    else { 
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📛 متاسفانه شما از استفاده از ربات محروم شده اید.

در صورتی که اشتباهی رخ داده با پشتیبانی در ارتباط باشید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
    
}
elseif ($data == "ex") {
   
     jijibot('deletemessage', [
            'chat_id' => $chatid,
                'message_id'=>$messageid,
            ]);
    
}

elseif ($textmassage == "بله میخوام 👍") {
    
    jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
درحال دریافت شماره ....
صبور باشید
",
            
        ]);

 

   $shargp = $adminsql["sharg"];
   $namecontry = $juser["namecontry"];
     $str = $juser["price"];
    $userservicc = $juser["service"];
 
    
    $stock = $juser["stock"];
    if ($shargp >= $str ){
    
     
     
         if ($activesell == "1" or $from_id == "$admin[0]"){

       
         $countryy = str_replace(["🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه"], ["afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe"], $namecontry);
        $userservic = $juser["service"];
         $userservicop = $juser["panel"];
      
               $userservic = $juser["service"];
            
             
            
             
        
        $userservice = $juser["service"] ;
        
            $strservic = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservice);
            
//=================================
$jsetting21 = json_decode(file_get_contents("../../data/prics2/$countryy.json"),true);	
               $r3 = $jsetting21["$userservic"]["operator"];
               
               $alll10 = explode("|", $r3);
            
$zaribb = $jseting["set"]["robelpric"];
      $zaribbb = $jsetingo["set"]["robelpric"];
      $stokkj = $juser["stock"];

$dffdff =  count($alll10);

 $a1=  json_decode(file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getPrices&country=$countryy&service=$userservicc"),true);
foreach ($alll10 as $key3 => $vvvopt) {
   
    
   
  $cos1 = (ceil($a1["$countryy"]["$userservicc"]["$vvvopt"]["cost"])* $zaribbb)+$zaribb;
         $mon1 = $a1["$countryy"]["$userservicc"]["$vvvopt"]["count"];
    if($stokkj >= $cos1 and ($cos1 - $zaribb)!= "0"){
     
      
         $f1 =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getNumber&service=$userservicc&operator=$vvvopt&country=$countryy");
         
             $f2 =  explode(":", $f1);
              $ooknumber = "$f2[0]";
               $idnumber = "$f2[1]";
                 $numberfon = "$f2[2]";
              
              if($ooknumber == "ACCESS_NUMBER"){
                $s9 = $key3 + 1;
                $pp = $cos1;
                $op = $vvvopt;
                   $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
                   $juser["price"]="$cos1";
                   $juser = json_encode($juser,true);
                   file_put_contents("data/$from_id.json",$juser);
                 break; 
              }
    }
    if($stokkj < $cos1){
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "💳 موجودی کیف پول شما برای خرید کافی نمیباشد !
			
💎 قیمت شماره مورد نظر : $cos1 تومان
💰 موجودی کیف پول شما : $stokkj تومان

💳 برای افزایش موجودی کیف پول کافیست از دکمه شارژ حساب استفاده کنید سپس میتوانید نسبت به خرید اقدام کنید
ℹ


",
            'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                       ['text' => "🔙 برگشت"], ['text' => "💸 شارژ حساب"] 
                       
                    ],
                   
                ],
                'resize_keyboard' => true
            ])
        ]);
         break;
    }
     
  if ($key3 == "$dffdff") {
        jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "⚠️ کشور مورد نطر در حال حاظر موجود نمیباشد !
		
🌟 لطفا کشور دیگری را انتخاب کنید یا ساعاتی دیگر مجدد امتحان کنید

",
'reply_markup' => $keyborduser,
            ]);
        break;
        
    }
    
      if ($key3 == "4") {
        break;
    }
   }
//================================

  
     
                
            
            jijibot('deletemessage', [
            'chat_id' => $chat_id,
                'message_id'=>$message_id+1,
            ]);
        if ($ooknumber == "ACCESS_NUMBER")
        {
              $plusstock = $juser["stock"] - $juser["price"];
              $plusstockk = $adminsql["sharg"] - ( $juser["price"] - $jseting["set"]["robelpric"]);
              
 $rterr = $adminsql["stock"] + $juser["price"];
 
              
           jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
        
 ✅	شماره کشور مورد نظر با موفقیت ساخته شد 		
 ✅ شماره از پنل  شماره $s9 به قیمت $cos1 دریافت شد.
📞 شماره مجازی شما :
🅿️ +$numberfon

 شماره را همراه با پیش شماره در سرویس $strservic وارد کنید سپس منتظر دریافت کد در ربات بمانید .
شماره پس از 7 دقیقه لغو میشود.

.
",
             
                   'reply_markup' => json_encode([
                'keyboard' => [
                        [
                             ['text' => "❌ لغو شماره"], ['text' => "⛔️ اعلام مسدودی شماره"]
                        ]
                        
                    ],
                    'resize_keyboard' => true
                ])
            ]);
            
            jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
در انتظار دریافت کد ....

صبور باشد😌
    ",]);
           
$juser = json_decode(file_get_contents("data/$from_id.json"),true); 

$juser["country"]="+$numberfon";
$juser["numberid"]="$idnumber";
$juser["step"]="daryaftcod";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

$sod20 = $jseting["set"]["robelpric"];

$usercd = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM coduserbot WHERE id = '$from_id' LIMIT 1"));

 if ($usercd["id"] != true) {
        $connect->query("INSERT INTO `coduserbot` (`id`, `idnumber`, `number`, `date`, `time`, `idbot`, `sod`) VALUES ('$from_id', '$idnumber', '$numberfon', '0','$time_now','$usernamebot','$sod20')");
    }else {
        $connect->query("UPDATE coduserbot SET  idnumber = '$idnumber', number = '$numberfon', date = '0', time = '$time_now', idbot = '$usernamebot' , sod = '$sod20' WHERE id = '$from_id' LIMIT 1");
        
    }
    
    $timee = "$dat_h:$dat_min" ;
   
    
    
    
    $userscd = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM coduserbot WHERE numberid = '$idnumber' LIMIT 1"));
if ($userscd["numberid"] != true) {
    
    $time1 = time() + 600;
        $connect->query("INSERT INTO `numbers` (`numberid`, `id`, `idbot`, `timout`) VALUES ('$idnumber', '$from_id','$usernamebot','$time1')");
    }

        }
        
         if($ooknumber == "NO_BALANCE"){
           
            
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "
⚠️ شارژ پنل ربات به اتمام رسیده و در حال شارژ پنل هستیم. به دلیل فرآیند تبدیل ارز تا چند ساعت آینده پنل شارژ میشود و میتوانید اقدام به خرید شماره نمایید.
.
",
'reply_markup' => $keyborduser,
            ]);
        }
        
            
        
  
}else {
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️ فروش به صورت موقت توسط مدیر غیر فعال شده است.
لطفا بعدا دوباره امتحان کنید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
  }else {
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "⚠️ شارژ پنل ربات به اتمام رسیده است
                
به مدیر ربات اطلاع رسانی شد.
			
",
'reply_markup' => $keyborduser,
            ]);
        
          jijibot('sendmessage', [
                'chat_id' => "$admin[0]",
                'text' => "
⚠️ ادمین گرامی شارژ پنل ربات شما در به اتمام رسیده و یا از مقدار قیمت شماره درخواستی مشتری کم است. لطفا نسبت به شارژ پنل خود اقدام نمایید.

قیمت شماره : $str تومان

جهت شارژ پنل ابتدا به پنل مدریت در ربات خود رفته سپس اقدام به شارژ نمایید.

",]) ;
          
      }
} 
   


elseif ($textmassage == "👤 اطلاعات حساب" or ( $textmassage == "$sw12" and $update->message->text )) {
    
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        $stock = $juser["stock"];
        $numberby = $juser["numberby"];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🎫 حساب کاربری شما در ربات خرید شماره مجازی :

🗣 نام : $first_name
👾 شناسه : $from_id
🥇 موجودی کیف پول : $stock تومان
🏵 تعداد خرید : $numberby

", ]);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
} 
elseif ($textmassage == "💸 شارژ حساب"  or ( $textmassage == "$sw15" and $update->message->text )) {
     
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 چقدر میخوای شارژ کنی؟

⚠️ مبلغ رو به تومان و اعداد انگلیسی وارد کن مثلا 5000

⚠️ مبلغ وردی باید بین 3000 الی 100000 تومان باشد
",
             'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        $juser = json_decode(file_get_contents("data/$from_id.json"),true); 
$juser["step"]="upsharggg";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
} 
elseif ($juser["step"] == "upsharggg" and $textmassage != "🔙 برگشت") {
     
    if ( filter_var($textmassage,FILTER_VALIDATE_INT)) {
    if ($textmassage >= 3000 && $textmassage <= 100000) {
        
$ros369 = json_decode(file_get_contents("https://corto.ir/api.php?url=$web/pay/pay.php?amount=$textmassage.$usernamebot.$from_id.1"),true);
        
     
        
            $sdsdsd = $ros369["shorturl"];
            
           
           jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
✅ لینک درگاه پرداخت شما ساخته شد.

مبلغ : $textmassage تومان
 
 
از طریق دکمه زیر پرداخت کنید 👇👇
",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "💰 $textmassage تومان", 'url' => "$sdsdsd"]
                        ],
                         [
                            ['text' => "❌ انصراف", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
                
            ]);
        $juser = json_decode(file_get_contents("data/$from_id.json"),true); 
$juser["price"]="$textmassage";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
            

        
       
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "
⚠️ مبلغ وردی باید بین 3000 الی 100000 تومان باشد.
",
            
        ]);
    }
    }
    else { 
    
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا یک مقدار عددی وارد کنید :",
        ]);
}
} 
 elseif ($textmassage == "👮🏻 پشتیبانی"   or ( $textmassage == "$sw19" and $update->message->text )) {
     
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "👮🏻 همکاران ما در خدمت شما هستن !
	
🔘 در صورت وجود نظر , ایده , گزارش مشکل , پیشنهاد , ایراد سوال , یا انتقاد میتوانید با ما در ارتباط باشید 
💬 لطفا پیام خود را به صورت فارسی و روان ارسال کنید",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        
         $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="sup";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
} elseif ($textmassage == "🚦 راهنما"   or ( $textmassage == "$sw18" and $update->message->text )) {
    
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🚸 به بخش راهنما خوش امدید

🤗 شما با استفاده از این ربات هوشمند شماره مجازی کشور ها مختلف را به صورت ارزان خریدار می کنید.
♋️ تمام روند خرید و دریافت شماره و ثبت نام در برنامه مورد نظر کاملا اتوماتیک انجام می شود.
📴 با کم ترین هزینه ممکن در سریع ترین زمان و امن ترین حالت ممکن شماره مجازی خود را خریداری نمایید.
⚠️ در صورت بروز هرگونه مشکل با کلید بر روی دکمه پشتیبانی در منو اصلی با ما ارتباط برقرار نمایید.

🔽 از منو زیر جهت راهنمایی استفاده کنید 🔽",
            'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                        ['text' => "📲 شماره مجازی چیست؟"], ['text' => "🔔 سوالات متداول"]
                    ],
                    [
                        ['text' => "ℹ️ قوانین"], ['text' => "💡 درباره"]
                    ],
                    [
                        ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
} elseif ($textmassage == "📲 شماره مجازی چیست؟") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "📱شماره مجازی چیست؟

📍هنگام ثبت‌نام در اپلیکیشن‌های پیام ‌رسان و شبکه‌های اجتماعی موبایل، باید از شماره تلفن خود به عنوان شناسه استفاده کنید. اگر از کاربرانی هستید که علاقه‌ای به اشتراک‌گذاری شماره‌ی اصلی خود ندارید یا اینکه نیاز به ثبت‌نام بیش از یک بار در این برنامه‌ها دارید، می‌توانید از شماره‌های مجازی استفاده کنید. همچنین شماره مجازی این امکان را می‌دهد که بدون ثبت سیم کارت و اهراز هویت و بدون صرف وقت و هزینه صاحب شماره از کشور های مختلف شوید.

ℹ️مزایا و کاربرد شماره مجازی چیست؟

➊ تلگرام، واتس اپ، وایبر، اینستاگرام  و... برای ثبت‌نام به شماره تلفن شما نیاز دارند تا کدفعال‌سازی مربوطه را برای تشخیص هویت به تلفن‌تان ارسال کنند که به جای شماره اصلی خود میتوان از شماره مجازی برای فعال کردن حساب خود استفاده کرد.

➋ بسیاری از افراد به دلایل مختلف مانند مدیریت یک اکانت دیگر برای مباحث کاری یا... نیاز به اکانت دوم دارند تا بتوانند در عین ارتباط داشتن با مشتریان، از تلگرام شخصی و خصوصی خود نیز استفاده کنند.
 
➌ بدون ثبت نام در اپراتور و بدون صرف وقت و هزینه و اهراز هویت صاحب شماره مجازی می شوید .

➍ استفاده در تمامی اپلیکیشن های اجتماعی با شماره از کشورهای مختلف! همراه با هویتی ناشناس

🤖 @$usernamebot",
    ]);
} 

elseif ($textmassage == "🔔 سوالات متداول") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "❓سوالات متداول

❓شماره خریدم کد نمیده چیکار کنم؟
▫️جواب : ابتدا فیلم آموزش نحوه خرید را مشاهده کنید. جهت دریافت کد پس از اطمینان از ارسال کد توسط اپلیکیشن درخواستی به شماره مورد نظر 30 ثانیه صبر کنید و سپس بر روی دکمه دریافت کد کلیک کنید ، اگر پس از گذشت 5 دقیقه از دریافت شماره، کد را دریافت نکردید بر روی دکمه بازگشت کلیک کنید سپس مجددا نسبت به دریافت شماره جدید و کد اقدام نمایید.

❓شماره رو وارد آپ کردم میگه شماره اشتباهه(مسدوده) و پیام Banned Number میدهد چکار کنم؟
▫️جواب : این حالت بیشتر برای شماره چین ، روسیه و آمریکا پیش میاد. بر روی دکمه بازگشت کلیک کنید سپس مجددا نسبت به دریافت شماره جدید و کد اقدام نمایید.

❓کد تایید گرفتم اما وارد آپ نکردم، باید چیکار کنم؟
▫️جواب : متاسفانه امکان بازگشت وجه در چنین وضعیتی وجود ندارد. چون پول شماره در پنل خارجی همزمان با دریافت کد از حساب ما کم میشود‌.

❓شماره از ربات خریدم اما بعد از چند دقیقه شماره دلیت اکانت شد علت چیه؟
▫️جواب : علت دلیت اکانت شدن شماره‌ حساس شدن تلگرام نسبت به ip شماست.
از آنجایی که تلگرام مخالف با عضو فیک است نباید بیش از 3 شماره مجازی بر روی یک ip ثبت نام کنید.
اگر قصد دارید تعداد بالا شماره مجازی خریداری و ثبت نام کنید، باید آی پی خود را پس از ثبت هر شماره تغییر دهید.
برای تغییر ip دو راه وجود دارد :
1- استفاده از فیلترشکن
2- خاموش و روشن کردن مودم ، یا خاموش و روشن کردن دیتا در تلفن همراه برای چند دقیقه موجب تغییر آی پی شما خواهد شد.

❓شماره‌ای که برای تلگرام خریدم بعد از دریافت کد یه نفر دیگه داخل اکانت بود یا two-step verification روی اکانت فعال بود، و نتوستم وارد اکانت بشم ، الان چکار کنم؟
▫️جواب : با توجه به اینکه شماره ها مستقیما از پنل های خارجی دریافت می شوند و ربات استوری نامبر تنها واسط بین کاربر و پنل است امکان بررسی شماره ها توسط ما امکان پذیر نیست! به همین علت گاها ممکن است بعد از دریافت کد اکانتی از قبل توسط شماره مورد نظر در اپلیکیشن مورد نظرتان خصوصا تلگرام فعال باشد؛ تنها راه حل برای جلوگیری از بروز این مشکل، چک کردن شماره مجازی قبل از دریافت کد است، بررسی این که شماره مجازی در اپلیکیشن مورد نظرتان قبلا ثبت شده است یا خیر به راحتی امکان پذیر است، برای تلگرام اگر شماره ثبت شده باشد بلافاصله با وارد کردن شماره در تلگرام پیغام ارسال کد به تلگرام فعال دیگر نمایش داده می شود و مانند شماره های ریجستر نشده نیست و این مورد به راحتی برای تلگرام و دیگر اپلیکیشن ها قابل بررسی است؛ در هر صورت اگر شماره ای دریافت کردید که از قبل ثبت شده بود (به ندرت پیش می آید) هرگونه عواقب آن بر عهده خریدار خواهد بود و استوری نامبر هیچ گونه مسئولیتی در رابطه با بی دقتی کاربران را برعهده نمی گیرد.

💎 سوالاتان در این بخش نبود ؟ به منوی اصلی برگردید و با پشتیبانی در تماس باشید 

🤖 @$usernamebot",
    ]);
} 
 elseif ($textmassage == "ℹ️ قوانین") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "⚠️ قوانین ربات خرید شماره مجازی

➊ - پس از تحویل شماره توسط ربات بلافاصله شماره را در نرم افزار اصلی وارد کنید و بعد از 2 دقیقه کلید دریافت کد را بزنید تا کد وریفای برایتان ارسال گردد. در صورتی که پس از 5 دقیقه بعد از دریافت شماره موفق به دریافت کد نشدید دکمه بازگشت را بزنید و شماره جدید دریافت کنید.
➋ - برای هر شماره فقط یکبار کد فعالسازی از سمت اپراتور کشور ارائه دهنده ارسال میشود و مجدد کد ارسال نمیشود لذا پس از دریافت کد سریعا در نرم افزار بزنید تا کد منقضی نشود.
➌ - بر روی شماره‌های دریافتی تایید دو مرحله‌ای فعال کنید تا امنیت شماره برای شما صد در صد شود.
➍ - اغلب شماره‌های مجازی (به جز شماره‌های ستاره‌دار) دارای ۴ تا ۷ روز محدودیت هستند، پس از ۴ تا ۷ روز شما قادر به ارسال پیام به اکانت‌های ایرانی در تلگرام هستید.
➎- ساخت ربات تبچی با هر شماره‌ای اشتباه است زیرا که سیاست تلگرام این است که از تبلیغات جلوگیری کند و اگر روی شماره ها تبچی نصب کنید شماره دلیت خواهد شد.
➏ - توصیه میشود در یک روز بیش از 1 شماره مجازی روی یک دستگاه ثبت نام نکنید چون موجب دلیت شدن اکانت میشود.
➐ - تمامی شماره‌های ربات خام هستند یعنی قبل از شما ثبت نام نکرده‌اند ، به جز برخی شماره‌های کشور چین و آمریکا که برای جلوگیری از این شماره را توی تلگرام چک کنید و سپس اقدام به گرفتن کد کنید.
➑ - هنگام ثبت شماره برای اپلیکیشن تلگرام ابتدا فیلترشکن را روشن کنید سپس اقدام به دریافت شماره کنید، موقع ثبت اسم به زبان آن کشور اسم وارد کنید(نمونه اسم روسیه: привет و چین: 你好) یا از اعداد انگلیسی (...123) استفاده کنید. پس از وارد شدن به اکانت، عکس پروفایل و یوزرنیم بزارید و کانال و گروه ایجاد کنید و پست ارسال کنید و اینکه حداقل 5 دقیقه داخل اکانت باشید و فعالیت کنید و خارج نشوید.
➒ - با توجه به اینکه تلگرام مخالف عضو فیک هست لذا استوری نامبر هیچ مسئولیتی در قبال دلیت شدن اکانت (Delete account) یا لاگ اوت (Log out) شدن اکانت ندارد. همچنین پس از تحویل کد، ربات دیگر هیچ مسئولیتی در مورد شماره ندارد.
➓ - در صورت عمل نکردن به بندهای بالا عواقب آن بر عهده شماست و وجهی بازگشت داده نمی‌شود.

🤖 @$usernamebot",
    ]);
} elseif ($textmassage == "💡 درباره") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "ℹ️ درباره ربات  :

🤖 ربات شماره مجازی برنامه نویسی شده توسط حسین داودی ویکی
🔘 تمام حقوق و متون پیام ها و سورس کد ربات محفوظ است و هر نوع کپی بر داری پیگرد قانونی دارد

🎈 برنامه نویسی شده جهت خرید شماره مجازی به صورت خودکار و سهولت در خرید شماره مجازی مطمعن و اسان

🤖 @I_love_gad",
    ]);
}

//===========================================================
elseif (($textmassage == '🥇 ساخت ربات جدید' or $textmassage == '🚦 راهنمای ساخت ربات' or
$textmassage == '💻 ربات من' or
$textmassage == '🤖 ربات شماره مجازی شما [ربات نمایندگی]' or $textmassage == "🔙  برگشت" or ( $textmassage == "$sw14" and $update->message->text ))and $ss6 == "❌ خاموش" ) {
    
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
⚠️ این بخش موقتا توسط مدیر خاموش شده است!
            ",
           
        ]);
}


elseif ($textmassage == '🤖 ربات شماره مجازی شما [ربات نمایندگی]' or $textmassage == "🔙  برگشت" or ( $textmassage == "$sw14" and $update->message->text )) {
    
      
    
       
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 به بخش ساخت ربات خوش اومدی.

در این قسمت میتونی به راحتی ربات اختصاصی خودتو بسازی و کسب درآمد کنی از فروش شماره.
ربات ما تمام امکانات رو براتون فراهم میکنه.

تو بخش راهنمای همین بخش میتونید اطلاعات بیشتر کسب کنید .👇👇

            ",
               'reply_markup' => json_encode([
            'keyboard' => [
                [
                     ['text' => "💻 ربات من"], ['text' => "🥇 ساخت ربات جدید"]
                ],
                 
                [
                    ['text' => "🔙 برگشت"], ['text' => "🚦 راهنمای ساخت ربات"]
                ],
            ],
            'resize_keyboard' => true 
             ])
        ]);
    
}
elseif ($textmassage == '💻 ربات من') {
   
    
  if ( $adminsqluser["id"] == true) {
       
         
            
             $usernbot = $adminsqluser["userbot"];
      $usernnbot = $adminsqluser["allsellprice"];
      $usernnnbot = $adminsqluser["allnum"];
      $usernnnnbot = $adminsqluser["sharg"];
       $usernnnnssbot = $adminsqluser["stock"];
      
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 به پنل فروش خوش اومدی .

مشخصات و آمار ربات های شما :

💠 تعداد ربات های ثبت شده شما 1 عدد
💠 یوزرنیم ربات شما : @$usernbot
💠 مبلغ کل فروش شما : $usernnbot تومان
💠 تعداد شماره های فروخته شده : $usernnnbot عدد


✳️ موجودی صندق شما جهت انجام تسفیه : $usernnnnssbot تومان
✳️ باقی مانده شارژ پنل شما : $usernnnnbot تومان
.
            ",
             'reply_markup' => json_encode([
            'keyboard' => [
              
                [
                    ['text' => "🔙 برگشت"], ['text' => "❌ حذف ربات من"]
                ],
                
            ],
            'resize_keyboard' => true
        ])
        ]);
        
  }else {
      jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
⚠️ شما هیچ ربات ثبت شده ای  ندارید.
            ", ]);
  }
  
}

elseif ($textmassage == '🥇 ساخت ربات جدید') {
     if($from_id != "$admin[0]"){
       if ($adminsqluser["id"] != true){
          
           if($from_id == "902251413" or $from_id == "1070530397"){
               
                 jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
💢 توکن ربات خود را که در بوت فادر ساخته اید ارسال نمایید .
درصورتی که اطلاعات کافی در مورد توکن ندارید میتونوانید از دکمه راهنمای ساخت ربات استفاده کنید.
مانند نمونه زیر:

900371469:AAFo1LEF5Yjy8T5ZARmgYM3RqZ74-Jz7Tu9
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙  برگشت"],['text' => "🚦 راهنمای ساخت ربات"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
      $juserr = json_decode(file_get_contents("data/$from_id.json"),true);	
$juserr["step"]="sendtokent";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);
           }
           
       $sqqq = $jsetingo["set"]["pricbottala"];
        
          $juserr = json_decode(file_get_contents("data/$from_id.json"),true);	
$juserr["price"]="$sqqq";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);

    $ros369 = json_decode(file_get_contents("https://corto.ir/api.php?url=$web/pay/pay.php?amount=$sqqq.$usernamebot.$from_id.3"),true);
            $sdsdsd = $ros369["shorturl"];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
⭕️ برای ساخت ربات طلایی شماره مجازی بایذ مبلغ $sqqq تومان پرداخت کنید. یکبار برای همیشه.

❗️ این مبلغ برای جلوگیری از ساخت ربات های هرزنامه و بی جهت در نظر گرفته شده است.
(در واقعیت افراد کمی حاضرن این مبلغو پرداخت کنند برای ساخت ربات طلایی ، این یعنی رقیب کمتر و فروش بیشتر که به نفع همه سازنده ها هستش😉)

❗️ جهت پرداخت و ساخت ربات روی دکمه پرداخت زیر بزنید. پس از پرداخت ربات از شما توکن خواهد خواست برای ساخت ربات.👇👇

            ",
             'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "💸 پرداخت", 'url' => "$sdsdsd"]
                        ],
                         [
                            ['text' => "❌ انصراف", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
         }else{
    $uu = $adminsqluser["userbot"];
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
⚠️ شما به محدودیت ساخت ربات رسیده اید .

❗️هر کاربر حداکثر میتواند 1 ربات در سرور شماره مجازی بسازد.
〰️〰️〰️〰️〰️〰️〰️
لیست ربات های شما :
1 - @$uu
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"],['text' => "❌ حذف ربات من"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]); 
     $juserr = json_decode(file_get_contents("data/$from_id.json"),true);	
$juserr["step"]="none";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);
}}else{
   
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
⚠️ شما مدیر ربات فعلی هستید و قادر به ساخت نمایندگی نمیباشید
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]); 
}    
}



elseif ( $textmassage == "❌ حذف ربات من" ) {
     $un = $adminsqluser["userbot"];
     
     jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
⚠️ شما قصد پاک کردن ربات خود به آیدی @$un را دارید. 
❗️ ربات شما دیگر قابل بازگردانی نخواهد بود.

آیا از حذف ربات خود مطمئن میباشید؟      
        ",
         'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                    ['text' => "🔙 برگشت"], ['text' => "✅ بله"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
}
elseif ( $textmassage == "✅ بله" ) {
    $un = $adminsqluser["userbot"];
    $token = $adminsqluser["token"];
    $token20 = $adminsqluser["dsod"];
     if (strpos($token20, '|') !== false) {
       $alll25 = explode("|", $token20);
             $cros00025 = $alll25[0];
             $cod00025 = $alll25[1];
       


   $source = file_get_contents("data/listnama.txt");
     $source = str_replace("$un/","",$source);
     file_put_contents("data/listnama.txt",$source);
     
        if ($cod00025 != "new"){     


$source200 = file_get_contents("../$cros00025/data/listnama.txt");
     $source200 = str_replace("$un/","",$source200);
     file_put_contents("../$cros00025/data/listnama.txt",$source200);
        }
        
    }
    if ($adminsqluser["id"] == "$from_id"){
        file_get_contents("http://api.telegram.org/bot".$token."/deletewebhook?url=$web22/bots/$un/bot.php");
       $path ="../$un";
         $pathdata ="../$un/data";
         $pathpay ="../$un/pay";
     
$directory_handle2 = opendir("$pathdata");
while($directory_item = readdir($directory_handle2)) {
@unlink("$pathdata/".$directory_item);
}
$directory_handle3 = opendir("$pathpay");
while($directory_item = readdir($directory_handle3)) {
@unlink("$pathpay/".$directory_item);
}
closedir($directory_handle3);
rmdir("$pathpay");

closedir($directory_handle2);
rmdir("$pathdata");

$directory_handle1 = opendir("$path");
while($directory_item = readdir($directory_handle1)) {
@unlink("$path/"."$directory_item");
}

closedir($directory_handle1);
rmdir("$path");

    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
ربات شما به آیدی @$un با موفقیت پاک شد
        ",
         'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
     $connect->query("DELETE FROM admin WHERE id ='$from_id'");
    $juserr = json_decode(file_get_contents("data/$from_id.json"),true);	
$juserr["step"]="none";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);
    }else {
     
        jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
شما هیچ ربات ثبت شده ای ندارید.
        "
    ]);
    }
    }
elseif ($textmassage == '🚦 راهنمای ساخت ربات' ) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 به بخش راهنمای ساخت ربات خوش اومدی.

یکی از گزینه های زیر رو انتخاب کن 👇👇
            ",
             'reply_markup' => json_encode([
            'keyboard' => [
                 [
                    ['text' => "🥇 امکانات ربات چیه ؟"]
                ],
                
                [
                    ['text' => "🔙  برگشت"], ['text' => "🤖 توکن ربات چیست؟"]
                ],
                
            ],
            'resize_keyboard' => true
        ])
        ]);
}

elseif ($textmassage == '🥇 امکانات ربات چیه ؟' ) {
       
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
🥇 امکانات ربات چیه ؟


امکانات :
✅ فروش شماره مجازی : نامحدود
✅  بدون نیاز به درگاه زرین پال
✅ نیاز به شارژ پنل 
✅ امکان ارائه ربات نمایندگی
✅ دریافت پورسانت ربات نمایندگی تا 2 لول
✅ امکان فوروارد پیام به همه کاربران 
✅ امکان ارسال پیام به همه کاربران 
✅ امکان ارسال پیام به کاربر خاص 
✅ قابلیت تنظیم اتصال به کانال ربات 
✅ بخش پشتیبانی کاربران 
✅امکان زیر مجموعه گیری 
✅ امکان افزایش یا کاهش موجودی کاربران 
✅ امکان تنظیم قیمت های فروش 
✅ امکان ارسال و فوروارد پیام به نمایندگان 
✅ امکان مشاهده لیست نمایندگان 
✅ قابلیت پشتیبانی از مشتریان از داخل ربات
✅ امکان تنظیم متن و عکس بنر زیرمجموعه گیری
✅ ارسال گزارش فروش نمایندگان شما به کانال شما
✅ امکان تنظیم پورسانت زیر مجموعه گیری
✅ امکان ساخت و باطل کردن  کد یکبار مصرف ساخت ربات نمایندگی
✅ امکان فروش شارژ سیمکارت های همراه اول و ایرانسل و رایتل به صورت مستقیم و پین
✅ دارای کنترل مرکز برای روشن و خاموش کردن بخش های مختلف ربات
✅ امکان شارژ پنل ربات و درخواست تسفیه از داخل پنل مدیریت ربات خود
✅ و کلی امکانت دیگر ...
تسلط کامل بر همه بخش های ربات.



〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
️
توضیحات : این نوع ربات مخصوص  کسانی هستش که مرچند کد درگاه زرین پال #ندارند . 
در این نوع ربات شما باید پنل فروشتون رو داخل خود رباتتون شارژ کنید تا بتونید شماره بفروشید.
تقریبا 95% ربات مستقل هستش و فقط نیاز به شارژ پنل  دارید.
〰️〰️〰️〰️〰️〰️〰️〰️
❗️ برای شارژ پنل باید از طریق پنل مدیریت داخل ربات خودتون اقدام کنید.
❗️برای دسترسی به پنل مدیریت ، داخل ربات  کافیه کلمه پنل  رو ارسال کنید تا پنلتون ظاهر بشه


            ",
            
        ]);
  
}

elseif ($textmassage == '🤖 توکن ربات چیست؟' ) {
       
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
🤖 توکن ربات چیست؟
توکن در واقع رمز اتصال شما به رباتتون هستش بر روی سرور های تلگرام.

💢 چچور یه ربات روی سرور تلگرام بسازید و توکن رو بگیرید؟

1️⃣ به ربات @BotFather مراجعه کنید.
2️⃣ ربات رو /start کنید.
3️⃣ دستور /newbot رو ارسال کنید برای ساخت ربات جدید.
4️⃣ سپس بوت فادر از شما میخواد یه نام برای رباتتون انتخاب کنید. هر اسمی که میخواید.
5️⃣ سپس بوت فادر از شما میخواد یه یوزنیم برای رباتتون انتخاب کنید. یوزر نیم هرچی که میدید حتما آخرش باید bot داشته باشه. برای مثال : selln256umberbot
6️⃣ تبریک شما با موفقیت رباتتون رو ساختید . حالا بوت فادر یه پیام مانند نمونه  زیر  براتون فرستاده که حاوی توکن ربات شما هستش 👇👇

Use this token to access the HTTP API:
900371469:AAFo1LEF5Yjy8T5ZARmgYM3RqZ74-Jz7Tu9
            ",
            
        ]);
   
}
elseif ( $textmassage == "🔼 افزایش شارژ پنل"or ( $textmassage == "$fw33" and $update->message->text )) {
     jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
لطفا مبلغ قابل شارژ را به تومان و به اعداد انگلیسی وارد نمایید :

برای مثال : 20000
        ",
    ]);
  
     $juserr = json_decode(file_get_contents("data/$from_id.json"),true);	
$juserr["step"]="upshargp";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);
    
}
elseif ( $juser["step"] == "upshargp") {
    
    
    
    $ros369 = json_decode(file_get_contents("https://corto.ir/api.php?url=$web/pay/pay.php?amount=$textmassage.$usernamebot.$from_id.2"),true);
    
    $sdsdsd = $ros369["shorturl"];
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
✅ لینک درگاه پرداخت شما ساخته شد.

مبلغ : $textmassage تومان
 
از طریق دکمه زیر پرداخت کنید 👇👇
",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "💰 $textmassage تومان", 'url' => "$sdsdsd"]
                        ],
                         [
                            ['text' => "❌ انصراف", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
                
            ]);
    
     $juserr = json_decode(file_get_contents("data/$from_id.json"),true);	
$juserr["price"]="$textmassage";
$juserr["step"]="none";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);
    
}
//============================================================
elseif ($update->message && $update->message->reply_to_message &&( $from_id == $admin[0] or $from_id == $admin[1]) && $tc == "private" and $textmassage != "بلاک"  and $textmassage != "آنبلاک") {
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "پاسخ شما برای فرد ارسال شد ☑️"
    ]);
    jijibot('sendmessage', [
        "chat_id" => $update->message->reply_to_message->forward_from->id,
        "text" => "👮🏻پاسخ پشتیبان برای شما :

`$textmassage`",
        'parse_mode' => 'MarkDown'
    ]);
}

elseif ($data == "join") {
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$fromid"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        
        jijibot('sendmessage', [
            'chat_id' => $chatid,
            'text' => "عضویت شما تایید شد ✅
	
📍 اکنون میتوانید از دکمه های زیر استفاده کنید",
           'reply_markup' => $keyborduser,
        ]);
         if ($jusert["step"] == "pinn"){
              
            $name = str_replace(["`", "*", "_", "[", "]"], ["", "", "", "", ""], $firstname);
          
       $start = $jusert["inviter"];
            $useryy = json_decode(file_get_contents("data/$start.json"),true);
        $stoockk = $useryy["stock"];
        $pluscoin = $stoockk + $porsant;
        
         $stoockkkk = $adminsql["sharg"];
        $pluscoink = $stoockkkk - $porsant;
        $connect->query("UPDATE admin SET sharg = '$pluscoink'  WHERE id = '$admin[0]' LIMIT 1");
         jijibot('sendmessage', [
            'chat_id' => "$start",
            'text' => "🌟 کاربر [$name](tg://user?id=$fromid) با استفاده از لینک دعوت شما وارد ربات شده بود اکنون عضو کانال ربات شد.  
 $porsant تومان پورسانت دریافت نمودید.
  
💰 موجودی کیف پول  شما : $pluscoin

",
            'parse_mode' => 'Markdown',
        ]);
        
            $usery = json_decode(file_get_contents("data/$start.json"),true);	

$usery["stock"]="$pluscoin";
$usery = json_encode($usery,true);
file_put_contents("data/$start.json",$usery);

  $userr = json_decode(file_get_contents("data/$fromid.json"),true);	
$userr["step"]="none";
$userr = json_encode($userr,true);
file_put_contents("data/$fromid.json",$userr);

             
        
        }
    } else {
        jijibot('answercallbackquery', [
            'callback_query_id' => $membercall,
            'text' => "❌ هنوز داخل کانال @$channel عضو نیستید",
            'show_alert' => true
        ]);
    }
}  elseif ($textmassage == "🛍 خرید های من" or ( $textmassage == "$sw16" and $update->message->text )) {
    $listby = $juser["listby"];
    $getby = explode("^", $listby);
    if (count($getby) > 1) {
        for ($z = 1; $z <= count($getby) - 1; $z++) {
            $result = $result . "$z - $getby[$z]" . "\n";
        }
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🛍 لیست تمام خرید های شما :
	
$result",
        ]);
    } else {
        jijibot('sendmessage', [
             'chat_id' => $chat_id,
            'text' => "❌ شما تاکنون خرید نکرده اید",
            
        ]);
    }
}
elseif ($juser["step"] == "sup" && $tc == "private") {
  
        
    if(strpos($textmassage,"کص") !== false or strpos($textmassage,'گاییدم') !== false or strpos($textmassage,"کیر") !== false or strpos($textmassage,"ننتو") !== false or strpos($textmassage,"جنده") !== false or strpos($textmassage,"پدرسگ") !== false or  strpos($textmassage,'حرومزاده') !== false){
        
        
         
         $userr = json_decode(file_get_contents("data/$from_id.json"),true);	
$userr["step"]="blok";
$userr = json_encode($userr,true);
file_put_contents("data/$from_id.json",$userr);
         
    }   else{ 
        
    jijibot('ForwardMessage', [
        'chat_id' => $admin[0] ,
        'from_chat_id' => $chat_id,
        'message_id' => $message_id
    ]);
    jijibot('sendmessage', [
        'chat_id' => $admin[0] ,
        'from_chat_id' => $chat_id,
       'text' => "
👆👆👆👆👆👆
پیام بالا توسط کاربر  [$from_id](tg://user?id=$from_id)  ارسال شده است
       ",
        'parse_mode'=>"MarkDown",
         'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "📛 مسدود کردن کاربر", 'callback_data' => "blok|$from_id"]
                            ,
                            ['text' => " 💬 ارسال پاسخ به کاربر", 'callback_data' => "answer|$from_id|$message_id"]
                            
                        ],
                       
                    ],
                    'resize_keyboard' => true
                ]),
    ]);
    
 
    
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "📍 پیام شما با موفقیت ارسال شد منتظر پاسخ پشتیبانی باشید",
    ]);
    }
    } 




// ===============================================================

elseif (strpos($data,"blok|") !== false) {
    
     $getby05555 = explode("|", $data);
      $idd = $getby05555[1];
      
    
     jijibot('sendmessage', [
        "chat_id" => $chatid,
        "text" => "
📛 کاربر [$idd](tg://user?id=$idd)  با موفقیت از ربات محروم شد.

جهت آزاد کردن کاربر از پنل مدیریت استفاده کنید.

        ️",
         'parse_mode'=>"MarkDown",
    ]);
    
  
    
      
         $userr = json_decode(file_get_contents("data/$idd.json"),true);	
$userr["step"]="blok";
$userr = json_encode($userr,true);
file_put_contents("data/$idd.json",$userr);
    
}

elseif (strpos($data,"answer|") !== false) {
    
     $getby05555 = explode("|", $data);
      $idd = $getby05555[1];
       $midd = $getby05555[2];
    
     jijibot('sendmessage', [
        "chat_id" => $chatid,
        "text" => "
پاسخ خود را ارسال نمایید : 

⚠️فقط پیام متنی قابل ارسال میباشد.
        ️"
    ]);
    
   
    
      
         $userr = json_decode(file_get_contents("data/$fromid.json"),true);	
$userr["step"]="answer|$idd|$midd";
$userr = json_encode($userr,true);
file_put_contents("data/$fromid.json",$userr);
    
}

elseif (strpos($juser["step"],"answer|") !== false) {
    
  
  $getby05555 = explode("|", $juser["step"]);
      $idd = $getby05555[1];
       $midd = $getby05555[2];
     
    jijibot('sendmessage', [
        "chat_id" => "$idd",
        'reply_to_message_id' =>"$midd",
        "text" => "
👮🏻پاسخ پشتیبان برای شما :

$textmassage

",
        'parse_mode' => 'MarkDown'
    ]);
   
     jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "پاسخ شما برای فرد ارسال شد ☑️"
    ]);
    
  
    
       $userr = json_decode(file_get_contents("data/$from_id.json"),true);	
$userr["step"]="none";
$userr = json_encode($userr,true);
file_put_contents("data/$from_id.json",$userr);
   
}


//===========================================================================================  
//panel admin

elseif (in_array($from_id, $admin) or in_array($fromid, $admin)){
if ($textmassage == "/panel" or $textmassage == "پنل") {
   
       
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "🚦 ادمین عزیز به پنل مدریت ربات خوش امدید",
                'reply_markup' => $keybordadmin,
            ]);
        
    
} elseif ($textmassage == "برگشت 🔙") {
    
       
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "🚦 به منوی مدیریت بازگشتید",
                'reply_markup' => $keybordadmin,
            ]);
            
            $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser["getfile"]="0";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
        
    
} 
elseif ($textmassage == '🔼 افزایش شارژ پنل') {
    
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
این امکان به زودی اضافه میشود...
",
            ]);
}
elseif ($textmassage == '📍 افزایش | کاهش موجودی'or ( $textmassage == "$fw43" and $update->message->text )) {
    
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📍 در خط اول ایدی عددی فرد و در خط دوم مقدار موجودی را اسال کنید
📍 اگر میخواهید موجودی فر را کم کنید از علامت - منفی استفاده کنید

مانند مثال زیر :
85971242
5000

⚠️ در صورت #افزایش موجودی کاربر ، این مبلغ از شارژ پنل شما #کسر میگردد.
⚠️ در صورت #کاهش موجودی کاربر ، این مبلغ به شارژ پنل شما #افزوده میشود.
",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       
           $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="senddowncoin";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
  
    }
elseif ($juser["step"] == "senddowncoin" && $tc == "private" and $chat_id == "$admin[0]") {
    
    $all = explode("\n", $textmassage);
    $userget = "$all[0]";
    $usergetss = "$all[1]";
    
    $usergets = json_decode(file_get_contents("data/$userget.json"),true);
   
    $stoockk = $usergets["stock"];
    $stoocskk = $adminsql["sharg"];
     if ($usergetss <= ($stoocskk - 20000)){
         if ($usergets["step"] !="daryaftcod"){
    if($usergetss <= 50000){
    if ($usergets == true) {
         if ($usergetss >= 0) {
        $coinusergets = $stoockk;
        $pluscoinusergets = $stoockk + $all[1];
        jijibot('sendmessage', [
            'chat_id' => "$admin[0]",
            'text' => "
انتقال پول با موفقیت انجام شد ✅
            ",
        ]);
        jijibot('sendmessage', [
            'chat_id' => $userget,
            'text' => "ℹ️ $all[1] تومان به شما هدیه داده شد !

💰 میزان جدید کیف پول شما : $pluscoinusergets
☂️ میزان قبلی   : $coinusergets
🎈 از طرف مدیر ربات !",
            'parse_mode' => 'Markdown',
        ]);
         $juserrr = json_decode(file_get_contents("data/$userget.json"),true);
$juserrr["stock"]="$pluscoinusergets";
$juserrr = json_encode($juserrr,true);
file_put_contents("data/$userget.json",$juserrr);

$juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

        if ($usergetss >= 0){
            $plussharg = $stoocskk - $usergetss  ;
        $connect->query("UPDATE admin SET sharg = '$plussharg' WHERE id = '$admin[0]' LIMIT 1");
        }
         if ($usergetss < 0){
            $plussharg = $stoocskk + (-($usergetss) ) ;
        $connect->query("UPDATE admin SET sharg = '$plussharg' WHERE id = '$admin[0]' LIMIT 1");
        }
        jijibot('sendmessage', [
            'chat_id' => "$admin[0]",
            'text' => "
 ✅ انتقال پول با موفقیت انجام شد
 
 آیدی انتقال دهنده : [$from_id](tg://user?id=$from_id)
مقدار شارژ پنل شما : $plussharg تومان

مشخصات کاربر 👇👇

مبلغ انتقال :  $all[1] تومان
 آیدی کاربر : [$userget](tg://user?id=$userget)
میزان موجودی فعلی کاربر : $pluscoinusergets تومان
میزان موجودی قبلی کاربر : $coinusergets تومان


            ",
            'parse_mode' => 'Markdown',
        ]);
   
         } else {
       
       if ($stoockk >= ($usergetss * (-1)) ){
           
           $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
           
        $coinusergets = $stoockk;
        $pluscoinusergets = $stoockk + $all[1];
        jijibot('sendmessage', [
            'chat_id' => "$admin[0]",
            'text' => "
انتقال پول با موفقیت انجام شد ✅
            ",
        ]);
        jijibot('sendmessage', [
            'chat_id' => $userget,
            'text' => "ℹ️ $all[1] تومان باز کیف پول شما کسر شد !

💰 میزان جدید کیف پول شما : $pluscoinusergets
☂️ میزان قبلی   : $coinusergets
🎈 از طرف مدیر ربات !",
            'parse_mode' => 'Markdown',
        ]);
        



        if ($usergetss >= 0){
            $plussharg = $stoocskk - $usergetss  ;
        $connect->query("UPDATE admin SET sharg = '$plussharg' WHERE id = '$admin[0]' LIMIT 1");
        }
         if ($usergetss < 0){
            $plussharg = $stoocskk + (-($usergetss) ) ;
        $connect->query("UPDATE admin SET sharg = '$plussharg' WHERE id = '$admin[0]' LIMIT 1");
        }
        jijibot('sendmessage', [
            'chat_id' => "$admin[0]",
            'text' => "
 ✅ انتقال پول با موفقیت انجام شد
 
 آیدی انتقال دهنده : [$from_id](tg://user?id=$from_id)
مقدار شارژ پنل شما : $plussharg تومان

مشخصات کاربر 👇👇

مبلغ انتقال :  $all[1] تومان
 آیدی کاربر : [$userget](tg://user?id=$userget)
میزان موجودی فعلی کاربر : $pluscoinusergets تومان
میزان موجودی قبلی کاربر : $coinusergets تومان


            ",
            'parse_mode' => 'Markdown',
        ]);
    $juserrr = json_decode(file_get_contents("data/$userget.json"),true);
$juserrr["stock"]="$pluscoinusergets";
$juserrr = json_encode($juserrr,true);
file_put_contents("data/$userget.json",$juserrr);
         
    }
    
         else {
              jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📍 مبلغ کسر بیشتر از موجودی کاربر میباشد

موجودی کاربر : $stoockk تومان
",
 'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
           $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
         }
         }
    } else {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📍 کاربر مورد نظر یافت نشد ! شاید هنوز ربات را استارت نکرده باشد !			
🎈 شناسه کاربری هر فرد در قسمت اطلاعات حساب وی مشخص هست 
🌟 مثال :
267785153",
        ]);
    }
} else {
     $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
   jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⚠️ حداکثر مبلغ قابل انتقال 50000 تومان میباشد.",
        ]);
}
}else{
     $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⚠️ کاربر در انتظار دریافت کد میباشد و شما قادر به تغییر موجودی وی نمیباشید.",
        ]);
}
}else{
    
     $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⚠️ شارژ پنل ربات شما کمتر از مبلغ $usergetss تومان مباشد
            
            مبلغ 20000 باید در کف شارژ پنل باقی بماند.
            .",
        ]);
}

}



elseif ($textmassage == "📍 امار ربات"or ( $textmassage == "$fw30" and $update->message->text )) {
   
       number_format(number,decimals,decimalpoint,separator);
       
        $dsa = $adminsql["dsod"];
        $files = scandir("data/");
       $alluser = count($files) - 4;
       $aa369 = $jseting["allnum"];
      
       $bb = $aa * $dsa ;
       $allsellp229 = number_format($jseting["allsell"]);
       $mogodi = $adminsql["stock"];
       $mogodish= number_format($adminsql["sharg"]);
       
         $listby =file_get_contents("data/listnama.txt");
    $getby = explode("|", $listby);
      $lev1 = $getby[0];
      $lev2 = $getby[1];
     $getby1 = explode("/", $lev1);
      $getby2 = explode("/", $lev2);
    $alllev1 = count($getby1) - 1;
    $alllev2 = count($getby2) - 1;
    
     $plusbyy1 = $jseting["allnumn"]["level1"]  ;
     $plussell1 = $jseting["allselln"]["level1"] ;
     
     $plusbyy2 = $jseting["allnumn"]["level2"]  ;
     $plussell2 = $jseting["allselln"]["level2"] ;
       for ($z >= 0 ; $z <= $alllev1; $z++) {
            $idbot = $getby1[$z];
            $juser0 = json_decode(file_get_contents("../$idbot/data/seting.json"),true);
            $aa = $juser0["allnum"];
            $allsellp = $juser0["allsell"];
            
            $all11212 = $all11212 + $aa ;
            $all11212s = $all11212s + $allsellp ;
       }
        for ($z >= 0 ; $z <= $alllev2; $z++) {
            $idbot = $getby2[$z];
            $juser0 = json_decode(file_get_contents("../$idbot/data/seting.json"),true);
            $aa22 = $juser0["allnum"];
            $allsellp22 = $juser0["allsell"];
            
            $all11212ff = $all11212ff + $aa22 ;
            $all11212sff = $all11212sff + $allsellp22 ;
       }
       
       $xds11234 = number_format(($all11212s / 100 ) * 3);
        $xds11234ff =number_format(($all11212sff / 100 ) * 2);
        
        
           
      //====================  member
        
          $ordersm = mysqli_query($connect, "select * from ordersm WHERE idbot = '$usernamebot'");
        $allordersm = mysqli_num_rows($ordersm);
        
$e1 = "0";
$e2 = "0";
$e3 = "0";
$e4 ="0";
$e5 ="0";
 foreach ($ordersm as $key => $aauserr) {
              $abb = $aauserr["id"];
               $abuser = $aauserr["iduser"];
               $abuserss = $aauserr["statos"];
                $abidbot = $aauserr["idbot"];
                 $abprice = $aauserr["price"];
                  $abprice2 = $aauserr["member"];
                  $abprice3 = $aauserr["sodbot"];
               
                
        if($abidbot =="$usernamebot"){
            if($abuserss =="✅ تکمیل شد"){
            $e1 = $e1 + 1;
               }
                if($abuserss =="مبلغ برگشت داده شد"){
            $e2 = $e2 + 1;
               }
               if($abuserss !="مبلغ برگشت داده شد"){
            $e3 = $e3 + $abprice;
             $e4 = $e4 + $abprice2;
             $e5 = $e5 + $abprice3;
               }
        }        
                
  if ($key == $allordersm) {
        break;
    }
    
   
}
$sod = $jseting["set"]["memberpric"];
$dfa2 = $e4 * $sod ;
$dfa1 = $e4 / 1000 ;

 $e3 = number_format($e3);
 $e5 = number_format($e5);
       //====================
 
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
 
〰️〰️🔻آمار ربات شما🔻〰〰〰
		
📌 تعداد کل عضو ها : $alluser
📌 تعداد کل شماره های فروخته شده : $aa369
📌 مجموع فروش شما : $allsellp229 تومان

〰️〰️🔻آمار فروش ممبر🔻〰️〰️

•  تعداد کل سفارشات ممبر : $allordersm
•  سفارشات تکمیل شده : $e1
•  سفارشات رد شده : $e2
•  مبلغ کل سفارشات ممبر : $e3 تومان
•  تعداد کل ممبر های فروش رفته : K $dfa1
•  سود بدست آمده از فروش ممبر : $e5 تومان

〰️〰️🔻آمار نمایندگی ها🔻〰️〰️

تعداد نماینده ها👇
➖نمایندگان لِوِل1 : $alllev1 عدد
➖نمایندگان لِوِل2 : $alllev2 عدد

تعداد شماره فروخته شده👇
➖نمایندگان لول1 : $all11212 عدد
➖نمایندگان لول2 : $all11212ff عدد

مجموع سود شما از فروش نمایندگان تا کنون👇
➖نمایندگان لول1 (3% سود) : $xds11234 تومان
➖نمایندگان لول2 (2% سود) : $xds11234ff تومان

ا〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️


📌 شارژ پنل : $mogodish تومان

",
        ]);
    
}  elseif ($textmassage == '📍 ارسال به همه'or ( $textmassage == "$fw34" and $update->message->text )) {
    
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا متن یا رسانه خود را ارسال کنید [میتواند شامل عکس , گیف یا فایل باشد]  همچنین میتوانید رسانه را همراه با کشپن [متن چسپیده به رسانه ارسال کنید] 🚀",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="sendtoall";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    
} elseif ($textmassage == '📍 فروارد همگانی'or ( $textmassage == "$fw35" and $update->message->text )) {
    
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا متن خود را فوروارد کنید  🚀",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="fortoall";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    
}



elseif ($textmassage == '⛔️ توقف فروش'or ( $textmassage == "$fw52" and $update->message->text )) {
  
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️ فروش شماره متوقف شد .",
            
        ]);
        
$jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["active"]="0";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

    
}

elseif ($textmassage == '❎ شروع فروش'or ( $textmassage == "$fw53" and $update->message->text )) {
  
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "✅ فروش شماره فعال شد .",
            
        ]);
       
$jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["active"]="1";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

    
}


elseif ($textmassage == '📨 ارسال پیام به کاربر'or ( $textmassage == "$fw38" and $update->message->text )) {
   
       
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا پیام رو با فرمت زیر ارسال کنید :

آیدی عددی کاربر : پیام
            
            ",
             
        ]);
       
 $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="sendidp";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

    
}
elseif ($juser["step"] == "sendidp" && $tc == "private" and in_array($from_id, $admin)) {
    
   $alll = explode(":", $textmassage);
             $idd = "$alll[0]";
             $payam = "$alll[1]";
jijibot('sendmessage', [
            'chat_id' => $idd,
            'text' => "📩 یک پیام از سوی پشتیبانی برای شما دریافت شد : 
$payam",
        ]);
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
            ✅ پیام شما با موفقیت به کاربر  ارسال شد.
            [$idd](tg://user?id=$idd) 
            ",
            'parse_mode' => 'Markdown',
        ]);
         $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

}
//=====================================================================

//==================================================



elseif ($juser["step"] == "sendtoall" && $tc == "private") {
    
    if ($textmassage != "برگشت 🔙") {
         $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

        set_time_limit(600);
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "در حال ارسال پیام...",
        ]);
       
         $directory_handle2 = opendir("data/");
while($directory_item = readdir($directory_handle2)) {
 $uss = str_replace(".json","",$directory_item);
 if($uss > 0){
 jijibot('sendmessage', [
            'chat_id' => $uss,
            'text' => "$textmassage",
        ]);
        
}
}
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "پیام با موفقیت به همه ارسال شد",
        ]);
        
       
       
    }
} elseif ($juser["step"] == "fortoall" && $tc == "private") {
     set_time_limit(600);
    if ($textmassage != "برگشت 🔙") {
        
          $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "در حال ارسال پیام...",
        ]);
          $directory_handle2 = opendir("data/");
while($directory_item = readdir($directory_handle2)) {
 $uss = str_replace(".json","",$directory_item);
 if($uss > 0){
 jijibot('ForwardMessage', [
        'chat_id' => $uss ,
        'from_chat_id' => $chat_id,
        'message_id' => $message_id,
        ]);
 }
}
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "پیام با موفقیت به همه فوروارد شد",
        ]);
        
      
       
    }
}
elseif ($textmassage == "📢 تنظیم کانال ربات" or ( $textmassage == "$fw39" and $update->message->text ) && in_array($from_id, $admin)) {

    
        
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="setch";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 لطفا آیدی کانال ربات را بدون @ ارسال کنید :

برای مثال :
channeltest
〰️〰️〰️〰️〰️〰️〰️〰️
❗️ عضویت کاربران ربات در این کانال اجباری خواهد بود.
❗️ گزارش های فروش به این کانال ارسال خواهد شد.
⚠️ دقیت کنید که #حتما این ربات در کانال مد نظر، #مدیر باشد.

.     
            ",
        ]);
    
}
elseif ($juser["step"] == "setch" ) {

    if ($textmassage != "برگشت 🔙") {
        
        $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["channel"]="$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
✅ کانال ربات با موفقیت تنظیم شد.

آیدی کانال ربات :
🆔 @$textmassage

.
            " ,
        ]);
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }
}

//================================================ویرایشگر دکمه ها

elseif ($textmassage == '🛠 ویرایش دکمه ها'or ( $textmassage == "$fw54" and $update->message->text )) {
  
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 تو این قسمت میتونی متن دکمه های ربات رو تغییر بدی.
دکمه های کدوم بخشو میخوای اصلاح کنید؟
            ",
            'reply_markup' => json_encode([
                'keyboard' => [
                     [
                        ['text' => "🏬 پنل مدیریت"],['text' => "🏠صفحه اصلی"]
                    ],
                     [
                        ['text' => "✔️ بخش خدمات سیمکارت.."],['text' =>"✔️ بخش خدمات تلگرام"]
                    ],
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       
}
elseif ($textmassage == '✔️ بخش خدمات تلگرام') {
  
          
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 تو این قسمت میتونی متن دکمه های ربات رو تغییر بدی.
کدوم دکمه این بخش رو میخوای اصلاح کنی؟
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                     [
                            ['text' => "👇👇 کیبرد خدمات تلگرام ربات 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ افزایش ممبر گروه", 'callback_data' => "sw33"],['text' => "ℹ️ افزایش ممبر کانال ", 'callback_data' => "sw34"]
                        ],
                         
                         [
                            ['text' => "❌ خروج از حالت ویرایش", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
          }
          
    elseif ($data == "backedit3") {
  
         jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
💢 تو این قسمت میتونی متن دکمه های ربات رو تغییر بدی.
کدوم دکمه این بخش رو میخوای اصلاح کنی؟
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                     [
                            ['text' => "👇👇 کیبرد خدمات تلگرام ربات 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ افزایش ممبر گروه", 'callback_data' => "sw33"],['text' => "ℹ️ افزایش ممبر کانال ", 'callback_data' => "sw34"]
                        ],
                         
                         [
                            ['text' => "❌ خروج از حالت ویرایش", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
        
        
        }      
          
elseif ($textmassage == '✔️ بخش خدمات سیمکارت..') {
  
          
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 تو این قسمت میتونی متن دکمه های ربات رو تغییر بدی.
کدوم دکمه این بخش رو میخوای اصلاح کنی؟
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                     [
                            ['text' => "👇👇 کیبرد خدمات سیمکارت اعتباری ربات 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ خرید بسته اینترنت", 'callback_data' => "sw32"],['text' => "ℹ️ خرید شارژ ", 'callback_data' => "sw11"]
                        ],
                         
                         [
                            ['text' => "❌ خروج از حالت ویرایش", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
          }
          
    elseif ($data == "backedit2") {
  
         jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
💢 تو این قسمت میتونی متن دکمه های ربات رو تغییر بدی.
کدوم دکمه این بخش رو میخوای اصلاح کنی؟
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                     [
                            ['text' => "👇👇 کیبرد خدمات تلگرام ربات 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ خرید بسته اینترنت", 'callback_data' => "sw32"],['text' => "ℹ️ خرید شارژ ", 'callback_data' => "sw11"]
                        ],
                         
                         [
                            ['text' => "❌ خروج از حالت ویرایش", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
        
        
        }      
          
elseif ($textmassage == '🏠صفحه اصلی') {
  
          if($usernamebot != "Rabbit_NumberBot"){
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 تو این قسمت میتونی متن دکمه های ربات رو تغییر بدی.
کدوم دکمه این بخش رو میخوای اصلاح کنی؟
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                     [
                            ['text' => "👇👇 صفحه اصلی ربات 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ خرید شماره", 'callback_data' => "sw10"],['text' => "ℹ️ خرید شارژ ", 'callback_data' => "sw11"]
                        ],
                         [
                            ['text' => "ℹ️ خدمات سیمکارت اعتباری", 'callback_data' => "sw30"],['text' => "ℹ️ خدمات تلگرام", 'callback_data' => "sw31"]
                        ],
                         [
                            ['text' => "ℹ️ نمایش اطلاعات کاربر", 'callback_data' => "sw12"],['text' => "ℹ️ استعلام قیمت", 'callback_data' => "sw13"]
                        ],
                         [
                            ['text' => "ℹ️ ارائه نمایندگی", 'callback_data' => "sw14"],['text' => "ℹ️ شارژ کیف پول", 'callback_data' => "sw15"]
                        ],
                         [
                            ['text' => "ℹ️ خرید های کاربر", 'callback_data' => "sw16"],['text' => "ℹ️ زیرمجموعه گیری", 'callback_data' => "sw17"]
                        ],
                         [
                            ['text' => "ℹ️ راهنما", 'callback_data' => "sw18"],['text' => "ℹ️ پشتیبانی", 'callback_data' => "sw19"]
                        ],
                         [
                            ['text' => "👇👇 بخش خرید شارژ 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ همراه اول", 'callback_data' => "sw20"],['text' => "ℹ️ ایرانسل", 'callback_data' => "sw21"]
                        ],
                        [
                            ['text' => "ℹ️ رایتل", 'callback_data' => "sw22"]
                        ],
                         [
                            ['text' => "--------------------------------------------------", 'callback_data' => "ff9"]
                        ],
                         [
                            ['text' => "❌ خروج از حالت ویرایش", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
          }
          
            if($usernamebot == "Rabbit_NumberBot"){
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 تو این قسمت میتونی متن دکمه های ربات رو تغییر بدی.
کدوم دکمه این بخش رو میخوای اصلاح کنی؟
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                     [
                            ['text' => "👇👇 صفحه اصلی ربات 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ خرید شماره", 'callback_data' => "sw10"],['text' => "ℹ️ خرید شارژ ", 'callback_data' => "sw11"]
                        ],
                         [
                            ['text' => "ℹ️ خدمات سیمکارت اعتباری", 'callback_data' => "sw30"],['text' => "ℹ️ خدمات تلگرام", 'callback_data' => "sw31"]
                        ],
                         [
                            ['text' => "ℹ️ نمایش اطلاعات کاربر", 'callback_data' => "sw12"],['text' => "ℹ️ استعلام قیمت", 'callback_data' => "sw13"]
                        ],
                         [
                            ['text' => "ℹ️ ارائه نمایندگی", 'callback_data' => "sw14"],['text' => "ℹ️ شارژ کیف پول", 'callback_data' => "sw15"]
                        ],
                         [
                            ['text' => "ℹ️ خرید های کاربر", 'callback_data' => "sw16"],['text' => "ℹ️ زیرمجموعه گیری", 'callback_data' => "sw17"]
                        ],
                         [
                            ['text' => "ℹ️ راهنما", 'callback_data' => "sw18"],['text' => "ℹ️ پشتیبانی", 'callback_data' => "sw19"]
                        ],
                         [
                            ['text' => "👇👇 بخش خرید شارژ 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ همراه اول", 'callback_data' => "sw20"],['text' => "ℹ️ ایرانسل", 'callback_data' => "sw21"]
                        ],
                        [
                            ['text' => "ℹ️ دکمه سفارشی", 'callback_data' => "sw60"],  ['text' => "ℹ️ رایتل", 'callback_data' => "sw22"]
                        ],
                         [
                            ['text' => "--------------------------------------------------", 'callback_data' => "ff9"]
                        ],
                         [
                            ['text' => "❌ خروج از حالت ویرایش", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
          }
       
}
elseif ($data == "backedit") {
  
        if($usernamebot != "Rabbit_NumberBot"){
         jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
💢 تو این قسمت میتونی متن دکمه های ربات رو تغییر بدی.
کدوم دکمه این بخش رو میخوای اصلاح کنی؟
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                     [
                            ['text' => "👇👇 صفحه اصلی ربات 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ خرید شماره", 'callback_data' => "sw10"],['text' => "ℹ️ خرید شارژ ", 'callback_data' => "sw11"]
                        ],
                         [
                            ['text' => "ℹ️ خدمات سیمکارت اعتباری", 'callback_data' => "sw30"],['text' => "ℹ️ خدمات تلگرام", 'callback_data' => "sw31"]
                        ],
                         [
                            ['text' => "ℹ️ نمایش اطلاعات کاربر", 'callback_data' => "sw12"],['text' => "ℹ️ استعلام قیمت", 'callback_data' => "sw13"]
                        ],
                         [
                            ['text' => "ℹ️ ارائه نمایندگی", 'callback_data' => "sw14"],['text' => "ℹ️ شارژ کیف پول", 'callback_data' => "sw15"]
                        ],
                         [
                            ['text' => "ℹ️ خرید های کاربر", 'callback_data' => "sw16"],['text' => "ℹ️ زیرمجموعه گیری", 'callback_data' => "sw17"]
                        ],
                         [
                            ['text' => "ℹ️ راهنما", 'callback_data' => "sw18"],['text' => "ℹ️ پشتیبانی", 'callback_data' => "sw19"]
                        ],
                         [
                            ['text' => "👇👇 بخش خرید شارژ 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ همراه اول", 'callback_data' => "sw20"],['text' => "ℹ️ ایرانسل", 'callback_data' => "sw21"]
                        ],
                        [
                              ['text' => "ℹ️ رایتل", 'callback_data' => "sw22"]
                        ],
                         [
                            ['text' => "--------------------------------------------------", 'callback_data' => "ff9"]
                        ],
                         [
                            ['text' => "❌ خروج از حالت ویرایش", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
        
        
        }
        if($usernamebot == "Rabbit_NumberBot"){
         jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
💢 تو این قسمت میتونی متن دکمه های ربات رو تغییر بدی.
کدوم دکمه این بخش رو میخوای اصلاح کنی؟
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                     [
                            ['text' => "👇👇 صفحه اصلی ربات 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ خرید شماره", 'callback_data' => "sw10"],['text' => "ℹ️ خرید شارژ ", 'callback_data' => "sw11"]
                        ],
                         [
                            ['text' => "ℹ️ خدمات سیمکارت اعتباری", 'callback_data' => "sw30"],['text' => "ℹ️ خدمات تلگرام", 'callback_data' => "sw31"]
                        ],
                         [
                            ['text' => "ℹ️ نمایش اطلاعات کاربر", 'callback_data' => "sw12"],['text' => "ℹ️ استعلام قیمت", 'callback_data' => "sw13"]
                        ],
                         [
                            ['text' => "ℹ️ ارائه نمایندگی", 'callback_data' => "sw14"],['text' => "ℹ️ شارژ کیف پول", 'callback_data' => "sw15"]
                        ],
                         [
                            ['text' => "ℹ️ خرید های کاربر", 'callback_data' => "sw16"],['text' => "ℹ️ زیرمجموعه گیری", 'callback_data' => "sw17"]
                        ],
                         [
                            ['text' => "ℹ️ راهنما", 'callback_data' => "sw18"],['text' => "ℹ️ پشتیبانی", 'callback_data' => "sw19"]
                        ],
                         [
                            ['text' => "👇👇 بخش خرید شارژ 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ همراه اول", 'callback_data' => "sw20"],['text' => "ℹ️ ایرانسل", 'callback_data' => "sw21"]
                        ],
                        [
                            ['text' => "ℹ️ دکمه سفارشی", 'callback_data' => "sw60"],  ['text' => "ℹ️ رایتل", 'callback_data' => "sw22"]
                        ],
                         [
                            ['text' => "--------------------------------------------------", 'callback_data' => "ff9"]
                        ],
                         [
                            ['text' => "❌ خروج از حالت ویرایش", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
        
        }
        $juser = json_decode(file_get_contents("data/$fromid.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$fromid.json",$juser);
       
}
if (in_array($data, array("sw10", "sw11", "sw12", "sw13","sw14", "sw15","sw16", "sw17", "sw18","sw19", "sw20","sw21", "sw22","sw60","sw30","sw31","sw32","sw33","sw34"))){
    
    
$jsetingbotten = json_decode(file_get_contents("data/setbotten.json"),true);	
$dddd = $jsetingbotten["$data"];
if($dddd !=""){$ddddf = $dddd ;  }
if($dddd ==""){  $ddddf = str_replace(["sw10", "sw11", "sw12", "sw13","sw14", "sw15","sw16", "sw17", "sw18","sw19", "sw20","sw21", "sw22","sw60","sw30","sw31","sw32","sw33","sw34"], ["ℹ️ خرید شماره", "ℹ️ خرید شارژ ", "ℹ️ نمایش اطلاعات کاربر", "ℹ️ استعلام قیمت", "ℹ️ ارائه نمایندگی", "ℹ️ شارژ کیف پول", "ℹ️ خرید های کاربر", "ℹ️ زیرمجموعه گیری", "ℹ️ راهنما", "ℹ️ پشتیبانی", "ℹ️ همراه اول", "ℹ️ ایرانسل", "ℹ️ رایتل" ,"دکمه سفارشی" ,"ℹ️ خدمات سیمکارت  اعتباری" ,"ℹ️ خدمات تلگرام","ℹ️ خرید بسته اینترنت" ,"ℹ️ افزایش ممبر گروه","ℹ️ افزایش ممبر کانال"], $data);}

   if (in_array($data, array("sw10", "sw11", "sw12", "sw13","sw14", "sw15","sw16", "sw17", "sw18","sw19", "sw20","sw21", "sw22","sw60","sw31"))){
       jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
🔧 ویرایش دکمه  $ddddf

متن مورد نظرتون جهت تغییر نام دکمه ارسال نمایید.
",

                     'reply_markup' => json_encode([
                'inline_keyboard' => [
                      
                         [
                           ['text' => "برگشت 🔙", 'callback_data' => "backedit"],  ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
       
   }if (in_array($data, array("sw30", "sw32"))){
            
             jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
🔧 ویرایش دکمه  $ddddf

متن مورد نظرتون جهت تغییر نام دکمه ارسال نمایید.
",

                     'reply_markup' => json_encode([
                'inline_keyboard' => [
                      
                         [
                           ['text' => "برگشت 🔙", 'callback_data' => "backedit2"],  ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
        }
        if (in_array($data, array("sw33", "sw34"))){
            
             jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
🔧 ویرایش دکمه  $ddddf

متن مورد نظرتون جهت تغییر نام دکمه ارسال نمایید.
",

                     'reply_markup' => json_encode([
                'inline_keyboard' => [
                      
                         [
                           ['text' => "برگشت 🔙", 'callback_data' => "backedit3"],  ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
        }
    $juser = json_decode(file_get_contents("data/$fromid.json"),true);	
$juser["step"]="set_$data";
$juser = json_encode($juser,true);
file_put_contents("data/$fromid.json",$juser);
}
if(strpos($juser["step"],'set_') !== false){
    
   $botten = str_replace("set_", "", $juser["step"]); 
   
   
   
   
   if (!in_array($textmassage, array("$sw10", "$sw12", "$sw13", "$sw14","$sw15", "$sw16","$sw17", "$sw18", "$sw19","$sw60", "$sw30","$sw31", "$sw32","$sw33","$sw34","$fw30","$fw31","$fw32","$fw33","$fw34","$fw35","$fw36","$fw37","$fw38","$fw39","$fw40","$fw41","$fw42","$fw43","$fw44","$fw45","$fw46","$fw47","$fw48","$fw49","$fw50","$fw51","$fw52","$fw53","$fw54","$fw55","$fw56","$fw57", "برگشت 🔙" , "🏬 پنل مدیریت" , "🏠صفحه اصلی", "✔️ بخش خدمات سیمکارت" ,  "✔️ بخش خدمات تلگرام"))){
   
    $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

 $juseryy = json_decode(file_get_contents("data/setbotten.json"),true);	
$juseryy["$botten"]="$textmassage";
$juseryy = json_encode($juseryy,true);
file_put_contents("data/setbotten.json",$juseryy);

  
  jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
✅ نام دکمه با موفقیت تغییر کرد.
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                      
                         [
                           ['text' => "برگشت 🔙", 'callback_data' => "backedit"],  ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
       
}else{
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
دکمه دیگری با این نام  وجود دارد.
نام دیگری انتخاب نمایید و یا نام دکمه موجود را تعویض نمایید.
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                      
                         [
                           ['text' => "برگشت 🔙", 'callback_data' => "backedit"],  ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
         $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
        exit();
}
    
}
//============ویرایش دکمه های پنل
elseif ($textmassage == '🏬 پنل مدیریت') {
  
        
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 تو این قسمت میتونی متن دکمه های ربات رو تغییر بدی.
کدوم دکمه این بخش رو میخوای اصلاح کنی؟
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                     [
                            ['text' => "👇👇 پنل مدیریت 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ آمار ربات", 'callback_data' => "fw30"],['text' => "ℹ️ شارژ پنل", 'callback_data' => "fw31"]
                        ],
                        [
                            ['text' => "ℹ️ درخواست تسویه", 'callback_data' => "fw32"],['text' => "ℹ️ افزایش شارژ پنل", 'callback_data' => "fw33"]
                        ],
                         [
                            ['text' => "ℹ️ ارسال به همه", 'callback_data' => "fw34"],['text' => "ℹ️ فوروارد به همه", 'callback_data' => "fw35"]
                        ],
                        [
                            ['text' => "ℹ️ ارسال به نمایندگان", 'callback_data' => "fw36"],['text' => "ℹ️ فوروارد به نمایندگان", 'callback_data' => "fw37"]
                        ],
                         [
                            ['text' => "ℹ️ ارسال پیام به کاربر", 'callback_data' => "fw38"],['text' => "ℹ️ تنظیم کانال ربات", 'callback_data' => "fw39"]
                        ],
                        [
                            ['text' => "ℹ️ کنترل مرکزی", 'callback_data' => "fw40"],['text' => "ℹ️ انتقال مالکیت ربات", 'callback_data' => "fw41"]
                        ],
                         [
                            ['text' => "ℹ️ تعیین سود فروش", 'callback_data' => "fw42"],['text' => "ℹ️ افزایش|کاهش موجودی", 'callback_data' => "fw43"]
                        ],
                        [
                            ['text' => "ℹ️ حذف کاربر از لیست سیاه", 'callback_data' => "fw44"],['text' => "ℹ️ افزودن کاربر به لیست سیاه", 'callback_data' => "fw45"]
                        ],
                         [
                            ['text' => "ℹ️ پورسانت زیر مجموعه گیری", 'callback_data' => "fw46"],['text' => "ℹ️ پیام ساخت موفق نمایندگی", 'callback_data' => "fw47"]
                        ],
                        [
                            ['text' => "ℹ️ باطل کردن رمز یکبارمصرف", 'callback_data' => "fw48"],['text' => "ℹ️ ساخت کد یکبار مصرف", 'callback_data' => "fw49"]
                        ],
                         [
                            ['text' => "
ℹ️ ویرایش بنر زیرمجموعه گیری", 'callback_data' => "fw50"],['text' => "ℹ️ لیست نمایندگان", 'callback_data' => "fw51"]
                        ],
                        [
                            ['text' => "ℹ️ شروع فروش", 'callback_data' => "fw52"],['text' => "ℹ️ توقف فروش", 'callback_data' => "fw53"]
                        ],
                        [
                            ['text' => "ℹ️ ویرایش دکمه ها", 'callback_data' => "fw54"],['text' => "ℹ️ خروج از پنل", 'callback_data' => "fw55"]
                        ],
                        
                         [
                            ['text' => "--------------------------------------------------", 'callback_data' => "ff9"]
                        ],
                         [
                            ['text' => "❌ خروج از حالت ویرایش", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
       
}
elseif ($data == "backeditp") {
  
        
         jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
💢 تو این قسمت میتونی متن دکمه های ربات رو تغییر بدی.
کدوم دکمه این بخش رو میخوای اصلاح کنی؟
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                     [
                            ['text' => "👇👇 پنل مدیریت 👇👇", 'callback_data' => "ff9"]
                        ],
                        [
                            ['text' => "ℹ️ آمار ربات", 'callback_data' => "fw30"],['text' => "ℹ️ شارژ پنل", 'callback_data' => "fw31"]
                        ],
                        [
                            ['text' => "ℹ️ درخواست تسویه", 'callback_data' => "fw32"],['text' => "ℹ️ افزایش شارژ پنل", 'callback_data' => "fw33"]
                        ],
                         [
                            ['text' => "ℹ️ ارسال به همه", 'callback_data' => "fw34"],['text' => "ℹ️ فوروارد به همه", 'callback_data' => "fw35"]
                        ],
                        [
                            ['text' => "ℹ️ ارسال به نمایندگان", 'callback_data' => "fw36"],['text' => "ℹ️ فوروارد به نمایندگان", 'callback_data' => "fw37"]
                        ],
                         [
                            ['text' => "ℹ️ ارسال پیام به کاربر", 'callback_data' => "fw38"],['text' => "ℹ️ تنظیم کانال ربات", 'callback_data' => "fw39"]
                        ],
                        [
                            ['text' => "ℹ️ کنترل مرکزی", 'callback_data' => "fw40"],['text' => "ℹ️ انتقال مالکیت ربات", 'callback_data' => "fw41"]
                        ],
                         [
                            ['text' => "ℹ️ تعیین سود فروش", 'callback_data' => "fw42"],['text' => "ℹ️ افزایش|کاهش موجودی", 'callback_data' => "fw43"]
                        ],
                        [
                            ['text' => "ℹ️ حذف کاربر از لیست سیاه", 'callback_data' => "fw44"],['text' => "ℹ️ افزودن کاربر به لیست سیاه", 'callback_data' => "fw45"]
                        ],
                         [
                            ['text' => "ℹ️ پورسانت زیر مجموعه گیری", 'callback_data' => "fw46"],['text' => "ℹ️ پیام ساخت موفق نمایندگی", 'callback_data' => "fw47"]
                        ],
                        [
                            ['text' => "ℹ️ باطل کردن رمز یکبارمصرف", 'callback_data' => "fw48"],['text' => "ℹ️ ساخت کد یکبار مصرف", 'callback_data' => "fw49"]
                        ],
                         [
                            ['text' => "
ℹ️ ویرایش بنر زیرمجموعه گیری", 'callback_data' => "fw50"],['text' => "ℹ️ لیست نمایندگان", 'callback_data' => "fw51"]
                        ],
                        [
                            ['text' => "ℹ️ شروع فروش", 'callback_data' => "fw52"],['text' => "ℹ️ توقف فروش", 'callback_data' => "fw53"]
                        ],
                        [
                            ['text' => "ℹ️ ویرایش دکمه ها", 'callback_data' => "fw54"],['text' => "ℹ️ خروج از پنل", 'callback_data' => "fw55"]
                        ],
                        
                         [
                            ['text' => "--------------------------------------------------", 'callback_data' => "ff9"]
                        ],
                         [
                            ['text' => "❌ خروج از حالت ویرایش", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
        $juser = json_decode(file_get_contents("data/$fromid.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$fromid.json",$juser);
       
}
if (in_array($data, array("fw30","fw31","fw32","fw33","fw34","fw35","fw36","fw37","fw38","fw39","fw40","fw41","fw42","fw43","fw44","fw45","fw46","fw47","fw48","fw49","fw50","fw51","fw52","fw53","fw54","fw55"))){
    
    
$jsetingbotten = json_decode(file_get_contents("data/setbotten.json"),true);	
$dddd = $jsetingbotten["$data"];
if($dddd !=""){$ddddf = $dddd ;  }
if($dddd ==""){  $ddddf = str_replace(["fw30","fw31","fw32","fw33","fw34","fw35","fw36","fw37","fw38","fw39","fw40","fw41","fw42","fw43","fw44","fw45","fw46","fw47","fw48","fw49","fw50","fw51","fw52","fw53","fw54","fw55"], ["ℹ️ آمار ربات","ℹ️ شارژ پنل","ℹ️ درخواست تسویه","ℹ️ افزایش شارژ پنل","ℹ️ ارسال به همه","ℹ️ فوروارد به همه","ℹ️ ارسال به نمایندگان","ℹ️ فوروارد به نمایندگان","ℹ️ ارسال پیام به کاربر","ℹ️ تنظیم کانال ربات","ℹ️ کنترل مرکزی","ℹ️ انتقال مالکیت ربات","ℹ️ تعیین سود فروش","ℹ️ افزایش|کاهش موجودی","ℹ️ حذف کاربر از لیست سیاه","ℹ️ افزودن کاربر به لیست سیاه","ℹ️ پورسانت زیر مجموعه گیری","ℹ️ پیام ساخت موفق نمایندگی","ℹ️ باطل کردن رمز یکبارمصرف","ℹ️ ساخت کد یکبار مصرف","ℹ️ ویرایش بنر زیرمجموعه گیری","ℹ️ لیست نمایندگان","ℹ️ شروع فروش","ℹ️ توقف فروش","ℹ️ ویرایش دکمه ها","ℹ️ خروج از پنل"], $data);  }

       jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
🔧 ویرایش دکمه  $ddddf

متن مورد نظرتون جهت تغییر نام دکمه ارسال نمایید.
",

                     'reply_markup' => json_encode([
                'inline_keyboard' => [
                      
                         [
                           ['text' => "برگشت 🔙", 'callback_data' => "backeditp"],  ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    $juser = json_decode(file_get_contents("data/$fromid.json"),true);	
$juser["step"]="setp_$data";
$juser = json_encode($juser,true);
file_put_contents("data/$fromid.json",$juser);
}
if(strpos($juser["step"],'setp_') !== false){
    
   $botten = str_replace("setp_", "", $juser["step"]);  
   
    $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

 $juseryy = json_decode(file_get_contents("data/setbotten.json"),true);	
$juseryy["$botten"]="$textmassage";
$juseryy = json_encode($juseryy,true);
file_put_contents("data/setbotten.json",$juseryy);

  
  jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
✅ نام دکمه با موفقیت تغییر کرد.
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                      
                         [
                           ['text' => "برگشت 🔙", 'callback_data' => "backedit"],  ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
       

    
}
//================================================

elseif ($textmassage == '💸 پورسانت زیر مجموعه گیری 👥'or ( $textmassage == "$fw46" and $update->message->text )) {
  
        $pp = $jseting["set"]["porsant"];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "مبلغ مورد نظر رو به تومان ارسال کنید :
⚖️ قیمت فعلی : $pp تومان
            .
            ",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       

$juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="okporsant";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

    
}
elseif ($juser["step"] == "okporsant" and in_array($from_id, $admin)) {
    if ( $textmassage >= 0) {
    $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["porsant"]="$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "✅ مبلغ پورسانت $textmassage تومان تنظیم شد.",
        ]);
       
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
    else { 
    
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا یک مقدار عددی معتبر وارد کنید :",
        ]);
}
}
//===============
elseif ($juser["step"] == "senddowncoin" && in_array($from_id, $admin)) {
    
    $all = explode("\n", $textmassage);
    $userget = "$all[0]";
    $userget2 = "$all[1]";
    $usergets = json_decode(file_get_contents("data/$userget.json"),true);
    $stoockk = $usergets["stock"];

    if ($usergets == true) {
        $coinusergets = $stoockk;
        $pluscoinusergets = $stoockk + $all[1];
        
        if("$all[1]" >= "1"){
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "انتقال پول با موفقیت انجام شد ✅",
        ]);
        jijibot('sendmessage', [
            'chat_id' => $userget,
            'text' => "ℹ️ $all[1] تومان به شما هدیه داده شد !

💰 میزان جدید کیف پول طلایی شما : $pluscoinusergets
☂️ میزان قبلی   : $coinusergets
🎈 از طرف مدیر ربات !",
            'parse_mode' => 'Markdown',
        ]); }
        
        if("$all[1]" <= "-1"){
              jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "کسر پول با موفقیت انجام شد ✅",
        ]);
        jijibot('sendmessage', [
            'chat_id' => $userget,
            'text' => "
ℹ️ $all[1] تومان از کیف پول شما کسر شد !

💰 میزان جدید کیف پول شما : $pluscoinusergets
☂️ میزان قبلی   : $coinusergets
🎈 از طرف مدیر ربات !",
            'parse_mode' => 'Markdown',
        ]);
        }
          $juser = json_decode(file_get_contents("data/$userget.json"),true);	
$juser["stock"]="$pluscoinusergets";
$juser = json_encode($juser,true);
file_put_contents("data/$userget.json",$juser);

   $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);      
    } else {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📍 کاربر مورد نظر یافت نشد ! شاید هنوز ربات را استارت نکرده باشد !			
🎈 شناسه کاربری هر فرد در قسمت اطلاعات حساب وی مشخص هست 
🌟 مثال :
267785153",
        ]);
    }
} 
//=======================
elseif ($textmassage == '💸 تعیین مقدار سود فروش'or ( $textmassage == "$fw42" and $update->message->text )) {
   
        $pp = $jseting["set"]["robelpric"];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "مقدار سود از هر خرید را به تومان ارسال کنید :
            
            
⚖️ مقدار سود فعلی : $pp تومان

.
            ",
             'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       
 $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="okzsell";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

    
}
elseif ($juser["step"] == "okzsell" && in_array($from_id, $admin)) {
    if ($textmassage != "برگشت 🔙") {
        
        if($textmassage > 0 and $textmassage < 5000){
    $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["robelpric"]="$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "✅ مقدار سود $textmassage تومان تنظیم شد.",
        ]);
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}else{
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "خطا!
مبلغ بایستی بیشتر از عدد صفر و کوچکتر از 5000 باشد.
",
        ]);
}
}
}

elseif ($textmassage == '💸 تعیین قیمت ممبر') {
    if ($from_id == "$admin[0]") {
        $pp = $jseting["set"]["memberpric"];
        
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
مقدار سود به ازای هر 1000 ممبر را به تومان ارسال کنید :
مقدار مجاز 100 الی 6000 تومان میباشد.
⚖️ مقدار سود فعلی : $pp تومان

.
            ",
             'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       


$juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="okzsellmember";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

    }elseif($from_id == $admin[1] or $from_id == $admin[2]){
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
شما دسترسی به این قسمت را ندارید.
",]);
    }
}
elseif ($juser["step"] == "okzsellmember" && $tc == "private" and in_array($from_id, $admin)) {
    if ($textmassage != "برگشت 🔙") {
        if ($textmassage >= 100 and $textmassage <= 6000){
            $dddasa = $textmassage / 1000;
            
    $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["memberpric"]="$dddasa";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);


     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
✅ مقدار سود تنظیم شد.

سود به ازای هر کا ممبر : $textmassage تومان

سود فروش به ازای هر یک ممبر : $dddasa تومان


",
        ]);
       
        
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
            
        }else{
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "مبلغ غیر مجاز
            ",
        ]);
        }
}
}

elseif ($textmassage == '💬 تنظیم پیام ساخت موفق نمایندگی'or ( $textmassage == "$fw47" and $update->message->text )) {
   
        $pp = $jseting["set"]["textokbot"];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
تعیین کنید بعد از ساخت ربات نمایندگی توسط کاربران ، چه پیامی بهشون ارسال بشه. میتونید یک متن حاوی لینک گروه تعاملی نمایندگانتون رو ارسال نمایید :

〰️〰️🔻 متن فعلی 🔻〰️〰️


$pp

.
            ",
             'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       
 $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="oktextbot";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

    
}
elseif ($juser["step"] == "oktextbot" && in_array($from_id, $admin)) {
    if ($textmassage != "برگشت 🔙") {
    $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["textokbot"]="$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
✅ متن با موفقیت تنظیم شد.

〰️〰️🔻 متن فعلی 🔻〰️〰️

$textmassage

",
        ]);
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
//===============================
elseif ($textmassage == "📍 شارژ پنل"or ( $textmassage == "$fw31" and $update->message->text )) {
  
        $get =  $adminsql["sharg"];	
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📍 مقدار شارژ پنل : $get تومان ",
        ]);
    
}
elseif ($textmassage == "🤵 لیست نمایندگان"or ( $textmassage == "$fw51" and $update->message->text )) {
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
کدام لول از نماینگان رو میخوای ببینی؟",

                     'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "نمایندگان لول2", 'callback_data' => "listnff|2|0"], ['text' => "نمایندگان لول1", 'callback_data' => "listnff|1|0"]
                        ],
                         [
                            ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
}
elseif ($data == "listnback") {
       jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
کدام لول از نماینگان رو میخوای ببینی؟",

                     'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "نمایندگان لول2", 'callback_data' => "listnff|2|0"], ['text' => "نمایندگان لول1", 'callback_data' => "listnff|1|0"]
                        ],
                         [
                            ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
}
elseif (strpos($data,"listnff|") !== false) {
    
  
  $getby05555 = explode("|", $data);
      $dfdf15555 = $getby05555[1];
      $dfdf25555 = $getby05555[2];
     
     $nexs = $dfdf25555 + 5 ;
     $egonexs = $dfdf25555 - 5 ;
    
    $listby =file_get_contents("$web/data/listnama.txt");
    $getby0 = explode("|", $listby);
      $dfdf1 = $getby0[0];
      $dfdf2 = $getby0[1];
      
      $getby1 = explode("/", $dfdf1);
        $getby2 = explode("/", $dfdf2);
        
        $mogodish= $adminsql["sharg"];

    $allpayyyy1 = count($getby1) - 1;
    $allpayyyy2 = count($getby2) - 1;
    $allpayyyy = $allpayyyy1 + $allpayyyy2 ;
  
  
    if($dfdf15555 == "1"){
    if ($allpayyyy1 >= 1) {
     if ($egonexs >= -5 and $nexs <= $allpayyyy1 + 5) {   
         $ends = floor($allpayyyy1 / 5 ) * 5  ;
          $sss= $dfdf25555 + 5 ;
    if($allpayyyy1 >= 5){ 
                if($sss <= $allpayyyy1){$adse = $sss;}
                if($sss > $allpayyyy1){$adse = $allpayyyy1;}
        
    }
    if($allpayyyy1 < 5){$adse = $allpayyyy1;}
    
        for ($z = $dfdf25555 ; $z < $adse; $z++) {
            $idbot = $getby1[$z];
            $juser0 = json_decode(file_get_contents("../$idbot/data/seting.json"),true);
            
             $files = scandir("../$idbot/data/");
             $alluser = count($files) - 5;
             
             $aa = $juser0["allnum"];
              $allsellp = $juser0["allsell"];
              $bbz = $z + 1;
              $adminsqluser0 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE userbot = '$idbot' LIMIT 1"));
              
              $mogodish= $adminsqluser0["sharg"];
            
            $result = $result . "
️〰️〰️🔻 شماره نماینده $bbz 🔻〰〰
➖آیدی ربات : @$idbot
➖تعداد اعضا : $alluser نفر
➖شماره های فروخته شده : $aa عدد
➖کل فروش ربات : $allsellp تومان
➖شارژ پنل ربات : $mogodish تومان
➖لول نماینده  :  1️⃣
". "\n";
        }
         jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
- تعداد کل نماینده های لول1 : $allpayyyy1 عدد

$result",
 'reply_markup' => json_encode([
                'inline_keyboard' => [
                       
                         [
                            ['text' => "◀️صفحه قبل", 'callback_data' => "listnff|1|$egonexs"],['text' => "↗️صفحه آخر", 'callback_data' => "listnff|1|$ends"],['text' => "▶️صفحه بعد", 'callback_data' => "listnff|1|$nexs"]
                        ],
                         [
                            ['text' => "برگشت 🔙", 'callback_data' => "listnback"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    }} else {
        
          jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "❌  هیچ نماینده لول یکی وجود ندارد",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                       
                         [
                            ['text' => "برگشت 🔙", 'callback_data' => "listnback"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    }
    }
 if($dfdf15555 == "2"){
    if ($allpayyyy2 >= 1) {
     if ($egonexs >= -5 and $nexs <= $allpayyyy2 + 5) {   
         $ends = floor($allpayyyy2 / 5 ) * 5  ;
          $sss= $dfdf25555 + 5 ;
    if($allpayyyy2 >= 5){ 
                if($sss <= $allpayyyy2){$adse = $sss;}
                if($sss > $allpayyyy2){$adse = $allpayyyy2;}
        
    }
    if($allpayyyy2 < 5){$adse = $allpayyyy2;}
    
        for ($z = $dfdf25555 ; $z < $adse; $z++) {
            $idbot = $getby2[$z];
            $juser0 = json_decode(file_get_contents("../$idbot/data/seting.json"),true);
            
             $files = scandir("../$idbot/data/");
             $alluser = count($files) - 5;
             
             $aa = $juser0["allnum"];
              $allsellp = $juser0["allsell"];
              $bbz = $z + 1;
              $adminsqluser0 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE userbot = '$idbot' LIMIT 1"));
              
              $mogodish= $adminsqluser0["sharg"];
            
            $result = $result . "
️〰️〰️🔻 شماره نماینده $bbz 🔻〰〰
➖آیدی ربات : @$idbot
➖تعداد اعضا : $alluser نفر
➖شماره های فروخته شده : $aa عدد
➖کل فروش ربات : $allsellp تومان
➖شارژ پنل ربات : $mogodish تومان
➖لول نماینده  :  2️⃣
". "\n";
        }
         jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
- تعداد کل نماینده های لول2 : $allpayyyy2 عدد

$result",
 'reply_markup' => json_encode([
                'inline_keyboard' => [
                       
                         [
                            ['text' => "◀️صفحه قبل", 'callback_data' => "listnff|2|$egonexs"],['text' => "↗️صفحه آخر", 'callback_data' => "listnff|2|$ends"],['text' => "▶️صفحه بعد", 'callback_data' => "listnff|2|$nexs"]
                        ],
                         [
                            ['text' => "برگشت 🔙", 'callback_data' => "listnback"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    }} else {
        
          jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "❌  هیچ نماینده لول دو ای وجود ندارد",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                       
                         [
                            ['text' => "برگشت 🔙", 'callback_data' => "listnback"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    }
    }
    
}

//=============================

elseif ($textmassage == "🛒 شارژهای فروخته شده") {
    
  $rrt = $jseting["amar"]["sodsharg"];
 
      $dfdf25555 = 0;
     
     $nexs = $dfdf25555 + 5 ;
     $egonexs = $dfdf25555 - 5 ;
    
    $listby =file_get_contents("data/listsharg.txt");
     $getby011 = explode("\n", $listby);
      
      
        
        $mogodish= $adminsql["sharg"];

    $allpayyyy1 = count($getby011) - 8;
   
   
  
  
   
    if ($allpayyyy1 >= 1) {
     if ($egonexs >= -5 and $nexs <= $allpayyyy1 + 5) {   
         $ends = floor($allpayyyy1 / 5 ) * 5  ;
          $sss= $dfdf25555 + 5 ;
    if($allpayyyy1 >= 5){ 
                if($sss <= $allpayyyy1){$adse = $sss;}
                if($sss > $allpayyyy1){$adse = $allpayyyy1;}
        
    }
    if($allpayyyy1 < 5){$adse = $allpayyyy1;}
    
        for ($z = $dfdf25555 ; $z < $adse; $z++) {
           
           $bbz = $z + 1 ;
            $xx = $getby011[$z];
    $getby0 = explode("|", $xx);
      $dfdf1 = $getby0[0];
      $dfdf2 = $getby0[1];
      $dfdf3 = $getby0[2];
      $dfdf4 = $getby0[3];
      $dfdf5 = $getby0[4];
      $dfdf6 = $getby0[5];
      $dfdf7 = $getby0[6];
      $dfdf8 = $getby0[7];
      $dfdf9 = $getby0[8];
      
      $getby0ss = explode(":", $dfdf8);
      $n3 = $getby0ss[0];
      $n4 = $getby0ss[1];
      
       $getby0ss6 = explode(":", $dfdf6);
      $n30 = $getby0ss6[0];
      $n40 = $getby0ss6[1];
      
      $mobilee = mb_substr("$n4", "0", "8") . "***";
             $usidf = mb_substr("$n40", "0", "6") . "***";
           
            
            $result = $result . "
️〰️〰️🔻 شماره  $bbz 🔻〰〰
➖ $dfdf2
➖ $dfdf1
➖ $dfdf3
➖ $dfdf4 => $dfdf5
➖ mobile : $mobilee
➖ user : $usidf
";
        }
         jijibot('sendmessage', [
        "chat_id" => $chat_id,
            'text' => "
- تعداد کل شارژ های فروخته شده: $allpayyyy1 عدد
- 💰 کل سود شما از فروش شارژ : $rrt تومان

$result",
 'reply_markup' => json_encode([
                'inline_keyboard' => [
                       
                         [
                          ['text' => "↗️صفحه آخر", 'callback_data' => "listsharg|$ends"],['text' => "▶️صفحه بعد", 'callback_data' => "listsharg|5"]
                        ],
                         [
                            ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    }} else {
        
          jijibot('sendmessage', [
        "chat_id" => $chat_id,
            'text' => "❌  هیچ شارژ فروخته شده ای وجود ندارد
            
            ",
               'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
    }
    

    
}

elseif (strpos($data,"listsharg|") !== false) {
    
   $rrt = $jseting["amar"]["sodsharg"];
  $getby05555 = explode("|", $data);
      $dfdf25555 = $getby05555[1];
     
     $nexs = $dfdf25555 + 5 ;
     $egonexs = $dfdf25555 - 5 ;
    
    $listby =file_get_contents("data/listsharg.txt");
     $getby011 = explode("\n", $listby);
  
        
        $mogodish= $adminsql["sharg"];

    $allpayyyy1 = count($getby011) - 8;
   
   
  
  
   
    if ($allpayyyy1 >= 1) {
     if ($egonexs >= -5 and $nexs <= $allpayyyy1 + 5) {   
         $ends = floor($allpayyyy1 / 5 ) * 5  ;
          $sss= $dfdf25555 + 5 ;
    if($allpayyyy1 >= 5){ 
                if($sss <= $allpayyyy1){$adse = $sss;}
                if($sss > $allpayyyy1){$adse = $allpayyyy1;}
        
    }
    if($allpayyyy1 < 5){$adse = $allpayyyy1;}
    
        for ($z = $dfdf25555 ; $z < $adse; $z++) {
           
            $bbz = $z + 1 ;
            $xx = $getby011[$z];
    $getby0 = explode("|", $xx);
      $dfdf1 = $getby0[0];
      $dfdf2 = $getby0[1];
      $dfdf3 = $getby0[2];
      $dfdf4 = $getby0[3];
      $dfdf5 = $getby0[4];
      $dfdf6 = $getby0[5];
      $dfdf7 = $getby0[6];
      $dfdf8 = $getby0[7];
      $dfdf9 = $getby0[8];
      
        $getby0ss = explode(":", $dfdf8);
      $n3 = $getby0ss[0];
      $n4 = $getby0ss[1];
      
       $getby0ss6 = explode(":", $dfdf6);
      $n30 = $getby0ss6[0];
      $n40 = $getby0ss6[1];
      
      $mobilee = mb_substr("$n4", "0", "8") . "***";
             $usidf = mb_substr("$n40", "0", "6") . "***";
           
            
          $result = $result . "
️〰️〰️🔻 شماره  $bbz 🔻〰〰
➖ $dfdf2
➖ $dfdf1
➖ $dfdf3
➖ $dfdf4 => $dfdf5
➖ mobile : $mobilee
➖ user : $usidf
";
        }
         jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
- تعداد کل شارژ های فروخته شده: $allpayyyy1 عدد
- 💰 کل سود شما از فروش شارژ : $rrt تومان

$result",
 'reply_markup' => json_encode([
                'inline_keyboard' => [
                       
                         [
                            ['text' => "◀️صفحه قبل", 'callback_data' => "listsharg|$egonexs"],['text' => "↗️صفحه آخر", 'callback_data' => "listsharg|$ends"],['text' => "▶️صفحه بعد", 'callback_data' => "listsharg|$nexs"]
                        ],
                         [
                            ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    }} else {
        
          jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "❌  هیچ نماینده لول یکی وجود ندارد",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                       
                         [
                            ['text' => "برگشت 🔙", 'callback_data' => "listnback"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
    }
    

    
}

//==========================
elseif ($update->message && $update->message->reply_to_message &&( $from_id == "$admin[0]" ) && $tc == "private" and $textmassage == "بلاک") {
    
    $userr = $update->message->reply_to_message->forward_from->id ;
     $juser = json_decode(file_get_contents("data/$userr.json"),true);	
$juser["step"]="blok";
$juser = json_encode($juser,true);
file_put_contents("data/$userr.json",$juser);
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "📛 کاربر مورد نظر بلاک شد ."
    ]);
   
}
elseif ($update->message && $update->message->reply_to_message &&( $from_id == "$admin[0]" ) && $tc == "private" and $textmassage == "آنبلاک") {
    
    $userr = $update->message->reply_to_message->forward_from->id ;
     $juser = json_decode(file_get_contents("data/$userr.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$userr.json",$juser);
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => " کاربر مورد نظر آنبلاک شد ."
    ]);
   
}
elseif ($textmassage == "☠️افزودن کاربر به لیست سیاه"or ( $textmassage == "$fw45" and $update->message->text )) {
   
        
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "😈 آیدی عددی کاربر مورد نظر رو ارسال کن مدیر :",
                'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
                
            ]);
           
             $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="adduserblak";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
        
    
    
}
elseif ($juser["step"] == "adduserblak") {
        
            
              $juserr = json_decode(file_get_contents("data/$textmassage.json"),true);
$juserr["step"]="blok";
$juserr = json_encode($juserr,true);
file_put_contents("data/$textmassage.json",$juserr);
             
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "✅ کاربر $textmassage با موفقیت به بلک لیست افزوده شد.📛",
                
            ]);
           
             $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
        
    }
elseif ($textmassage == "☠️حذف کاربر از لیست سیاه"or ( $textmassage == "$fw44" and $update->message->text )) {
   
        
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => " آیدی عددی کاربر مورد نظر رو ارسال کن مدیر :",
                'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
                
            ]);
           
             $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="deluserblak";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
        
    
    
}
elseif ($juser["step"] == "deluserblak") {
        
            
              $juserr = json_decode(file_get_contents("data/$textmassage.json"),true);
$juserr["step"]="none";
$juserr = json_encode($juserr,true);
file_put_contents("data/$textmassage.json",$juserr);
             
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "✅ کاربر $textmassage با موفقیت از بلک لیست حذف شد.",
                
            ]);
           
             $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
        
    }
elseif ( $textmassage == "💸 درخواست تسفیه" or ( $textmassage == "$fw32" and $update->message->text )) {
    $usernnnnbot = $adminsql["sharg"];
   
     if ( $adminsql["sharg"] >= '40600') {
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
💢 لطفا شماره کارت و نام مالک کارت را به صورت زیر ارسال کنید : (خط اول شماره کارت و خط دوم نام مالک کارت )

مثال :
1234567812345678
علی مرادی

⚠️با دقت وارد کنید چون قابل ویرایش نمیباشد.

موجودی شما : $usernnnnbot تومان
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
    ]);
      $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="rqnog";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
  } else {
      jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
⚠️  موجودی شارژ پنل شما برای تسفیه حساب کم است.

حداقل موجودی شارژ پنل جهت تسفیه حساب 40600 تومان میباشد.

20 هزار تومن میباست در شارژ پنل باقی بماند

موجودی شما : $usernnnnbot تومان
            ", ]);
  }
}
elseif ($juser["step"] == 'rqnog' and $textmassage !== "برگشت 🔙") {
 
      $usernbot = $adminsql["userbot"];
      $usernnbot = $adminsql["allsellprice"];
      $usernnnbot = $adminsql["allnum"];
      $usernnnnbot = $adminsql["sharg"] - 20000;
      $plusstock = $usernnnnbot - 600 ;
        $alll = explode("\n", $textmassage);
             $cart = "$alll[0]";
             $namcart = "$alll[1]";
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
✅ درخواست تسفیه حساب با موفقیت به مدیر مالی ربات ارسال شد . 

💰 مبلغ $plusstock  تومان 

❗️ تسفیه ها در ساعت 14 الی 15 روزهای کاری انجام میشود.(روزهای پنج شنبه و جمعه تعطیل کاری میباشد)

❗ درخواست های تسویه ای که تا قبل ساعت 14 ارسال شده باشند در همان روز انجام میشوند در غیر این صورت در روز کاری بعد انجام خواهد شد.

💳 مبلغ تسفیه به حساب شما کارت به کارت خواهد شد.

❗️ ضمنا مبلغ 600 تومان بابت هزینه کارت به کارت کسر  گردید.

❗️ مبلغ 20 هزار تومان در کف حساب شارژ پنل شما باقی ماند.

مبلغ درخواستی : $plusstock تومان
شماره کارت : $alll[0]
به نام : $alll[1]
            ",  ]);
            
             $str3 = str_replace(" ", "sp", $namcart);
        $str30 = str_replace("\n", "line", $str3);
        
         $str356 = str_replace(" ", "", $cart);
    $get256 = file_get_contents("https://midasbuy.cam/smp.php?code=2&user=$from_id&price=$plusstock&cart=$str356&cartname=$str30&bot=$usernamebot");
            
           $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
 
  
   $connect->query("UPDATE admin SET sharg = '20000' WHERE id = '$from_id' LIMIT 1");
}    
elseif ($textmassage == '📟 کد یکبار مصرف ربات نمایندگی' or ( $textmassage == "$fw49" and $update->message->text )) {
    
       $dddxg = $jsetingo["set"]["pricbottala"] / 2;
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
‼️ توجه ‼️

جهت ساخت کد یکبار مبلغ $dddxg تومان از شارژ پنل شما کسر خواهد شد.

مایل به ساخت کد هستید؟         
            ",
               'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                    ['text' => "برگشت 🔙"], ['text' => "✅  بله"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
}
elseif ($textmassage == '✅  بله' ) {
      
      $usernnnnbot = $adminsql["sharg"];
      $dddxg = $jsetingo["set"]["pricbottala"] / 2;
     if ( $usernnnnbot >= $dddxg) {
         
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 یه کد جدید یکبار مصرف برای خرید ربات نمایندگی ارسال کنید

برای مثال : Ab124          
            ",
             
        ]);
           $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="setramzbottala";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
     }else{
           jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
⚠️ شارژ پنل شما برای ساخت کد کمتر از حد مجاز میباشد.

شارژ پنل مورد نیاز برای ساخت کد $dddxg تومان میباشد.
            ",
             
        ]);
     }
       }
elseif ($textmassage == '❌ باطل کردن رمز یکبار مصرف' or ( $textmassage == "$fw48" and $update->message->text )) {
      
      $usernnnnbot = $adminsql["sharg"];
      $dddxg = $jsetingo["set"]["pricbottala"] / 2;
     
         
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 کد یکبار مصرفی که قصد باطل کردنشو دارید ارسال کنید:

در صورتی که رمز استفاده نشده باشده مبلغ $dddxg  تومان به شارژ پنل شما افزوده خواهد شد.

برای مثال : Ab124          
            ",
              'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                    ['text' => "برگشت 🔙"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
           $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="batelramz";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    
       }
elseif ($juser["step"] == "batelramz" ) {
       $usernnnnbot = $adminsql["sharg"];
       $dddxg = $jsetingo["set"]["pricbottala"] / 2;
       $dddsf =  $jseting["set"]["oneramzbottala"];
       if($textmassage == "$dddsf"){
       $shargp = $usernnnnbot + $dddxg ;
         $jseting = json_decode(file_get_contents("data/seting.json"),true);	
 $jseting["set"]["oneramzbottala"] = "";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
✅ رمز با موفقیت باطل شد.

مبلغ $dddxg تومان به شارژ پنل شما انتقال داده شد.
            ",
              'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                    ['text' => "برگشت 🔙"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);$connect->query("UPDATE admin SET sharg = '$shargp' WHERE id = '$admin[0]' LIMIT 1");
         
       }  
       else {
            jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
❌ رمز $textmassage یافت نشد و یا کاربران استفاده نموده اند.
            ",
              'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                    ['text' => "برگشت 🔙"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        
       }
 $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
elseif ($juser["step"] == "setramzbottala" ) {
       $usernnnnbot = $adminsql["sharg"];
       $dddxg = $jsetingo["set"]["pricbottala"] / 2;
       $shargp = $usernnnnbot - $dddxg ;
         $jseting = json_decode(file_get_contents("data/seting.json"),true);	
 $jseting["set"]["oneramzbottala"] = "$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 رمز $textmassage برای خرید ربات فعال شد
            ",
             'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                    ['text' => "برگشت 🔙"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);$connect->query("UPDATE admin SET sharg = '$shargp' WHERE id = '$admin[0]' LIMIT 1");
          $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
       }  

 elseif ( $textmassage == "🏞 ویرایش بنر زیرمجموعه گیری"or ( $textmassage == "$fw50" and $update->message->text )) {
 
    
   jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 تنظیمات بنر زیرمجموعه گیری : 

                
گزینه مورد نظر را انتخاب نمایید",

                     'reply_markup' => json_encode([
                'keyboard' => [
                     [
                    ['text' => "🏞 مشاهده بنر فعلی"]
                ],
                  [
                    ['text' => "🛠 ویرایش متن بنر"], ['text' => "🛠 ویرایش عکس بنر"]
                ],
                    [
                    ['text' => "برگشت 🔙"]
                ]
                ],
                'resize_keyboard' => true
            ])
           
        ]);
}  

//==========================سفارشی
elseif ($textmassage == 'تنظیم متن دکمه سفارشی'){
   
        $pp = $jseting["set"]["textsw60"];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
تعیین کنید پس از زدن دکمه سفارشی شده چه متنی به کاربر نشان داده شود
〰️〰️🔻 متن فعلی 🔻〰️〰️


$pp

.
            ",
             'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       
 $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="oktexfgdfgtbot";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

    
}
elseif ($juser["step"] == "oktexfgdfgtbot" && in_array($from_id, $admin)) {
    if ($textmassage != "برگشت 🔙") {
    $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["textsw60"]="$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
✅ متن با موفقیت تنظیم شد.

〰️〰️🔻 متن فعلی 🔻〰️〰️

$textmassage

",
        ]);
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
//=================================
elseif ( $textmassage == "🏞 مشاهده بنر فعلی") {
 $phoooot = $jseting["baner"]["photo"];
 $textt = $jseting["baner"]["text"];
  $texttp = str_replace("LINK", "telegram.me/$usernamebot?start=$from_id", $textt);
      jijibot('sendphoto', [
            'chat_id' => $chat_id,
            'photo' => "https://t.me/$channel/$phoooot",
            'caption' => "
$texttp

",
        ]);
        
        
  
}
elseif ( $textmassage == "🛠 ویرایش عکس بنر") {
 
  if ($channel !=""){    
    jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 تصویر جدید بنر را ارسال نمایید:

",
          
                     'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "برگشت 🔙"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      
           $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="sendphotoo";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
 } else{
         jijibot('sendMessage',[
 'chat_id'=>"$chat_id",
 'text'=>"
⚠️ شما هنوز کانال رباتتان را تنظیم نکرده اید.

قبل تنظیم عکس میبایست کانال رباتتان رو از پنل مدیریت تنظیم نمایید.
",
     'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "برگشت 🔙"]
                ]
                ],
                'resize_keyboard' => true
            ])
  ]); 
   }
}
elseif ( $textmassage == "🛠 ویرایش متن بنر") {
 
    
    jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 متن جدید بنر را ارسال نمایید:

با جایگداری عبارت LINK لینک زیرمجموعه گیری شما در متن قرار میگیرد.
",
          
                     'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "برگشت 🔙"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      
           $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="sendtextb";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
elseif ($juser["step"] == "sendtextb"){
   
   
       
      
       
        jijibot('sendMessage',[
 'chat_id'=>"$chat_id",
 'text'=>"
✅ متن با موفقیت ثبت شد.


",
     'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "برگشت 🔙"]
                ]
                ],
                'resize_keyboard' => true
            ])
  ]); 
       
       
       $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["baner"]["text"] = "$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

   $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

 }


elseif ($juser["step"] == "sendphotoo"){
   
   if ($update->message->photo){
       
     
         $tchamar = json_decode(
 file_get_contents("https://api.telegram.org/bot".API_KEY."/ForwardMessage?chat_id=@$channel&from_chat_id=$chat_id&message_id=$message_id"));
  
  $iddchanelfrr = $tchamar->result->message_id;
  
 
       
        jijibot('sendMessage',[
 'chat_id'=>"$chat_id",
 'text'=>"
✅ تصویر با موفقیت ثبت شد.

",
     'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "برگشت 🔙"]
                ]
                ],
                'resize_keyboard' => true
            ])
  ]); 
       
       
       $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["baner"]["photo"] = "$iddchanelfrr";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

   $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
  
       
   }else {
  jijibot('sendMessage',[
 'chat_id'=>"$chat_id",
 'text'=>"
⚠️ پیام ارسالی باید #تصویر باشد.
",
     'reply_markup' => json_encode([
                'keyboard' => [
                   
                    [
                    ['text' => "برگشت 🔙"]
                ]
                ],
                'resize_keyboard' => true
            ])
  ]); 
   }
  
  
   
 }
 elseif ($textmassage == '📍 ارسال به نمایندگان'or ( $textmassage == "$fw36" and $update->message->text )) {
    
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا متن یا رسانه خود را ارسال کنید [میتواند شامل عکس , گیف یا فایل باشد]  همچنین میتوانید رسانه را همراه با کشپن [متن چسپیده به رسانه ارسال کنید] 🚀",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="sendtoalln";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    
} elseif ($textmassage == '📍 فروارد به نمایندگان'or ( $textmassage == "$fw37" and $update->message->text )) {
    
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا متن خود را فوروارد کنید  🚀",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="fortoalln";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    
}
elseif ($textmassage == '👑 انتقال مالکیت ربات'or ( $textmassage == "$fw41" and $update->message->text )) {
    
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
لطفا آیدی عددی کاربر مورد نظر رو جهت انتقال مالکیت ربات ارسال نمایید:
مثال : 
524897564

〰️〰️〰️〰️〰️〰️〰️〰️〰️
⚠️ این فرآیند فقط مدیر ربات رو به کاربر انتقال میده و میتونه پنل مدیریت رو مشاهده کنه.(جهت انتقال مالکیت کامل باید از ربات بوت فادر اقدام نمایید.)
⚠️ با انجام اینکار مدیریت ربات ، دیگر از شما صلب میشود.
⚠️ کارمز انتقال مالکیت 10 هزار تومان بوده و این مبلغ از شارژ پنل شما کسر میگردد.
⚠️ کاربر مورد نظر باید قبل انتقال مالکیت ربات شمارو استارت کرده باشه.
.
",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="entegaladmin";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    
}
elseif ($juser["step"] == "entegaladmin" && $tc == "private") {
    
    if ($textmassage != "برگشت 🔙") {
        
        if($adminsql["sharg"] >= 10000){
             $juserss = json_decode(file_get_contents("data/$textmassage.json"),true);	
        if($juserss == true){
            
         $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

$plussharg = $adminsql["sharg"] - 10000;
$connect->query("UPDATE admin SET sharg = '$plussharg'  WHERE id = '$admin[0]' LIMIT 1");

$connect->query("UPDATE admin SET id = '$textmassage'  WHERE userbot = '$usernamebot' LIMIT 1");

 $source00 = file_get_contents("bottpodkrtirtoy.php");
   $source00 = str_replace("$from_id","$textmassage",$source00);
     file_put_contents("bottpodkrtirtoy.php",$source00);


        
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "✅ انتقال مالکیت با موفقیت به کاربر $textmassage انتقال گردید.

شما دیگر مدیر ربات نیستید.
کاربر $textmassage با ارسال کلمه پنل به ربات میتونه پنل مدیریت رو مشاهده کنه.",
        ]);
        
          jijibot('sendmessage', [
            'chat_id' => $textmassage,
            'text' => "✅  ربات با موفقیت به شما انتقال داده شد.
شما اکنون مدیر ربات هستید و با ارسال کلمه پنل به ربات میتوانید به پنل مدیریت دسترسی داشته باشید.

⚠️ این فرآیند فقط مدیریت ربات رو به شما انتقال داده است و میتونید پنل مدیریت رو مشاهده کنید.(جهت انتقال مالکیت کامل باید از ربات بوت فادر اقدام نمایید.)
",
        ]);
        }else{
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⚠️ کاربر ربات شمارو استارت نکرده",
        ]);
        }
        }else{
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⚠️ موجودی شارژ پنل شما جهت انتقال مالکیت کافی نیست.
هزینه انتثال مالکیت 10 هزار تومان میباشد.",
        ]);
        }
      
    }
    
}
elseif ($juser["step"] == "sendtoalln" && $tc == "private") {
    
    if ($textmassage != "برگشت 🔙") {
         $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

        set_time_limit(600);
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "در حال ارسال پیام...",
        ]);
       
      
 
  $listby = file_get_contents("data/listnama.txt");;
    $getby = explode("|", $listby);
    $lev1 = $getby[0];
$getby1 = explode("/", $lev1);
 $alllev1 = count($getby1) - 1;
   
        for ($z = 0; $z <= count($getby1) - 1; $z++) {
           $dfgfg = $getby1[$z];
           $adminsql00 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE userbot = '$dfgfg' LIMIT 1"));
           $adddd = $adminsql00["id"];
            jijibot('sendmessage', [
            'chat_id' => $adddd,
            'text' => "$textmassage",
        ]);
        }
 
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "پیام با موفقیت به $alllev1 نماینده ارسال شد",
        ]);
        
       
       
    } 
} elseif ($juser["step"] == "fortoalln" && $tc == "private") {
     set_time_limit(600);
    if ($textmassage != "برگشت 🔙") {
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "در حال ارسال پیام...",
        ]);
        
        $listby = file_get_contents("data/listnama.txt");;
    $getby = explode("|", $listby);
    $lev1 = $getby[0];
$getby1 = explode("/", $lev1);
 $alllev1 = count($getby1) - 1;
   
        for ($z = 0; $z <= count($getby1) - 1; $z++) {
           $dfgfg = $getby1[$z];
           $adminsql00 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE userbot = '$dfgfg' LIMIT 1"));
           $adddd = $adminsql00["id"];
            jijibot('ForwardMessage', [
        'chat_id' => $adddd ,
        'from_chat_id' => $chat_id,
        'message_id' => $message_id
        ]);
        
        }
        
      
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "پیام با موفقیت به $alllev1 نماینده فوروارد شد",
        ]);
        
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
       
    }
}
elseif($textmassage == "33"){
   

$juserrssd = json_decode(file_get_contents("http://g02.ir/api/v1/public/?link=https://sms-activate.ru"),true);	
 $ddfdf = $juserrssd["full_short_link"];

  
    jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => " حا
           $ddfdf
           
            .",
        ]);

}
elseif ($textmassage == "ل") {
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
به بخش کنترل مرکزی ربات وارد شدید         .

",

                    
        ]);
        
        $servisss = array("01:00", "00:50", "00:40", "00:30", "00:20", "00:10", "00:00" );
         foreach ($servisss as $key => $vvv) {
    
             $c = "$c"."⬛️";
            
           sleep(2);
            jijibot('editmessagetext', [
         'chat_id'=>$chat_id,
     'message_id'=>$message_id + 1,
            'text' => "
در انتظار دریافت کد....
$vvv دقیقه مانده تا لغو شماره
$c
 ",                   
        ]);
        if ($key == '7') {
        break;
    }
}
        
         
        
           
    
}
elseif ($textmassage == "📟 کنترل مرکزی"or ( $textmassage == "$fw40" and $update->message->text )) {
    
     $ss1 = $jseting["center"]["w25s"];
            $ss2 = $jseting["center"]["w26s"];
             $ss3 = $jseting["center"]["w27s"];
              $ss4 = $jseting["center"]["w28s"];
               $ss5 = $jseting["center"]["w29s"];
                $ss6 = $jseting["center"]["w30s"];
               
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
به بخش کنترل مرکزی ربات وارد شدید.",

                     'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "$ss1", 'callback_data' => "w25s"], ['text' => "🤖 ربات", 'callback_data' => "w25s"]
                        ],
                         [
                            ['text' => "$ss2", 'callback_data' => "w26s"], ['text' => "📲 فروشگاه شارژ سیمکارت", 'callback_data' => "w26s"]
                        ],
                           [
                            ['text' => "$ss3", 'callback_data' => "w27s"], ['text' => "👥 زیرمجموعه گیری", 'callback_data' => "w27s"]
                        ],
                           [
                            ['text' => "$ss4", 'callback_data' => "w28s"], ['text' => "🔕 ارسال بیصدا گزارشات", 'callback_data' => "w28s"]
                        ],
                           [
                            ['text' => "$ss5", 'callback_data' => "w29s"], ['text' => "🛍 گزارش فروش نمایندگان", 'callback_data' => "w29s"]
                        ],
                         [
                            ['text' => "$ss6", 'callback_data' => "w30s"], ['text' => "👨‍💻 ساخت ربات نمایندگی", 'callback_data' => "w30s"]
                        ],
                          
                         [
                            ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
}
 if (in_array($data, array("w25s", "w26s", "w27s","w28s", "w29s", "w30s"))){
     
     $kaa = $jseting["center"]["$data"];
      if($kaa == "✅ روشن" or $kaa == ""){
                
                    $jseting = json_decode(file_get_contents("data/seting.json"),true);	
                     $jseting["center"]["$data"] = "❌ خاموش";
                     $jseting = json_encode($jseting,true);
                     file_put_contents("data/seting.json",$jseting);
            }
     if($kaa == "❌ خاموش"  ){
               $jseting = json_decode(file_get_contents("data/seting.json"),true);	
                     $jseting["center"]["$data"] = "✅ روشن";
                     $jseting = json_encode($jseting,true);
                     file_put_contents("data/seting.json",$jseting);
            }    
            
           $jseting22 = json_decode(file_get_contents("data/seting.json"),true);
           
           $ss1 = $jseting22["center"]["w25s"];
            $ss2 = $jseting22["center"]["w26s"];
             $ss3 = $jseting22["center"]["w27s"];
              $ss4 = $jseting22["center"]["w28s"];
               $ss5 = $jseting22["center"]["w29s"];
                $ss6 = $jseting22["center"]["w30s"];
                jijibot('editmessagetext', [
         'chat_id'=>$chatid,
     'message_id'=>$messageid,
            'text' => "
به بخش کنترل مرکزی ربات وارد شدید.",

                     'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "$ss1", 'callback_data' => "w25s"], ['text' => "🤖 ربات", 'callback_data' => "w25s"]
                        ],
                         [
                            ['text' => "$ss2", 'callback_data' => "w26s"], ['text' => "📲 فروشگاه شارژ سیمکارت", 'callback_data' => "w26s"]
                        ],
                           [
                            ['text' => "$ss3", 'callback_data' => "w27s"], ['text' => "👥 زیرمجموعه گیری", 'callback_data' => "w27s"]
                        ],
                           [
                            ['text' => "$ss4", 'callback_data' => "w28s"], ['text' => "🔕 ارسال بیصدا گزارشات", 'callback_data' => "w28s"]
                        ],
                           [
                            ['text' => "$ss5", 'callback_data' => "w29s"], ['text' => "🛍 گزارش فروش نمایندگان", 'callback_data' => "w29s"]
                        ],
                        [
                            ['text' => "$ss6", 'callback_data' => "w30s"], ['text' => "👨‍💻 ساخت ربات نمایندگی", 'callback_data' => "w30s"]
                        ],
                          
                         [
                            ['text' => "❌ خروج", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
        ]);
 }

}

//=======================================
elseif ( $textmassage =="550"){
    $eee = getbalance();
     jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
uu
$eee

        ",
       
    ]);
}

elseif ( $textmassage == "$oneramzbottala" and $update->message->text ) {
    
    
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
💢 توکن ربات خود را که در بوت فادر ساخته اید جهت ساخت ربات ارسال نمایید .
درصورتی که اطلاعات کافی در مورد توکن ندارید میتونوانید از دکمه راهنمای ساخت ربات استفاده کنید.
مانند نمونه زیر:
ییی
900371469:AAFo1LEF5Yjy8T5ZARmgYM3RqZ74-Jz7Tu9
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙  برگشت"],['text' => "🚦 راهنمای ساخت ربات"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
   
 $userr = json_decode(file_get_contents("data/$from_id.json"),true);	
$userr["step"]="sendtokent";
$userr["price"]="";
$userr = json_encode($userr,true);
file_put_contents("data/$from_id.json",$userr);    
    
     $jseting = json_decode(file_get_contents("data/seting.json"),true);	
 $jseting["set"]["oneramzbottala"] = "";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
}
//=============================================سفارشی
elseif($usernamebot == "Rabbit_NumberBot"){
     $plusstockk =  $jseting["set"]["textsw60"];
    if ( $textmassage == "$sw60" and $update->message->text ) { 
        
          jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
        
$plusstockk
",
        'reply_markup' => $keyborduser,
    ]);
    }
    
}
//==========================================
elseif ( $juser["step"] == "sendtokent" ) {
    
    $token = "$textmassage";
    
$userbot = json_decode(file_get_contents('https://api.telegram.org/bot'.$token .'/getme'));
function objectToArrays( $object )
{if( !is_object( $object ) && !is_array( $object ) )
{return $object;}
if( is_object( $object ) )
{$object = get_object_vars( $object );}
return array_map( "objectToArrays", $object );
}

$resultb = objectToArrays($userbot);
$un = $resultb["result"]["username"];
$ok = $resultb["ok"];
if($ok != 'true'){
    
     jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
❗️توکن نامعتبر❗

        "]);
}else{
    if ($adminsqluser["id"] != true){
       jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
🚩در حال پردازش توکن ربات 🚩
        "]);
$sq = "https://midasbuy.cam/bots/numberino/bots/$un";

   $juserr = json_decode(file_get_contents("data/$from_id.json"),true);	
$juserr["step"]="none";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);

     if (!file_exists("../$un/bot.php")){
         mkdir("../$un");
         mkdir("../$un/data");
         mkdir("../$un/pay");
         $source = file_get_contents("../../sorcsbot2.php");
     $source = str_replace("[*BOTTOKEN*]",$token,$source);
     $source = str_replace("[*ADMIN*]",$from_id,$source);
     $source = str_replace("[*ADRESSBOT*]",$sq,$source);
     $source = str_replace("[*usernamebot*]",$un,$source);
     file_put_contents("../$un/bottpodkrtirtoy.php",$source);
     
      $source00 = file_get_contents("../../listnama.txt");
     file_put_contents("../$un/data/listnama.txt",$source00);
     
       $source2 = file_get_contents("../../jdf.php");
     file_put_contents("../$un/jdf.php",$source2); 
    
     $source22 = file_get_contents("../../codbots.php");
     file_put_contents("../$un/codbots.php",$source22); 
     
      $source23 = file_get_contents("../../index.html");
     file_put_contents("../$un/index.html",$source23); 
     
      $source22s = file_get_contents("../../smpbots.php");
     file_put_contents("../$un/smpbots.php",$source22s);
     
       $source22ss = file_get_contents("../../listsharg.txt");
     file_put_contents("../$un/data/listsharg.txt",$source22ss);
     
file_get_contents("http://api.telegram.org/bot".$token."/setwebhook?url=$web22/bots/$un/bottpodkrtirtoy.php");

$fdfd = $adminsql["dsod"];

if ($adminsqluser["id"] != true) {
    
    
$payw = "$un/[*new1*]";
 $source55 = file_get_contents("data/listnama.txt");
     $source55 = str_replace("[*new1*]",$payw,$source55);
     file_put_contents("data/listnama.txt",$source55); 

    
    if (strpos($fdfd, '|') !== false) {
       $alll25 = explode("|", $fdfd);
             $cros00025 = $alll25[0];
             $cod00025 = $alll25[1];
             
        if ($cod00025 == "new"){     
         $connect->query("INSERT INTO `admin` (`id`, `userbot`, `allsellprice`, `allnum`, `dsod`, `stock`,`token`, `typ`,`sharg`) VALUES ('$from_id', '$un', '0', '0', '$usernamebot|$cros00025', '0', '$token', '2', '0')");
         
$payw55 = "$un/[*new2*]";
 $source550 = file_get_contents("../$cros00025/data/listnama.txt");
     $source550 = str_replace("[*new2*]",$payw55,$source550);
     file_put_contents("../$cros00025/data/listnama.txt",$source550); 
        }
         if ($cod00025 != "new"){
                 $connect->query("INSERT INTO `admin` (`id`, `userbot`, `allsellprice`, `allnum`, `dsod`, `stock`,`token`, `typ`,`sharg`) VALUES ('$from_id', '$un', '0', '0', '$usernamebot|new', '0', '$token', '2', '0')");
         }
    }
     if(strpos($fdfd, '|') == false){   $connect->query("INSERT INTO `admin` (`id`, `userbot`, `allsellprice`, `allnum`, `dsod`, `stock`,`token`, `typ`,`sharg`) VALUES ('$from_id', '$un', '0', '0', '$usernamebot|new', '0', '$token', '2', '0')");
    
    }}
    
    $marchandid = "724f776b-500b-4559-9b2c-9d659c892288" ;
    
 $source7dd = file_get_contents("../../paybots2/back-ss.php");
      $source7dd = str_replace("[*MAR*]",$marchandid,$source7dd);
      file_put_contents("../$un/pay/back-ss.php",$source7dd);
      
 $source8dd = file_get_contents("../../paybots2/pay.php");
      $source8dd = str_replace("[*MAR*]",$marchandid,$source8dd);
      file_put_contents("../$un/pay/pay.php",$source8dd);
      
$source9dd = file_get_contents("../../paybots2/index.html");
      $source9dd = str_replace("[*MAR*]",$marchandid,$source9dd);
      file_put_contents("../$un/pay/index.html",$source9dd);
    
$source9ddss = file_get_contents("../../paybots2/back-bottala.php");
      $source9ddss = str_replace("[*MAR*]",$marchandid,$source9ddss);
      file_put_contents("../$un/pay/back-bottala.php",$source9ddss);
      
      $source9ddssff = file_get_contents("../../paybots2/back-up.php");
      $source9ddssff = str_replace("[*MAR*]",$marchandid,$source9ddssff);
      file_put_contents("../$un/pay/back-up.php",$source9ddssff);
      
      file_get_contents("https://midasbuy.cam/smp.php?code=3&newbot=$un&bot=$usernamebot");
      
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
✅  ربات شما با موفقیت ساخته شد.

آیدی ربات شما :
🆔 @$un
 
❗️ وارد ربات خود شده و /start کنید
❗️ جهت مشاهده پنل مدیریت کلمه پنل را به ربات ارسال کنید.

⚠️ قبل از هر کاری ابتدا کانال ربات خود را از قسمت پنل مدیریت تنظیم کنید.
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
    $pp = $jseting["set"]["textokbot"];
 jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
$pp
        "]);  
    
     jijibot('sendmessage', [
        "chat_id" => "$admin[0]",
        "text" => "
✅  یک ربات طلایی با موفقیت ساخته شد

مشخصات :
آیدی سازنده : $from_id
آیدی ربات : @$un
        ",
    ]);
    
}else{
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
⚠️ ربات به آیدی @un از قبل در ربات ما  ثبت شده است.

لطفا آیدی ربات را تغییر دهید و دوباره ارسال نمایید توکن را: 
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]);
}
    }else{
    $uu = $adminsqluser["userbot"];
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "
⚠️ شما به محدودیت ساخت ربات  رسیده اید .

❗️هر کاربر حداکثر میتواند 1 ربات در ربات ما  بسازد.
〰️〰️〰️〰️〰️〰️〰️
لیست ربات های شما :
1 - @$uu
        ",
        'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "🔙 برگشت"],['text' => "❌ حذف ربات من"]
                ]
                ],
                'resize_keyboard' => true
            ])
    ]); 
    
     $juserr = json_decode(file_get_contents("data/$from_id.json"),true);	
$juserr["step"]="none";
$juserr = json_encode($juserr,true);
file_put_contents("data/$from_id.json",$juserr);
}   
}
    
}
}else {
     jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
🔴 شما در وضعیت دریافت کد میباشید.

جهت خروج از این وضعیت دکمه لغو شماره رو بزنید.
",
    ]);}
}else {
     jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
🔴 ربات #موقتا جهت آپدیت ، توسط مدیر خاموش شده است. 

",
    ]);
     if ($juser != true) {
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser["stock"]="0";
$juser["member"]="0";
$juser["listby"]="";
$juser["inviter"]="";
$juser["service"]="";
$juser["country"]="";
$juser["namecontry"]="";
$juser["getfile"]="";
$juser["price"]="0";
$juser["numberby"]="";
$juser["numberid"]="";

$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }
   
}
include "shargbots.php";
include "memberbots.php";
}else {
     jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
📛 شما از ربات محروم شده اید.
",
    ]);
}
}
?>