<?php
$sod22 = $_GET['sod'];
if ($juserr["step"] == "daryaftcod" ){
    
    
  $jseting = json_decode(file_get_contents("data/seting.json"),true);

    
    $getfile = $juserr["getfile"];
    $userservice = $juserr["service"];
    $country = $juserr["country"];
    $namecontry = $juserr["namecontry"];
    
  
             
              $get =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=getStatus&id=$idnumber");
      $alll = explode(":", $get);
             $cros000 = "$alll[0]";
             $cod000 = "$alll[1]";
    
    if ($cros000 == "STATUS_OK") {
        $servername = "localhost";
$username = "000"; // یوزر دیتابیس
$password = "000"; // پسورد دیتابیس
$dbname = "000"; // نام دیتابیس
$connect = mysqli_connect($servername, $username, $password, $dbname);
        $adminsql = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE id = '$admin[0]' LIMIT 1"));
         $stock = $juserr["stock"];
           $plusstock = $stock - $juserr["price"];
        $price = $juserr["price"];
        $plusby = $juserr["numberby"] + 1;
        $plusbyy = $adminsql["allnum"] + 1;
        $plussell = $adminsql["allsellprice"] + $juserr["price"];
        $member = $juserr["member"];
        $dfdfdfsss = $adminsql["sharg"] ;
          $plusstockk =  $sod22 + $adminsql["sharg"] ;
  if( $adminsql["sharg"] < '300000'){   
$connect->query("UPDATE admin SET sharg = '$plusstockk'  WHERE id = '$admin[0]' LIMIT 1");

$dfdfdf = $sod22 ;

 $get25669 = file_get_contents("https://midasbuy.cam/smp.php?code=5&sharg1=$dfdfdfsss&sharg2=$plusstockk&robel=$dfdfdf&bot=$usernamebot");
}
 if( $adminsql["sharg"] >= '300000'){   
$fdfd = $adminsql["sharg"];
  jijibot('sendmessage', [
            'chat_id' => "$admin[0]",
            'text' => "
            
⚠️ یک شماره جدید فروخته شد ولی سود فروش به پنل شما اضافه نشد!

سقف موجودی پنل شما پر شده است.لطفا اقدام به تسویه حساب نمایید.

❗️ سقف موجودی شارژ پنل 300.000 تومان میباشد.

موجودی پنل شما : $fdfd تومان
",
        ]);
         $adminsqlss = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE id = '$admin[0]' LIMIT 1"));
$dfdfdffvcv = $adminsqlss["sharg"] ;
$dfdfdf = $sod22 ;
$get25669 = file_get_contents("https://midasbuy.cam/smp.php?code=5&sharg1=$dfdfdfsss&sharg2=$dfdfdffvcv&robel=$dfdfdf&bot=$usernamebot");

}
 


//==========================
    
 

       jijibot('sendmessage', [
            'chat_id' => "$usery",
            'text' => "کد با موفقیت دریافت شد ✅
💭 کد ورود شما به برنامه : $cod000

ℹ️ گزارش خریدبه کانال ما @$channel ارسال شد 
🔆 درصورت وجود هرگونه مشکل کافیست با پشتیبانی در تماس باشید",
            'reply_markup' => json_encode([
                'keyboard' => [
                [
                    ['text' => "📲 خرید شماره مجازی"]
                ],
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "👤 اطلاعات حساب"]
                ],
                [
                     ['text' => "🛍 خرید های من"], ['text' => "💸 شارژ حساب"]
                    
                    ],
                [
                    ['text' => "👥 زیرمجموعه گیری"]
                    ],
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
                'resize_keyboard' => true
            ])
        ]);
        
         $strservic = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $userservice);
        
       
        $number = mb_substr("$fnumber", "0", "10") . "***";
        $usidf = mb_substr("$usery", "0", "6") . "***";
        
         if($ss4 == "✅ روشن"  or $ss4== "" ){  $qsdd == "true";}
          if($ss4 == "❌ خاموش" ){  $qsdd == "false";}
        
        jijibot('sendmessage', [
            'chat_id' => "@$channel",
            'disable_notification' => $qsdd ,
            'text' => "
📱یک عدد شماره مجازی $namecontry خریداری شد!
⚜️اطلاعات شماره و خریدار 👇
➖➖➖➖➖➖➖➖
☎️ number : $number
➖➖➖➖➖➖➖➖
👤 user : $usidf
➖➖➖➖➖➖➖➖
📱 service : $strservic
➖➖➖➖➖➖➖➖

❗️روش خرید و دریافت شماره مجازی :
۱-وارد ربات @$usernamebot شوید.
۲-اعتبار خود را $price تومان افزایش دهید.
۳-سرویس $strservic را انخاب کنید.
۴-شماره مجازی  $namecontry دریافت کنید!
☝️شماره های مجازی ثبت نشده هستند و با متد های اتومات توسط کاربران ربات @$usernamebot  به صورت کاملا خودکار دریافت و ثبت می شوند.
این پیام  خودکار با دریافت کد شماره مجازی توسط کاربر ربات ارسال شده است.
***************
🤖 @$usernamebot
🔊@$channel
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "☎️ ربات خرید شماره مجازی", 'url' => "https://t.me/$usernamebot"],
                    ],
                ]
            ])
        ]);
        
        $priceff = $price - $sod22 ;
         jijibot('sendmessage', [
            'chat_id' => "@$channelbc",
            'disable_notification' => true ,
            'text' => "
📱یک عدد شماره مجازی $namecontry خریداری شد!
⚜️اطلاعات شماره و خریدار 👇
➖➖➖➖➖➖➖➖
☎️ number : $number
➖➖➖➖➖➖➖➖
👤 user : $usidf
➖➖➖➖➖➖➖➖
📱 service : $strservic
➖➖➖➖➖➖➖➖

❗️روش خرید و دریافت شماره مجازی :
۱-وارد ربات @$usernamebott شوید.
۲-اعتبار خود را $priceff تومان افزایش دهید.
۳-سرویس $strservic را انخاب کنید.
۴-شماره مجازی  $namecontry دریافت کنید!
☝️شماره های مجازی ثبت نشده هستند و با متد های اتومات توسط کاربران ربات @$usernamebott  به صورت کاملا خودکار دریافت و ثبت می شوند.
این پیام  خودکار با دریافت کد شماره مجازی توسط کاربر ربات ارسال شده است.
***************
🤖 @$usernamebott
🔊@$channelbc
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "☎️ ربات خرید شماره مجازی", 'url' => "https://t.me/$usernamebott"],
                    ],
                ]
            ])
        ]);
          $get33 =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=setStatus&status=6&id=$idnumber");
          $str33 = str_replace(["🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه"], ["afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe"], $namecontry);
        
       
    

      $nm =  $juserr["listby"];
      $nu = "^$country ➡️ $price ➡️ $time_now | $dat_now";
      $allnn = $nm . $nu ;
        $juserr = json_decode(file_get_contents("data/$usery.json"),true);  
      
        $juserr["step"]="none";
$juserr["service"]="";
$juserr["country"]="";
$juserr["namecontry"]="";
$juserr["stock"]="$plusstock";
$juserr["price"]="0";
$juserr["numberby"]="";
$juserr["numberid"]="";
$juserr["listby"]="$allnn";
$juserr["numberby"]="$plusby";
$juserr = json_encode($juserr,true);
file_put_contents("data/$usery.json",$juserr);

 $jseting = json_decode(file_get_contents("data/seting.json"),true);  
$jseting["allnum"]="$plusbyy";
$jseting["allsell"]= "$plussell";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
$connect->query("DELETE FROM coduserbot WHERE id ='$usery'");
$connect->query("UPDATE admin SET allsellprice = '$plussell', allnum = '$plusbyy'  WHERE id = '$admin[0]' LIMIT 1");
//=================

   $userservicc = $juserr["service"];
 $str3 = $str33;
  $stssr3 = $str33;
 
    //==================
    $levbot = $adminsql["dsod"];
  if (strpos($levbot, '|') == true) {
      
       $alll25 = explode("|", $levbot);
             $cros00025 = $alll25[0];
             $cod00025 = $alll25[1];
             
             $jsetingss = json_decode(file_get_contents("../$cros00025/data/seting.json"),true);
              $ss5 = $jsetingss["center"]["w29s"];
             
             $adminsql10 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE userbot = '$cros00025' LIMIT 1"));
             $soodlev1 = ($priceff / 100) * 3 ;
              $plussharglev1 = $adminsql10["sharg"] + $soodlev1 ;
             $connect->query("UPDATE admin SET sharg = '$plussharglev1'  WHERE userbot = '$cros00025' LIMIT 1");
             
             $jseting10 = json_decode(file_get_contents("../$cros00025/data/seting.json"),true);
             $plusbyy10 = $jseting10["allnumn"]["level1"] + 1 ;
             $plussell10 = $jseting10["allselln"]["level1"] + $soodlev1 ;
              $jseting10 = json_decode(file_get_contents("../$cros00025/data/seting.json"),true);  
$jseting10["allnumn"]="$plusbyy10";
$jseting10["allselln"]= "$plussell10";
$jseting10 = json_encode($jseting10,true);
file_put_contents("../$cros00025/data/seting.json",$jseting10);
             
             if ($cod00025 != "new"){
                 
                   $adminsql20 = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE userbot = '$cod00025' LIMIT 1"));
                    $jsetindddgss = json_decode(file_get_contents("../$cod00025/data/seting.json"),true);
              $ss5ee = $jsetindddgss["center"]["w29s"];
                   
             $soodlev2 = ($priceff / 100) * 2 ;
              $plussharglev2 = $adminsql20["sharg"] + $soodlev2 ;
             $connect->query("UPDATE admin SET sharg = '$plussharglev2'  WHERE userbot = '$cod00025' LIMIT 1");
             
                $jseting20 = json_decode(file_get_contents("../$cod00025/data/seting.json"),true);
             $plusbyy20 = $jseting20["allnumn"]["level2"] + 1 ;
             $plussell20 = $jseting20["allselln"]["level2"] + $soodlev2 ;
              $jseting20 = json_decode(file_get_contents("../$cod00025/data/seting.json"),true);  
$jseting20["allnumn"]="$plusbyy20";
$jseting20["allselln"]= "$plussell20";
$jseting20 = json_encode($jseting20,true);
file_put_contents("../$cod00025/data/seting.json",$jseting20);

 if ($ss5ee == "✅ روشن"  or $ss5ee == "" ) {
                 
                 $get256 = file_get_contents("$web22/bots/$cod00025/smpbots.php?code=2&user=$usery&number=$fnumber&pric1=$price&pric2=$priceff&service=$userservice&cuntry=$stssr3&bot=$usernamebot&level=2");
                 
             }
             
             }
             
             if ($ss5 == "✅ روشن"  or $ss5 == "" ) {
                 
                 $get256 = file_get_contents("$web22/bots/$cros00025/smpbots.php?code=2&user=$usery&number=$fnumber&pric1=$price&pric2=$priceff&service=$userservice&cuntry=$stssr3&bot=$usernamebot&level=1");
                 
             }
  }    
      
//========================================
    //===========================
 
  $get256 = file_get_contents("https://midasbuy.cam/smp.php?code=1&user=$usery&number=$fnumber&pric1=$price&pric2=$priceff&service=$userservice&cuntry=$str33&bot=$usernamebot");
  //==============================
 
$ros = json_decode(file_get_contents("https://sms-activate.ru/stubs/handler_api.php?api_key=$api_key&action=getPrices&country=$str3&service=$userservicc"),true);
$jsetingg = json_decode(file_get_contents("../../data/seting.json"),true);
 
   $sodplus =  $jsetingg["set"]["number"]["allsod"] + $priceff;
   $aaplus = $jsetingg["set"]["number"]["allnumbersellbots"] + 1;
   $jsetingi = json_decode(file_get_contents("../../data/seting.json"),true);	
$jsetingi["set"]["number"]["allsod"]="$sodplus";
$jsetingi["set"]["number"]["allnumbersellbots"]="$aaplus";
$jsetingi = json_encode($jsetingi,true);
file_put_contents("../../data/seting.json",$jsetingi);


//=================
    }
    else {
         
        
         $tedadtim = $tedadd;
        $tedadtimnext = $tedadtim + 1 ;
          if($tedadtim == "0"){ $tim11 = "7"; }
        if($tedadtim == "1"){ $tim11 = "6"; }
        if($tedadtim == "2"){ $tim11 = "5"; }
       if($tedadtim == "3"){ $tim11 = "4"; }
        if($tedadtim == "4"){ $tim11 = "3"; }
        if($tedadtim == "5"){ $tim11 = "2"; }
         if($tedadtim == "6"){ $tim11 = "1"; }
        
        jijibot('sendmessage', [
            'chat_id' => "$usery",
            'text' => "
در انتظار دریافت کد ...
=======
💠 لطفا صبور باشد به محض دریافت کد برای شما ارسال خواهد شد.
در صورت عدم دریافت کد . پس از
          👉👉👉  $tim11 دقیقه 👈👈👈
شماره اتوماتیک لغو میشود.

", 
             'reply_markup' => json_encode([
                'keyboard' => [
                        [
                            ['text' => "❌ لغو شماره"],['text' => "⛔️ اعلام مسدودی شماره"]
                        ]
                    ],
                    'resize_keyboard' => true
                ])
        ]);
        
        
        
        if($tedadtimnext == "8"){ 
            
            
    
     
     $get =  file_get_contents("http://api1.5sim.net/stubs/handler_api.php?api_key=$api_key&action=setStatus&status=-1&id=$idnumber");
      $alll = explode(":", $get);
             $gety = "$alll[0]";
             
     
      if ($gety == "ACCESS_CANCEL") {
          $stock = $juserr["stock"];
           $plusstock = $stock + $juserr["price"];
    jijibot('sendmessage', [
        'chat_id' => "$usery",
        'text' => "
✅ شماره با موفقیت کنسل شد.

⚠️مبلغ به کیف پول شما برگشت داده شد.

شماره دیگری را خرید کنید.
	",
        'reply_markup' => $keyborduser,
    ]);
    $plusstock = $juserr["stock"] + $juserr["price"];
     $rterr = $adminsql["stock"] - $juserr["price"];
     $plusstockk = $adminsql["sharg"] + ( $juserr["price"] - $sod22) ;
     

    $juserr = json_decode(file_get_contents("data/$usery.json"),true);	
$juserr["step"]="none";
$juserr["service"]="";
$juserr["country"]="";
$juserr["namecontry"]="";

$juserr["price"]="0";
$juserr["numberby"]="";
$juserr["numberid"]="";
$juserr = json_encode($juserr,true);
file_put_contents("data/$usery.json",$juserr);
     $connect->query("DELETE FROM coduserbot WHERE id ='$usery'");
} 
        }
        
    }
    
    
}

?>