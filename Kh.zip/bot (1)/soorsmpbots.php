<?php

error_reporting(0);


if($cod =="1" or $cod =="0"){
    
    

   
 $user1 = $_GET['user'];    
 $price1 = $_GET['price'];  
$timee = "$dat_h:$dat_min";

if($cod =="1" ){
      jijibot('sendmessage', [
            'chat_id' => $user1,
            'text' => "
✅ درخواست تسفیه شما با مشخصات زیر انجام شد :

💰 مبلغ : $price1  تومان
⏳ تاریخ انجام واریز :  $dat_now
⏰ در ساعت : $timee
            ",]);
}
if( $cod =="0"){
    
      $usernnnnbot = $adminsql["sharg"];
      $plusstock = $usernnnnbot + $price1 + 600 ;
      
       $connect->query("UPDATE admin SET sharg = '$plusstock' WHERE id = '$user1' LIMIT 1");
    
      jijibot('sendmessage', [
            'chat_id' => $user1,
            'text' => "
❌ درخواست تسفیه شما به مبلغ $price1 تومان انجام نشد .

✅ مبلغ به شارژ پنل شما برگردانده شد.
⚠️ لطفا اطلاعات کارت و نام صاحب کارت را با دقت ارسال نمایید.
⚠️ شما میتوانید هم اکنون دوباره درخواست تسفیه به ثبت رسانید.

🗄موجودی فعلی شارژ پنل شما : $plusstock تومان
            ",]);
            
}
      
}
if($cod =="2"){
    $dgfg = $_GET['level'];
 $d12 = $_GET['bot'];   
 $user1 = $_GET['user'];    
 $number1 = $_GET['number'];    
 $price1 = $_GET['pric1'] + 2000;  
  $price11 = $_GET['pric2'];
   $service1 = $_GET['service'];  
  $country1 = $_GET['cuntry'];     
    
      $strservic = str_replace(["instagram","telegram","whatsapp","wechat","viber","twitter","line","imo","facebook","google","yahoo","discord","amazon","alibaba","alipay","bigolive","linkedin","microsoft","paypal","snapchat","tiktok","digikala","divar","hamrahaval","irancell","pubg","blockchain","tango","1688","1xbet","23red","ace2three","adidas","airbnb","airtel","akelni","aliexpress","amasia","aol","avito","azino","b4ucabs","bigcash","bitclout","bittube","blablacar","blizzard","burgerking","careem","cdkeys","cekkazan","citymobil","clickentregas","coinbase","craigslist","deliveroo","delivery","dent","didi","dixy","dodopizza","domdara","dostavista","douyu","drom","drugvokrug","dukascopy","ebay","edgeless","electroneum","ezway","fiverr","flipkart","foodpanda","foody","forwarding","galaxy","gameflip","gcash","get","getir","gett","globus","glovo","grabtaxi","green","grindr","haraj","hezzl","hopi","hqtrivia","icard","icq","ininal","iost","jd","justdating","kakaotalk","keybase","komandacard","kotak811","kufarby","kwai","lazada","lbry","lenta","lianxin","livescore","magnit","magnolia","mailru","mamba","mcdonalds","meetme","mega","mercado","michat","miratorg","mtscashback","nana","naver","netflix","nhseven","nifty","nike","nimses","nttgame","odnoklassniki","offerup","okcupid","okey","olx","openpoint","oraclecloud","ozon","pairs","papara","paycell","paymaya","paysend","peoplecom","perekrestok","pof","pokec","pokermaster","potato","proton","protp","pyaterochka","qiwiwallet","quioo","quipp","reuse","ripkord","samokat","seosprint","sheerid","shopee","signal","sikayetvar","skout","steam","swvl","taksheel","tantan","taobao","tencentqq","tinder","tosla","totalcoin","touchance","trendyol","truecaller","uber","uploaded","vernyi","vkontakte","voopee","weibo","weku","winston","wish","yalla","yandex","yemeksepeti","youdo","youla","zalo","zoho","zomato","other"], ["💠 اینستاگرام","💠 تلگرام","💠 واتساپ","💠 وی چت","💠 وایبر","💠 توییتر","💠 لاین","💠 ایمو","💠 فیسبوک","💠 گوگل","💠 یاهو","💠 دیسکورد","💠 آمازون","💠 علی بابا","💠 علی پی","💠 بیگو لایو","💠 لینکدین","💠 ماکروسافت","💠 پی پال","💠 اسنپ چت","💠 تیک تاک","💠 دیجی کالا","💠 دیوار","💠 همراه اول","💠 ایرانسل","💠  پابجی","💠  بلاکچین","💠 تانگو","💠 1688","💠 1xbet","💠 23red","💠 ace2three","💠 adidas","💠 airbnb","💠 airtel","💠 akelni","💠 aliexpress","💠 amasia","💠 aol","💠 avito","💠 azino","💠 b4ucabs","💠 bigcash","💠 bitclout","💠 bittube","💠 blablacar","💠 blizzard","💠 burgerking","💠 careem","💠 cdkeys","💠 cekkazan","💠 citymobil","💠 clickentregas","💠 coinbase","💠 craigslist","💠 deliveroo","💠 delivery","💠 dent","💠 didi","💠 dixy","💠 dodopizza","💠 domdara","💠 dostavista","💠 douyu","💠 drom","💠 drugvokrug","💠 dukascopy","💠 ebay","💠 edgeless","💠 electroneum","💠 ezway","💠 fiverr","💠 flipkart","💠 foodpanda","💠 foody","💠 forwarding","💠 galaxy","💠 gameflip","💠 gcash","💠 get","💠 getir","💠 gett","💠 globus","💠 glovo","💠 grabtaxi","💠 green","💠 grindr","💠 haraj","💠 hezzl","💠 hopi","💠 hqtrivia","💠 icard","💠 icq","💠 ininal","💠 iost","💠 jd","💠 justdating","💠 kakaotalk","💠 keybase","💠 komandacard","💠 kotak811","💠 kufarby","💠 kwai","💠 lazada","💠 lbry","💠 lenta","💠 lianxin","💠 livescore","💠 magnit","💠 magnolia","💠 mailru","💠 mamba","💠 mcdonalds","💠 meetme","💠 mega","💠 mercado","💠 michat","💠 miratorg","💠 mtscashback","💠 nana","💠 naver","💠 netflix","💠 nhseven","💠 nifty","💠 nike","💠 nimses","💠 nttgame","💠 odnoklassniki","💠 offerup","💠 okcupid","💠 okey","💠 olx","💠 openpoint","💠 oraclecloud","💠 ozon","💠 pairs","💠 papara","💠 paycell","💠 paymaya","💠 paysend","💠 peoplecom","💠 perekrestok","💠 pof","💠 pokec","💠 pokermaster","💠 potato","💠 proton","💠 protp","💠 pyaterochka","💠 qiwiwallet","💠 quioo","💠 quipp","💠 reuse","💠 ripkord","💠 samokat","💠 seosprint","💠 sheerid","💠 shopee","💠 signal","💠 sikayetvar","💠 skout","💠 steam","💠 swvl","💠 taksheel","💠 tantan","💠 taobao","💠 tencentqq","💠 tinder","💠 tosla","💠 totalcoin","💠 touchance","💠 trendyol","💠 truecaller","💠 uber","💠 uploaded","💠 vernyi","💠 vkontakte","💠 voopee","💠 weibo","💠 weku","💠 winston","💠 wish","💠 yalla","💠 yandex","💠 yemeksepeti","💠 youdo","💠 youla","💠 zalo","💠 zoho","💠 zomato", "🌐 دیگر سرویس ها"], $service1); 
     
                 
    
     
      $str3 = str_replace(["afghanistan","albania","algeria","angola","anguilla","antiguaandbarbuda","argentina","armenia","aruba","australia","austria","azerbaijan","bahamas","bahrain","bangladesh","barbados","belarus","belgium","belize","benin","bhutane","bih","bolivia","botswana","brazil","bulgaria","burkinafaso","burundi","cambodia","cameroon","canada","capeverde","caymanislands","chad","chile","china","colombia","comoros","congo","costarica","croatia","cuba","cyprus","czech","djibouti","dominica","dominicana","drcongo","easttimor","ecuador","egypt","england","equatorialguinea","eritrea","estonia","ethiopia","finland","france","frenchguiana","gabon","gambia","georgia","germany","ghana","greece","grenada","guadeloupe","guatemala","guinea","guineabissau","guyana","haiti","honduras","hungary","india","indonesia","iran","iraq","ireland","israel","italy","ivorycoast","jamaica","japan","jordan","kazakhstan","kenya","kuwait","kyrgyzstan","laos","latvia","lesotho","liberia","libya","lithuania","luxembourg","macau","madagascar","malawi","malaysia","maldives","mali","mauritania","mauritius","mexico","moldova","mongolia","montenegro","montserrat","morocco","mozambique","myanmar","namibia","nepal","netherlands","newcaledonia","newzealand","nicaragua","niger","nigeria","northmacedonia","norway","oman","pakistan","panama","papuanewguinea","paraguay","peru","philippines","poland","portugal","puertorico","qatar","reunion","romania","russia","rwanda","saintkittsandnevis","saintlucia","saintvincentandgrenadines","salvador","samoa","saotomeandprincipe","saudiarabia","senegal","serbia","seychelles","sierraleone","singapore","slovakia","slovenia","solomonislands","somalia","southafrica","southsudan","spain","srilanka","sudan","suriname","swaziland","sweden","switzerland","syria","taiwan","tajikistan","tanzania","thailand","tit","togo","tonga","tunisia","turkey","turkmenistan","turksandcaicos","uae","uganda","ukraine","uruguay","usa","uzbekistan","venezuela","vietnam","virginislands","yemen","zambia","zimbabwe"], ["🇦🇫 افغانستان" , "🇦🇱 آلبانی" , "🇩🇿 الجزایر" ,"🇦🇴 آنگولا" ,"🏳️‍⚧ آنگویلا" , "🇦🇸 آنتی گواآندباربودا" ,"🇦🇷 آرژانتین" , "🇦🇲 ارمنستان" , "🇦🇼 آروبا" , "🇦🇶 استرالیا" , "🇦🇺 استرالیا" ,"🇦🇿 آذربایجان" , "🇧🇸 باهاما" ,"🇧🇭 بحرین","🇧🇩 بنگلادش","🇧🇧 باربادوس","🇧🇾 بلاروس","🇧🇪 بلژیک","🇧🇿 بلیز","🇧🇯 بنین","🇧🇹 بوتان","🇧🇾 بیه","🇧🇴 بولیوی","🇧🇼 بوتسوانا ","🇧🇷 برزیل","🇧🇬 بلغارستان" ,"🇧🇫 بورکینافاسو" ,"🇧🇮 بوروندی" ,"🇰🇭 کامبوج" ,"🇨🇲 کامرون" ,"🇨🇦 کانادا" ,"🇮🇴 کیپورده" ,"🇻🇬 جزایر کیمن" ,"🇹🇩 چاد" ,"🇨🇱 شیلی" ,"🇨🇳 چین" ,"🇨🇴 کلمبیا" ,"🇰🇭 کومور" ,"🇨🇬 کنگو","🇨🇻 کوستاریکا","🇭🇷 کرواسی","🇨🇺 کوبا","🇨🇾 قبرس","🇨🇿 چک","🇩🇯 جیبوتی","🇹🇩 دومنیکا","🇨🇱 دومنیکانا","🇨🇩 کنگو","🇹🇱 تیمور شرقی","🇪🇨 اکوادور","🇪🇬 مصر" , "🏴 انگلیس" ,"🇰🇲 استوایی گینه" ,"🇪🇷 اریتره" ,"🇪🇪 استونی" ,"🇪🇹 اتیوپی" ,"🇨🇷 فینلند" ,"🇫🇷 فرانسه" ,"🇩🇰 فرانسویان" ,"🇬🇦 گابن","🇬🇲 گامبیا" ,"🇩🇴 جورجیا" ,"🇩🇪 آلمان" ,"🇬🇭 غنا","🇬🇷 یونان","🇬🇩 گرنادا","🇬🇵 گوادلوپ","🇬🇹 گواتمالا","🇬🇳 گینه","🇪🇹 گینه آباساو","🇪🇺 گویانا","🇭🇹 هاییتی","🇭🇳 هندوراس","🇫🇯 هندی","🇮🇳 هند","🇮🇩 اندونزی" ,"🇮🇷 ایران" ,"🇪🇬 عراق" ,"🇮🇪 ایرلند" ,"🇮🇱 اسرائیل" ,"🇮🇹 ایتالیا" ,"🇨🇮 ساحل عاج" ,"🇯🇲 جامائیکا" ,"🇯🇵 ژاپن" ,"🇯🇴 اردن" ,"🇰🇿 قزاقستان" ,"🇰🇪 کنیا" ,"🇰🇼 کویت" ,"🇰🇬 قرقیزستان","🇱🇦 لائوس","🇱🇻 لتونی","🇱🇸 لسوتو","🇱🇷 لیبریا","🇱🇾 لیبی","🇱🇹 لیتوانی","🇱🇺 لوکزامبورگ","🇲🇴 ماکائو","🇲🇬 ماداگاسکار","🇲🇼 مالاوی","🇲🇾 مالزی","🇲🇻 مالدیو","🇲🇱 مالی","🇲🇷 موریتانی","🇲🇺 موریس","🇲🇽 مکزیک","🇲🇩 مولداوی","🇱🇮 مغولستان","🇲🇪 مونته نگرو","🇲🇸 مونتسرات","🇲🇦 مراکش" ,"🇲🇿 موزامبیک" , "🇲🇲 میانمار" ,"🇳🇦 نامیبیا" ,"🇳🇵 نپال" ,"🇳🇱 هلند" , "🇲🇹 نیوکالدونی" ,"🇦🇺 نیوزلند" ,"🇳🇮 نیکاراگوئه" ,"🇯🇲 نیجریه" ,"🇳🇬 نیجریه" ,"🇲🇰 شمال مقدونیه" ,"🇳🇴 نروژ" ,"🇴🇲 عمان","🇵🇰 پاکستان","🇵🇦 پاناما","🇵🇬 پاپوانوگوینه","🇵🇾 پاراگوئه","🇵🇪 پرو","🇵🇭 فیلیپین","🇲🇿 پولند","🇵🇹 پرتغال","🇵🇷 پورتوریکو","🇶🇦 قطر","🇳🇵 اتحاد مجدد","🇷🇴 رومانی" ,"🇷🇺 روسیه" , "🇷🇼 رواندا" , "🇳🇪 سانت کیتساندنوسی" ,"🇧🇱 سنتلوسیا" , "🇳🇺 سن وین سنت و گرنادین ها" ,"🇳🇫 سالوادور" ,"🇼🇸 ساموآ" ,"🇻🇮 ساوتومند و چاپ" ,"🇸🇦 عربستان سعودی" , "🇸🇳 سنگال" ,"🇷🇸 صربستان" ,"🇸🇨 سیشل" , "🇵🇦 سیروان","🇸🇬 سنگاپور","🇸🇰 اسلواکی","🇸🇮 اسلوونی","🇸🇧 جزایر سلیمان","🇸🇴 سومالی","🇿🇦 آفریقای جنوبی","🇸🇸 سودان جنوبی","🇪🇸 اسپانیا","🇱🇰 سریلانکا","🇸🇩 سودان","🇸🇷 سورینام","🇸🇿 سوازیلند" ,"🇸🇪 سوئد" ,"🇨🇭 سوئیس" ,"🇸🇾 سوریه" ,"🇹🇼 تایوان" ,"🇹🇯 تاجیکستان" , "🇹🇿 تانزانیا" , "🇹🇭 تایلند" ,"🇸🇬 تیت" , "🇹🇬 توگو" , "🇸🇰 تونگا" ,"🇹🇳 تونس" , "🇹🇷 ترکیه" , "🇹🇲 ترکمنستان","🇸🇴 تورک و کایکو","🇦🇪 امارات","🇺🇬 اوگاندا","🇺🇦 اوکراین","🇺🇾 اروگوئه","🇺🇸 آمریکا","🇺🇿 ازبکستان","🇻🇪 ونزوئلا","🇻🇳 ویتنام","🇻🇦 جزایر ویرجین","🇾🇪 یمن","🇿🇲 زامبیا" ,"🇿🇼 زیمبابوه"], $country1);
     
      $number = mb_substr("$number1", "0", "10") . "***";
        $usidf = mb_substr("$user1", "0", "6") . "***";
        
       
      
      jijibot('sendmessage', [
            'chat_id' => "@$channel",
            'disable_notification' => true ,
            'text' => "
📱یک عدد شماره مجازی $str3 از ربات #نمایندگی لول $dgfg  خریداری شد!
⚜️اطلاعات شماره و خریدار 👇
➖➖➖➖➖➖➖➖
☎️ number : $number
➖➖➖➖➖➖➖➖
👤 user : $usidf
➖➖➖➖➖➖➖➖
📱 service : $strservic
➖➖➖➖➖➖➖➖

فروش به قیمت $price1  تومان توسط #نماینده لول $dgfg ربات ما 
قیمت این شماره در ربات  ما $price11 تومان


            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                         ['text' => "📱خرید از ربات ", 'url' => "https://t.me/$usernamebot"]
                    ]
                    
                ]
            ])
        ]);
      
}
if($cod =="3"){
    
    $user1 = $_GET['order'];    
    
    $aauserr = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM ordersm  WHERE id = '$user1' LIMIT 1"));
    
                $ablink = $aauserr["link"];
                 $abtype = $aauserr["service"];
                  $abprice = $aauserr["price"];
                   $abdate = $aauserr["date"];
                    $abmember = $aauserr["member"];
                     $abuser = $aauserr["iduser"];
                    
                    	$result =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
     
                         $pin100= $result['products']["$abtype"]['name'];
    
  jijibot('sendmessage', [
            'chat_id' => "$abuser",
            'text' =>"
✅ سفارش شما با شناسه $user1 با موفقیت تکمیل شد

🔗 لینک : $ablink
🌐 نوع سفارش : $pin100
💰 هزینه سفارش : $abprice تومان
⏱ زمان : $abdate
👤 تعداد ممبر درخواستی : $abmember
.           " ,
        ]);
  
}


if($cod =="4"){
    
 $user1 = $_GET['order'];    
    
    $aauserr = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM ordersm  WHERE id = '$user1' LIMIT 1"));
    
     $ablink = $aauserr["statos"];
      $abuser = $aauserr["iduser"];
    
      jijibot('sendmessage', [
            'chat_id' => "$abuser",
            'text' =>"
❗️ سفارش شما با شناسه $user1 تغییر وضعیت پیدا کرد.

وضعیت فعلی سفارش : $ablink
.           " ,
        ]);
 
}
if($cod =="5"){
    
     $user1 = $_GET['order'];    
    
    $aauserr = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM ordersm  WHERE id = '$user1' LIMIT 1"));
    
                $ablink = $aauserr["link"];
                 $abtype = $aauserr["service"];
                  $abprice = $aauserr["price"];
                   $abdate = $aauserr["date"];
                    $abmember = $aauserr["member"];
                     $abuser = $aauserr["iduser"];
                      $abusersss = $aauserr["sodbot"];
                    
                    	$result =  json_decode(file_get_contents("https://senatorozv.com/web/web.php?apikey=$apimember&type=list"),true);
     
                         $pin100= $result['products']["$abtype"]['name'];
                         
                         
                          $juserll = json_decode(file_get_contents("data/$abuser.json"),true);	
                         $eee3= $juserll["stock"];
 $plusstock = $eee3 + $abprice;
 $juserr = json_decode(file_get_contents("data/$abuser.json"),true);	
$juserr["stock"]="$plusstock";
$juserr = json_encode($juserr,true);
file_put_contents("data/$abuser.json",$juserr);

 $bb12 = $jsetingo["set"]["number"]["allsod"] - $abprice ;
        $jsetingo = json_decode(file_get_contents("../../data/seting.json"),true);	
 $jsetingo["set"]["number"]["allsod"] = "$bb12";
$jsetingo = json_encode($jsetingo,true);
file_put_contents("../../data/seting.json",$jsetingo);

 $sod2 = $jseting["set"]["memberpric"];
 $get =  $adminsql["sharg"];	
 $plusshargg = $adminsql["sharg"] - $abusersss;
              
$connect->query("UPDATE admin SET sharg = '$plusshargg' WHERE id = '$admin[0]' LIMIT 1");
    
  jijibot('sendmessage', [
            'chat_id' => "$abuser",
            'text' =>"
❌ سفارش شما با شناسه $user1 انجام نشد و مبلغ کسر شده به شما برگشت داده شد

🔗 لینک : $ablink
🌐 نوع سفارش : $pin100
💰 هزینه سفارش : $abprice تومان
⏱ زمان : $abdate
👤 تعداد ممبر درخواستی : $abmember
.           " ,
        ]);
}
?>