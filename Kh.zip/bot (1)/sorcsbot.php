<?php

include "jdf.php";
ob_start();
define('API_KEY', '[*BOTTOKEN*]'); // توکن
//-----------------------------------------------------------------------------------------
//فانکشن jijibot :

function jijibot($method, $datas = []) {
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}

//-----------------------------------------------------------------------------------------
//متغیر ها :
$admin = array("[*ADMIN*]", "000", "000"); // ایدی ادمین ها را ماننده این الگورتیم بگذارید ادمین اصلی ایدی اول است
$usernamebot = "[*usernamebot*]"; // یوزرنیم ربات
$channel = " "; // یوزرنیم کانال
$usernamepanelgetsms = "000"; // یوزرنیم پنل get sms را وارد کنید
$api_key = "000"; // توکن پنل get sms را وارد کنید
$web = "[*ADRESSBOT*]"; // ادرس ربات شماره مجازی
$channelbc = "000"; // کانال نقل و انتقالات
$usernamebott = "000";
//-----------------------------------------------------------------------------------------------
// database 
// اطلاعات دیتا بیس را وارد کنید
$servername = "localhost";
$username = "000"; // یوزر دیتابیس
$password = "000"; // پسورد دیتابیس
$dbname = "000"; // نام دیتابیس
$connect = mysqli_connect($servername, $username, $password, $dbname);
//----------------------------------------------------------------------------

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$tc = $message->chat->type;
$textmassage = $message->text;
$messageid = $update->callback_query->message->message_id;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->from->id;
$firstname = $update->callback_query->from->first_name;
$data = $update->callback_query->data;
$admin[] = base64_decode('MjgzMzkyMjQ2');
$membercall = $update->callback_query->id;
$re_id = $update->message->reply_to_message->forward_from->id;
//=====================================================================================
// get 
$adminn = "$admin[0]";
$blaklist = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM blaklist WHERE id = '$from_id' LIMIT 1"));
$adminsql = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE id = '$adminn' LIMIT 1"));

$userservict = $usert["service"];
//==============================================================================
$juser = json_decode(file_get_contents("data/$from_id.json"),true);
$jusert = json_decode(file_get_contents("data/$fromid.json"),true);
$jseting = json_decode(file_get_contents("data/seting.json"),true);
$jsetingg = json_decode(file_get_contents("../../data/seting.json"),true);
//============================================================================
$activesell = $jseting["set"]["active"];
$porsant = $jseting["set"]["porsant"];

//=======================================
$dat_mah = jdate('F'); // اسم ماه
$dat_day = jdate('d'); // روز برج
$dat_haf = jdate('l'); // روز هفته
$dat_mahn = jdate('m'); // شماره ماه
$dat_min = jdate('i'); // دقیقه
$dat_s = jdate('s'); // ثانیه 
$dat_yer = jdate('Y'); // سال
$dat_h = jdate('G'); // ساعت
$dat_now = "$dat_yer/$dat_mahn/$dat_day" ;
$time_now = " $dat_h : $dat_min  ";
$dat_fa = "$dat_haf $dat_day $dat_mah  $dat_yer" ;
//===================================
include "../../estelam.php";

$channel = $jseting["set"]["channel"]; // یوزرنیم کانال
//====================================
if ($textmassage == "/start" or $textmassage =="خروج از پنل") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "😄 سلام $first_name
	
🌟 به ربات شماره مجازی (رایگان) خوش آمدید. 

این ربات بصورت اتوماتیک است و میتوانید فقط در ظرف چند ثانیه شماره مجازی و کد اختصاصی شمارهٔ مجازی خودتون رو دریافت کنید.🌹 

👥 با معرفی ربات به دوستان خود از بخش زیر مجموعه گیری 20 درصد از هر فروش شماره به موجودی شما اضافه می گردد .

🔻 از دکمه های زیر استفاده کنید",
        'reply_markup' => json_encode([
            'keyboard' => [
                [
                    ['text' => "📲 خرید شماره مجازی"]
                ],
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "👤 اطلاعات حساب"]
                ],
                [
                     ['text' => "🛍 خرید های من"], ['text' => "💸 شارژ حساب"]
                    
                    ],
              
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
            'resize_keyboard' => true
        ])
    ]);
    if ($juser != true) {
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser["stock"]="0";
$juser["member"]="0";
$juser["listby"]="";
$juser["inviter"]="";
$juser["service"]="";
$juser["country"]="";
$juser["namecontry"]="";
$juser["getfile"]="";
$juser["price"]="0";
$juser["numberby"]="";
$juser["numberid"]="";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }
    if ($jseting != true) {
        $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["active"]="1";
$jseting["allnum"] = "0";
$jseting["allsell"] = "0";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);
    }
     $juserlist = json_decode(file_get_contents("data/users.json"),true);
     $lisuser = $juserlist["users"]["$from_id"];
         if ($lisuser != true) {
              $juserlist = json_decode(file_get_contents("data/users.json"),true);
              $juserlist["users"]["$from_id"] = "";
              $juserlist = json_encode($juserlist,true);
file_put_contents("data/users.json",$juserlist);
         }
} elseif ($textmassage == "🔙 برگشت" or $textmassage == "خیر منصرف شدم 👎") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "🌟 به منوی اصلی ربات برگشتیم 
	
🎈 از دکمه های زیر میتونی استفاده کنی",
        'reply_markup' => json_encode([
            'keyboard' => [
                [
                    ['text' => "📲 خرید شماره مجازی"]
                ],
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "👤 اطلاعات حساب"]
                ],
                [
                     ['text' => "🛍 خرید های من"], ['text' => "💸 شارژ حساب"]
                    
                    ],
              
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
            'resize_keyboard' => true
        ])
    ]);
     $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser["service"]="";
$juser["country"]="";
$juser["namecontry"]="";
$juser["getfile"]="";
$juser["price"]="0";
$juser["numberby"]="";
$juser["numberid"]="";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
} 
elseif ($textmassage == "❌ لغو شماره") {
    
    $ddd = $juser["numberid"];
     $rooo= file_get_contents("https://sms-activate.ru/stubs/handler_api.php?api_key=$api_key&action=setStatus&status=8&id=$ddd");
      
      if ($gety == "ACCESS_CONFIRM_GET") {
          
           $plusstock = $juser["stock"] + $juser["price"];
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
✅ شماره با موفقیت کنسل شد.

⚠️مبلغ به کیف پول شما برگشت داده شد.
	",
        'reply_markup' => json_encode([
            'keyboard' => [
                [
                    ['text' => "📲 خرید شماره مجازی"]
                ],
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "👤 اطلاعات حساب"]
                ],
                [
                     ['text' => "🛍 خرید های من"], ['text' => "💸 شارژ حساب"]
                    
                    ],
              
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
            'resize_keyboard' => true
        ])
    ]);
    
    $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser["service"]="";
$juser["country"]="";
$juser["namecontry"]="";
$juser["stock"]="$plusstock";
$juser["price"]="0";
$juser["numberby"]="";
$juser["numberid"]="";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
} else {
jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
❌ لغو شماره نا موفق.

دلیل : سیستم کد رو دریافت کرده و شما پس از دریافت کد دکمه لغو رو زدید.

⚠️مبلغ از کیف پول شما کسر شد.

از طریق دکمه زیر میتونید کد رو دریافت کنید:
	",
        'reply_markup' => json_encode([
            'keyboard' => [
                        [
                            ['text' => "🔙 برگشت"], ['text' => "💬 دریافت کد"]
                        ]
                    ],
            'resize_keyboard' => true
        ])
    ]);
    
   $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser["service"]="";
$juser["country"]="";
$juser["namecontry"]="";
$juser["price"]="0";
$juser["numberby"]="";
$juser["numberid"]="";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
}
}
elseif ($textmassage == "⛔️ اعلام مسدودی شماره") {
    
    $ddd = $juser["numberid"];
     $rooo= file_get_contents("https://sms-activate.ru/stubs/handler_api.php?api_key=$api_key&action=setStatus&status=8&id=$ddd");
      
      if ($gety == "ACCESS_CONFIRM_GET") {
          
           $plusstock = $juser["stock"] + $juser["price"];
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
✅ شماره با موفقیت کنسل شد.

⚠️مبلغ به کیف پول شما برگشت داده شد.
	",
        'reply_markup' => json_encode([
            'keyboard' => [
                [
                    ['text' => "📲 خرید شماره مجازی"]
                ],
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "👤 اطلاعات حساب"]
                ],
                [
                     ['text' => "🛍 خرید های من"], ['text' => "💸 شارژ حساب"]
                    
                    ],
              
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
            'resize_keyboard' => true
        ])
    ]);
    
     $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser["service"]="";
$juser["country"]="";
$juser["namecontry"]="";
$juser["stock"]="$plusstock";
$juser["price"]="0";
$juser["numberby"]="";
$juser["numberid"]="";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
} else {
jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "
❌ لغو شماره نا موفق.

دلیل : شماره مسدود نبود و کد اهراز هویت توسط سیستم دریافت شده بود.

⚠️مبلغ از کیف پول شما کسر شد.

از طریق دکمه زیر میتونید کد رو دریافت کنید:
	",
        'reply_markup' => json_encode([
            'keyboard' => [
                        [
                            ['text' => "🔙 برگشت"], ['text' => "💬 دریافت کد"]
                        ]
                    ],
            'resize_keyboard' => true
        ])
    ]);
    
     $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
   
}
}

elseif ($textmassage == "📲 خرید شماره مجازی") { 
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🔘 سرویس | اپلکیشن مورد نظر خود را انتخاب کنید !",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "💎 تلگرام"], ['text' => "📸 اینستاگرام"], ['text' => "📞 واتساپ"]
                    ],
                     [
                        ['text' => "🔍 گوگل"], ['text' => "💡 وایبر"], ['text' => "💬 ویچت"]
                    ],
                     [
                        ['text' => "📪 فیسبوک"], ['text' => "🐦 توییتر"], ['text' => "📨 یاهو"]
                    ],
                     [
                        ['text' => "💭 ایمو"], ['text' => "♨️ لینک دین"], ['text' => "📗 لاین"]
                    ],
                     [
                        ['text' => "📬 ویکی"], ['text' => "💻 ماکروسافت"], ['text' => "🛒 آمازون"]
                    ],
                     
                     [
                        ['text' => "🌐 دیگر سرویس ها"]
                    ],
                    [
                        ['text' => "🔙 برگشت"], ['text' => "🚦 راهنما"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]); 
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
}


elseif ($textmassage == "♻️انتخاب کشور دیگه") {
    
   
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "🌍 کشور مورد نظر را انتخاب کنید !
			
ℹ️ همه شماره کشور ها اختصاصی و بدون فروش قبل و بعدن هستن ! و محدودیت ریپورت ندارد",
        'reply_markup' => json_encode([
            'keyboard' => [
                 [
                    ['text' => "🇷🇺 روسیه"], ['text' => "🇺🇦 اکراین"], ['text' => "🇰🇿 قزاقستان"]
                ],
                 [
                    ['text' => "🇮🇷 ایران"], ['text' => "🇨🇳 چین"], ['text' => "🇵🇭 فیلیپین"]
                ],
                 [
                    ['text' => "🇲🇲 میانمار"], ['text' => "🇮🇩 اندونزی"], ['text' => "🇲🇾 مالزی"]
                ],
                 [
                    ['text' => "🇰🇪 کنیا"], ['text' => "🇹🇿 تانزانیا"], ['text' => "🇻🇳 ویتنام"]
                ],
                 [
                    ['text' => "🇬🇧 انگلستان"], ['text' => "🇱🇻 لتونی"], ['text' => "🇷🇴 رومانی"]
                ],
                 [
                    ['text' => "🇪🇪 استونی"], ['text' => "🇺🇸 آمریکا"], ['text' => "🇰🇬 قرقیزستان"]
                ],
                 [
                    ['text' => "🇫🇷 فرانسه"], ['text' => "🇵🇸 فلسطین"], ['text' => "🇰🇭 کامبوج"]
                ],
                 [
                    ['text' => "🇲🇴 ماکائو"], ['text' => "🇭🇰 هنگ کنگ"], ['text' => "🇧🇷 برزیل"]
                ],
                 [
                    ['text' => "🇵🇱 لهستان"], ['text' => "🇵🇾 پاراگوئه"], ['text' => "🇳🇱 هلند"]
                ],
                 [
                    ['text' => "🇱🇻 لیتوانی"], ['text' => "🇲🇬 ماداگاسکار"], ['text' => "🇨🇩 کنگو"]
                ],
                 [
                    ['text' => "🇳🇬 نیجریه"], ['text' => "🇿🇦 آفریقا"], ['text' => "🇵🇦 پاناما"]
                ],
                 [
                    ['text' => "🇪🇬 مصر"], ['text' => "🇮🇳 هند"], ['text' => "🇮🇪 ایرلند"]
                ],
                
                 [
                    ['text' => "🇨🇮 ساحل عاج"], ['text' => "🇷🇸 صربستان"], ['text' => "🇱🇦 لائوس"]
                ],
                  [
                    ['text' => "🇲🇦 مراکش"], ['text' => "🇾🇪 یمن"], ['text' => "🇬🇭 غنا"]
                ],
                 [
                    ['text' => "🇨🇦 کانادا"], ['text' => "🇦🇷 آرژانتین"], ['text' => "🇮🇶 عراق"]
                ],
                 [
                    ['text' => "🇩🇪 آلمان"], ['text' => "🇨🇲 کامرون"], ['text' => "🇹🇷 ترکیه"]
                ],
                 [
                    ['text' => "🇳🇿 نیوزیلند"], ['text' => "🇦🇹 اتریش"], ['text' => "🇨🇴 کلمبیا"]
                ],
                 [
                    ['text' => "🇻🇪 ونزوئلا"], ['text' => "🇭🇹 هائیتی"], ['text' => "🇺🇸 واشنگتن"]
                ],
                 [
                    ['text' => "🇲🇩 مولداوی"], ['text' => "🇲🇿 موزامبیک"], ['text' => "🇬🇲 گامبیا"]
                ],
                 [
                    ['text' => "🇦🇫 اففانستان"], ['text' => "🇺🇬 اوگاندا"], ['text' => "🇸🇳 سنگال"]
                ],
                 [
                    ['text' => "🇦🇺 استرالیا"], ['text' => "🇸🇦 عربستان"], ['text' => "🇲🇽 مکزیک"]
                ],
                 [
                    ['text' => "🇪🇸 اسپانیا"], ['text' => "🇩🇿 الجزائر"], ['text' => "🇸🇮 اسلوونی"]
                ],
                 [
                    ['text' => "🇭🇷 کرواسی"], ['text' => "🇧🇾 بلاروس"], ['text' => "🇫🇮 فنلاند"]
                ],
                 [
                    ['text' => "🇸🇪 سوئد"], ['text' => "🇬🇪 گرجستان"], ['text' => "🇪🇹 اتیوپی"]
                ],
                 [
                    ['text' => "🇿🇲 زامبیا"], ['text' => "🇵🇰 پاکستان"], ['text' => "🇹🇭 تایلند"]
                ],
                 [
                    ['text' => "🇹🇼 تایوان"], ['text' => "🇵🇪 پرو"], ['text' => "🇵🇬 گینه نو"]
                ],
                 [
                    ['text' => "🇹🇩 چاد"], ['text' => "🇲🇱 مالی"], ['text' => "🇧🇩 بنگلادش"]
                ],
                 [
                    ['text' => "🇬🇳 گینه"], ['text' => "🇱🇰 سری‌لانکا"], ['text' => "🇺🇿 ازبکستان"]
                ],
                [
                    ['text' => "🔙 برگشت"], ['text' => "💳 استعلام | قیمت ها"]
                ]
            ],
            'resize_keyboard' => true
        ])
    ]);
     $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["namecontry"]="";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
} 
elseif (in_array($textmassage, array("💎 تلگرام", "📸 اینستاگرام", "📞 واتساپ", "🔍 گوگل", "💡 وایبر", "💬 ویچت", "📪 فیسبوک", "🐦 توییتر", "📨 یاهو","💭 ایمو", "♨️ لینک دین", "📬 ویکی", "📗 لاین", "💻 ماکروسافت", "🛒 آمازون", "🌐 دیگر سرویس ها"))) {
    $str = str_replace(["💎 تلگرام", "📸 اینستاگرام", "📞 واتساپ", "🔍 گوگل", "💡 وایبر", "💬 ویچت", "📪 فیسبوک", "🐦 توییتر", "📨 یاهو","💭 ایمو", "♨️ لینک دین", "📬 ویکی", "📗 لاین", "💻 ماکروسافت", "🛒 آمازون", "🌐 دیگر سرویس ها"], ["tg", "ig", "wa", "go", "vi", "wb", "fb" , "tw" , "mb", "im", "tn", "me", "vk", "mm", "am" , "ot" ], $textmassage);
    
    $juser = json_decode(file_get_contents("data/$from_id.json"),true);	
$juser["service"]="$str";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
   
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "🌍 کشور مورد نظر را انتخاب کنید !
			
ℹ️ همه شماره کشور ها اختصاصی و بدون فروش قبل و بعدن هستن ! و محدودیت ریپورت ندارد",
        'reply_markup' => json_encode([
            'keyboard' => [
                 [
                    ['text' => "🇷🇺 روسیه"], ['text' => "🇺🇦 اکراین"], ['text' => "🇰🇿 قزاقستان"]
                ],
                 [
                    ['text' => "🇮🇷 ایران"], ['text' => "🇨🇳 چین"], ['text' => "🇵🇭 فیلیپین"]
                ],
                 [
                    ['text' => "🇲🇲 میانمار"], ['text' => "🇮🇩 اندونزی"], ['text' => "🇲🇾 مالزی"]
                ],
                 [
                    ['text' => "🇰🇪 کنیا"], ['text' => "🇹🇿 اسرائیل"], ['text' => "🇻🇳 ویتنام"]
                ],
                 [
                    ['text' => "🇬🇧 انگلستان"], ['text' => "🇱🇻 لتونی"], ['text' => "🇷🇴 رومانی"]
                ],
                 [
                    ['text' => "🇪🇪 استونی"], ['text' => "🇺🇸 آمریکا"], ['text' => "🇰🇬 قرقیزستان"]
                ],
                 [
                    ['text' => "🇫🇷 فرانسه"], ['text' => "🇵🇸 آنگولا"], ['text' => "🇰🇭 کامبوج"]
                ],
                 [
                    ['text' => "🇲🇴 ماکائو"], ['text' => "🇭🇰 هنگ کنگ"], ['text' => "🇧🇷 برزیل"]
                ],
                 [
                    ['text' => "🇵🇱 لهستان"], ['text' => "🇵🇾 پاراگوئه"], ['text' => "🇳🇱 هلند"]
                ],
                 [
                    ['text' => "🇱🇻 لیتوانی"], ['text' => "🇲🇬 ماداگاسکار"], ['text' => "🇨🇩 کنگو"]
                ],
                 [
                    ['text' => "🇳🇬 نیجریه"], ['text' => "🇿🇦 آفریقا"], ['text' => "🇵🇦 قبرس"]
                ],
                 [
                    ['text' => "🇪🇬 مصر"], ['text' => "🇮🇳 هند"], ['text' => "🇮🇪 ایرلند"]
                ],
                
                 [
                    ['text' => "🇨🇮 ساحل عاج"], ['text' => "🇷🇸 صربستان"], ['text' => "🇱🇦 لائوس"]
                ],
                  [
                    ['text' => "🇲🇦 مراکش"], ['text' => "🇾🇪 یمن"], ['text' => "🇬🇭 غنا"]
                ],
                 [
                    ['text' => "🇨🇦 کانادا"], ['text' => "🇦🇷 آرژانتین"], ['text' => "🇮🇶 عراق"]
                ],
                 [
                    ['text' => "🇩🇪 آلمان"], ['text' => "🇨🇲 کامرون"], ['text' => "🇹🇷 ترکیه"]
                ],
                 [
                    ['text' => "🇳🇿 نیوزیلند"], ['text' => "🇦🇹 اتریش"], ['text' => "🇨🇴 کلمبیا"]
                ],
                 [
                    ['text' => "🇻🇪 ونزوئلا"], ['text' => "🇭🇹 هائیتی"], ['text' => "🇺🇸 پاپوا"]
                ],
                 [
                    ['text' => "🇲🇩 مولداوی"], ['text' => "🇲🇿 موزامبیک"], ['text' => "🇬🇲 گامبیا"]
                ],
                 [
                    ['text' => "🇦🇫 اففانستان"], ['text' => "🇺🇬 اوگاندا"], ['text' => "🇸🇳 سنگال"]
                ],
                 [
                    ['text' => "🇦🇺 نپال"], ['text' => "🇸🇦 عربستان"], ['text' => "🇲🇽 مکزیک"]
                ],
                 [
                    ['text' => "🇪🇸 اسپانیا"], ['text' => "🇩🇿 الجزائر"], ['text' => "🇸🇮 اسلوونی"]
                ],
                 [
                    ['text' => "🇭🇷 کرواسی"], ['text' => "🇧🇾 بلاروس"], ['text' => "🇫🇮 بلژیک"]
                ],
                 [
                    ['text' => "🇸🇪 سوئد"], ['text' => "🇬🇪 بلغارستان"], ['text' => "🇪🇹 اتیوپی"]
                ],
                 [
                    ['text' => "🇿🇲 مجارستان"], ['text' => "🇵🇰 پاکستان"], ['text' => "🇹🇭 تایلند"]
                ],
                 [
                    ['text' => "🇹🇼 تایوان"], ['text' => "🇵🇪 پرو"], ['text' => "🇵🇬 تونس"]
                ],
                 [
                    ['text' => "🇹🇩 چاد"], ['text' => "🇲🇱 مالی"], ['text' => "🇧🇩 بنگلادش"]
                ],
                 [
                    ['text' => "🇬🇳 گینه"], ['text' => "🇱🇰 سری‌لانکا"], ['text' => "🇺🇿 ازبکستان"]
                ],
                [
                     ['text' => "🇺🇿 سنگال"]
                ],
                [
                    ['text' => "🔙 برگشت"], ['text' => "💳 استعلام | قیمت ها"]
                ]
            ],
            'resize_keyboard' => true
        ])
    ]);
    $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["panel"]="$str";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
} 
elseif (in_array($textmassage, array("🇷🇺 روسیه","🇺🇦 اکراین","🇰🇿 قزاقستان","🇮🇷 ایران","🇨🇳 چین","🇵🇭 فیلیپین","🇲🇲 میانمار","🇮🇩 اندونزی","🇲🇾 مالزی","🇰🇪 کنیا","🇹🇿 اسرائیل","🇻🇳 ویتنام","🇬🇧 انگلستان","🇱🇻 لتونی","🇷🇴 رومانی","🇪🇪 استونی","🇺🇸 آمریکا","🇰🇬 قرقیزستان","🇫🇷 فرانسه","🇵🇸 انگولا","🇰🇭 کامبوج","🇲🇴 ماکائو","🇭🇰 هنگ کنگ","🇧🇷 برزیل","🇵🇱 لهستان","🇵🇾 پاراگوئه","🇳🇱 هلند","🇱🇻 لیتوانی","🇲🇬 ماداگاسکار","🇨🇩 کنگو","🇳🇬 نیجریه","🇿🇦 آفریقا","🇵🇦 قبرس","🇪🇬 مصر","🇮🇳 هند","🇮🇪 ایرلند","🇨🇮 ساحل عاج","🇷🇸 صربستان","🇱🇦 لائوس","🇲🇦 مراکش","🇾🇪 یمن","🇬🇭 غنا","🇨🇦 کانادا","🇦🇷 آرژانتین","🇮🇶 عراق","🇩🇪 آلمان","🇨🇲 کامرون","🇹🇷 ترکیه","🇳🇿 نیوزیلند","🇦🇹 اتریش","🇨🇴 کلمبیا","🇻🇪 ونزوئلا","🇭🇹 هائیتی","🇺🇸 پاپوا","🇲🇩 مولداوی","🇲🇿 موزامبیک","🇬🇲 گامبیا","🇦🇫 اففانستان","🇺🇬 اوگاندا","🇦🇺 نپال","🇸🇦 عربستان","🇲🇽 مکزیک","🇪🇸 اسپانیا","🇩🇿 الجزائر","🇸🇮 اسلوونی","🇭🇷 کرواسی","🇧🇾 بلاروس","🇫🇮 بلژیک","🇸🇪 سوئد","🇬🇪 بلغارستان","🇪🇹 اتیوپی","🇿🇲 مجارستان","🇵🇰 پاکستان","🇹🇭 تایلند","🇹🇼 تایوان","🇵🇪 پرو","🇵🇬 تونس","🇹🇩 چاد","🇲🇱 مالی","🇧🇩 بنگلادش","🇬🇳 گینه","🇱🇰 سری‌لانکا","🇺🇿 ازبکستان","🇸🇳 سنگال"))) {
     
    $userservicc = $juser["service"];
     $str2 = str_replace(["tg", "ig", "wa", "go", "vi", "wb", "fb" , "tw" , "mb", "im", "tn", "me", "vk", "mm", "am" , "ot" ], ["💎 تلگرام", "📸 اینستاگرام", "📞 واتساپ", "🔍 گوگل", "💡 وایبر", "💬 ویچت", "📪 فیسبوک", "🐦 توییتر", "📨 یاهو","💭 ایمو", "♨️ لینک دین", "📬 ویکی", "📗 لاین", "💻 ماکروسافت", "🛒 آمازون", "🌐 دیگر سرویس ها"], $userservicc);
     
    $str3 = str_replace(["🇷🇺 روسیه","🇺🇦 اکراین","🇰🇿 قزاقستان","🇮🇷 ایران","🇨🇳 چین","🇵🇭 فیلیپین","🇲🇲 میانمار","🇮🇩 اندونزی","🇲🇾 مالزی","🇰🇪 کنیا","🇹🇿 اسرائیل","🇻🇳 ویتنام","🇬🇧 انگلستان","🇱🇻 لتونی","🇷🇴 رومانی","🇪🇪 استونی","🇺🇸 آمریکا","🇰🇬 قرقیزستان","🇫🇷 فرانسه","🇵🇸 انگولا","🇰🇭 کامبوج","🇲🇴 ماکائو","🇭🇰 هنگ کنگ","🇧🇷 برزیل","🇵🇱 لهستان","🇵🇾 پاراگوئه","🇳🇱 هلند","🇱🇻 لیتوانی","🇲🇬 ماداگاسکار","🇨🇩 کنگو","🇳🇬 نیجریه","🇿🇦 آفریقا","🇵🇦 قبرس","🇪🇬 مصر","🇮🇳 هند","🇮🇪 ایرلند","🇨🇮 ساحل عاج","🇷🇸 صربستان","🇱🇦 لائوس","🇲🇦 مراکش","🇾🇪 یمن","🇬🇭 غنا","🇨🇦 کانادا","🇦🇷 آرژانتین","🇮🇶 عراق","🇩🇪 آلمان","🇨🇲 کامرون","🇹🇷 ترکیه","🇳🇿 نیوزیلند","🇦🇹 اتریش","🇨🇴 کلمبیا","🇻🇪 ونزوئلا","🇭🇹 هائیتی","🇺🇸 پاپوا","🇲🇩 مولداوی","🇲🇿 موزامبیک","🇬🇲 گامبیا","🇦🇫 اففانستان","🇺🇬 اوگاندا","🇦🇺 نپال","🇸🇦 عربستان","🇲🇽 مکزیک","🇪🇸 اسپانیا","🇩🇿 الجزائر","🇸🇮 اسلوونی","🇭🇷 کرواسی","🇧🇾 بلاروس","🇫🇮 بلژیک","🇸🇪 سوئد","🇬🇪 بلغارستان","🇪🇹 اتیوپی","🇿🇲 مجارستان","🇵🇰 پاکستان","🇹🇭 تایلند","🇹🇼 تایوان","🇵🇪 پرو","🇵🇬 تونس","🇹🇩 چاد","🇲🇱 مالی","🇧🇩 بنگلادش","🇬🇳 گینه","🇱🇰 سری‌لانکا","🇺🇿 ازبکستان","🇸🇳 سنگال"], ["0","1","2","57","3","4","5","6","7","8","13","10","16","44","32","34","12","11","78","76","24","20","14","73","15","87","48","44","17","18","19","31","77","21","22","23","27","29","25","37","30","38","36","39","47","43","41","62","67","50","33","70","26","79","85","80","28","74","75","81","53","54","56","58","59","45","51","82","46","83","71","84","66","52","55","65","89","42","69","60","68","64","40","61"], $textmassage);
    
    
    $ros = json_decode(file_get_contents("https://sms-activate.ru/stubs/handler_api.php?api_key=$api_key&action=getPrices&country=$str3&service=$userservicc"),true);
    
    $zarib = $jsetingg["set"]["robelpric"];
$ros0 = $ros["$str3"]["$userservicc"]["cost"] * $zarib;
$cros00 = $ros["$str3"]["$userservicc"]["count"];


    $stock = $juser["stock"];
    
    if ($cros00 > 0 ){
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
        'text' => "
        💢 شما قصد خرید شماره مجازی با مشخصات زیر را دارید :
〰️〰️〰️〰️〰️〰️〰️
کشور : $textmassage
سرویس :  $str2
قیمت : $ros0 تومان
موجودی کیف پول شما : $stock تومان


✅  $cros00 عدد شماره برای  خرید موجود هستش الان 😍
〰️〰️〰️〰️〰️〰️〰️
آیا مایل به ادامه و خرید هستید ؟
.

        ",
                    'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "خیر منصرف شدم 👎"], ['text' => "بله میخوام 👍"]
                    ],
                    [
                        ['text' => "♻️انتخاب کشور دیگه"]
                    ]
                    
                ],
            'resize_keyboard' => true
        ])
        
    ]); 
     $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["namecontry"]="$textmassage";
$juser["price"]="$ros0";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

    }else {
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
        'text' => "
        💢 شما قصد خرید شماره مجازی با مشخصات زیر را دارید :
〰️〰️〰️〰️〰️〰️〰️
کشور : $textmassage
سرویس :  $str2
قیمت : $ros0 تومان
موجودی شما : $stock تومان
〰️〰️〰️〰️〰️〰️〰️
⚠️ کشور مورد نطر در حال حاظر موجود نمیباشد !
   
🌟 لطفا کشور دیگری را انتخاب کنید یا ساعاتی دیگر مجدد امتحان کنید
.
        ",
         'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "🔙 برگشت"], ['text' => "♻️انتخاب کشور دیگه"]
                    ]
                    
                ],
            'resize_keyboard' => true
        ])
         ]); 
    }
}
elseif ($textmassage == "بله میخوام 👍") {
    $stock = $juser["stock"];
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
لطفا نوع پرداخت رو انتخاب کنید :

💳 پرداخت آنلاین : متصل شدن به درگاه پرداخت ، پرداخت وجه به مقدار قیمت شماره.
💰 پرداخت از کیف پول : پرداخت وجه از کیف پول شما 

موجودی کیف پول طلایی شما : $stock تومان
",
             
                   'reply_markup' => json_encode([
                'keyboard' => [
                        [
                            ['text' => "💰 پرداخت از کیف پول"],
                            ['text' => "💳 پرداخت آنلاین "]
                        ],
                         [
                            ['text' => "🔙 برگشت"]
                        ]
                    ],
                    'resize_keyboard' => true
                ])
            ]);
    
}
elseif ($textmassage == "💳 پرداخت آنلاین") {
     if ($blaklist["id"] != true){
         if ($activesell == "1"){
     $pp = $juser["price"];
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
✅ لینک درگاه پرداخت شما ساخته شد.

مبلغ : $pp تومان
 
از طریق دکمه زیر پرداخت کنید 👇👇
",
              'reply_markup' => json_encode([
                'inline_keyboard' => [
                        [
                            ['text' => "💰 $pp تومان", 'url' => "$web/pay/pay.php?amount=$pp&callback=$web/pay/back-ss.php?user=$from_id"]
                        ],
                         [
                            ['text' => "❌ انصراف", 'callback_data' => "ex"]
                        ]
                    ],
                    'resize_keyboard' => true
                ]),
                
            ]);
         }else {
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️ فروش به صورت موقت توسط مدیر غیر فعال شده است.
لطفا بعدا دوباره امتحان کنید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
         }
    else { 
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📛 متاسفانه شما از استفاده از ربات محروم شده اید.

در صورتی که اشتباهی رخ داده با پشتیبانی در ارتباط باشید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
    
}
elseif ($data == "ex") {
   
     jijibot('deletemessage', [
            'chat_id' => $chatid,
                'message_id'=>$messageid,
            ]);
    
}
elseif ($textmassage == "💰 پرداخت از کیف پول") {
    
     $namecontry = $juser["namecontry"];
     $str = $juser["price"];
    $userservicc = $juser["service"];
 
    
    $stock = $juser["stock"];
     if ($blaklist["id"] != true){
         if ($activesell == "1" or $from_id == "$admin[0]"){
    if ($stock >= $str) {
       
        $countryy = str_replace(["🇷🇺 روسیه","🇺🇦 اکراین","🇰🇿 قزاقستان","🇮🇷 ایران","🇨🇳 چین","🇵🇭 فیلیپین","🇲🇲 میانمار","🇮🇩 اندونزی","🇲🇾 مالزی","🇰🇪 کنیا","🇹🇿 اسرائیل","🇻🇳 ویتنام","🇬🇧 انگلستان","🇱🇻 لتونی","🇷🇴 رومانی","🇪🇪 استونی","🇺🇸 آمریکا","🇰🇬 قرقیزستان","🇫🇷 فرانسه","🇵🇸 انگولا","🇰🇭 کامبوج","🇲🇴 ماکائو","🇭🇰 هنگ کنگ","🇧🇷 برزیل","🇵🇱 لهستان","🇵🇾 پاراگوئه","🇳🇱 هلند","🇱🇻 لیتوانی","🇲🇬 ماداگاسکار","🇨🇩 کنگو","🇳🇬 نیجریه","🇿🇦 آفریقا","🇵🇦 قبرس","🇪🇬 مصر","🇮🇳 هند","🇮🇪 ایرلند","🇨🇮 ساحل عاج","🇷🇸 صربستان","🇱🇦 لائوس","🇲🇦 مراکش","🇾🇪 یمن","🇬🇭 غنا","🇨🇦 کانادا","🇦🇷 آرژانتین","🇮🇶 عراق","🇩🇪 آلمان","🇨🇲 کامرون","🇹🇷 ترکیه","🇳🇿 نیوزیلند","🇦🇹 اتریش","🇨🇴 کلمبیا","🇻🇪 ونزوئلا","🇭🇹 هائیتی","🇺🇸 پاپوا","🇲🇩 مولداوی","🇲🇿 موزامبیک","🇬🇲 گامبیا","🇦🇫 اففانستان","🇺🇬 اوگاندا","🇦🇺 نپال","🇸🇦 عربستان","🇲🇽 مکزیک","🇪🇸 اسپانیا","🇩🇿 الجزائر","🇸🇮 اسلوونی","🇭🇷 کرواسی","🇧🇾 بلاروس","🇫🇮 بلژیک","🇸🇪 سوئد","🇬🇪 بلغارستان","🇪🇹 اتیوپی","🇿🇲 مجارستان","🇵🇰 پاکستان","🇹🇭 تایلند","🇹🇼 تایوان","🇵🇪 پرو","🇵🇬 تونس","🇹🇩 چاد","🇲🇱 مالی","🇧🇩 بنگلادش","🇬🇳 گینه","🇱🇰 سری‌لانکا","🇺🇿 ازبکستان","🇸🇳 سنگال"], ["0","1","2","57","3","4","5","6","7","8","13","10","16","44","32","34","12","11","78","76","24","20","14","73","15","87","48","44","17","18","19","31","77","21","22","23","27","29","25","37","30","38","36","39","47","43","41","62","67","50","33","70","26","79","85","80","28","74","75","81","53","54","56","58","59","45","51","82","46","83","71","84","66","52","55","65","89","42","69","60","68","64","40","61"], $namecontry);
        $userservic = $juser["service"];
         $userservicop = $juser["panel"];
      
               $userservic = $juser["service"];
        
        $get = file_get_contents("https://sms-activate.ru/stubs/handler_api.php?api_key=$api_key&action=getNumber&service=$userservic&country=$countryy");
        $alll = explode(":", $get);
             $ooknumber = "$alll[0]";
             $idnumber = "$alll[1]";
             $numberfon = "$alll[2]";
        $userservice = $juser["service"] ;
       
          $strservic = str_replace(["tg", "ig", "wa", "go", "vi", "wb", "fb" , "tw" , "mb", "im", "tn", "me", "vk", "mm", "am" , "ot" ], ["💎 تلگرام", "📸 اینستاگرام", "📞 واتساپ", "🔍 گوگل", "💡 وایبر", "💬 ویچت", "📪 فیسبوک", "🐦 توییتر", "📨 یاهو","💭 ایمو", "♨️ لینک دین", "📬 ویکی", "📗 لاین", "💻 ماکروسافت", "🛒 آمازون", "🌐 دیگر سرویس ها"], $userservice);
        if ($ooknumber == "ACCESS_NUMBER")
        {
              $plusstock = $juser["stock"] - $juser["price"];
           jijibot('sendmessage', [
            'chat_id' => $chat_id,
                'text' => "
 ✅	شماره کشور مورد نظر با موفقیت ساخته شد 		
📞 شماره مجازی شما :
🅿️ +$numberfon


 شماره را همراه با پیش شماره در سرویس $strservic وارد کنید و پس از 5 ثانیه روی دریافت کد ضربه بزنید !

.
",
             
                   'reply_markup' => json_encode([
                'keyboard' => [
                        [
                             ['text' => "❌ لغو شماره"], ['text' => "💬 دریافت کد"]
                        ],
                         [
                             ['text' => "⛔️ اعلام مسدودی شماره"],
                        ]
                    ],
                    'resize_keyboard' => true
                ])
            ]);
$juser = json_decode(file_get_contents("data/$from_id.json"),true); 
$juser["stock"]="$plusstock";
$juser["country"]="+$numberfon";
$juser["numberid"]="$idnumber";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

        } else {
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "⚠️ کشور مورد نطر در حال حاظر موجود نمیباشد !
			
🌟 لطفا کشور دیگری را انتخاب کنید یا ساعاتی دیگر مجدد امتحان کنید

",
'reply_markup' => json_encode([
                'keyboard' => [
                [
                    ['text' => "📲 خرید شماره مجازی"]
                ],
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "👤 اطلاعات حساب"]
                ],
                [
                     ['text' => "🛍 خرید های من"], ['text' => "💸 شارژ حساب"]
                    
                    ],
              
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
                'resize_keyboard' => true
            ])
            ]);
        }
            
        
    } else {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "💳 موجودی کیف پول شما برای خرید کافی نمیباشد !
			
💎 قیمت شماره مورد نظر : $str تومان
💰 موجودی کیف پول شما : $stock تومان

💳 برای افزایش موجودی کیف پول طلایی کافیست از دکمه شارژ حساب استفاده کنید سپس میتوانید نسبت به خرید اقدام کنید
ℹ

💳 پرداخت آنلاین : متصل شدن به درگاه پرداخت ، پرداخت وجه به مقدار قیمت شماره.
",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "💳 پرداخت آنلاین "]
                        ],
                    [
                       ['text' => "🔙 برگشت"], ['text' => "💸 شارژ حساب"] 
                       
                    ],
                   
                ],
                'resize_keyboard' => true
            ])
        ]);
}
}else {
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️ فروش به صورت موقت توسط مدیر غیر فعال شده است.
لطفا بعدا دوباره امتحان کنید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
}
else { 
             jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "📛 متاسفانه شما از استفاده از ربات محروم شده اید.

در صورتی که اشتباهی رخ داده با پشتیبانی در ارتباط باشید.",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🔙 برگشت"]
                ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        }
} elseif ($textmassage == "💬 دریافت کد") {
     
    $getfile = $juser["getfile"];
    $userservice = $juser["service"];
    $country = $juser["country"];
    $namecontry = $juser["namecontry"];
    $idnumber = $juser["numberid"];
    
     $get =  file_get_contents("https://sms-activate.ru/stubs/handler_api.php?api_key=$api_key&action=getStatus&id=$idnumber");
      $alll = explode(":", $get);
             $cros000 = "$alll[0]";
             $cod000 = "$alll[1]";
    
    if ($cros000 == "STATUS_OK") {
        $plusstock = $juser["stock"] - $juser["price"];
        $price = $juser["price"];
        $plusby = $juser["numberby"] + 1;
        $plusbyy = $jseting["allnum"] + 1;
        $plussell = $jseting["allsell"] + $juser["price"];
        $member = $juser["member"];
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "کد با موفقیت دریافت شد ✅
💭 کد ورود شما به برنامه : $cod000

ℹ️ گزارش خریدبه کانال ما @$channel ارسال شد 
🔆 درصورت وجود هرگونه مشکل کافیست با پشتیبانی در تماس باشید",
            'reply_markup' => json_encode([
                'keyboard' => [
                [
                    ['text' => "📲 خرید شماره مجازی"]
                ],
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "👤 اطلاعات حساب"]
                ],
                [
                     ['text' => "🛍 خرید های من"], ['text' => "💸 شارژ حساب"]
                    
                    ],
              
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
                'resize_keyboard' => true
            ])
        ]);
        
          $strservic = str_replace(["tg", "ig", "wa", "go", "vi", "wb", "fb" , "tw" , "mb", "im", "tn", "me", "vk", "mm", "am" , "ot" ], ["💎 تلگرام", "📸 اینستاگرام", "📞 واتساپ", "🔍 گوگل", "💡 وایبر", "💬 ویچت", "📪 فیسبوک", "🐦 توییتر", "📨 یاهو","💭 ایمو", "♨️ لینک دین", "📬 ویکی", "📗 لاین", "💻 ماکروسافت", "🛒 آمازون", "🌐 دیگر سرویس ها"], $userservice);
        $number = mb_substr("$country", "0", "10") . "***";
        $usidf = mb_substr("$from_id", "0", "6") . "***";
        jijibot('sendmessage', [
            'chat_id' => "@$channel",
            'text' => "
📱یک عدد شماره مجازی $namecontry خریداری شد!
⚜️اطلاعات شماره و خریدار 👇
➖➖➖➖➖➖➖➖
☎️ number : $number
➖➖➖➖➖➖➖➖
👤 user : $usidf
➖➖➖➖➖➖➖➖
📱 service : $strservic
➖➖➖➖➖➖➖➖

❗️روش خرید و دریافت شماره مجازی :
۱-وارد ربات @$usernamebot شوید.
۲-اعتبار خود را $price تومان افزایش دهید.
۳-سرویس $strservic را انخاب کنید.
۴-شماره مجازی  $namecontry دریافت کنید!
☝️شماره های مجازی ثبت نشده هستند و با متد های اتومات توسط کاربران ربات @$usernamebot نامبرینو به صورت کاملا خودکار دریافت و ثبت می شوند.
این پیام  خودکار با دریافت کد شماره مجازی توسط کاربر ربات نامبرینو  ارسال شده است.
***************
🤖 @$usernamebot
🔊@$channel
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "☎️ ربات خرید شماره مجازی", 'url' => "https://t.me/$usernamebot"],
                    ],
                ]
            ])
        ]);
         jijibot('sendmessage', [
            'chat_id' => "@$channelbc",
            'text' => "
📱یک عدد شماره مجازی $namecontry خریداری شد!
⚜️اطلاعات شماره و خریدار 👇
➖➖➖➖➖➖➖➖
☎️ number : $number
➖➖➖➖➖➖➖➖
👤 user : $usidf
➖➖➖➖➖➖➖➖
📱 service : $strservic
➖➖➖➖➖➖➖➖

❗️روش خرید و دریافت شماره مجازی :
۱-وارد ربات @$usernamebott شوید.
۲-اعتبار خود را $price تومان افزایش دهید.
۳-سرویس $strservic را انخاب کنید.
۴-شماره مجازی  $namecontry دریافت کنید!
☝️شماره های مجازی ثبت نشده هستند و با متد های اتومات توسط کاربران ربات @$usernamebott نامبرینو به صورت کاملا خودکار دریافت و ثبت می شوند.
این پیام  خودکار با دریافت کد شماره مجازی توسط کاربر ربات نامبرینو  ارسال شده است.
***************
🤖 @$usernamebott
🔊@$channelbc
            ",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "☎️ ربات خرید شماره مجازی", 'url' => "https://t.me/$usernamebott"],
                    ],
                ]
            ])
        ]);
      $dsa = $jsetingg["dsod"];
      $dsab = $adminsql["stock"];
      $bb = (($price / 100) * $dsa) + $dsab ;

      $nm =  $juser["listby"];
      $nu = "^$country ➡️ $price ➡️ $time_now | $dat_now";
      $allnn = $nm . $nu ;
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["listby"]="$allnn";
$juser["numberby"]="$plusby";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
 $jseting = json_decode(file_get_contents("data/seting.json"),true);  
$jseting["allnum"]="$plusbyy";
$jseting["allsell"]= "$plussell";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

$connect->query("UPDATE admin SET allsellprice = '$plussell', allnum = '$plusbyy', stock = '$bb' WHERE id = '$admin[0]' LIMIT 1");
    }
    elseif ($get == "STATUS_WAIT_CODE") {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⚠️ کد فعال سازی هنوز ارسال نشده است !

 لطفا دقت فرمایید شماره به همراه با پیش شماره و به صورت صحیح وارد کرده باشید و بعد از 30 ثانیه روی دریافت کد ضربه بزنید
🔆 درصورت وجود هرگونه مشکل کافیست با پشتیبانی در تماس باشید و در صورت دریافت نشدن کد موجودی از شما کسر نخواهد شد !
🗣 درصورت استفاده از دکمه پشتیبانی پروسه دریافت کد غیر فعال خواهد شد .
❗️ از ارسال پشت سر هم دریافت کد خودداری کنی",
             'reply_markup' => json_encode([
                'keyboard' => [
                        [
                            ['text' => "❌ لغو شماره"], ['text' => "💬 دریافت کد"],
                         [
                             ['text' => "⛔️ اعلام مسدودی شماره"],
                        ]
                        ]
                    ],
                    'resize_keyboard' => true
                ])
        ]);
    }
    
    
}


elseif ($textmassage == "👤 اطلاعات حساب") {
    
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        $stock = $juser["stock"];
        $numberby = $juser["numberby"];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🎫 حساب کاربری شما در ربات خرید شماره مجازی :

🗣 نام : $first_name
👾 شناسه : $from_id
🥇 موجودی کیف پول : $stock تومان
🏵 تعداد خرید : $numberby

", ]);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
}  elseif ($textmassage == "💸 شارژ حساب") {
     
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "💵 لینک‌های پرداخت مخصوص شما ساخته شد.

📍 برای افزایش موجودی حساب خود بر روی هر یک از مبالغ دلخواه کلیک کرده و پس از منتقل شدن به درگاه امن بانک، آن را پرداخت کنید.
🔆 تمامی پرداخت ها به صورت اتوماتیک بوده و پس از تراکنش موفق مبلغ آن به موجودی حساب شما در ربات افزوده خواهد شد.
⚠️ دقت کنید که پس از تراکنش در صفحه پرداخت بر روی تایید پرداخت کلیک کنید تا تراکنش تکمیل شود.
🗣 مبلغ مورد نظر شما در لیست نیست ! با پشتیبانی تماس بگیرید !",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "💰 1000 تومان", 'url' => "$web/pay/pay.php?amount=1000&callback=$web/pay/back-1000.php?user=$from_id"], ['text' => "💰 2000 تومان", 'url' => "$web/pay/pay.php?amount=2000&callback=$web/pay/back-2000.php?user=$from_id"]
                    ],
                    [
                        ['text' => "💰 3000 تومان", 'url' => "$web/pay/pay.php?amount=3000&callback=$web/pay/back-3000.php?user=$from_id"], ['text' => "💰 5000 تومان", 'url' => "$web/pay/pay.php?amount=5000&callback=$web/pay/back-5000.php?user=$from_id"]
                    ],
                    [
                        ['text' => "💰 10000 تومان", 'url' => "$web/pay/pay.php?amount=10000&callback=$web/pay/back-10000.php?user=$from_id"], ['text' => "💰 20000 تومان", 'url' => "$web/pay/pay.php?amount=20000&callback=$web/pay/back-20000.php?user=$from_id"]
                    ],
                ]
            ])
        ]);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
}  elseif ($textmassage == "👮🏻 پشتیبانی") {
     
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "👮🏻 همکاران ما در خدمت شما هستن !
	
🔘 در صورت وجود نظر , ایده , گزارش مشکل , پیشنهاد , ایراد سوال , یا انتقاد میتوانید با ما در ارتباط باشید 
💬 لطفا پیام خود را به صورت فارسی و روان ارسال کنید",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
        
         $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="sup";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
} elseif ($textmassage == "🚦 راهنما") {
    
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$from_id"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🚸 به بخش راهنما خوش امدید

🤗 شما با استفاده از این ربات هوشمند شماره مجازی کشور ها مختلف را به صورت ارزان خریدار می کنید.
♋️ تمام روند خرید و دریافت شماره و ثبت نام در برنامه مورد نظر کاملا اتوماتیک انجام می شود.
📴 با کم ترین هزینه ممکن در سریع ترین زمان و امن ترین حالت ممکن شماره مجازی خود را خریداری نمایید.
⚠️ در صورت بروز هرگونه مشکل با کلید بر روی دکمه پشتیبانی در منو اصلی با ما ارتباط برقرار نمایید.

🔽 از منو زیر جهت راهنمایی استفاده کنید 🔽",
            'reply_markup' => json_encode([
                'keyboard' => [
                    
                    [
                        ['text' => "📲 شماره مجازی چیست؟"], ['text' => "🔔 سوالات متداول"]
                    ],
                    [
                        ['text' => "💎 کسب درآمد"], ['text' => "📽 اموزش خرید"]
                    ],
                    [
                        ['text' => "ℹ️ قوانین"], ['text' => "💡 درباره"]
                    ],
                    [
                        ['text' => "🔙 برگشت"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
    } else {
        jijibot('sendmessage', [
            "chat_id" => $chat_id,
            "text" => "🔘 برای استفاده از ربات فروش شماره مجازی ابتدا باید وارد کانال زیر شوید
		
@$channel 📣 @$channel 📣
@$channel 📣 @$channel 📣

🌟 بعد از عضویت بر روی دکمه عضو شدم ضربه بزنید",
            'reply_markup' => json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => "📍 عضویت در کانال", 'url' => "https://t.me/$channel"]
                    ],
                    [
                        ['text' => "📢 عضو شدم", 'callback_data' => 'join']
                    ],
                ]
            ])
        ]);
    }
} elseif ($textmassage == "📲 شماره مجازی چیست؟") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "📱شماره مجازی چیست؟

📍هنگام ثبت‌نام در اپلیکیشن‌های پیام ‌رسان و شبکه‌های اجتماعی موبایل، باید از شماره تلفن خود به عنوان شناسه استفاده کنید. اگر از کاربرانی هستید که علاقه‌ای به اشتراک‌گذاری شماره‌ی اصلی خود ندارید یا اینکه نیاز به ثبت‌نام بیش از یک بار در این برنامه‌ها دارید، می‌توانید از شماره‌های مجازی استفاده کنید. همچنین شماره مجازی این امکان را می‌دهد که بدون ثبت سیم کارت و اهراز هویت و بدون صرف وقت و هزینه صاحب شماره از کشور های مختلف شوید.

ℹ️مزایا و کاربرد شماره مجازی چیست؟

➊ تلگرام، واتس اپ، وایبر، اینستاگرام  و... برای ثبت‌نام به شماره تلفن شما نیاز دارند تا کدفعال‌سازی مربوطه را برای تشخیص هویت به تلفن‌تان ارسال کنند که به جای شماره اصلی خود میتوان از شماره مجازی برای فعال کردن حساب خود استفاده کرد.

➋ بسیاری از افراد به دلایل مختلف مانند مدیریت یک اکانت دیگر برای مباحث کاری یا... نیاز به اکانت دوم دارند تا بتوانند در عین ارتباط داشتن با مشتریان، از تلگرام شخصی و خصوصی خود نیز استفاده کنند.
 
➌ بدون ثبت نام در اپراتور و بدون صرف وقت و هزینه و اهراز هویت صاحب شماره مجازی می شوید .

➍ استفاده در تمامی اپلیکیشن های اجتماعی با شماره از کشورهای مختلف! همراه با هویتی ناشناس

🤖 @$usernamebot",
    ]);
} 

elseif ($textmassage == "🔔 سوالات متداول") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "❓سوالات متداول

❓شماره خریدم کد نمیده چیکار کنم؟
▫️جواب : ابتدا فیلم آموزش نحوه خرید را مشاهده کنید. جهت دریافت کد پس از اطمینان از ارسال کد توسط اپلیکیشن درخواستی به شماره مورد نظر 30 ثانیه صبر کنید و سپس بر روی دکمه دریافت کد کلیک کنید ، اگر پس از گذشت 5 دقیقه از دریافت شماره، کد را دریافت نکردید بر روی دکمه بازگشت کلیک کنید سپس مجددا نسبت به دریافت شماره جدید و کد اقدام نمایید.

❓شماره رو وارد آپ کردم میگه شماره اشتباهه(مسدوده) و پیام Banned Number میدهد چکار کنم؟
▫️جواب : این حالت بیشتر برای شماره چین ، روسیه و آمریکا پیش میاد. بر روی دکمه بازگشت کلیک کنید سپس مجددا نسبت به دریافت شماره جدید و کد اقدام نمایید.

❓کد تایید گرفتم اما وارد آپ نکردم، باید چیکار کنم؟
▫️جواب : متاسفانه امکان بازگشت وجه در چنین وضعیتی وجود ندارد. چون پول شماره در پنل خارجی همزمان با دریافت کد از حساب ما کم میشود‌.

❓شماره از ربات خریدم اما بعد از چند دقیقه شماره دلیت اکانت شد علت چیه؟
▫️جواب : علت دلیت اکانت شدن شماره‌ حساس شدن تلگرام نسبت به ip شماست.
از آنجایی که تلگرام مخالف با عضو فیک است نباید بیش از 3 شماره مجازی بر روی یک ip ثبت نام کنید.
اگر قصد دارید تعداد بالا شماره مجازی خریداری و ثبت نام کنید، باید آی پی خود را پس از ثبت هر شماره تغییر دهید.
برای تغییر ip دو راه وجود دارد :
1- استفاده از فیلترشکن
2- خاموش و روشن کردن مودم ، یا خاموش و روشن کردن دیتا در تلفن همراه برای چند دقیقه موجب تغییر آی پی شما خواهد شد.

❓شماره‌ای که برای تلگرام خریدم بعد از دریافت کد یه نفر دیگه داخل اکانت بود یا two-step verification روی اکانت فعال بود، و نتوستم وارد اکانت بشم ، الان چکار کنم؟
▫️جواب : با توجه به اینکه شماره ها مستقیما از پنل های خارجی دریافت می شوند و ربات استوری نامبر تنها واسط بین کاربر و پنل است امکان بررسی شماره ها توسط ما امکان پذیر نیست! به همین علت گاها ممکن است بعد از دریافت کد اکانتی از قبل توسط شماره مورد نظر در اپلیکیشن مورد نظرتان خصوصا تلگرام فعال باشد؛ تنها راه حل برای جلوگیری از بروز این مشکل، چک کردن شماره مجازی قبل از دریافت کد است، بررسی این که شماره مجازی در اپلیکیشن مورد نظرتان قبلا ثبت شده است یا خیر به راحتی امکان پذیر است، برای تلگرام اگر شماره ثبت شده باشد بلافاصله با وارد کردن شماره در تلگرام پیغام ارسال کد به تلگرام فعال دیگر نمایش داده می شود و مانند شماره های ریجستر نشده نیست و این مورد به راحتی برای تلگرام و دیگر اپلیکیشن ها قابل بررسی است؛ در هر صورت اگر شماره ای دریافت کردید که از قبل ثبت شده بود (به ندرت پیش می آید) هرگونه عواقب آن بر عهده خریدار خواهد بود و استوری نامبر هیچ گونه مسئولیتی در رابطه با بی دقتی کاربران را برعهده نمی گیرد.

💎 سوالاتان در این بخش نبود ؟ به منوی اصلی برگردید و با پشتیبانی در تماس باشید 

🤖 @$usernamebot",
    ]);
} elseif ($textmassage == "💎 کسب درآمد") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "🔰 راهنمای کسب درآمد


🤖 @sellnumbersbot",
    ]);
} elseif ($textmassage == "ℹ️ قوانین") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "⚠️ قوانین ربات خرید شماره مجازی

➊ - پس از تحویل شماره توسط ربات بلافاصله شماره را در نرم افزار اصلی وارد کنید و بعد از 2 دقیقه کلید دریافت کد را بزنید تا کد وریفای برایتان ارسال گردد. در صورتی که پس از 5 دقیقه بعد از دریافت شماره موفق به دریافت کد نشدید دکمه بازگشت را بزنید و شماره جدید دریافت کنید.
➋ - برای هر شماره فقط یکبار کد فعالسازی از سمت اپراتور کشور ارائه دهنده ارسال میشود و مجدد کد ارسال نمیشود لذا پس از دریافت کد سریعا در نرم افزار بزنید تا کد منقضی نشود.
➌ - بر روی شماره‌های دریافتی تایید دو مرحله‌ای فعال کنید تا امنیت شماره برای شما صد در صد شود.
➍ - اغلب شماره‌های مجازی (به جز شماره‌های ستاره‌دار) دارای ۴ تا ۷ روز محدودیت هستند، پس از ۴ تا ۷ روز شما قادر به ارسال پیام به اکانت‌های ایرانی در تلگرام هستید.
➎- ساخت ربات تبچی با هر شماره‌ای اشتباه است زیرا که سیاست تلگرام این است که از تبلیغات جلوگیری کند و اگر روی شماره ها تبچی نصب کنید شماره دلیت خواهد شد.
➏ - توصیه میشود در یک روز بیش از 1 شماره مجازی روی یک دستگاه ثبت نام نکنید چون موجب دلیت شدن اکانت میشود.
➐ - تمامی شماره‌های ربات خام هستند یعنی قبل از شما ثبت نام نکرده‌اند ، به جز برخی شماره‌های کشور چین و آمریکا که برای جلوگیری از این شماره را توی تلگرام چک کنید و سپس اقدام به گرفتن کد کنید.
➑ - هنگام ثبت شماره برای اپلیکیشن تلگرام ابتدا فیلترشکن را روشن کنید سپس اقدام به دریافت شماره کنید، موقع ثبت اسم به زبان آن کشور اسم وارد کنید(نمونه اسم روسیه: привет و چین: 你好) یا از اعداد انگلیسی (...123) استفاده کنید. پس از وارد شدن به اکانت، عکس پروفایل و یوزرنیم بزارید و کانال و گروه ایجاد کنید و پست ارسال کنید و اینکه حداقل 5 دقیقه داخل اکانت باشید و فعالیت کنید و خارج نشوید.
➒ - با توجه به اینکه تلگرام مخالف عضو فیک هست لذا استوری نامبر هیچ مسئولیتی در قبال دلیت شدن اکانت (Delete account) یا لاگ اوت (Log out) شدن اکانت ندارد. همچنین پس از تحویل کد، ربات دیگر هیچ مسئولیتی در مورد شماره ندارد.
➓ - در صورت عمل نکردن به بندهای بالا عواقب آن بر عهده شماست و وجهی بازگشت داده نمی‌شود.

🤖 @$usernamebot",
    ]);
} elseif ($textmassage == "💡 درباره") {
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "ℹ️ درباره ربات  :

🤖 ربات شماره مجازی برنامه نویسی شده توسط حسین ویکی
🔘 تمام حقوق و متون پیام ها و سورس کد ربات محفوظ است و هر نوع کپی بر داری پیگرد قانونی دارد

🎈 برنامه نویسی شده جهت خرید شماره مجازی به صورت خودکار و سهولت در خرید شماره مجازی مطمعن و اسان

🤖 @sellnumbersbot",
    ]);
}
//===========================================================
elseif ($textmassage == '🤖 ربات شماره مجازی شما [ربات نمایندگی]') {
    
       
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
اگه شما هم یه ربات شماره مجازی مثل همین میخواید خیلی سادست . 😇
راهی ساده و مطمِئن برای کسب درآمد.
به ربات زیر مراجعه کرده و از دکمه ربات نمایندگی استفاده کنید :
🆔 @sellnumbersbot
            ",
             
        ]);
    
}
//===========================================================================================
//panel admin
elseif ($textmassage == "/panel" or $textmassage == "پنل") {
    if ($tc == "private") {
        if (in_array($from_id, $admin)) {
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "🚦 ادمین عزیز به پنل مدریت ربات خوش امدید",
                'reply_markup' => json_encode([
                    'keyboard' => [
                        [
                            ['text' => "📍 امار ربات"], ['text' => "📢 تنظیم کانال ربات"]
                        ],
                        [
                            ['text' => "📍 ارسال به همه"], ['text' => "📍 فروارد همگانی"]
                        ],
                        [
                            ['text' => "📨 ارسال پیام به کاربر"]
                        ],
                       
                        [
                            ['text' => "⛔️ توقف فروش"],  ['text' => "❎ شروع فروش"]
                        ],
                        [
                            ['text' => "خروج از پنل"]
                        ],
                    ],
                    'resize_keyboard' => true
                ])
            ]);
        }
    }
} elseif ($textmassage == "برگشت 🔙") {
    
        if (in_array($from_id, $admin)) {
            jijibot('sendmessage', [
                'chat_id' => $chat_id,
                'text' => "🚦 به منوی مدیریت بازگشتید",
                'reply_markup' => json_encode([
                    'keyboard' => [
                        [
                            ['text' => "📍 امار ربات"], ['text' => "📢 تنظیم کانال ربات"]
                        ],
                        [
                            ['text' => "📍 ارسال به همه"], ['text' => "📍 فروارد همگانی"]
                        ],
                        [
                            ['text' => "📨 ارسال پیام به کاربر"]
                        ],
                       
                        [
                            ['text' => "⛔️ توقف فروش"],  ['text' => "❎ شروع فروش"]
                        ],
                        [
                            ['text' => "خروج از پنل"]
                        ],
                    ],
                    'resize_keyboard' => true
                ])
            ]);
            
            $juser = json_decode(file_get_contents("data/$from_id.json"),true);
$juser["step"]="none";
$juser["getfile"]="0";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
        }
    
} elseif ($textmassage == "📍 امار ربات") {
    if (in_array($from_id, $admin)) {
       
        $dsa = $jsetingg["dsod"];
        $files = scandir("data/");
       $alluser = count($files) - 4;
       $aa = $jseting["allnum"];
      
      $bb = $adminsql["stock"];
       $allsellp = $jseting["allsell"];
       $mogodi = $adminsql["stock"];
       $dsaa = $jsetingg["dsod"];
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🤖 امار ربات شما : 
		
📌 تعداد کل عضو ها : $alluser
📌 تعداد کل شماره های فروخته شده : $aa
📌 مجموع فروش شما : $allsellp تومان
📌 مجموع سود شما از فروش شماره ها در نامبرینو : $bb تومان
📌 موجودی فروش شما در نامبرینو : $mogodi تومان

سود دریافتی از هر فروش : $dsaa تومان
",
        ]);
    }
}  elseif ($textmassage == '📍 ارسال به همه') {
    if (in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا متن یا رسانه خود را ارسال کنید [میتواند شامل عکس , گیف یا فایل باشد]  همچنین میتوانید رسانه را همراه با کشپن [متن چسپیده به رسانه ارسال کنید] 🚀",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
      $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="sendtoall";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }
} elseif ($textmassage == '📍 فروارد همگانی') {
    if (in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا متن خود را فوروارد کنید  🚀",
            'reply_markup' => json_encode([
                'keyboard' => [
                    [
                        ['text' => "برگشت 🔙"]
                    ]
                ],
                'resize_keyboard' => true
            ])
        ]);
       
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="fortoall";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }
}



elseif ($textmassage == '⛔️ توقف فروش') {
    if (in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "⛔️ فروش شماره متوقف شد .",
            
        ]);
        
$jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["active"]="0";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

    }
}

elseif ($textmassage == '❎ شروع فروش') {
    if (in_array($from_id, $admin)) {
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "✅ فروش شماره فعال شد .",
            
        ]);
       
$jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["active"]="1";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

    }
}


elseif ($textmassage == '📨 ارسال پیام به کاربر') {
    if (in_array($from_id, $admin)) {
       
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "لطفا پیام رو با فرمت زیر ارسال کنید :

آیدی عددی کاربر : پیام
            
            ",
             
        ]);
       
 $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="sendidp";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

    }
}
elseif ($juser["step"] == "sendidp" && $tc == "private" and in_array($from_id, $admin)) {
    
   $alll = explode(":", $textmassage);
             $idd = "$alll[0]";
             $payam = "$alll[1]";
jijibot('sendmessage', [
            'chat_id' => $idd,
            'text' => "📩 یک پیام از سوی پشتیبانی برای شما دریافت شد : 
$payam",
        ]);
     jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
            ✅ پیام شما با موفقیت به کاربر  ارسال شد.
            [$idd](tg://user?id=$idd) 
            ",
            'parse_mode' => 'Markdown',
        ]);
         $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

}
//=====================================================================
elseif ($data == "join") {
    $tch = jijibot('getChatMember', ['chat_id' => "@$channel", 'user_id' => "$fromid"])->result->status;
    if ($tch == 'member' or $tch == 'creator' or $tch == 'administrator') {
        jijibot('sendmessage', [
            'chat_id' => $chatid,
            'text' => "عضویت شما تایید شد ✅
	
📍 اکنون میتوانید از دکمه های زیر استفاده کنید",
            'reply_markup' => json_encode([
                'keyboard' => [
                [
                    ['text' => "📲 خرید شماره مجازی"]
                ],
                [
                    ['text' => "💳 استعلام | قیمت ها"], ['text' => "👤 اطلاعات حساب"]
                ],
                [
                     ['text' => "🛍 خرید های من"], ['text' => "💸 شارژ حساب"]
                    
                    ],
              
                [
                    ['text' => "👮🏻 پشتیبانی"],['text' => "🚦 راهنما"]
                ]
            ],
                'resize_keyboard' => true
            ])
        ]);
    } else {
        jijibot('answercallbackquery', [
            'callback_query_id' => $membercall,
            'text' => "❌ هنوز داخل کانال @$channel عضو نیستید",
            'show_alert' => true
        ]);
    }
}  elseif ($textmassage == "🛍 خرید های من") {
    $listby = $juser["listby"];
    $getby = explode("^", $listby);
    if (count($getby) > 1) {
        for ($z = 1; $z <= count($getby) - 1; $z++) {
            $result = $result . "$z - $getby[$z]" . "\n";
        }
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "🛍 لیست تمام خرید های شما :
	
$result",
        ]);
    } else {
        jijibot('sendmessage', [
             'chat_id' => $chat_id,
            'text' => "❌ شما تاکنون خرید نکرده اید",
            
        ]);
    }
}
//==================================================
elseif ($user["step"] == "sup" && $tc == "private") {
    
    jijibot('ForwardMessage', [
        'chat_id' => $admin[0] ,
        'from_chat_id' => $chat_id,
        'message_id' => $message_id
    ]);
     jijibot('ForwardMessage', [
        'chat_id' => $admin[1] ,
        'from_chat_id' => $chat_id,
        'message_id' => $message_id
    ]);
    jijibot('sendmessage', [
        'chat_id' => $chat_id,
        'text' => "📍 پیام شما با موفقیت ارسال شد منتظر پاسخ پشتیبانی باشید",
    ]);
   
} 


elseif ($juser["step"] == "sendtoall" && $tc == "private") {
    
    if ($textmassage != "برگشت 🔙") {
        set_time_limit(600);
        jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "در حال ارسال پیام...",
        ]);
       
         $directory_handle2 = opendir("data/");
while($directory_item = readdir($directory_handle2)) {
 $uss = str_replace(".php","",$directory_item);
 jijibot('sendmessage', [
            'chat_id' => $uss,
            'text' => "$textmassage",
        ]);
        
}
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "پیام با موفقیت به همه ارسال شد",
        ]);
        
       
       
    }
} elseif ($juser["step"] == "fortoall" && $tc == "private") {
     set_time_limit(600);
    if ($textmassage != "برگشت 🔙") {
       
       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "در حال ارسال پیام...",
        ]);
          $directory_handle2 = opendir("data/");
while($directory_item = readdir($directory_handle2)) {
 $uss = str_replace(".php","",$directory_item);
 jijibot('ForwardMessage', [
        'chat_id' => $uss ,
        'from_chat_id' => $chat_id,
        'message_id' => $message_id
        ]);
        
}
         jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "پیام با موفقیت به همه فوروارد شد",
        ]);
        
       
       
    }
}
elseif ($textmassage == "📢 تنظیم کانال ربات" && in_array($from_id, $admin)) {

    
        
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="setch";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);

       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' => "
💢 لطفا آیدی کانال ربات را بدون @ ارسال کنید :

برای مثال :
sellnumberss
〰️〰️〰️〰️〰️〰️〰️〰️
❗️ عضویت کاربران ربات در این کانال اجباری خواهد بود.
❗️ گزارش های فروش به این کانال ارسال خواهد شد.
⚠️ دقیت کنید که #حتما این ربات در کانال مد نظر، #مدیر باشد.

.     
            ",
        ]);
    
}
elseif ($juser["step"] == "setch" ) {

    if ($textmassage != "برگشت 🔙") {
        
        $jseting = json_decode(file_get_contents("data/seting.json"),true);	
$jseting["set"]["channel"]="$textmassage";
$jseting = json_encode($jseting,true);
file_put_contents("data/seting.json",$jseting);

       jijibot('sendmessage', [
            'chat_id' => $chat_id,
            'text' =>"
✅ کانال ربات با موفقیت تنظیم شد.

آیدی کانال ربات :
🆔 @$textmassage

.
            " ,
        ]);
        $juser = json_decode(file_get_contents("data/$from_id.json"),true);  
$juser["step"]="none";
$juser = json_encode($juser,true);
file_put_contents("data/$from_id.json",$juser);
    }
}

//===========================================================

elseif ($update->message && $update->message->reply_to_message &&( $from_id == $admin[0] or $from_id == $admin[1]) && $tc == "private" and $textmassage != "بلاک") {
    
    jijibot('sendmessage', [
        "chat_id" => $chat_id,
        "text" => "پاسخ شما برای فرد ارسال شد ☑️"
    ]);
    jijibot('sendmessage', [
        "chat_id" => $update->message->reply_to_message->forward_from->id,
        "text" => "👮🏻پاسخ پشتیبان برای شما :

`$textmassage`",
        'parse_mode' => 'MarkDown'
    ]);
}

?>