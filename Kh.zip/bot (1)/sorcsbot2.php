<?php


include "jdf.php";
ob_start();
define('API_KEY', '[*BOTTOKEN*]'); // توکن
//-----------------------------------------------------------------------------------------
//فانکشن jijibot :

function jijibot($method, $datas = []) {
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}

//-----------------------------------------------------------------------------------------
//متغیر ها :
$admin = array("[*ADMIN*]", "00000000", "00000000"); // ایدی ادمین ها را ماننده این الگورتیم بگذارید ادمین اصلی ایدی اول است
$usernamebot = "[*usernamebot*]"; // یوزرنیم ربات
$channel = " "; // یوزرنیم کانال
$usernamepanelgetsms = "hosenbaner@gmail.com"; // یوزرنیم پنل get sms را وارد کنید
$api_key = "f948A05Af7cAeAb3e2Ae6d87c18c699f"; // توکن پنل get sms را وارد کنید
$web = "[*ADRESSBOT*]"; // ادرس ربات شماره مجازی
$channelbc = "numbersino"; // کانال نقل و انتقالات
$usernamebott = "numberinobot";
//-----------------------------------------------------------------------------------------------
// database 
// اطلاعات دیتا بیس را وارد کنید
include "../../config.php";
//----------------------------------------------------------------------------

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$tc = $message->chat->type;
$textmassage = $message->text;
$messageid = $update->callback_query->message->message_id;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->from->id;
$firstname = $update->callback_query->from->first_name;
$data = $update->callback_query->data;

$membercall = $update->callback_query->id;
$re_id = $update->message->reply_to_message->forward_from->id;
//=====================================================================================
// get 
$adminn = $admin[0];
$blaklist = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM blaklist WHERE id = '$from_id' LIMIT 1"));
$adminsql = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE id = '$adminn' LIMIT 1"));
$adminsqluser = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM admin WHERE id = '$from_id' LIMIT 1"));
$userservict = $usert["service"];
//==============================================================================
$juser = json_decode(file_get_contents("data/$from_id.json"),true);
$jusert = json_decode(file_get_contents("data/$fromid.json"),true);
$jseting = json_decode(file_get_contents("data/seting.json"),true);
$jsetingo = json_decode(file_get_contents("../../data/seting.json"),true);

//============================================================================
$activesell = $jseting["set"]["active"];
$porsant = $jseting["set"]["porsant"];

//=======================================
$dat_mah = jdate('F'); // اسم ماه
$dat_day = jdate('d'); // روز برج
$dat_haf = jdate('l'); // روز هفته
$dat_mahn = jdate('m'); // شماره ماه
$dat_min = jdate('i'); // دقیقه
$dat_s = jdate('s'); // ثانیه 
$dat_yer = jdate('Y'); // سال
$dat_h = jdate('G'); // ساعت
$dat_now = "$dat_yer/$dat_mahn/$dat_day" ;
$time_now = " $dat_h : $dat_min  ";
$dat_fa = "$dat_haf $dat_day $dat_mah  $dat_yer" ;
//===================================
include "../../estelam2.php";

$channel = $jseting["set"]["channel"]; // یوزرنیم کانال
//====================================
include "../../soor.php";
//====================================
?>