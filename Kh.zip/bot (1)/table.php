<?php

include "bottpodkrtirtoy.php";
// table creator
$connect->query("CREATE TABLE user (
    id bigint(20) PRIMARY KEY,
	step varchar(200) NOT NULL,
	stock varchar(200) NOT NULL,
	member varchar(200) NOT NULL,
	listby varchar(1800) NOT NULL,
	inviter varchar(200) NOT NULL,
	service varchar(200) NOT NULL,
	country varchar(200) NOT NULL,
	namecontry varchar(200) NOT NULL,
	getfile varchar(200) NOT NULL,
	price varchar(200) NOT NULL,
	numberby varchar(200) NOT NULL,
	panel varchar(200) NOT NULL,
	numberid varchar(200) NOT NULL
  )");
  $connect->query("CREATE TABLE blaklist (
    id bigint(20) PRIMARY KEY,
	bicuse varchar(200) NOT NULL
  )");
 
  $connect->query("CREATE TABLE admin (
    id bigint(20) PRIMARY KEY,
	userbot varchar(200) NOT NULL,
	allsellprice varchar(200) NOT NULL,
	allnum varchar(200) NOT NULL,
	dsod varchar(1800) NOT NULL,
	stock varchar(200) NOT NULL,
	token varchar(8000) NOT NULL
  )");
  $connect->query("CREATE TABLE coduser (
    id bigint(20) PRIMARY KEY,
    number varchar(200) NOT NULL,
	date varchar(200) NOT NULL,
	time varchar(200) NOT NULL
	

  )");
   $connect->query("CREATE TABLE coduserbot (
    id bigint(20) PRIMARY KEY,
    idnumber varchar(200) NOT NULL,
	number varchar(200) NOT NULL,
	date varchar(200) NOT NULL,
    time varchar(200) NOT NULL,
	idbot varchar(200) NOT NULL

  )");
  $connect->query("CREATE TABLE numbers (
    numberid bigint(20) PRIMARY KEY,
	id varchar(200) NOT NULL,
	idbot varchar(200) NOT NULL,
	timout varchar(200) NOT NULL

  )");
  $connect->query("CREATE TABLE ordersm (
    id bigint(20) PRIMARY KEY,
	iduser varchar(200) NOT NULL,
	idbot varchar(200) NOT NULL,
	sodbot varchar(200) NOT NULL,
	statos varchar(200) NOT NULL,
	service varchar(200) NOT NULL,
	member varchar(200) NOT NULL,
	member0 varchar(200) NOT NULL,
	price varchar(200) NOT NULL,
	date varchar(200) NOT NULL,
	link varchar(200) NOT NULL
  )");
?>