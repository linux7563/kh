<?php

$servername = "localhost";
$username = "000"; // یوزر دیتابیس
$password = "000"; // پسورد دیتابیس
$dbname = "000"; // نام دیتابیس
$connect = mysqli_connect($servername, $username, $password, $dbname);
// table creator

  
$connect->query("CREATE TABLE apikeys (
    id bigint(20) PRIMARY KEY,
	iduser varchar(200) NOT NULL,
	stock varchar(200) NOT NULL,
	orders varchar(200) NOT NULL,
	pricorders varchar(200) NOT NULL
  )");
  
  
?>